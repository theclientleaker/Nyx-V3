#pragma once
#include <Core/BaseModule.hpp>
#include <string>
#include <vector>
#include <cstdint>

namespace UNIx {

    class SafetyModule : public BaseModule {
    public:
        SafetyModule()
            : BaseModule("Antis", "Anti-crash protection", 0, "Safety") {
            m_showInQuickMenu = false;
            m_enabled = true;
        }

        void OnUpdate() override;
        void OnDisable() override;
        void OnSetupQuickMenu(uint32_t moduleId, uint32_t categoryPageId) override;

    private:
        struct ProtectionHook {
            std::string name;
            std::string className;
            std::string methodName;
            int paramCount = 0;
            uint32_t hookId = 0;
            bool active = false;
            bool enabled = false;
        };

        void InstallHook(size_t index);
        void RemoveHook(size_t index);

        std::vector<ProtectionHook> m_hooks;
        bool m_initialized = false;

        static SafetyModule* s_instance;
        static void __cdecl QmToggleCallback(uint32_t buttonId, bool isOn);
        std::vector<uint32_t> m_toggleIds;

        static bool PrefixBlockEvent67(void* thisPtr, void* eventData);
        static bool PrefixLimitParticle(void* thisPtr);
        static bool PrefixLimitLight(void* thisPtr);
        static bool PrefixLimitCloth(void* thisPtr);
        static bool PrefixLimitMaterial(void* thisPtr, void* material);
        static bool PrefixValidateRenderer(void* thisPtr);
        static bool PrefixBlockShader(void* name, void*& __retval);
        static bool PrefixGuardDynBone(void* thisPtr);
        static bool PrefixLimitDynBoneCollider(void* thisPtr);
        static bool PrefixBlockPatreon(void* thisPtr);
        static bool PrefixAntiBlock(void* thisPtr, void* eventData);
        static bool PrefixAntiPortal(void* thisPtr);
        static bool PrefixAntiUdon(void* thisPtr, void* target, void* eventName);
        static bool PrefixAntiVideoURL(void* thisPtr, void* url);
        static bool PrefixAntiMeshCrashSMR(void* thisPtr, bool enabling);
        static bool PrefixAntiMeshCrashMR(void* thisPtr, bool enabling);
    };

} // namespace UNIx
