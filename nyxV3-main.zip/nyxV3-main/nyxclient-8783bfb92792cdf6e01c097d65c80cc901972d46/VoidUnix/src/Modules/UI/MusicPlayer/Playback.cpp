#include <Modules/UI/MusicPlayer/Playback.hpp>
#include <Core/FileLog/FileLog.hpp>

#pragma comment(lib, "runtimeobject.lib")

#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.Foundation.Collections.h>
#include <winrt/Windows.Media.Control.h>
#include <winrt/Windows.Storage.Streams.h>
#include <filesystem>
#include <fstream>

namespace UNIx {

    using namespace winrt;
    using namespace Windows::Media::Control;
    using namespace Windows::Storage::Streams;

    Playback& Playback::Get() {
        static Playback instance;
        return instance;
    }

    void Playback::Start() {
        if (m_running.exchange(true)) return;
        m_thread = std::thread(&Playback::WorkerThread, this);
    }

    void Playback::Stop() {
        m_running = false;
        if (m_thread.joinable())
            m_thread.join();
    }

    Playback::MediaInfo Playback::GetMediaInfo() {
        std::lock_guard lock(m_mutex);
        return m_info;
    }

    void Playback::WorkerThread() {
        try {
            winrt::init_apartment(winrt::apartment_type::multi_threaded);
        }
        catch (...) {
            FLOG("[MusicPlayer] winrt::init_apartment failed");
            m_running = false;
            return;
        }
        FLOG("[MusicPlayer] SMTC worker started");

        GlobalSystemMediaTransportControlsSessionManager manager{nullptr};
        try {
            manager = GlobalSystemMediaTransportControlsSessionManager::RequestAsync().get();
        }
        catch (...) {
            FLOG("[MusicPlayer] Failed to get SMTC session manager");
            m_running = false;
            try { winrt::uninit_apartment(); } catch (...) {}
            return;
        }

        while (m_running) {
            try {
                auto session = manager.GetCurrentSession();
                m_hasSession.store(session != nullptr, std::memory_order_relaxed);

                if (session) {
                    MediaInfo info;

                    auto props = session.TryGetMediaPropertiesAsync().get();
                    info.title = winrt::to_string(props.Title());
                    info.artist = winrt::to_string(props.Artist());
                    info.album = winrt::to_string(props.AlbumTitle());

                    auto playback = session.GetPlaybackInfo();
                    auto status = playback.PlaybackStatus();
                    info.isPlaying = (status == GlobalSystemMediaTransportControlsSessionPlaybackStatus::Playing);

                    auto timeline = session.GetTimelineProperties();
                    info.positionSeconds = std::chrono::duration<double>(timeline.Position()).count();
                    info.durationSeconds = std::chrono::duration<double>(timeline.EndTime()).count();
                    info.lastUpdate = std::chrono::steady_clock::now();

                    auto thumbRef = props.Thumbnail();
                    if (thumbRef) {
                        try {
                            auto stream = thumbRef.OpenReadAsync().get();
                            auto size = static_cast<uint32_t>(stream.Size());
                            if (size > 0 && size < 4 * 1024 * 1024) {
                                DataReader reader(stream);
                                reader.LoadAsync(size).get();
                                info.thumbnailData.resize(size);
                                reader.ReadBytes(info.thumbnailData);
                                reader.Close();
                                stream.Close();
                            }
                        }
                        catch (...) {}
                    }

                    if (info.thumbnailData.empty()) {
                        try {
                            wchar_t* localAppData = nullptr;
                            if (_wdupenv_s(&localAppData, nullptr, L"LOCALAPPDATA") == 0 && localAppData) {
                                std::filesystem::path artDir(localAppData);
                                free(localAppData);
                                artDir /= L"Microsoft\\MediaPlayer\\Art Cache\\LocalMLS";
                                if (std::filesystem::exists(artDir)) {
                                    std::filesystem::path newest;
                                    std::filesystem::file_time_type newestTime{};
                                    for (auto& entry : std::filesystem::directory_iterator(artDir)) {
                                        if (!entry.is_regular_file()) continue;
                                        auto ext = entry.path().extension().string();
                                        if (ext != ".jpg" && ext != ".jpeg" && ext != ".png" && ext != ".bmp") continue;
                                        auto wt = entry.last_write_time();
                                        if (newest.empty() || wt > newestTime) {
                                            newest = entry.path();
                                            newestTime = wt;
                                        }
                                    }
                                    if (!newest.empty()) {
                                        std::ifstream file(newest, std::ios::binary | std::ios::ate);
                                        if (file) {
                                            auto sz = file.tellg();
                                            if (sz > 0 && sz < 4 * 1024 * 1024) {
                                                info.thumbnailData.resize(static_cast<size_t>(sz));
                                                file.seekg(0);
                                                file.read(reinterpret_cast<char*>(info.thumbnailData.data()), sz);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        catch (...) {}
                    }

                    if (!info.thumbnailData.empty()) {
                        uint64_t hash = 0x811c9dc5u;
                        for (size_t i = 0; i < info.thumbnailData.size(); i += 64) {
                            hash ^= info.thumbnailData[i];
                            hash *= 0x01000193u;
                        }
                        info.thumbnailHash = hash;
                    }

                    {
                        std::lock_guard lock(m_mutex);
                        bool sameThumbnail = (info.thumbnailHash != 0 &&
                                              info.thumbnailHash == m_info.thumbnailHash);
                        if (sameThumbnail) {
                            info.thumbnailData = std::move(m_info.thumbnailData);
                            info.thumbnailHash = m_info.thumbnailHash;
                        }
                        m_info = std::move(info);
                    }
                }
                else {
                    std::lock_guard lock(m_mutex);
                    m_info = MediaInfo{};
                }
            }
            catch (...) {}

            for (int i = 0; i < 10 && m_running; ++i)
                Sleep(50);
        }

        winrt::uninit_apartment();
        FLOG("[MusicPlayer] SMTC worker stopped");
    }

}
