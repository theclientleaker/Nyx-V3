#pragma once

#define IDR_ICON_TERMINAL           101
#define IDR_ICON_GAUGE              102
#define IDR_ICON_AIRPLANE_TILT      103
#define IDR_ICON_CROSSHAIR          104
#define IDR_ICON_IDENTIFICATION_CARD 105
#define IDR_ICON_USERS_THREE        106
#define IDR_ICON_MUSIC_NOTES        107
#define IDR_ICON_DOOR               108
#define IDR_ICON_ARROWS_CLOCKWISE   109
#define IDR_ICON_CUBE               110
#define IDR_ICON_HAND_GRABBING      111
#define IDR_ICON_GHOST              112
#define IDR_ICON_LIGHTNING          113
#define IDR_ICON_CHAT_TEXT          114
#define IDR_ICON_SHIELD_CHECK       115
#define IDR_ICON_WRENCH             116
#define IDR_ICON_GLOBE              117
#define IDR_PANEL_BG                118
#define IDR_ICON_LOGO               119
#define IDR_TOAST_BG                120
#define IDR_MP_PREV                 121
#define IDR_MP_PLAY                 122
#define IDR_MP_PAUSE                123
#define IDR_MP_NEXT                 124
#define IDR_MP_VOL_UP               125
#define IDR_MP_VOL_DOWN             126
#define IDR_MP_VOL_MUTE             127

#define IDR_ICON_WIFI               128
#define IDR_ICON_FILM_STRIP         129

#define IDR_NOTIF_BACKGROUND        201
#define IDR_NOTIF_PLAYER            202
#define IDR_NOTIF_INFO              203
#define IDR_NOTIF_ERROR             204
#define IDR_NOTIF_WARNING           205
#define IDR_NOTIF_TIME              206
