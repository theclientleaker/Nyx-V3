#pragma once
#include <Core/BaseModule.hpp>

namespace UNIx {

    class UIRemoverModule : public BaseModule {
    public:
        UIRemoverModule()
            : BaseModule("UI Remover", "Removes unwanted QM UI elements", 0, "UI") {
            m_showInQuickMenu = true;
            m_enabled = true;
        }

        void OnUpdate() override;
        void OnEnable() override;
        void OnDisable() override;
        void OnSceneLoad(int scene, int loadMode) override;

    private:
        void ApplyRemovals();
        void CreateNyxButton();
        bool m_applied = false;
        bool m_nyxBtnCreated = false;
        void* m_nyxBtnGO = nullptr;
    };

} // namespace UNIx
