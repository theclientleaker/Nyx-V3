#include <Modules/UI/MusicPlayer/MusicPlayerModule.hpp>
#include <Modules/UI/MusicPlayer/Playback.hpp>
#include <Core/FileLog/FileLog.hpp>
#include <Core/QuickMenuEx.hpp>

#include <IL2CPP.Module/include/il2cpp_module.hpp>
#include <IL2CPP.Common/il2cpp_shared.hpp>
#include <IL2CPP.Module/include/Unity/GameObject.hpp>
#include <IL2CPP.Module/include/Unity/Transform.hpp>
#include <IL2CPP.Module/include/Unity/RectTransform.hpp>
#include <IL2CPP.Module/include/Unity/TMP_Text.hpp>
#include <IL2CPP.Module/include/Unity/Object.hpp>
#include <IL2CPP.Module/include/Unity/Component.hpp>
#include <IL2CPP.Module/include/Unity/Image.hpp>
#include <IL2CPP.Module/include/Reflection.hpp>
#include <IL2CPP.Module/include/MethodHandler.hpp>
#include <Core/SpriteLoader/SpriteLoader.hpp>
#include "resource.h"

#include <cstdio>

namespace UNIx {

using namespace IL2CPP::Module;
using namespace IL2CPP::Module::Unity;

MusicPlayerModule* MusicPlayerModule::s_instance = nullptr;

void MusicPlayerModule::SendMediaKey(uint8_t vk) {
    keybd_event(vk, vk, 0, 0);
    keybd_event(vk, vk, KEYEVENTF_KEYUP, 0);
}

static GameObject CloneAndStrip(void* templateGORaw, const std::string& name) {
    GameObject templateGO(templateGORaw);
    auto clone = templateGO.Instantiate();
    if (!clone.raw() || !clone.IsValid()) return GameObject{};

    GameObject go(clone.raw());
    go.SetName(name);
    go.SetActive(true);

    auto t = go.GetTransform();
    for (int i = t.GetChildCount() - 1; i >= 0; --i) {
        auto childT = t.GetChild(i);
        if (childT.valid()) {
            auto childGO = childT.GetGameObject();
            if (childGO.valid()) Object(childGO.raw()).DestroyImmediate();
        }
    }

    const char* stripComponents[] = {
        "VRC.UI.Core.Styles.StyleElement",
        "UnityEngine.Localization.PropertyVariants.GameObjectLocalizer",
        "UnityEngine.Localization.Components.LocalizeStringEvent",
        "VRC.UI.Core.Styles.StyleString",
    };
    for (auto& comp : stripComponents) {
        try {
            auto c = go.GetComponentByName(comp);
            if (c.valid()) Object(c.raw()).DestroyImmediate();
        } catch (...) {}
    }

    return go;
}

static void StripAutoSize(void* tmpRaw) {
    static auto setAutoSize = MethodHandler::resolve("TMPro.TMP_Text", "set_enableAutoSizing", 1);
    if (setAutoSize) {
        bool val = false;
        void* args[] = { &val };
        MethodHandler::invoke<void>(setAutoSize, tmpRaw, args);
    }
}

static void SetIgnoreLayout(void* goRaw) {
    if (!goRaw) return;
    GameObject go(goRaw);
    auto leClass = Class::find("UnityEngine.UI.LayoutElement");
    if (!leClass) return;
    auto existing = go.GetComponent(leClass);
    void* le = existing.valid() ? existing.raw() : go.AddComponent(leClass).raw();
    if (!le) return;
    static auto setIgnore = MethodHandler::resolve("UnityEngine.UI.LayoutElement", "set_ignoreLayout", 1);
    if (setIgnore) {
        bool val = true;
        void* args[] = { &val };
        MethodHandler::invoke(setIgnore, le, args);
    }
}

static void* MakeClickable(void* goRaw) {
    if (!goRaw) return nullptr;
    GameObject go(goRaw);

    static auto setRaycast = MethodHandler::resolve("UnityEngine.UI.Graphic", "set_raycastTarget", 1);
    if (setRaycast) {
        auto graphic = go.GetComponentByName("UnityEngine.UI.Image");
        if (!graphic.valid()) graphic = go.GetComponentByName("TMPro.TextMeshProUGUI");
        if (graphic.valid()) {
            bool val = true;
            void* args[] = { &val };
            MethodHandler::invoke(setRaycast, graphic.raw(), args);
        }
    }

    auto buttonClass = Class::find("UnityEngine.UI.Button");
    if (buttonClass) {
        auto existing = go.GetComponent(buttonClass);
        if (!existing.valid()) {
            auto btn = go.AddComponent(buttonClass);
            if (btn.valid()) {
                static auto setTransition = MethodHandler::resolve(
                    "UnityEngine.UI.Selectable", "set_transition", 1);
                if (setTransition) {
                    int none = 0;
                    void* args[] = { &none };
                    MethodHandler::invoke(setTransition, btn.raw(), args);
                }
            }
        }
    }
    return goRaw;
}

void MusicPlayerModule::SetTMP(void* tmpComp, const char* text, float fontSize) {
    if (!tmpComp) return;
    StripAutoSize(tmpComp);
    TMP_Text tmp(tmpComp);
    if (fontSize > 0.f) tmp.SetFontSize(fontSize);
    tmp.SetRichText(true);
    tmp.SetEnableWordWrapping(false);
    tmp.SetText(std::string(text));
}

void* MusicPlayerModule::CloneTMP(void* templateGO, void* parent, const char* name) {
    if (!templateGO || !parent) return nullptr;
    auto go = CloneAndStrip(templateGO, name);
    if (!go.raw()) return nullptr;
    Transform parentT(parent);
    go.GetTransform().SetParent(parentT, false);
    return go.raw();
}

void MusicPlayerModule::OnEnable() {
    s_instance = this;
}

void MusicPlayerModule::OnDisable() {
    Playback::Get().Stop();
    DestroyPanel();
}

void MusicPlayerModule::OnSceneLoad(int, int) {
    ResetState();
}

void MusicPlayerModule::ResetState() {
    m_panelGO = nullptr;
    m_albumArtGO = nullptr;
    m_albumArtImage = nullptr;
    m_titleTMP = nullptr;
    m_btnPrev = nullptr;
    m_btnPlayPause = nullptr;
    m_btnNext = nullptr;
    m_btnVolDown = nullptr;
    m_btnVolMute = nullptr;
    m_btnVolUp = nullptr;
    m_playPauseImage = nullptr;
    m_lastPlaying = false;
    m_lastSelected = nullptr;
    m_thumbHash = 0;
    m_lastTitle.clear();
    m_panelCreated = false;
    m_initDelay = 0;
    m_updateSkip = 0;
}

void MusicPlayerModule::DestroyPanel() {
    if (m_panelGO) {
        try {
            GameObject go(m_panelGO);
            if (go.valid() && go.IsValid()) go.Destroy();
        } catch (...) {}
    }
    ResetState();
}

void MusicPlayerModule::OnUpdate() {
    if (!m_panelCreated) {
        if (++m_initDelay < 240) return;
        Playback::Get().Start();
        try { CreatePanel(); }
        catch (...) { FLOG("[MusicPlayer] CreatePanel crashed"); }
        if (!m_panelCreated) m_initDelay = 90;
        return;
    }

    if (m_panelGO) {
        try {
            GameObject go(m_panelGO);
            if (!go.valid() || !go.IsValid()) {
                ResetState();
                return;
            }
        } catch (...) {
            ResetState();
            return;
        }
    }

    if (m_updateSkip > 0) { --m_updateSkip; return; }

    try { UpdatePanel(); } catch (...) {}
    try { HandleClicks(); } catch (...) {}
}

void MusicPlayerModule::CreatePanel() {
    auto qmCanvas = GameObject::Find("Canvas_QuickMenu(Clone)");
    if (!qmCanvas.IsValid()) return;

    auto qmT = qmCanvas.GetTransform();
    auto windowT = qmT.Find("CanvasGroup/Container/Window");
    if (!windowT.valid()) return;

    auto spotifyPanelT = windowT.Find("SpotifyPanel");
    if (!spotifyPanelT.valid()) {
        FLOG("[MusicPlayer] SpotifyPanel not found, waiting...");
        return;
    }

    auto existingT = spotifyPanelT.Find("nyx_MP_Container");
    if (existingT.valid()) {
        auto existingGO = existingT.GetGameObject();
        if (existingGO.valid()) existingGO.Destroy();
    }

    RectTransform spotifyRT(spotifyPanelT.raw());
    spotifyRT.SetSizeDelta({ 340.f, 350.f });
    spotifyRT.SetAnchoredPosition({ 679.6f, 588.75f });

    auto tmpClass = Class::find("TMPro.TextMeshProUGUI");
    if (!tmpClass) { FLOG("[MusicPlayer] TMP class not found"); return; }

    auto bgLayerT = qmT.Find("CanvasGroup/Container/Window/QMParent/BackgroundLayer01");
    if (!bgLayerT.valid()) return;
    auto bgLayerGO = bgLayerT.GetGameObject();
    if (!bgLayerGO.valid()) return;

    static auto instantiate = MethodHandler::resolve("UnityEngine.Object", "Instantiate", 1);
    if (!instantiate) return;

    void* cloneParams[] = { bgLayerGO.raw() };
    void* containerRaw = MethodHandler::invoke<void*>(instantiate, nullptr, cloneParams);
    if (!containerRaw) return;

    GameObject containerGO(containerRaw);
    auto containerT = containerGO.GetTransform();
    if (!containerT.valid()) { Object(containerRaw).Destroy(); return; }

    for (int i = containerT.GetChildCount() - 1; i >= 0; --i) {
        auto child = containerT.GetChild(i);
        if (child.valid()) {
            auto childGO = child.GetGameObject();
            if (childGO.valid()) Object(childGO.raw()).DestroyImmediate();
        }
    }

    auto compClass = Class::find("UnityEngine.Component");
    if (compClass) {
        auto allComps = containerGO.GetComponents(compClass);
        for (auto& comp : allComps) {
            if (!comp || !comp.raw()) continue;
            try {
                std::string cn = comp.get_class_name();
                if (cn == "RectTransform" || cn == "CanvasRenderer") continue;
                Object(comp.raw()).Destroy();
            } catch (...) {}
        }
    }

    containerGO.SetName("nyx_MP_Container");
    containerT.SetParent(spotifyPanelT, false);

    RectTransform containerRT(containerT.raw());
    containerRT.SetAnchorMin({ 0.f, 0.f });
    containerRT.SetAnchorMax({ 1.f, 1.f });
    containerRT.SetPivot({ 0.5f, 0.5f });
    containerRT.SetAnchoredPosition({ 0.f, 0.f });
    containerRT.SetSizeDelta({ 0.f, 0.f });

    containerGO.SetActive(true);
    m_panelGO = containerRaw;

    void* tmpTemplate = nullptr;
    auto launchpadVLGT = qmT.Find(
        "CanvasGroup/Container/Window/QMParent/Body/Menu_QM_Launchpad/"
        "ScrollRect/Viewport/VerticalLayoutGroup");
    if (launchpadVLGT.valid()) {
        auto vlgGO = launchpadVLGT.GetGameObject();
        if (vlgGO.valid()) {
            auto tc = vlgGO.GetComponentInChildren(tmpClass, true);
            if (tc.valid()) {
                static auto getGO = MethodHandler::resolve("UnityEngine.Component", "get_gameObject", 0);
                tmpTemplate = MethodHandler::invoke<void*>(getGO, tc.raw());
            }
        }
    }

    if (!tmpTemplate) { FLOG("[MusicPlayer] No TMP template found"); return; }

    auto artGO = CloneAndStrip(tmpTemplate, "nyx_MP_Art");
    if (artGO.raw()) {
        auto artT = artGO.GetTransform();
        artT.SetParent(containerT, false);
        SetIgnoreLayout(artGO.raw());

        auto artTmp = artGO.GetComponentByName("TMPro.TextMeshProUGUI");
        if (artTmp.valid()) Object(artTmp.raw()).DestroyImmediate();

        auto imageClass = Class::find("UnityEngine.UI.Image");
        if (imageClass) {
            auto imgComp = artGO.AddComponent(imageClass);
            if (imgComp.valid()) {
                m_albumArtGO = artGO.raw();
                m_albumArtImage = imgComp.raw();

                Unity::Image img(imgComp.raw());
                img.SetColor({ 1.f, 1.f, 1.f, 0.f });
                img.SetPreserveAspect(true);

                static auto setRaycast = MethodHandler::resolve("UnityEngine.UI.Graphic", "set_raycastTarget", 1);
                if (setRaycast) {
                    bool off = false;
                    void* rp[] = { &off };
                    MethodHandler::invoke(setRaycast, imgComp.raw(), rp);
                }
            }
        }

        RectTransform artRT(artT.raw());
        artRT.SetAnchorMin({ 0.5f, 1.f });
        artRT.SetAnchorMax({ 0.5f, 1.f });
        artRT.SetPivot({ 0.5f, 1.f });
        artRT.SetAnchoredPosition({ 0.f, -5.f });
        artRT.SetSizeDelta({ 240.f, 240.f });
    }

    auto titleGO = CloneAndStrip(tmpTemplate, "nyx_MP_Title");
    if (!titleGO.raw()) { FLOG("[MusicPlayer] Title clone failed"); return; }

    auto titleT = titleGO.GetTransform();
    titleT.SetParent(containerT, false);
    SetIgnoreLayout(titleGO.raw());

    RectTransform titleRT(titleT.raw());
    titleRT.SetAnchorMin({ 0.f, 1.f });
    titleRT.SetAnchorMax({ 1.f, 1.f });
    titleRT.SetPivot({ 0.5f, 1.f });
    titleRT.SetAnchoredPosition({ 0.f, -250.f });
    titleRT.SetSizeDelta({ -10.f, 40.f });

    auto oldTitleTmp = titleGO.GetComponentByName("TMPro.TextMeshProUGUI");
    if (oldTitleTmp.valid()) Object(oldTitleTmp.raw()).DestroyImmediate();

    auto freshTmp = titleGO.AddComponent(tmpClass);
    if (freshTmp.valid()) {
        StripAutoSize(freshTmp.raw());
        TMP_Text tmp(freshTmp.raw());
        tmp.SetRichText(true);
        tmp.SetFontSize(18.f);
        tmp.SetAlignment(514);
        tmp.SetEnableWordWrapping(true);
        tmp.SetColor({ 1.f, 1.f, 1.f, 1.f });
        tmp.SetText(std::string("Media Controls"));
        m_titleTMP = freshTmp.raw();

        static auto setOverflow = MethodHandler::resolve("TMPro.TMP_Text", "set_overflowMode", 1);
        if (setOverflow) {
            int ellipsis = 1;
            void* op[] = { &ellipsis };
            MethodHandler::invoke(setOverflow, freshTmp.raw(), op);
        }

        static auto setRaycast = MethodHandler::resolve("UnityEngine.UI.Graphic", "set_raycastTarget", 1);
        if (setRaycast) {
            bool off = false;
            void* rp[] = { &off };
            MethodHandler::invoke(setRaycast, freshTmp.raw(), rp);
        }
    }

    struct BtnDef { const char* name; uint32_t iconId; const char* cacheKey; void** goPtr; float xOff; };
    BtnDef buttons[] = {
        { "nyx_MP_Prev",      IDR_MP_PREV,     "mp_prev",     &m_btnPrev,      -130.f },
        { "nyx_MP_PlayPause", IDR_MP_PLAY,     "mp_play",     &m_btnPlayPause,  -78.f },
        { "nyx_MP_Next",      IDR_MP_NEXT,     "mp_next",     &m_btnNext,       -26.f },
        { "nyx_MP_VolDown",   IDR_MP_VOL_DOWN, "mp_vol_down", &m_btnVolDown,    26.f },
        { "nyx_MP_VolMute",   IDR_MP_VOL_MUTE, "mp_vol_mute", &m_btnVolMute,   78.f },
        { "nyx_MP_VolUp",     IDR_MP_VOL_UP,   "mp_vol_up",   &m_btnVolUp,    130.f },
    };

    auto& sprites = SpriteLoader::Get();
    auto imageClass = Class::find("UnityEngine.UI.Image");

    float btnY = -300.f;

    for (auto& def : buttons) {
        auto btnGO = CloneAndStrip(tmpTemplate, def.name);
        if (!btnGO.raw()) continue;

        auto t = btnGO.GetTransform();
        t.SetParent(containerT, false);
        SetIgnoreLayout(btnGO.raw());

        auto tmp = btnGO.GetComponentByName("TMPro.TextMeshProUGUI");
        if (tmp.valid()) Object(tmp.raw()).DestroyImmediate();

        if (imageClass) {
            auto imgComp = btnGO.AddComponent(imageClass);
            if (imgComp.valid()) {
                Unity::Image img(imgComp.raw());
                void* sprite = sprites.LoadFromResource(def.iconId, def.cacheKey);
                if (sprite) img.SetSprite(sprite);
                img.SetColor({ 1.f, 1.f, 1.f, 1.f });
                img.SetPreserveAspect(true);

                if (def.goPtr == &m_btnPlayPause) m_playPauseImage = imgComp.raw();
            }
        }

        RectTransform rt(t.raw());
        rt.SetAnchorMin({ 0.5f, 1.f });
        rt.SetAnchorMax({ 0.5f, 1.f });
        rt.SetPivot({ 0.5f, 0.5f });
        rt.SetSizeDelta({ 35.f, 35.f });
        rt.SetAnchoredPosition({ def.xOff, btnY });

        MakeClickable(btnGO.raw());
        *def.goPtr = btnGO.raw();
    }

    m_panelCreated = true;
    m_updateSkip = 10;
    FLOG("[MusicPlayer] Panel created in SpotifyPanel");
}

void MusicPlayerModule::UpdatePanel() {
    if (!Playback::Get().HasSession()) {
        if (m_titleTMP && !m_lastTitle.empty()) {
            TMP_Text tx(m_titleTMP);
            tx.SetText(std::string("Media Controls"));
            m_lastTitle.clear();
        }
        return;
    }

    auto info = Playback::Get().GetMediaInfo();

    std::string display = info.title;
    if (!info.artist.empty()) display += " - " + info.artist;

    if (display != m_lastTitle) {
        m_lastTitle = display;
        if (m_titleTMP) {
            TMP_Text tx(m_titleTMP);
            tx.SetText(display.empty() ? std::string("Media Controls") : display);
        }
    }

    if (m_playPauseImage && info.isPlaying != m_lastPlaying) {
        m_lastPlaying = info.isPlaying;
        auto& sprites = SpriteLoader::Get();
        void* sprite = info.isPlaying
            ? sprites.LoadFromResource(IDR_MP_PAUSE, "mp_pause")
            : sprites.LoadFromResource(IDR_MP_PLAY, "mp_play");
        if (sprite) {
            Unity::Image img(m_playPauseImage);
            img.SetSprite(sprite);
        }
    }

    if (m_albumArtImage && info.thumbnailHash != 0 && info.thumbnailHash != m_thumbHash) {
        m_thumbHash = info.thumbnailHash;
        try {
            std::string cacheKey = "mp_thumb_" + std::to_string(info.thumbnailHash);
            void* sprite = SpriteLoader::Get().LoadFromMemory(
                cacheKey, info.thumbnailData.data(), info.thumbnailData.size());
            if (sprite) {
                Unity::Image img(m_albumArtImage);
                img.SetSprite(sprite);
                img.SetColor({ 1.f, 1.f, 1.f, 1.f });
                img.SetPreserveAspect(true);
            }
        }
        catch (...) {}
    }
}

void MusicPlayerModule::HandleClicks() {
    static auto getCurrent = MethodHandler::resolve(
        "UnityEngine.EventSystems.EventSystem", "get_current", 0);
    static auto getSelectedGO = MethodHandler::resolve(
        "UnityEngine.EventSystems.EventSystem", "get_currentSelectedGameObject", 0);
    if (!getCurrent || !getSelectedGO) return;

    void* eventSystem = MethodHandler::invoke<void*>(getCurrent, nullptr);
    if (!eventSystem) return;
    void* selectedGO = MethodHandler::invoke<void*>(getSelectedGO, eventSystem, nullptr);

    if (selectedGO && selectedGO != m_lastSelected) {
        uint8_t mediaKey = 0;

        if      (selectedGO == m_btnPlayPause) mediaKey = VK_MEDIA_PLAY_PAUSE;
        else if (selectedGO == m_btnNext)      mediaKey = VK_MEDIA_NEXT_TRACK;
        else if (selectedGO == m_btnPrev)      mediaKey = VK_MEDIA_PREV_TRACK;
        else if (selectedGO == m_btnVolDown)   mediaKey = VK_VOLUME_DOWN;
        else if (selectedGO == m_btnVolMute)   mediaKey = VK_VOLUME_MUTE;
        else if (selectedGO == m_btnVolUp)     mediaKey = VK_VOLUME_UP;

        if (mediaKey != 0) {
            SendMediaKey(mediaKey);

            static auto setSelected = MethodHandler::resolve(
                "UnityEngine.EventSystems.EventSystem", "SetSelectedGameObject", 1);
            if (setSelected) {
                void* null = nullptr;
                void* args[] = { null };
                MethodHandler::invoke(setSelected, eventSystem, args);
            }
            selectedGO = nullptr;
        }
    }

    m_lastSelected = selectedGO;
}

void MusicPlayerModule::OnSetupQuickMenu(uint32_t moduleId, uint32_t categoryPageId) {
    s_instance = this;
    m_moduleId = moduleId;
    m_categoryPageId = categoryPageId;

    auto& qmEx = QuickMenuEx::Get();
    qmEx.set_subpage_nav_icon_vrc(moduleId, categoryPageId, Bootstrap::Sprite::Bundle_FileAudio);
}

} // namespace UNIx
