#include <Modules/UI/Spotify/SpotifyModule.hpp>
#include <Modules/UI/MusicPlayer/Playback.hpp>
#include <Core/FileLog/FileLog.hpp>
#include <Core/QuickMenuEx.hpp>
#include <Core/SpriteLoader/SpriteLoader.hpp>
#include "resource.h"

#include <IL2CPP.Module/include/il2cpp_module.hpp>
#include <IL2CPP.Common/il2cpp_shared.hpp>
#include <IL2CPP.Module/include/Unity/GameObject.hpp>
#include <IL2CPP.Module/include/Unity/Transform.hpp>
#include <IL2CPP.Module/include/Unity/RectTransform.hpp>
#include <IL2CPP.Module/include/Unity/Object.hpp>
#include <IL2CPP.Module/include/Unity/Image.hpp>
#include <IL2CPP.Module/include/Unity/TMP_Text.hpp>
#include <IL2CPP.Module/include/Unity/Time.hpp>
#include <IL2CPP.Module/include/Unity/Input.hpp>
#include <IL2CPP.Module/include/Unity/Component.hpp>
#include <IL2CPP.Module/include/Reflection.hpp>
#include <IL2CPP.Module/include/MethodHandler.hpp>
#include <IL2CPP.Module/include/ManagedObject.hpp>

#include <cstdio>
#include <string>

namespace UNIx {

using namespace IL2CPP::Module;
using namespace IL2CPP::Module::Unity;

SpotifyModule* SpotifyModule::s_instance = nullptr;

void SpotifyModule::SendMediaKey(uint8_t vk) {
    keybd_event(vk, vk, 0, 0);
    keybd_event(vk, vk, KEYEVENTF_KEYUP, 0);
}

static GameObject CloneAndStrip(void* templateGORaw, const std::string& name) {
    GameObject templateGO(templateGORaw);
    auto clone = templateGO.Instantiate();
    if (!clone.raw() || !clone.IsValid()) return GameObject{};

    GameObject go(clone.raw());
    go.SetName(name);
    go.SetActive(true);

    auto t = go.GetTransform();
    for (int i = t.GetChildCount() - 1; i >= 0; --i) {
        auto childT = t.GetChild(i);
        if (childT.valid()) {
            auto childGO = childT.GetGameObject();
            if (childGO.valid()) Object(childGO.raw()).DestroyImmediate();
        }
    }

    const char* stripComponents[] = {
        "VRC.UI.Core.Styles.StyleElement",
        "UnityEngine.Localization.PropertyVariants.GameObjectLocalizer",
        "UnityEngine.Localization.Components.LocalizeStringEvent",
        "VRC.UI.Core.Styles.StyleString",
    };
    for (auto& comp : stripComponents) {
        try {
            auto c = go.GetComponentByName(comp);
            if (c.valid()) Object(c.raw()).DestroyImmediate();
        } catch (...) {}
    }

    return go;
}

static void StripAutoSize(void* tmpRaw) {
    static auto setAutoSize = MethodHandler::resolve("TMPro.TMP_Text", "set_enableAutoSizing", 1);
    if (setAutoSize) {
        bool val = false;
        void* args[] = { &val };
        MethodHandler::invoke<void>(setAutoSize, tmpRaw, args);
    }
}


static void SetIgnoreLayout(void* goRaw) {
    if (!goRaw) return;
    GameObject go(goRaw);
    auto leClass = Class::find("UnityEngine.UI.LayoutElement");
    if (!leClass) return;
    auto existing = go.GetComponent(leClass);
    void* le = existing.valid() ? existing.raw() : go.AddComponent(leClass).raw();
    if (!le) return;
    static auto setIgnore = MethodHandler::resolve("UnityEngine.UI.LayoutElement", "set_ignoreLayout", 1);
    if (setIgnore) {
        bool val = true;
        void* args[] = { &val };
        MethodHandler::invoke(setIgnore, le, args);
    }
}

static void* MakeClickable(void* goRaw) {
    if (!goRaw) return nullptr;
    GameObject go(goRaw);

    static auto setRaycast = MethodHandler::resolve("UnityEngine.UI.Graphic", "set_raycastTarget", 1);
    if (setRaycast) {
        auto graphic = go.GetComponentByName("UnityEngine.UI.Image");
        if (!graphic.valid()) graphic = go.GetComponentByName("TMPro.TextMeshProUGUI");
        if (graphic.valid()) {
            bool val = true;
            void* args[] = { &val };
            MethodHandler::invoke(setRaycast, graphic.raw(), args);
        }
    }

    auto buttonClass = Class::find("UnityEngine.UI.Button");
    if (buttonClass) {
        auto existing = go.GetComponent(buttonClass);
        if (!existing.valid()) {
            auto btn = go.AddComponent(buttonClass);
            if (btn.valid()) {
                static auto setTransition = MethodHandler::resolve(
                    "UnityEngine.UI.Selectable", "set_transition", 1);
                if (setTransition) {
                    int none = 0;
                    void* args[] = { &none };
                    MethodHandler::invoke(setTransition, btn.raw(), args);
                }
            }
        }
    }
    return goRaw;
}

void SpotifyModule::SetTMP(void* tmpComp, const char* text, float fontSize) {
    if (!tmpComp) return;
    StripAutoSize(tmpComp);
    TMP_Text tmp(tmpComp);
    if (fontSize > 0.f) tmp.SetFontSize(fontSize);
    tmp.SetRichText(true);
    tmp.SetEnableWordWrapping(false);
    tmp.SetText(std::string(text));
}

void* SpotifyModule::CloneTMP(void* templateGO, void* parent, const char* name) {
    if (!templateGO || !parent) return nullptr;
    auto go = CloneAndStrip(templateGO, name);
    if (!go.raw()) return nullptr;
    Transform parentT(parent);
    go.GetTransform().SetParent(parentT, false);
    return go.raw();
}

void SpotifyModule::OnEnable() {
    s_instance = this;
}

void SpotifyModule::OnDisable() {
    Playback::Get().Stop();
    DestroyPanel();
}

void SpotifyModule::OnSceneLoad(int, int) {
    ResetState();
    m_sceneGuard = 180;
}

void SpotifyModule::ResetState() {
    m_panelGO = nullptr;
    m_containerGO = nullptr;
    m_albumArtGO = nullptr;
    m_albumArtImage = nullptr;
    m_titleTMP = nullptr;
    m_artistTMP = nullptr;
    m_albumTMP = nullptr;
    m_timeTMP = nullptr;
    m_progressFillGO = nullptr;
    m_btnPrev = nullptr;
    m_btnPlayPause = nullptr;
    m_btnNext = nullptr;
    m_btnVolDown = nullptr;
    m_btnVolMute = nullptr;
    m_btnVolUp = nullptr;
    m_playPauseImage = nullptr;
    m_lastPlaying = false;
    m_thumbHash = 0;
    m_lastTitle.clear();
    m_lastArtist.clear();
    m_lastAlbum.clear();
    m_lastTime.clear();
    m_panelCreated = false;
    m_panelInjected = false;
    m_failed = false;
    m_retryTimer = 0.f;
    m_initDelay = 0;
    m_updateSkip = 0;
    m_scrollX = 0.f;
    m_scrollResetAt = 0.f;
    m_titleGO = nullptr;
    m_titleViewport = nullptr;
}

void SpotifyModule::DestroyPanel() {
    if (m_panelGO) {
        try {
            GameObject go(m_panelGO);
            if (go.valid() && go.IsValid()) go.Destroy();
        } catch (...) {}
    }
    ResetState();
}

void SpotifyModule::OnUpdate() {
    if (m_sceneGuard > 0) { --m_sceneGuard; return; }

    try {
        if (!m_panelInjected) {
            if (m_failed) return;
            m_retryTimer -= Time::GetDeltaTime();
            if (m_retryTimer > 0.f) return;
            m_retryTimer = 1.0f;
            try { CreateSpotifyPanel(); }
            catch (...) { FLOG("[Spotify] CreateSpotifyPanel crashed"); }
            return;
        }

        if (!m_panelCreated) {
            if (++m_initDelay < 60) return;
            Playback::Get().Start();
            try { CreateMediaControls(); }
            catch (...) { FLOG("[Spotify] CreateMediaControls crashed"); }
            if (!m_panelCreated) m_initDelay = 30;
            return;
        }

        if (m_panelGO) {
            GameObject go(m_panelGO);
            if (!go.valid() || !go.IsValid()) {
                ResetState();
                return;
            }
        }

        if (m_updateSkip > 0) { --m_updateSkip; return; }

        UpdatePanel();
        HandleClicks();
    } catch (...) {
        ResetState();
    }
}

void SpotifyModule::CreateSpotifyPanel() {
    auto qm = GameObject::Find("Canvas_QuickMenu(Clone)");
    if (!qm.valid()) return;

    auto qmT = qm.GetTransform();
    auto wingT = qmT.Find("CanvasGroup/Container/Window/Wing_Right");
    if (!wingT.valid()) return;

    auto existing = wingT.Find("SpotifyPanel");
    if (existing.valid()) {
        m_panelGO = existing.GetGameObject().raw();
        m_panelInjected = true;
        return;
    }

    auto bgLayerT = qmT.Find("CanvasGroup/Container/Window/QMParent/BackgroundLayer01");
    if (!bgLayerT.valid()) return;

    auto bgLayerGO = bgLayerT.GetGameObject();
    if (!bgLayerGO.valid()) return;

    static auto instantiate = MethodHandler::resolve("UnityEngine.Object", "Instantiate", 1);
    if (!instantiate) { m_failed = true; return; }

    void* cloneParams[] = { bgLayerGO.raw() };
    void* clonedRaw = MethodHandler::invoke<void*>(instantiate, nullptr, cloneParams);
    if (!clonedRaw) return;

    GameObject panel(clonedRaw);
    auto panelT = panel.GetTransform();
    if (!panelT.valid()) { Object(clonedRaw).Destroy(); return; }

    for (int i = panelT.GetChildCount() - 1; i >= 0; --i) {
        auto child = panelT.GetChild(i);
        if (child.valid()) {
            auto childGO = child.GetGameObject();
            if (childGO.valid()) childGO.Destroy();
        }
    }

    auto compClass = Class::find("UnityEngine.Component");
    if (compClass) {
        auto allComps = panel.GetComponents(compClass);
        for (auto& comp : allComps) {
            if (!comp || !comp.raw()) continue;
            try {
                std::string cn = comp.get_class_name();
                if (cn == "RectTransform" || cn == "CanvasRenderer") continue;
                Object(comp.raw()).DestroyImmediate();
            } catch (...) {}
        }
    }

    panelT.SetParent(wingT, false);

    static auto setName = MethodHandler::resolve("UnityEngine.Object", "set_name", 1);
    if (setName) {
        void* nameStr = IL2CPP::Module::StringNew("SpotifyPanel");
        if (nameStr) {
            void* np[] = { nameStr };
            MethodHandler::invoke<void>(setName, clonedRaw, np);
        }
    }

    RectTransform rt(panelT.raw());
    rt.SetAnchorMin({0.5f, 1.f});
    rt.SetAnchorMax({0.5f, 1.f});
    rt.SetPivot({0.5f, 0.f});
    rt.SetSizeDelta({420.f, 170.f});
    rt.SetAnchoredPosition({0.f, 5.f});

    auto imgClass = Class::find("UnityEngine.UI.Image");
    ManagedObject imageComp;
    if (imgClass) imageComp = panel.AddComponent(imgClass);

    if (imageComp.valid()) {
        static auto setColor = MethodHandler::resolve("UnityEngine.UI.Graphic", "set_color", 1);
        if (setColor) {
            IL2CPP::Color col{0.07f, 0.07f, 0.09f, 0.85f};
            void* cp[] = { &col };
            MethodHandler::invoke(setColor, imageComp.raw(), cp);
        }

        void* panelSprite = SpriteLoader::Get().LoadFromResource(IDR_PANEL_BG, "panel_bg");
        if (panelSprite) {
            static auto setSprite = MethodHandler::resolve("UnityEngine.UI.Image", "set_sprite", 1);
            if (setSprite) {
                void* sp[] = { panelSprite };
                MethodHandler::invoke(setSprite, imageComp.raw(), sp);
            }
        }

        static auto setRaycast = MethodHandler::resolve("UnityEngine.UI.Graphic", "set_raycastTarget", 1);
        if (setRaycast) {
            bool off = false;
            void* rp[] = { &off };
            MethodHandler::invoke(setRaycast, imageComp.raw(), rp);
        }
    }

    panel.SetActive(true);
    m_panelGO = clonedRaw;
    m_panelInjected = true;
    FLOG("[Spotify] Panel injected under Window");
}

void SpotifyModule::CreateMediaControls() {
    auto qmCanvas = GameObject::Find("Canvas_QuickMenu(Clone)");
    if (!qmCanvas.valid() || !qmCanvas.IsValid()) return;

    auto qmT = qmCanvas.GetTransform();
    auto wingT = qmT.Find("CanvasGroup/Container/Window/Wing_Right");
    if (!wingT.valid()) return;

    auto spotifyPanelT = wingT.Find("SpotifyPanel");
    if (!spotifyPanelT.valid()) return;

    RectTransform panelRT(spotifyPanelT.raw());
    panelRT.SetSizeDelta({ 420.f, 170.f });

    auto existingT = spotifyPanelT.Find("nyx_MP_Container");
    if (existingT.valid()) {
        auto existingGO = existingT.GetGameObject();
        if (existingGO.valid()) existingGO.Destroy();
    }

    auto tmpClass = Class::find("TMPro.TextMeshProUGUI");
    if (!tmpClass) { FLOG("[Spotify] TMP class not found"); return; }

    auto bgLayerT = qmT.Find("CanvasGroup/Container/Window/QMParent/BackgroundLayer01");
    if (!bgLayerT.valid()) return;
    auto bgLayerGO = bgLayerT.GetGameObject();
    if (!bgLayerGO.valid()) return;

    static auto instantiate = MethodHandler::resolve("UnityEngine.Object", "Instantiate", 1);
    if (!instantiate) return;

    void* cloneParams[] = { bgLayerGO.raw() };
    void* containerRaw = MethodHandler::invoke<void*>(instantiate, nullptr, cloneParams);
    if (!containerRaw) return;

    GameObject containerGO(containerRaw);
    auto containerT = containerGO.GetTransform();
    if (!containerT.valid()) { Object(containerRaw).Destroy(); return; }

    for (int i = containerT.GetChildCount() - 1; i >= 0; --i) {
        auto child = containerT.GetChild(i);
        if (child.valid()) {
            auto childGO = child.GetGameObject();
            if (childGO.valid()) Object(childGO.raw()).DestroyImmediate();
        }
    }

    auto compClass = Class::find("UnityEngine.Component");
    if (compClass) {
        auto allComps = containerGO.GetComponents(compClass);
        for (auto& comp : allComps) {
            if (!comp || !comp.raw()) continue;
            try {
                std::string cn = comp.get_class_name();
                if (cn == "RectTransform" || cn == "CanvasRenderer") continue;
                Object(comp.raw()).Destroy();
            } catch (...) {}
        }
    }

    containerGO.SetName("nyx_MP_Container");
    containerT.SetParent(spotifyPanelT, false);

    RectTransform containerRT(containerT.raw());
    containerRT.SetAnchorMin({ 0.f, 0.f });
    containerRT.SetAnchorMax({ 1.f, 1.f });
    containerRT.SetPivot({ 0.5f, 0.5f });
    containerRT.SetAnchoredPosition({ 0.f, 0.f });
    containerRT.SetSizeDelta({ 0.f, 0.f });

    containerGO.SetActive(true);
    m_containerGO = containerRaw;

    void* tmpTemplate = nullptr;
    auto launchpadVLGT = qmT.Find(
        "CanvasGroup/Container/Window/QMParent/Body/Menu_QM_Launchpad/"
        "ScrollRect/Viewport/VerticalLayoutGroup");
    if (launchpadVLGT.valid()) {
        auto vlgGO = launchpadVLGT.GetGameObject();
        if (vlgGO.valid()) {
            auto tc = vlgGO.GetComponentInChildren(tmpClass, true);
            if (tc.valid()) {
                static auto getGO = MethodHandler::resolve("UnityEngine.Component", "get_gameObject", 0);
                tmpTemplate = MethodHandler::invoke<void*>(getGO, tc.raw());
            }
        }
    }

    if (!tmpTemplate) { FLOG("[Spotify] No TMP template found"); return; }

    auto imageClass = Class::find("UnityEngine.UI.Image");
    auto& sprites = SpriteLoader::Get();
    static auto setOverflow = MethodHandler::resolve("TMPro.TMP_Text", "set_overflowMode", 1);
    static auto setRaycastG = MethodHandler::resolve("UnityEngine.UI.Graphic", "set_raycastTarget", 1);

    auto createText = [&](const char* name, float fontSize, IL2CPP::Color color, int alignment)
        -> std::pair<void*, void*> {
        auto go = CloneAndStrip(tmpTemplate, name);
        if (!go.raw()) return { nullptr, nullptr };
        go.GetTransform().SetParent(containerT, false);
        SetIgnoreLayout(go.raw());

        auto tmp = go.GetComponentByName("TMPro.TextMeshProUGUI");
        if (!tmp.valid()) {
            tmp = go.AddComponent(tmpClass);
            if (!tmp.valid()) return { go.raw(), nullptr };
        }

        StripAutoSize(tmp.raw());
        TMP_Text tx(tmp.raw());
        tx.SetRichText(true);
        tx.SetFontSize(fontSize);
        tx.SetAlignment(alignment);
        tx.SetEnableWordWrapping(false);
        tx.SetColor(color);
        tx.SetText(std::string(""));

        if (setOverflow) {
            int ellipsis = 1;
            void* op[] = { &ellipsis };
            MethodHandler::invoke(setOverflow, tmp.raw(), op);
        }
        if (setRaycastG) {
            bool off = false;
            void* rp[] = { &off };
            MethodHandler::invoke(setRaycastG, tmp.raw(), rp);
        }

        return { go.raw(), tmp.raw() };
    };

    auto createBar = [&](const char* name, IL2CPP::Color color) -> void* {
        auto go = CloneAndStrip(tmpTemplate, name);
        if (!go.raw()) return nullptr;
        go.GetTransform().SetParent(containerT, false);
        SetIgnoreLayout(go.raw());

        auto old = go.GetComponentByName("TMPro.TextMeshProUGUI");
        if (old.valid()) Object(old.raw()).DestroyImmediate();

        if (imageClass) {
            auto img = go.AddComponent(imageClass);
            if (img.valid()) {
                Unity::Image im(img.raw());
                im.SetColor(color);
                if (setRaycastG) {
                    bool off = false;
                    void* rp[] = { &off };
                    MethodHandler::invoke(setRaycastG, img.raw(), rp);
                }
            }
        }
        return go.raw();
    };

    auto artGO = CloneAndStrip(tmpTemplate, "nyx_MP_Art");
    if (artGO.raw()) {
        auto artT = artGO.GetTransform();
        artT.SetParent(containerT, false);
        SetIgnoreLayout(artGO.raw());

        auto artTmp = artGO.GetComponentByName("TMPro.TextMeshProUGUI");
        if (artTmp.valid()) Object(artTmp.raw()).DestroyImmediate();

        if (imageClass) {
            auto imgComp = artGO.AddComponent(imageClass);
            if (imgComp.valid()) {
                m_albumArtGO = artGO.raw();
                m_albumArtImage = imgComp.raw();
                Unity::Image img(imgComp.raw());
                img.SetColor({ 1.f, 1.f, 1.f, 0.f });
                img.SetPreserveAspect(true);
                if (setRaycastG) {
                    bool off = false;
                    void* rp[] = { &off };
                    MethodHandler::invoke(setRaycastG, imgComp.raw(), rp);
                }
            }
        }

        RectTransform artRT(artT.raw());
        artRT.SetAnchorMin({ 0.f, 1.f });
        artRT.SetAnchorMax({ 0.f, 1.f });
        artRT.SetPivot({ 0.f, 1.f });
        artRT.SetAnchoredPosition({ 10.f, -10.f });
        artRT.SetSizeDelta({ 70.f, 70.f });
    }

    {
        auto viewportGO = CloneAndStrip(tmpTemplate, "nyx_MP_TitleViewport");
        if (viewportGO.raw()) {
            auto vpT = viewportGO.GetTransform();
            vpT.SetParent(containerT, false);
            SetIgnoreLayout(viewportGO.raw());

            auto vpTmp = viewportGO.GetComponentByName("TMPro.TextMeshProUGUI");
            if (vpTmp.valid()) Object(vpTmp.raw()).DestroyImmediate();

            RectTransform vpRT(vpT.raw());
            vpRT.SetAnchorMin({ 0.f, 1.f });
            vpRT.SetAnchorMax({ 0.f, 1.f });
            vpRT.SetPivot({ 0.f, 1.f });
            vpRT.SetAnchoredPosition({ 90.f, -5.f });
            vpRT.SetSizeDelta({ 250.f, 38.f });

            try {
                auto maskClass = Class::find("UnityEngine.UI.RectMask2D");
                if (maskClass) viewportGO.AddComponent(maskClass);
            } catch (...) { FLOG("[Spotify] RectMask2D AddComponent failed"); }

            m_titleViewport = viewportGO.raw();

            auto [goRaw, tmpRaw] = createText("nyx_MP_Title", 28.f, { 1.f, 1.f, 1.f, 1.f }, 513);
            if (goRaw) {
                GameObject(goRaw).GetTransform().SetParent(vpT, false);
                m_titleTMP = tmpRaw;
                m_titleGO = goRaw;

                if (setOverflow && tmpRaw) {
                    int overflow = 0;
                    void* op[] = { &overflow };
                    MethodHandler::invoke(setOverflow, tmpRaw, op);
                }

                RectTransform rt(GameObject(goRaw).GetTransform().raw());
                rt.SetAnchorMin({ 0.f, 0.f });
                rt.SetAnchorMax({ 0.f, 1.f });
                rt.SetPivot({ 0.f, 0.5f });
                rt.SetAnchoredPosition({ 0.f, 0.f });
                rt.SetSizeDelta({ 2000.f, 0.f });

                if (tmpRaw) TMP_Text(tmpRaw).SetText(std::string("Media Controls"));
            }
        }
    }

    {
        auto [goRaw, tmpRaw] = createText("nyx_MP_Artist", 24.f, { 1.f, 1.f, 1.f, 1.f }, 513);
        if (goRaw) {
            m_artistTMP = tmpRaw;
            RectTransform rt(GameObject(goRaw).GetTransform().raw());
            rt.SetAnchorMin({ 0.f, 1.f });
            rt.SetAnchorMax({ 0.f, 1.f });
            rt.SetPivot({ 0.f, 1.f });
            rt.SetAnchoredPosition({ 90.f, -40.f });
            rt.SetSizeDelta({ 250.f, 36.f });
        }
    }

    {
        auto [goRaw, tmpRaw] = createText("nyx_MP_Album", 13.f, { 1.f, 1.f, 1.f, 1.f }, 513);
        if (goRaw) {
            m_albumTMP = tmpRaw;
            GameObject(goRaw).SetActive(false);
        }
    }

    {
        auto [goRaw, tmpRaw] = createText("nyx_MP_Time", 18.f, { 0.8f, 0.8f, 0.8f, 1.f }, 516);
        if (goRaw) {
            m_timeTMP = tmpRaw;
            RectTransform rt(GameObject(goRaw).GetTransform().raw());
            rt.SetAnchorMin({ 1.f, 1.f });
            rt.SetAnchorMax({ 1.f, 1.f });
            rt.SetPivot({ 1.f, 1.f });
            rt.SetAnchoredPosition({ -70.f, -72.f });
            rt.SetSizeDelta({ 120.f, 24.f });
        }
    }

    {
        auto bgRaw = createBar("nyx_MP_ProgressBG", { 0.2f, 0.2f, 0.2f, 0.6f });
        if (bgRaw) {
            RectTransform rt(GameObject(bgRaw).GetTransform().raw());
            rt.SetAnchorMin({ 0.f, 1.f });
            rt.SetAnchorMax({ 0.f, 1.f });
            rt.SetPivot({ 0.f, 1.f });
            rt.SetAnchoredPosition({ 10.f, -100.f });
            rt.SetSizeDelta({ 340.f, 5.f });
        }
    }

    {
        auto fillRaw = createBar("nyx_MP_ProgressFill", { 1.f, 1.f, 1.f, 1.f });
        if (fillRaw) {
            m_progressFillGO = fillRaw;
            RectTransform rt(GameObject(fillRaw).GetTransform().raw());
            rt.SetAnchorMin({ 0.f, 1.f });
            rt.SetAnchorMax({ 0.f, 1.f });
            rt.SetPivot({ 0.f, 1.f });
            rt.SetAnchoredPosition({ 10.f, -100.f });
            rt.SetSizeDelta({ 0.f, 5.f });
        }
    }

    struct BtnDef { const char* name; uint32_t iconId; const char* cacheKey; void** goPtr; float x; float y; float size; };
    BtnDef buttons[] = {
        { "nyx_MP_Prev",      IDR_MP_PREV,     "mp_prev",     &m_btnPrev,       -55.f, -130.f, 36.f },
        { "nyx_MP_PlayPause", IDR_MP_PLAY,     "mp_play",     &m_btnPlayPause,    0.f, -130.f, 48.f },
        { "nyx_MP_Next",      IDR_MP_NEXT,     "mp_next",     &m_btnNext,        55.f, -130.f, 36.f },
        { "nyx_MP_VolUp",     IDR_MP_VOL_UP,   "mp_vol_up",   &m_btnVolUp,     190.f,  -45.f, 35.f },
        { "nyx_MP_VolDown",   IDR_MP_VOL_DOWN, "mp_vol_down", &m_btnVolDown,   190.f,  -85.f, 35.f },
        { "nyx_MP_VolMute",   IDR_MP_VOL_MUTE, "mp_vol_mute", &m_btnVolMute,   190.f, -125.f, 35.f },
    };

    for (auto& def : buttons) {
        auto btnGO = CloneAndStrip(tmpTemplate, def.name);
        if (!btnGO.raw()) continue;

        auto t = btnGO.GetTransform();
        t.SetParent(containerT, false);
        SetIgnoreLayout(btnGO.raw());

        auto tmp = btnGO.GetComponentByName("TMPro.TextMeshProUGUI");
        if (tmp.valid()) Object(tmp.raw()).DestroyImmediate();

        if (imageClass) {
            auto imgComp = btnGO.AddComponent(imageClass);
            if (imgComp.valid()) {
                Unity::Image img(imgComp.raw());
                void* sprite = sprites.LoadFromResource(def.iconId, def.cacheKey);
                if (sprite) img.SetSprite(sprite);
                img.SetColor({ 1.f, 1.f, 1.f, 1.f });
                img.SetPreserveAspect(true);

                if (setRaycastG) {
                    bool on = true;
                    void* rp[] = { &on };
                    MethodHandler::invoke(setRaycastG, imgComp.raw(), rp);
                }

                if (def.goPtr == &m_btnPlayPause) m_playPauseImage = imgComp.raw();
            }
        }

        RectTransform rt(t.raw());
        rt.SetAnchorMin({ 0.5f, 1.f });
        rt.SetAnchorMax({ 0.5f, 1.f });
        rt.SetPivot({ 0.5f, 0.5f });
        rt.SetSizeDelta({ def.size, def.size });
        rt.SetAnchoredPosition({ def.x, def.y });

        MakeClickable(btnGO.raw());
        *def.goPtr = btnGO.raw();
    }

    m_panelCreated = true;
    m_updateSkip = 10;
    FLOG("[Spotify] Media controls created");
}

void SpotifyModule::UpdatePanel() {
    if (!Playback::Get().HasSession()) {
        if (m_titleTMP && !m_lastTitle.empty()) {
            try { TMP_Text(m_titleTMP).SetText(std::string("Media Controls")); } catch (...) { m_titleTMP = nullptr; }
            m_lastTitle.clear();
            m_scrollX = 0.f;
            m_scrollResetAt = 0.f;
            if (m_titleGO) {
                try {
                    RectTransform rt(GameObject(m_titleGO).GetTransform().raw());
                    rt.SetAnchoredPosition({ 0.f, 0.f });
                } catch (...) { m_titleGO = nullptr; }
            }
        }
        if (m_artistTMP && !m_lastArtist.empty()) {
            try { TMP_Text(m_artistTMP).SetText(std::string("")); } catch (...) { m_artistTMP = nullptr; }
            m_lastArtist.clear();
        }
        if (m_albumTMP && !m_lastAlbum.empty()) {
            try { TMP_Text(m_albumTMP).SetText(std::string("")); } catch (...) { m_albumTMP = nullptr; }
            m_lastAlbum.clear();
        }
        if (m_timeTMP && !m_lastTime.empty()) {
            try { TMP_Text(m_timeTMP).SetText(std::string("")); } catch (...) { m_timeTMP = nullptr; }
            m_lastTime.clear();
        }
        if (m_progressFillGO) {
            try {
                GameObject go(m_progressFillGO);
                if (go.valid() && go.IsValid())
                    RectTransform(go.GetTransform().raw()).SetSizeDelta({ 0.f, 5.f });
            } catch (...) { m_progressFillGO = nullptr; }
        }
        return;
    }

    auto info = Playback::Get().GetMediaInfo();

    if (info.title != m_lastTitle) {
        m_lastTitle = info.title;
        m_scrollX = 0.f;
        m_scrollResetAt = 0.f;
    }

    if (m_titleTMP) {
        std::string display = m_lastTitle.empty() ? std::string("Media Controls") : m_lastTitle;
        constexpr float kCharWidth = 15.f;
        constexpr int kMaxVisible = 16;
        std::string sep = "          ";

        bool needsScroll = (int)display.size() > kMaxVisible;

        if (needsScroll && m_scrollResetAt == 0.f) {
            m_scrollResetAt = (float)(display.size() + sep.size()) * kCharWidth;
            TMP_Text(m_titleTMP).SetText(display + sep + display + sep);
        } else if (!needsScroll && m_scrollResetAt != -1.f) {
            m_scrollResetAt = -1.f;
            TMP_Text(m_titleTMP).SetText(display);
            if (m_titleGO) {
                RectTransform rt(GameObject(m_titleGO).GetTransform().raw());
                rt.SetAnchoredPosition({ 0.f, 0.f });
            }
        }

        if (m_scrollResetAt > 0.f && m_titleGO) {
            m_scrollX += kScrollSpeed * Time::GetDeltaTime();
            if (m_scrollX >= m_scrollResetAt) m_scrollX -= m_scrollResetAt;
            RectTransform rt(GameObject(m_titleGO).GetTransform().raw());
            rt.SetAnchoredPosition({ -m_scrollX, 0.f });
        }
    }

    if (info.artist != m_lastArtist) {
        m_lastArtist = info.artist;
        if (m_artistTMP)
            TMP_Text(m_artistTMP).SetText(info.artist);
    }

    if (info.album != m_lastAlbum) {
        m_lastAlbum = info.album;
        if (m_albumTMP)
            TMP_Text(m_albumTMP).SetText(info.album);
    }

    if (m_timeTMP && info.durationSeconds > 0.0) {
        int pos = static_cast<int>(info.positionSeconds);
        int dur = static_cast<int>(info.durationSeconds);
        char buf[32];
        std::snprintf(buf, sizeof(buf), "%d:%02d/%d:%02d", pos / 60, pos % 60, dur / 60, dur % 60);
        std::string timeStr(buf);
        if (timeStr != m_lastTime) {
            m_lastTime = timeStr;
            TMP_Text(m_timeTMP).SetText(timeStr);
        }
    }

    if (m_progressFillGO && info.durationSeconds > 0.0) {
        float progress = static_cast<float>(info.positionSeconds / info.durationSeconds);
        if (progress < 0.f) progress = 0.f;
        if (progress > 1.f) progress = 1.f;
        try {
            GameObject go(m_progressFillGO);
            if (go.valid() && go.IsValid())
                RectTransform(go.GetTransform().raw()).SetSizeDelta({ 340.f * progress, 5.f });
        } catch (...) {}
    }

    if (m_playPauseImage && info.isPlaying != m_lastPlaying) {
        m_lastPlaying = info.isPlaying;
        auto& spriteLoader = SpriteLoader::Get();
        void* sprite = info.isPlaying
            ? spriteLoader.LoadFromResource(IDR_MP_PAUSE, "mp_pause")
            : spriteLoader.LoadFromResource(IDR_MP_PLAY, "mp_play");
        if (sprite) {
            Unity::Image img(m_playPauseImage);
            img.SetSprite(sprite);
        }
    }

    if (m_albumArtImage && info.thumbnailHash != 0 && info.thumbnailHash != m_thumbHash) {
        m_thumbHash = info.thumbnailHash;
        try {
            std::string cacheKey = "mp_thumb_" + std::to_string(info.thumbnailHash);
            void* sprite = SpriteLoader::Get().LoadFromMemory(
                cacheKey, info.thumbnailData.data(), info.thumbnailData.size());
            if (sprite) {
                Unity::Image img(m_albumArtImage);
                img.SetSprite(sprite);
                img.SetColor({ 1.f, 1.f, 1.f, 1.f });
                img.SetPreserveAspect(true);
            }
        }
        catch (...) {}
    }
}

void SpotifyModule::HandleClicks() {
    if (!Input::GetMouseButtonDown(0)) return;

    IL2CPP::Vector3 mousePos = Input::GetMousePosition();

    void* camRaw = nullptr;
    auto canvasClass = Class::find("UnityEngine.Canvas");
    if (canvasClass) {
        auto qm = GameObject::Find("Canvas_QuickMenu(Clone)");
        if (qm.valid()) {
            auto cc = qm.GetComponent(canvasClass);
            if (cc.valid()) {
                static auto gwc = MethodHandler::resolve("UnityEngine.Canvas", "get_worldCamera", 0);
                if (gwc) camRaw = MethodHandler::invoke<void*>(gwc, cc.raw());
            }
        }
    }
    if (!camRaw) return;
    Camera uiCam(camRaw);

    struct { void* go; uint8_t key; } checks[] = {
        { m_btnPrev,      VK_MEDIA_PREV_TRACK },
        { m_btnPlayPause, VK_MEDIA_PLAY_PAUSE },
        { m_btnNext,      VK_MEDIA_NEXT_TRACK },
        { m_btnVolDown,   VK_VOLUME_DOWN },
        { m_btnVolMute,   VK_VOLUME_MUTE },
        { m_btnVolUp,     VK_VOLUME_UP },
    };

    for (auto& c : checks) {
        if (!c.go) continue;
        try {
            GameObject go(c.go);
            if (!go.valid() || !go.IsValid()) continue;
            auto t = go.GetTransform();
            if (!t.valid()) continue;

            IL2CPP::Vector3 worldPos = t.GetPosition();
            IL2CPP::Vector3 screenPos = uiCam.WorldToScreenPoint(worldPos);

            float dx = mousePos.x - screenPos.x;
            float dy = mousePos.y - screenPos.y;
            if (dx * dx + dy * dy < 625.f) {
                SendMediaKey(c.key);
                return;
            }
        } catch (...) {}
    }
}

void SpotifyModule::OnSetupQuickMenu(uint32_t moduleId, uint32_t categoryPageId) {
    s_instance = this;
    m_moduleId = moduleId;
    m_categoryPageId = categoryPageId;

    auto& qmEx = QuickMenuEx::Get();
    qmEx.set_subpage_nav_icon_vrc(moduleId, categoryPageId, Bootstrap::Sprite::Bundle_FileAudio);
}

} // namespace UNIx
