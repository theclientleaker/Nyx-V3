#include <Core/DiscordRPC/DiscordRPC.hpp>
#include <Core/FileLog/FileLog.hpp>
#include <chrono>
#include <cstring>
#include <sstream>

namespace UNIx {

    DiscordRPC& DiscordRPC::Get() {
        static DiscordRPC instance;
        return instance;
    }

    bool DiscordRPC::Connect() {
        if (m_connected) return true;

        for (int i = 0; i < 10; ++i) {
            std::string pipeName = "\\\\.\\pipe\\discord-ipc-" + std::to_string(i);
            m_pipe = CreateFileA(pipeName.c_str(), GENERIC_READ | GENERIC_WRITE,
                0, nullptr, OPEN_EXISTING, 0, nullptr);
            if (m_pipe != INVALID_HANDLE_VALUE) {
                FLOG("[DiscordRPC] Connected to pipe {}", i);
                break;
            }
        }

        if (m_pipe == INVALID_HANDLE_VALUE) return false;

        std::string handshake = "{\"v\":1,\"client_id\":\"" + GetApplicationId() + "\"}";
        if (!Send(0, handshake)) {
            Disconnect();
            return false;
        }

        if (!Recv()) {
            Disconnect();
            return false;
        }

        m_connected = true;
        FLOG("[DiscordRPC] Handshake complete");
        return true;
    }

    void DiscordRPC::Disconnect() {
        if (m_pipe != INVALID_HANDLE_VALUE) {
            CloseHandle(m_pipe);
            m_pipe = INVALID_HANDLE_VALUE;
        }
        m_connected = false;
    }

    bool DiscordRPC::Send(int opcode, const std::string& json) {
        if (m_pipe == INVALID_HANDLE_VALUE) return false;

        uint32_t header[2];
        header[0] = static_cast<uint32_t>(opcode);
        header[1] = static_cast<uint32_t>(json.size());

        DWORD written = 0;
        if (!WriteFile(m_pipe, header, sizeof(header), &written, nullptr) || written != sizeof(header))
            return false;
        if (!WriteFile(m_pipe, json.data(), static_cast<DWORD>(json.size()), &written, nullptr))
            return false;

        return true;
    }

    bool DiscordRPC::Recv() {
        if (m_pipe == INVALID_HANDLE_VALUE) return false;

        uint32_t header[2] = {};
        DWORD bytesRead = 0;
        if (!ReadFile(m_pipe, header, sizeof(header), &bytesRead, nullptr) || bytesRead < sizeof(header))
            return false;

        uint32_t len = header[1];
        if (len > 0 && len < 65536) {
            std::string buf(len, '\0');
            ReadFile(m_pipe, buf.data(), len, &bytesRead, nullptr);
        }

        return true;
    }

    void DiscordRPC::Start() {
        if (m_started) return;
        m_started = true;
        m_startTime = std::chrono::duration_cast<std::chrono::seconds>(
            std::chrono::system_clock::now().time_since_epoch()).count();
        FLOG("[DiscordRPC] Started");
    }

    void DiscordRPC::Stop() {
        if (!m_started) return;
        m_started = false;
        Disconnect();
        FLOG("[DiscordRPC] Stopped");
    }

    void DiscordRPC::SetWorld(const std::string& worldName, const std::string& instanceId,
                              const std::string& accessType, int playerCount,
                              const std::string& thumbnailUrl, int maxPlayers) {
        m_worldName = worldName;
        m_instanceId = instanceId;
        m_accessType = accessType;
        m_thumbnailUrl = thumbnailUrl;
        m_playerCount = playerCount;
        m_maxPlayers = maxPlayers;
        m_inWorld = true;
        m_dirty = true;
    }

    void DiscordRPC::SetLobby() {
        m_inWorld = false;
        m_worldName.clear();
        m_instanceId.clear();
        m_accessType.clear();
        m_thumbnailUrl.clear();
        m_playerCount = 0;
        m_maxPlayers = 0;
        m_dirty = true;
    }

    void DiscordRPC::SetUsername(const std::string& name) {
        if (m_username != name) {
            m_username = name;
            m_dirty = true;
        }
    }

    std::string DiscordRPC::JsonEscape(const std::string& s) {
        std::string out;
        out.reserve(s.size());
        for (char c : s) {
            switch (c) {
            case '"':  out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:   out += c; break;
            }
        }
        return out;
    }

    std::string DiscordRPC::BuildPresenceJson() {
        std::string details, state, largeText, smallText;

        if (m_inWorld) {
            details = m_worldName;

            std::string playerStr;
            if (m_maxPlayers > 0)
                playerStr = std::to_string(m_playerCount) + "/" + std::to_string(m_maxPlayers) + " Players";
            else
                playerStr = std::to_string(m_playerCount) + " Players";

            state = playerStr;

            largeText = m_username.empty() ? "nyx" : m_username;
            smallText = "VRChat";
        } else {
            details = "In Menus";
            state = "Idle";
            largeText = m_username.empty() ? "nyx" : m_username;
            smallText = "VRChat";
        }

        std::ostringstream ss;
        ss << "{\"cmd\":\"SET_ACTIVITY\",\"args\":{\"pid\":" << GetCurrentProcessId()
           << ",\"activity\":{"
           << "\"details\":\"" << JsonEscape(details) << "\""
           << ",\"state\":\"" << JsonEscape(state) << "\""
           << ",\"timestamps\":{\"start\":" << m_startTime << "}"
           << ",\"assets\":{"
           << "\"large_image\":\"nyx_logo\""
           << ",\"large_text\":\"" << JsonEscape(largeText) << "\""
           << ",\"small_image\":\"vrchat\""
           << ",\"small_text\":\"" << JsonEscape(smallText) << "\""
           << "}"
           << "}},\"nonce\":\"" << m_nonce++ << "\"}";

        return ss.str();
    }

    void DiscordRPC::UpdatePresence() {
        std::string json = BuildPresenceJson();
        if (!Send(1, json)) {
            FLOG("[DiscordRPC] Send failed, reconnecting");
            Disconnect();
        }
    }

    void DiscordRPC::Update() {
        if (!m_started) return;

        if (!m_connected) {
            if (!Connect()) return;
            m_dirty = true;
        }

        if (m_dirty) {
            UpdatePresence();
            m_dirty = false;
        }
    }

} // namespace UNIx
