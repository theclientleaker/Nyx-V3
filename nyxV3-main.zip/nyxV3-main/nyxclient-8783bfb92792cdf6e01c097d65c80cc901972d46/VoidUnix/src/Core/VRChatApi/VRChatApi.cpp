#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#include <winhttp.h>

#include <Core/VRChatApi/VRChatApi.hpp>
#include <Core/FileLog/FileLog.hpp>

#include <IL2CPP.Module/include/il2cpp_module.hpp>
#include <IL2CPP.Module/include/System/String.hpp>

#pragma comment(lib, "winhttp.lib")

namespace UNIx {

    static const wchar_t* kVrcHost = L"api.vrchat.cloud";
    static constexpr size_t kMaxHandledNotifications = 500;

    VRChatApi& VRChatApi::Get() {
        static VRChatApi instance;
        return instance;
    }

    VRChatApi::~VRChatApi() {
        StopNotificationPoller();
        JoinFireThreads();
        CloseHttpSession();
    }

    void VRChatApi::EnsureHttpSession() {
        std::lock_guard lock(m_sessionMutex);
        if (m_hSession) return;
        m_hSession = WinHttpOpen(L"VRC.Core.BestHTTP",
            WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
        if (!m_hSession) return;
        m_hConnect = WinHttpConnect(static_cast<HINTERNET>(m_hSession), kVrcHost, INTERNET_DEFAULT_HTTPS_PORT, 0);
        if (!m_hConnect) {
            WinHttpCloseHandle(static_cast<HINTERNET>(m_hSession));
            m_hSession = nullptr;
        }
    }

    void VRChatApi::CloseHttpSession() {
        std::lock_guard lock(m_sessionMutex);
        if (m_hConnect) { WinHttpCloseHandle(static_cast<HINTERNET>(m_hConnect)); m_hConnect = nullptr; }
        if (m_hSession) { WinHttpCloseHandle(static_cast<HINTERNET>(m_hSession)); m_hSession = nullptr; }
    }

    void VRChatApi::TrackNotification(const std::string& id) {
        m_handledNotifSet.insert(id);
        m_handledNotifOrder.push_back(id);
        if (m_handledNotifOrder.size() > kMaxHandledNotifications) {
            size_t toRemove = m_handledNotifOrder.size() / 2;
            for (size_t i = 0; i < toRemove; ++i)
                m_handledNotifSet.erase(m_handledNotifOrder[i]);
            m_handledNotifOrder.erase(m_handledNotifOrder.begin(), m_handledNotifOrder.begin() + toRemove);
        }
    }

    void VRChatApi::JoinFireThreads() {
        std::lock_guard lock(m_fireThreadMutex);
        for (auto& t : m_fireThreads) {
            if (t.joinable()) t.join();
        }
        m_fireThreads.clear();
    }

    std::string VRChatApi::GetAuthToken() {
        static IL2CPP::Module::Class credClass;
        static bool searched = false;
        if (!searched) {
            searched = true;
            credClass = IL2CPP::Module::Class::find("VRC.Core.ApiCredentials");
        }
        if (!credClass) return "";

        auto field = credClass.get_field("authToken");
        if (!field) return "";

        void* strPtr = nullptr;
        field.get_static_value(&strPtr);
        if (!strPtr) return "";

        return IL2CPP::Module::System::String(strPtr).to_string();
    }

    std::string VRChatApi::ExtractJsonString(const std::string& json, const std::string& key) {
        std::string search = "\"" + key + "\"";
        size_t pos = json.find(search);
        if (pos == std::string::npos) return "";

        size_t colon = json.find(':', pos + search.size());
        if (colon == std::string::npos) return "";

        size_t qStart = json.find('"', colon + 1);
        if (qStart == std::string::npos) return "";

        size_t qEnd = qStart + 1;
        while (qEnd < json.size()) {
            if (json[qEnd] == '"' && json[qEnd - 1] != '\\') break;
            ++qEnd;
        }
        if (qEnd >= json.size()) return "";

        return json.substr(qStart + 1, qEnd - qStart - 1);
    }

    std::string VRChatApi::VrcApiRequest(const wchar_t* method, const std::string& path, const std::string& body) {
        std::string authToken = GetAuthToken();
        if (authToken.empty()) {
            FLOG("[VRChatApi] No auth token available");
            return "";
        }

        EnsureHttpSession();
        if (!m_hConnect) return "";

        std::wstring wpath(path.begin(), path.end());
        HINTERNET hRequest = WinHttpOpenRequest(static_cast<HINTERNET>(m_hConnect), method, wpath.c_str(),
            nullptr, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, WINHTTP_FLAG_SECURE);
        if (!hRequest) return "";

        std::wstring wAuth(authToken.begin(), authToken.end());
        std::wstring headers = L"Cookie: auth=" + wAuth + L"\r\nUser-Agent: VRC.Core.BestHTTP";
        if (!body.empty())
            headers += L"\r\nContent-Type: application/json";

        LPVOID bodyPtr = body.empty() ? WINHTTP_NO_REQUEST_DATA : const_cast<char*>(body.c_str());
        DWORD bodyLen = static_cast<DWORD>(body.size());

        BOOL sent = WinHttpSendRequest(hRequest, headers.c_str(), static_cast<DWORD>(headers.size()),
            bodyPtr, bodyLen, bodyLen, 0);

        std::string response;
        if (sent && WinHttpReceiveResponse(hRequest, nullptr)) {
            DWORD bytesAvailable = 0;
            std::vector<char> buf(8192);
            while (WinHttpQueryDataAvailable(hRequest, &bytesAvailable) && bytesAvailable > 0) {
                if (bytesAvailable > buf.size()) buf.resize(bytesAvailable);
                DWORD bytesRead = 0;
                WinHttpReadData(hRequest, buf.data(), bytesAvailable, &bytesRead);
                response.append(buf.data(), bytesRead);
            }
        }

        WinHttpCloseHandle(hRequest);
        return response;
    }

    void VRChatApi::SendInvite(const std::string& targetUserId, const std::string& instanceId) {
        std::string worldId = instanceId;
        size_t colon = worldId.find(':');
        if (colon != std::string::npos)
            worldId = worldId.substr(0, colon);

        std::string body = "{\"instanceId\":\"" + instanceId + "\",\"worldId\":\"" + worldId + "\",\"worldName\":\"\"}";
        std::string path = "/api/1/invite/" + targetUserId;

        {
            std::lock_guard lock(m_fireThreadMutex);
            std::erase_if(m_fireThreads, [](std::thread& t) {
                if (!t.joinable()) return true;
                if (WaitForSingleObject(t.native_handle(), 0) == WAIT_OBJECT_0) {
                    t.join();
                    return true;
                }
                return false;
            });
            m_fireThreads.emplace_back([this, path, body]() {
                FLOG("[VRChatApi] Sending invite: {}", path);
                std::string resp = VrcApiRequest(L"POST", path, body);
                FLOG("[VRChatApi] Invite response: {}", resp.substr(0, 200));
            });
        }
    }

    void VRChatApi::RequestInvite(const std::string& targetUserId) {
        std::string path = "/api/1/requestInvite/" + targetUserId;

        {
            std::lock_guard lock(m_fireThreadMutex);
            std::erase_if(m_fireThreads, [](std::thread& t) {
                if (!t.joinable()) return true;
                if (WaitForSingleObject(t.native_handle(), 0) == WAIT_OBJECT_0) {
                    t.join();
                    return true;
                }
                return false;
            });
            m_fireThreads.emplace_back([this, path]() {
                FLOG("[VRChatApi] Requesting invite: {}", path);
                std::string resp = VrcApiRequest(L"POST", path, "{}");
                FLOG("[VRChatApi] RequestInvite response: {}", resp.substr(0, 200));
            });
        }
    }

    void VRChatApi::HideNotification(const std::string& notificationId) {
        std::string path = "/api/1/auth/user/notifications/" + notificationId + "/hide";
        FLOG("[VRChatApi] Hiding notification: {}", notificationId);
        VrcApiRequest(L"PUT", path);
    }

    void VRChatApi::SetInviteAcceptedCallback(InviteCallback cb) {
        std::lock_guard lock(m_mutex);
        m_inviteCallback = std::move(cb);
    }

    void VRChatApi::SetFriendStatusCallback(FriendStatusCallback cb) {
        std::lock_guard lock(m_mutex);
        m_friendStatusCallback = std::move(cb);
    }

    std::vector<std::pair<std::string, std::string>> VRChatApi::ExtractFriends(const std::string& json) {
        std::vector<std::pair<std::string, std::string>> result;
        size_t pos = 0;
        while (pos < json.size()) {
            size_t objStart = json.find('{', pos);
            if (objStart == std::string::npos) break;

            int depth = 0;
            size_t objEnd = objStart;
            for (size_t i = objStart; i < json.size(); ++i) {
                if (json[i] == '{') ++depth;
                else if (json[i] == '}') {
                    --depth;
                    if (depth == 0) { objEnd = i; break; }
                }
            }
            if (depth != 0) break;

            std::string obj = json.substr(objStart, objEnd - objStart + 1);
            pos = objEnd + 1;

            std::string id = ExtractJsonString(obj, "id");
            std::string name = ExtractJsonString(obj, "displayName");
            if (!id.empty() && !name.empty())
                result.push_back({ id, name });
        }
        return result;
    }

    void VRChatApi::PollFriendStatus() {
        std::string resp = VrcApiRequest(L"GET", "/api/1/auth/user/friends?offline=false&n=100");
        if (resp.empty() || resp[0] != '[') return;

        auto friends = ExtractFriends(resp);
        std::set<std::string> currentOnline;
        std::unordered_map<std::string, std::string> idToName;
        for (auto& [id, name] : friends) {
            currentOnline.insert(id);
            idToName[id] = name;
        }

        FriendStatusCallback cb;
        {
            std::lock_guard lock(m_mutex);
            cb = m_friendStatusCallback;
            for (auto& [id, name] : idToName)
                m_friendNames[id] = name;
        }

        if (m_friendsInitialized && cb) {
            for (auto& id : currentOnline) {
                if (!m_onlineFriends.count(id))
                    cb(idToName[id], true);
            }
            for (auto& id : m_onlineFriends) {
                if (!currentOnline.count(id)) {
                    auto it = idToName.find(id);
                    std::string name = (it != idToName.end()) ? it->second : id;
                    cb(name, false);
                }
            }
        }

        m_onlineFriends = std::move(currentOnline);
        m_friendsInitialized = true;
    }

    void VRChatApi::ExpectInviteFrom(const std::string& userId) {
        std::lock_guard lock(m_mutex);
        m_expectedInviteFrom.insert(userId);
        FLOG("[VRChatApi] Expecting invite from: {}", userId);
    }

    void VRChatApi::StartNotificationPoller() {
        if (m_polling.exchange(true)) return;
        m_pollThread = std::thread(&VRChatApi::PollLoop, this);
        FLOG("[VRChatApi] Notification poller started");
        StartWebSocket();
    }

    void VRChatApi::StopNotificationPoller() {
        StopWebSocket();
        if (!m_polling.exchange(false)) return;
        if (m_pollThread.joinable()) m_pollThread.join();
        FLOG("[VRChatApi] Notification poller stopped");
    }

    void VRChatApi::PollLoop() {
        while (m_polling) {
            for (int i = 0; i < 50 && m_polling; ++i)
                Sleep(100);
            if (!m_polling) break;

            std::string resp = VrcApiRequest(L"GET", "/api/1/auth/user/notifications?type=invite&sent=false");
            if (resp.empty() || resp[0] != '[') continue;

            size_t pos = 0;
            while (pos < resp.size()) {
                size_t objStart = resp.find('{', pos);
                if (objStart == std::string::npos) break;

                int depth = 0;
                size_t objEnd = objStart;
                for (size_t i = objStart; i < resp.size(); ++i) {
                    if (resp[i] == '{') ++depth;
                    else if (resp[i] == '}') {
                        --depth;
                        if (depth == 0) { objEnd = i; break; }
                    }
                }
                if (depth != 0) break;

                std::string obj = resp.substr(objStart, objEnd - objStart + 1);
                pos = objEnd + 1;

                std::string type = ExtractJsonString(obj, "type");
                if (type != "invite") continue;

                std::string notifId = ExtractJsonString(obj, "id");
                if (notifId.empty()) continue;

                {
                    std::lock_guard lock(m_mutex);
                    if (m_handledNotifSet.count(notifId)) continue;
                    TrackNotification(notifId);
                }

                std::string details = ExtractJsonString(obj, "details");
                std::string unescaped;
                for (size_t i = 0; i < details.size(); ++i) {
                    if (details[i] == '\\' && i + 1 < details.size()) {
                        unescaped += details[i + 1];
                        ++i;
                    } else {
                        unescaped += details[i];
                    }
                }
                std::string worldId = ExtractJsonString(unescaped, "worldId");
                std::string senderUserId = ExtractJsonString(obj, "senderUserId");

                FLOG("[VRChatApi] Found invite from {}, world: {}, id: {}", senderUserId, worldId, notifId);

                {
                    std::lock_guard lock(m_mutex);
                    if (!m_expectedInviteFrom.count(senderUserId)) {
                        FLOG("[VRChatApi] Ignoring unexpected invite from: {}", senderUserId);
                        continue;
                    }
                    m_expectedInviteFrom.erase(senderUserId);
                }

                if (!worldId.empty()) {
                    InviteCallback cb;
                    {
                        std::lock_guard lock(m_mutex);
                        cb = m_inviteCallback;
                    }
                    if (cb) {
                        FLOG("[VRChatApi] Joining world from requested invite: {}", worldId);
                        cb(worldId);
                    }
                }

                HideNotification(notifId);
            }
        }
    }

    std::string VRChatApi::UnescapeJson(const std::string& s) {
        std::string result;
        result.reserve(s.size());
        for (size_t i = 0; i < s.size(); ++i) {
            if (s[i] == '\\' && i + 1 < s.size()) {
                result += s[i + 1];
                ++i;
            } else {
                result += s[i];
            }
        }
        return result;
    }

    void VRChatApi::HandlePipelineEvent(const std::string& type, const std::string& content) {
        std::string inner = UnescapeJson(content);

        if (type == "friend-online") {
            std::string userId = ExtractJsonString(inner, "userId");
            std::string displayName = ExtractJsonString(inner, "displayName");
            if (userId.empty()) return;

            FriendStatusCallback cb;
            {
                std::lock_guard lock(m_mutex);
                if (!displayName.empty())
                    m_friendNames[userId] = displayName;
                bool wasOffline = !m_onlineFriends.count(userId);
                m_onlineFriends.insert(userId);
                cb = wasOffline ? m_friendStatusCallback : nullptr;
            }
            if (cb) {
                std::string name = displayName.empty() ? userId : displayName;
                cb(name, true);
            }
        }
        else if (type == "friend-offline") {
            std::string userId = ExtractJsonString(inner, "userId");
            if (userId.empty()) return;

            FriendStatusCallback cb;
            std::string displayName;
            {
                std::lock_guard lock(m_mutex);
                bool wasOnline = m_onlineFriends.count(userId) > 0;
                m_onlineFriends.erase(userId);
                auto it = m_friendNames.find(userId);
                displayName = (it != m_friendNames.end()) ? it->second : userId;
                cb = wasOnline ? m_friendStatusCallback : nullptr;
            }
            if (cb) cb(displayName, false);
        }
        else if (type == "friend-location") {
            std::string userId = ExtractJsonString(inner, "userId");
            std::string displayName = ExtractJsonString(inner, "displayName");
            if (!userId.empty() && !displayName.empty()) {
                std::lock_guard lock(m_mutex);
                m_friendNames[userId] = displayName;
            }
        }
    }

    void VRChatApi::StartWebSocket() {
        if (m_wsRunning.exchange(true)) return;
        m_wsThread = std::thread(&VRChatApi::WebSocketLoop, this);
        FLOG("[VRChatApi] Pipeline WebSocket started");
    }

    void VRChatApi::StopWebSocket() {
        if (!m_wsRunning.exchange(false)) return;
        {
            std::lock_guard lock(m_mutex);
            if (m_wsHandle) {
                WinHttpCloseHandle(static_cast<HINTERNET>(m_wsHandle));
                m_wsHandle = nullptr;
            }
        }
        if (m_wsThread.joinable()) m_wsThread.join();
        FLOG("[VRChatApi] Pipeline WebSocket stopped");
    }

    void VRChatApi::WebSocketLoop() {
        int wsReconnects = 0;
        while (m_wsRunning) {
            std::string authToken = GetAuthToken();
            if (authToken.empty()) {
                for (int i = 0; i < 100 && m_wsRunning; ++i) Sleep(100);
                continue;
            }

            PollFriendStatus();

            HINTERNET hSession = WinHttpOpen(L"VRC.Core.BestHTTP",
                WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
            if (!hSession) {
                for (int i = 0; i < 50 && m_wsRunning; ++i) Sleep(100);
                continue;
            }

            HINTERNET hConnect = WinHttpConnect(hSession, L"pipeline.vrchat.cloud", INTERNET_DEFAULT_HTTPS_PORT, 0);
            if (!hConnect) {
                WinHttpCloseHandle(hSession);
                for (int i = 0; i < 50 && m_wsRunning; ++i) Sleep(100);
                continue;
            }

            std::wstring wAuth(authToken.begin(), authToken.end());
            std::wstring wsPath = L"/?authToken=" + wAuth;

            HINTERNET hRequest = WinHttpOpenRequest(hConnect, L"GET", wsPath.c_str(),
                nullptr, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, WINHTTP_FLAG_SECURE);
            if (!hRequest) {
                WinHttpCloseHandle(hConnect);
                WinHttpCloseHandle(hSession);
                for (int i = 0; i < 50 && m_wsRunning; ++i) Sleep(100);
                continue;
            }

            WinHttpSetOption(hRequest, WINHTTP_OPTION_UPGRADE_TO_WEB_SOCKET, nullptr, 0);

            BOOL sent = WinHttpSendRequest(hRequest, WINHTTP_NO_ADDITIONAL_HEADERS, 0,
                WINHTTP_NO_REQUEST_DATA, 0, 0, 0);
            if (!sent || !WinHttpReceiveResponse(hRequest, nullptr)) {
                WinHttpCloseHandle(hRequest);
                WinHttpCloseHandle(hConnect);
                WinHttpCloseHandle(hSession);
                for (int i = 0; i < 100 && m_wsRunning; ++i) Sleep(100);
                continue;
            }

            HINTERNET hWebSocket = WinHttpWebSocketCompleteUpgrade(hRequest, 0);
            WinHttpCloseHandle(hRequest);
            if (!hWebSocket) {
                WinHttpCloseHandle(hConnect);
                WinHttpCloseHandle(hSession);
                for (int i = 0; i < 100 && m_wsRunning; ++i) Sleep(100);
                continue;
            }

            {
                std::lock_guard lock(m_mutex);
                m_wsHandle = hWebSocket;
            }

            wsReconnects = 0;

            std::string msgBuffer;
            BYTE recvBuf[4096];
            while (m_wsRunning) {
                DWORD bytesRead = 0;
                WINHTTP_WEB_SOCKET_BUFFER_TYPE bufType;
                DWORD err = WinHttpWebSocketReceive(hWebSocket, recvBuf, sizeof(recvBuf), &bytesRead, &bufType);
                if (err != NO_ERROR) break;
                if (bufType == WINHTTP_WEB_SOCKET_CLOSE_BUFFER_TYPE) break;

                msgBuffer.append(reinterpret_cast<char*>(recvBuf), bytesRead);

                if (bufType == WINHTTP_WEB_SOCKET_UTF8_MESSAGE_BUFFER_TYPE ||
                    bufType == WINHTTP_WEB_SOCKET_BINARY_MESSAGE_BUFFER_TYPE) {
                    std::string type = ExtractJsonString(msgBuffer, "type");
                    std::string content = ExtractJsonString(msgBuffer, "content");
                    if (!type.empty() && !content.empty())
                        HandlePipelineEvent(type, content);
                    msgBuffer.clear();
                }
            }

            bool needClose = false;
            {
                std::lock_guard lock(m_mutex);
                if (m_wsHandle == hWebSocket) {
                    m_wsHandle = nullptr;
                    needClose = true;
                }
            }
            if (needClose) {
                WinHttpWebSocketClose(hWebSocket, WINHTTP_WEB_SOCKET_SUCCESS_CLOSE_STATUS, nullptr, 0);
                WinHttpCloseHandle(hWebSocket);
            }
            WinHttpCloseHandle(hConnect);
            WinHttpCloseHandle(hSession);

            if (m_wsRunning) {
                ++wsReconnects;
                if (wsReconnects <= 1)
                    FLOG("[VRChatApi] Pipeline disconnected, reconnecting...");
                int delaySec = (std::min)(wsReconnects * 5, 30);
                for (int i = 0; i < delaySec * 10 && m_wsRunning; ++i) Sleep(100);
            }
        }
    }

} // namespace UNIx
