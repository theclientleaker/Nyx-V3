#pragma once

#include <Core/BaseModule.hpp>

namespace UNIx {

    class InstanceHistoryModule : public BaseModule {
    public:
        InstanceHistoryModule();

        void OnRender() override;
        void OnEnable() override;
        void OnDisable() override;
    };

} // namespace UNIx
