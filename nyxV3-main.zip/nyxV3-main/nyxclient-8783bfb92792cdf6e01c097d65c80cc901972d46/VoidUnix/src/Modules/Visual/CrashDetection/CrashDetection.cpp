#include <Modules/Visual/CrashDetection/CrashDetection.hpp>
#include <Core/ModuleManager.hpp>
#include <Core/Globals.hpp>
#include <Core/FileLog/FileLog.hpp>

#include <IL2CPP.Module/include/Unity/Transform.hpp>
#include <IL2CPP.Module/include/Unity/Component.hpp>
#include <IL2CPP.Module/include/Unity/TMP_Text.hpp>
#include <IL2CPP.Module/include/Unity/Time.hpp>
#include <IL2CPP.Module/include/MethodHandler.hpp>

#include <Bootstrap.Module/include/VRChat/VRCPlayer.hpp>
#include <Bootstrap.Module/include/VRChat/PlayerNameplate.hpp>
#include <Bootstrap.Module/include/VRChat/VRCPlayerApi.hpp>

#include <ThirdParty/imgui/imgui.h>

#include <cmath>

using namespace IL2CPP::Module;
using namespace IL2CPP::Module::Unity;

namespace UNIx {

    static bool SafeIsValid(void* ptr) {
        if (!ptr) return false;
        __try {
            void* cachedPtr = *reinterpret_cast<void**>(reinterpret_cast<uintptr_t>(ptr) + 0x10);
            if (!cachedPtr) return false;
            uintptr_t addr = reinterpret_cast<uintptr_t>(cachedPtr);
            return addr >= 0x10000 && addr <= 0x7FFFFFFF0000;
        } __except(EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }

    static constexpr float kInitDelay = 10.0f;
    static constexpr float kRetryDelay = 3.0f;
    static constexpr int kMaxRetries = 10;

    CrashDetectionModule::CrashDetectionModule()
        : BaseModule("Crash Detection", "Detect crashed players via frozen position + velocity", 0, "Visual") {
        m_enabled = true;
        m_crashThreshold = 12.f;
    }

    void CrashDetectionModule::OnEnable() {}
    void CrashDetectionModule::OnDisable() { CleanupAll(); }

    void CrashDetectionModule::OnPlayerJoinComplete(IL2CPP::VRChat::Player player) {
        if (!player) return;
        auto api = player.GetVRCPlayerApi();
        if (!api) return;

        int id = api.GetPlayerId();
        auto localApi = GetLocalPlayerApi();
        if (localApi && localApi.GetPlayerId() == id) return;

        CrashDetectionState state;
        state.playerId = id;
        state.pendingTimer = kInitDelay;
        m_states.push_back(std::move(state));
    }

    void CrashDetectionModule::OnPlayerLeave(IL2CPP::VRChat::Player player) {
        if (!player) return;
        auto api = player.GetVRCPlayerApi();
        if (!api) return;
        int id = api.GetPlayerId();

        for (auto it = m_states.begin(); it != m_states.end(); ++it) {
            if (it->playerId == id) {
                CleanupState(*it);
                m_states.erase(it);
                break;
            }
        }
    }

    void CrashDetectionModule::OnSceneLoad(int, int) {
        CleanupAll();
    }

    void CrashDetectionModule::CleanupState(CrashDetectionState& state) {
        if (state.statusTextObject && SafeIsValid(state.statusTextObject)) {
            Object obj(state.statusTextObject);
            __try { obj.Destroy(); } __except(EXCEPTION_EXECUTE_HANDLER) {}
        }
        state.statusTextObject = nullptr;
    }

    void CrashDetectionModule::CleanupAll() {
        for (auto& s : m_states)
            CleanupState(s);
        m_states.clear();
    }

    void CrashDetectionModule::InitializePlayer(CrashDetectionState& state) {
        auto playerApi = IL2CPP::VRChat::VRCPlayerApi::GetPlayerById(state.playerId);
        if (!playerApi.raw()) { state.pendingTimer = kRetryDelay; state.retryCount++; return; }

        auto vrcPlayer = playerApi.GetVRCPlayer();
        if (!vrcPlayer.raw()) { state.pendingTimer = kRetryDelay; state.retryCount++; return; }

        auto nameplate = vrcPlayer.GetNameplate();
        if (!nameplate.raw()) { state.pendingTimer = kRetryDelay; state.retryCount++; return; }

        auto contentsGO = nameplate.GetContents();
        if (!contentsGO.valid()) { state.pendingTimer = kRetryDelay; state.retryCount++; return; }

        auto quickStats = nameplate.GetQuickStats();
        if (!quickStats.valid()) { state.pendingTimer = kRetryDelay; state.retryCount++; return; }

        auto qsT = quickStats.GetTransform();
        if (!qsT.valid()) { state.pendingTimer = kRetryDelay; state.retryCount++; return; }
        auto trustTextT = qsT.Find("Trust Text");
        if (!trustTextT.valid()) { state.pendingTimer = kRetryDelay; state.retryCount++; return; }
        auto trustTextGO = trustTextT.GetGameObject();
        if (!trustTextGO.valid()) { state.pendingTimer = kRetryDelay; state.retryCount++; return; }

        auto clone = Object(trustTextGO.raw()).Instantiate();
        if (!clone.raw() || !clone.IsValid()) { state.pendingTimer = kRetryDelay; state.retryCount++; return; }

        GameObject cloneGo(clone.raw());
        cloneGo.SetActive(true);

        auto contentsT = contentsGO.GetTransform();
        auto cloneT = cloneGo.GetTransform();
        cloneT.SetParent(contentsT, false);
        cloneT.SetLocalPosition({ 0.f, 120.f, 0.f });
        cloneT.SetLocalScale({ 1.f, 1.f, 1.f });

        auto tmpComp = cloneGo.GetComponentByName("TMPro.TextMeshProUGUI");
        if (!tmpComp.valid())
            tmpComp = cloneGo.GetComponentByName("TextMeshProUGUI");
        if (!tmpComp.valid()) { state.pendingTimer = kRetryDelay; state.retryCount++; return; }

        TMP_Text tmp(tmpComp.raw());

        static auto setAutoSize = MethodHandler::resolve("TMPro.TMP_Text", "set_enableAutoSizing", 1);
        if (setAutoSize) {
            bool autoSizeOff = false;
            void* params[] = { &autoSizeOff };
            MethodHandler::invoke<void>(setAutoSize, tmpComp.raw(), params);
        }

        tmp.SetRichText(true);
        tmp.SetFontSize(32.f);
        tmp.SetText("");

        auto styleComp = cloneGo.GetComponentByName("VRC.UI.Core.Styles.StyleElement");
        if (styleComp.valid())
            Object(styleComp.raw()).Destroy();

        state.statusTextObject = clone.raw();
        state.initialized = true;
        state.isCrashed = false;
        state.hasFirstSample = false;
        state.frozenTimer = 0.f;
        state.validSampleCount = 0;
    }

    void CrashDetectionModule::UpdateStatusText(CrashDetectionState& state) {
        if (!state.statusTextObject || !SafeIsValid(state.statusTextObject)) {
            state.initialized = false;
            state.statusTextObject = nullptr;
            state.pendingTimer = kRetryDelay;
            state.retryCount = 0;
            return;
        }

        GameObject go(state.statusTextObject);
        auto tmpComp = go.GetComponentByName("TMPro.TextMeshProUGUI");
        if (!tmpComp.valid())
            tmpComp = go.GetComponentByName("TextMeshProUGUI");
        if (!tmpComp.valid()) return;

        TMP_Text tmp(tmpComp.raw());

        if (state.isCrashed)
            tmp.SetText("<color=#FF0000>Crashed</color>");
        else
            tmp.SetText("");
    }

    void CrashDetectionModule::OnUpdate() {
        if (!InRoom()) return;

        float dt = Time::GetDeltaTime();

        for (auto& state : m_states) {
            if (!state.initialized && state.retryCount < kMaxRetries) {
                state.pendingTimer -= dt;
                if (state.pendingTimer <= 0.f)
                    InitializePlayer(state);
                continue;
            }
            if (!state.initialized) continue;

            try {
                auto playerApi = IL2CPP::VRChat::VRCPlayerApi::GetPlayerById(state.playerId);
                if (!playerApi.valid() || !playerApi.IsValid()) continue;

                auto pos = playerApi.GetPosition();

                bool posAtOrigin = (pos.x == 0.f && pos.y == 0.f && pos.z == 0.f);
                if (posAtOrigin) continue;

                if (state.validSampleCount < 3) {
                    state.lastPos = pos;
                    state.validSampleCount++;
                    state.frozenTimer = 0.f;
                    continue;
                }

                float dx = pos.x - state.lastPos.x;
                float dy = pos.y - state.lastPos.y;
                float dz = pos.z - state.lastPos.z;
                float distSq = dx * dx + dy * dy + dz * dz;

                if (distSq == 0.f) {
                    state.frozenTimer += dt;
                } else {
                    state.frozenTimer = 0.f;
                }

                state.lastPos = pos;

                bool wasCrashed = state.isCrashed;
                state.isCrashed = (state.frozenTimer >= m_crashThreshold);

                if (state.isCrashed != wasCrashed)
                    UpdateStatusText(state);
            } catch (...) {}
        }
    }

    void CrashDetectionModule::OnRender() {
        ImGui::SliderFloat("Crash Threshold (s)", &m_crashThreshold, 10.f, 120.f, "%.0f");

        int total = static_cast<int>(m_states.size());
        int crashed = 0;
        for (auto& s : m_states)
            if (s.isCrashed) crashed++;
        ImGui::Text("Tracking: %d players, %d crashed", total, crashed);
    }

} // namespace UNIx
