#pragma once
#include <Core/BaseModule.hpp>
#include <string>
#include <vector>
#include <cstdint>

namespace UNIx {

    class MusicPlayerModule : public BaseModule {
    public:
        MusicPlayerModule()
            : BaseModule("Music Player", "Control system media playback from QM", 0, "UI") {
            m_enabled = true;
            m_showInQuickMenu = false;
        }

        void OnEnable() override;
        void OnDisable() override;
        void OnUpdate() override;
        void OnSceneLoad(int scene, int loadMode) override;
        void OnSetupQuickMenu(uint32_t moduleId, uint32_t categoryPageId) override;

        static MusicPlayerModule* s_instance;

    private:
        void CreatePanel();
        void UpdatePanel();
        void HandleClicks();
        void DestroyPanel();
        void ResetState();

        static void SendMediaKey(uint8_t vk);

        static void SetTMP(void* tmpComp, const char* text, float fontSize = 0.f);
        static void* CloneTMP(void* templateGO, void* parent, const char* name);

        bool m_panelCreated = false;
        int m_initDelay = 0;
        int m_updateSkip = 0;

        void* m_panelGO = nullptr;
        void* m_albumArtGO = nullptr;
        void* m_albumArtImage = nullptr;
        void* m_titleTMP = nullptr;

        void* m_btnPrev = nullptr;
        void* m_btnPlayPause = nullptr;
        void* m_btnNext = nullptr;
        void* m_btnVolDown = nullptr;
        void* m_btnVolMute = nullptr;
        void* m_btnVolUp = nullptr;
        void* m_playPauseImage = nullptr;
        bool m_lastPlaying = false;

        void* m_lastSelected = nullptr;
        uint64_t m_thumbHash = 0;
        std::string m_lastTitle;

        uint32_t m_moduleId = 0;
        uint32_t m_categoryPageId = 0;
    };

}
