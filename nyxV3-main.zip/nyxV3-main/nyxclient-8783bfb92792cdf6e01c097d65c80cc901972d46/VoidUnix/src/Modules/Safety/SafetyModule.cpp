#include <Modules/Safety/SafetyModule.hpp>
#include <Core/Globals.hpp>
#include <Core/FileLog/FileLog.hpp>
#include <Core/SpriteLoader/SpriteLoader.hpp>
#include <IL2CPP.Module/include/Reflection.hpp>
#include <IL2CPP.Module/include/MethodHandler.hpp>
#include <IL2CPP.Module/include/ManagedObject.hpp>
#include <IL2CPP.Module/include/System/String.hpp>
#include <Bootstrap.Module/include/bootstrap_module.hpp>
#include <Core/DashboardConsole/DashboardConsole.hpp>
#include "resource.h"

namespace Hooking::Module {
    extern const Hooking::HookVtable* get_connection_vtable() noexcept;
}

using namespace IL2CPP::Module;

namespace UNIx {

    SafetyModule* SafetyModule::s_instance = nullptr;

    bool SafetyModule::PrefixBlockEvent67(void* thisPtr, void* eventData) {
        if (!eventData) return true;
        ManagedObject ev(eventData);
        auto code = ev.get_property<uint8_t>("Code");
        if (code == 67) {
            FLOG("[Safety] Blocked Event 67");
            return false;
        }
        return true;
    }

    bool SafetyModule::PrefixLimitParticle(void* thisPtr) {
        if (!thisPtr) return true;
        ManagedObject ps(thisPtr);
        auto maxParticles = ps.get_property<int>("maxParticles");
        if (maxParticles > 50000) {
            ps.set_property<int>("maxParticles", 1000);
            FLOG("[Safety] Limited particle count");
        }
        return true;
    }

    bool SafetyModule::PrefixLimitLight(void* thisPtr) {
        if (!thisPtr) return true;
        ManagedObject light(thisPtr);
        auto range = light.get_property<float>("range");
        if (range > 1000.f) {
            light.set_property<float>("range", 100.f);
            FLOG("[Safety] Limited light range");
        }
        auto intensity = light.get_property<float>("intensity");
        if (intensity > 100.f) {
            light.set_property<float>("intensity", 10.f);
        }
        return true;
    }

    bool SafetyModule::PrefixLimitCloth(void* thisPtr) {
        return true;
    }

    bool SafetyModule::PrefixLimitMaterial(void* thisPtr, void* material) {
        return true;
    }

    bool SafetyModule::PrefixValidateRenderer(void* thisPtr) {
        return true;
    }

    bool SafetyModule::PrefixBlockShader(void* name, void*& __retval) {
        return true;
    }

    bool SafetyModule::PrefixGuardDynBone(void* thisPtr) {
        return true;
    }

    bool SafetyModule::PrefixLimitDynBoneCollider(void* thisPtr) {
        return true;
    }

    bool SafetyModule::PrefixBlockPatreon(void* thisPtr) {
        return true;
    }

    bool SafetyModule::PrefixAntiBlock(void* thisPtr, void* eventData) {
        // Intercept moderation events (OnEvent) — block code 21 (moderation data)
        // which contains block/mute information
        if (!eventData) return true;
        ManagedObject ev(eventData);
        auto code = ev.get_property<uint8_t>("Code");
        // Code 21 = moderation event (block, mute, etc.)
        if (code == 21) {
            FLOG("[Safety] Blocked moderation event (anti-block)");
            return false; // Skip the event
        }
        return true;
    }

    static bool SafeDestroyPortal(void* thisPtr) {
        static auto destroyMethod = MethodHandler::resolve("UnityEngine.Object", "Destroy", 1);
        static auto getGO = MethodHandler::resolve("UnityEngine.Component", "get_gameObject", 0);
        if (destroyMethod && getGO) {
            void* go = MethodHandler::invoke<void*>(getGO, thisPtr);
            if (go) {
                void* params[] = { go };
                MethodHandler::invoke<void>(destroyMethod, nullptr, params);
                return true;
            }
        }
        return false;
    }

    bool SafetyModule::PrefixAntiPortal(void* thisPtr) {
        if (!thisPtr) return true;
        if (SafeDestroyPortal(thisPtr))
            FLOG("[Safety] Destroyed portal");
        return false;
    }

    static bool SafeCheckUdonEvent(void* eventName) {
        __try {
            if (!eventName) return true;
            wchar_t* chars = reinterpret_cast<wchar_t*>(reinterpret_cast<char*>(eventName) + 0x14);
            int len = *reinterpret_cast<int*>(reinterpret_cast<char*>(eventName) + 0x10);
            if (len <= 0 || len > 256) return false;
            for (int i = 0; i < len && i < 20; ++i) {
                if (chars[i] == L'_') return true;
            }
        } __except(EXCEPTION_EXECUTE_HANDLER) {}
        return true;
    }

    bool SafetyModule::PrefixAntiUdon(void* thisPtr, void* target, void* eventName) {
        return SafeCheckUdonEvent(eventName);
    }

    static bool SafeCheckVideoURL(void* url, bool* outBlocked) {
        __try {
            if (!url) return true;
            wchar_t* chars = reinterpret_cast<wchar_t*>(reinterpret_cast<char*>(url) + 0x14);
            int len = *reinterpret_cast<int*>(reinterpret_cast<char*>(url) + 0x10);
            if (len <= 0 || len > 2048) { *outBlocked = true; return true; }

            char buf[256] = {};
            int copyLen = len < 255 ? len : 255;
            for (int i = 0; i < copyLen; ++i)
                buf[i] = static_cast<char>(chars[i] < 128 ? chars[i] : '?');

            for (auto& c : buf) if (c >= 'A' && c <= 'Z') c += 32;

            const char* allowed[] = {
                "youtube.com", "youtu.be", "twitch.tv", "soundcloud.com",
                "vimeo.com", "nicovideo.jp", "vrchat.cloud", "assets.vrchat.com"
            };
            for (auto* site : allowed) {
                if (strstr(buf, site)) return true;
            }

            *outBlocked = true;
            return true;
        } __except(EXCEPTION_EXECUTE_HANDLER) {}
        return true;
    }

    bool SafetyModule::PrefixAntiVideoURL(void* thisPtr, void* url) {
        if (!thisPtr || !url) return true;
        bool blocked = false;
        SafeCheckVideoURL(url, &blocked);
        if (blocked) {
            FLOG("[Safety] Blocked suspicious video URL");
            return false;
        }
        return true;
    }

    static struct MeshCheckMethods {
        Method getVertexCount;
        Method getSharedMats;
        Method getSubMeshCount;
        Method getSharedMeshSMR;
        Method getSharedMeshMF;
        Method setEnabled;
        Method getGameObject;
        Method getComponent;
        Class  meshFilterClass;
        bool resolved = false;

        void Resolve() {
            if (resolved) return;
            resolved = true;
            getVertexCount = MethodHandler::resolve("UnityEngine.Mesh", "get_vertexCount", 0);
            getSharedMats = MethodHandler::resolve("UnityEngine.Renderer", "get_sharedMaterials", 0);
            getSubMeshCount = MethodHandler::resolve("UnityEngine.Mesh", "get_subMeshCount", 0);
            getSharedMeshSMR = MethodHandler::resolve("UnityEngine.SkinnedMeshRenderer", "get_sharedMesh", 0);
            getSharedMeshMF = MethodHandler::resolve("UnityEngine.MeshFilter", "get_sharedMesh", 0);
            setEnabled = MethodHandler::resolve("UnityEngine.Renderer", "set_enabled", 1);
            getGameObject = MethodHandler::resolve("UnityEngine.Component", "get_gameObject", 0);
            getComponent = MethodHandler::resolve("UnityEngine.GameObject", "GetComponent", 1);
            meshFilterClass = Class::find("UnityEngine.MeshFilter");
        }
    } s_meshMethods;

    static bool DoCheckVertexCount(void* meshRaw, int maxVerts) {
        __try {
            if (!s_meshMethods.getVertexCount || !meshRaw) return true;
            int verts = MethodHandler::invoke<int>(s_meshMethods.getVertexCount, meshRaw);
            return verts <= maxVerts;
        } __except(EXCEPTION_EXECUTE_HANDLER) { return true; }
    }

    static int DoGetMaterialCount(void* rendererRaw) {
        __try {
            if (!s_meshMethods.getSharedMats || !rendererRaw) return 0;
            void* arr = MethodHandler::invoke<void*>(s_meshMethods.getSharedMats, rendererRaw);
            if (!arr) return 0;
            return *reinterpret_cast<int*>(reinterpret_cast<char*>(arr) + 0x18);
        } __except(EXCEPTION_EXECUTE_HANDLER) { return 0; }
    }

    static int DoGetSubMeshCount(void* meshRaw) {
        __try {
            if (!s_meshMethods.getSubMeshCount || !meshRaw) return 0;
            return MethodHandler::invoke<int>(s_meshMethods.getSubMeshCount, meshRaw);
        } __except(EXCEPTION_EXECUTE_HANDLER) { return 0; }
    }

    static void* DoGetSharedMeshSMR(void* smrRaw) {
        __try {
            if (!s_meshMethods.getSharedMeshSMR || !smrRaw) return nullptr;
            return MethodHandler::invoke<void*>(s_meshMethods.getSharedMeshSMR, smrRaw);
        } __except(EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }

    static void DoDisableRenderer(void* rendererRaw) {
        __try {
            if (s_meshMethods.setEnabled && rendererRaw) {
                bool off = false;
                void* p[] = { &off };
                MethodHandler::invoke<void>(s_meshMethods.setEnabled, rendererRaw, p);
            }
        } __except(EXCEPTION_EXECUTE_HANDLER) {}
    }

    static void* DoGetMeshFromMR(void* mrRaw) {
        __try {
            if (!s_meshMethods.getGameObject || !s_meshMethods.getComponent ||
                !s_meshMethods.meshFilterClass || !s_meshMethods.getSharedMeshMF || !mrRaw)
                return nullptr;

            void* go = MethodHandler::invoke<void*>(s_meshMethods.getGameObject, mrRaw);
            if (!go) return nullptr;

            auto mfType = s_meshMethods.meshFilterClass.get_type();
            if (!mfType) return nullptr;
            void* typeObj = mfType.raw();
            void* p[] = { typeObj };
            void* mf = MethodHandler::invoke<void*>(s_meshMethods.getComponent, go, p);
            if (!mf) return nullptr;

            return MethodHandler::invoke<void*>(s_meshMethods.getSharedMeshMF, mf);
        } __except(EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
    }

    bool SafetyModule::PrefixAntiMeshCrashSMR(void* thisPtr, bool enabling) {
        if (!thisPtr || !enabling) return true;
        s_meshMethods.Resolve();

        void* mesh = DoGetSharedMeshSMR(thisPtr);
        if (!mesh) return true;

        if (!DoCheckVertexCount(mesh, 500000)) {
            FLOG("[Safety] Blocked renderer (too many verts)");
            return false;
        }

        int matCount = DoGetMaterialCount(thisPtr);
        if (matCount > 32) {
            FLOG("[Safety] Blocked renderer (too many materials)");
            return false;
        }

        return true;
    }

    bool SafetyModule::PrefixAntiMeshCrashMR(void* thisPtr, bool enabling) {
        (void)thisPtr; (void)enabling;
        return true;
    }

    void __cdecl SafetyModule::QmToggleCallback(uint32_t buttonId, bool isOn) {
        if (!s_instance) return;
        for (size_t i = 0; i < s_instance->m_toggleIds.size(); ++i) {
            if (s_instance->m_toggleIds[i] == buttonId) {
                if (i < s_instance->m_hooks.size()) {
                    s_instance->m_hooks[i].enabled = isOn;
                    if (isOn)
                        s_instance->InstallHook(i);
                    else
                        s_instance->RemoveHook(i);
                }
                return;
            }
        }
    }

    void SafetyModule::OnSetupQuickMenu(uint32_t moduleId, uint32_t categoryPageId) {
        s_instance = this;
        auto& qm = Bootstrap::Module::QuickMenu::Get();
        uint32_t root = qm.create_sub_page(moduleId, categoryPageId, "Antis");
        void* icon = SpriteLoader::Get().LoadFromResource(IDR_ICON_SHIELD_CHECK, "shield_check");
        if (icon) qm.set_page_icon(moduleId, root, icon);

        m_hooks.clear();
        m_toggleIds.clear();

        struct HookDef {
            const char* label;
            const char* className;
            const char* methodName;
            int paramCount;
        };

        HookDef defs[] = {
            {"Anti Event 67",                "LoadBalancingClient", "OnEvent", 1},                           // 0
            {"Anti Block",                   "LoadBalancingClient", "OnEvent", 1},                           // 1
            {"Anti Crash Material",          "UnityEngine.Renderer", "set_material", 1},                     // 2
            {"Anti Crash Shader",            "UnityEngine.Shader", "Find", 1},                               // 3
            {"Anti Crash DynBone Collider",  "DynamicBoneCollider", "OnValidate", 0},                        // 4
            {"Anti Portal",                  "VRC.SDKBase.VRC_PortalMarker", "Awake", 0},                    // 5
            {"Anti Udon Events",             "VRC.Udon.UdonBehaviour", "SendCustomNetworkEvent", 2},         // 6
            {"Anti Video URL",               "VRC.SDK3.Video.Components.Base.BaseVRCVideoPlayer", "PlayURL", 1}, // 7
            {"Anti Mesh Crash",              "UnityEngine.Renderer", "set_enabled", 1},                      // 8
        };

        for (auto& def : defs) {
            ProtectionHook ph;
            ph.name = def.label;
            ph.className = def.className;
            ph.methodName = def.methodName;
            ph.paramCount = def.paramCount;
            m_hooks.push_back(ph);

            uint32_t tid = qm.add_toggle(moduleId, root, def.label, false, QmToggleCallback);
            m_toggleIds.push_back(tid);
        }
    }

    void SafetyModule::InstallHook(size_t index) {
        if (index >= m_hooks.size()) return;
        auto& ph = m_hooks[index];
        if (ph.active) return;
        if (!g_hook || !g_hook->valid()) return;

        auto klass = Class::find(ph.className);
        if (!klass) {
            if (ph.className == std::string("DynamicBoneCollider"))
                klass = Class::find("VRC.Dynamics.PhysBoneCollider");
            if (ph.className == std::string("DynamicBone"))
                klass = Class::find("VRC.Dynamics.PhysBone");
        }

        if (!klass) {
            FLOG("[Safety] Class not found: " + ph.className);
            return;
        }

        auto method = MethodHandler::resolve(ph.className, ph.methodName, ph.paramCount);
        if (!method) {
            FLOG("[Safety] Method not found: " + ph.className + "." + ph.methodName);
            return;
        }

        void* ptr = method.pointer();
        uint32_t hookId = 0;

        switch (index) {
        case 0:  hookId = g_hook->create_prefix("Safety_Event67", ptr, PrefixBlockEvent67); break;
        case 1:  hookId = g_hook->create_prefix("Safety_AntiBlock", ptr, PrefixAntiBlock); break;
        case 2:  hookId = g_hook->create_prefix("Safety_Material", ptr, PrefixLimitMaterial); break;
        case 3:  hookId = g_hook->create_prefix("Safety_Shader", ptr, PrefixBlockShader); break;
        case 4:  hookId = g_hook->create_prefix("Safety_DynBoneCol", ptr, PrefixLimitDynBoneCollider); break;
        case 5:  hookId = g_hook->create_prefix("Safety_Portal", ptr, PrefixAntiPortal); break;
        case 6:  hookId = g_hook->create_prefix("Safety_Udon", ptr, PrefixAntiUdon); break;
        case 7:  hookId = g_hook->create_prefix("Safety_VideoURL", ptr, PrefixAntiVideoURL); break;
        case 8:  hookId = g_hook->create_prefix("Safety_MeshCrash", ptr, PrefixAntiMeshCrashSMR); break;
        default: return;
        }

        ph.hookId = hookId;
        ph.active = (hookId != 0);

        if (ph.active)
            FLOG("[Safety] Installed: " + ph.name);
        else
            FLOG("[Safety] Failed to install: " + ph.name);
    }

    void SafetyModule::RemoveHook(size_t index) {
        if (index >= m_hooks.size()) return;
        auto& ph = m_hooks[index];
        if (!ph.active) return;
        if (!g_hook || !g_hook->valid()) return;

        g_hook->remove_hook(ph.hookId);
        ph.active = false;
        ph.hookId = 0;
        FLOG("[Safety] Removed: " + ph.name);
    }

    void SafetyModule::OnUpdate() {
    }

    void SafetyModule::OnDisable() {
        for (size_t i = 0; i < m_hooks.size(); ++i) {
            if (m_hooks[i].active)
                RemoveHook(i);
        }
    }

} // namespace UNIx
