#include <Modules/Visual/OrbitCamera/OrbitCameraModule.hpp>
#include <Core/FileLog/FileLog.hpp>

#include <IL2CPP.Module/include/Unity/Camera.hpp>
#include <IL2CPP.Module/include/Unity/GameObject.hpp>
#include <IL2CPP.Module/include/Unity/Transform.hpp>
#include <IL2CPP.Module/include/Unity/Input.hpp>
#include <IL2CPP.Module/include/Unity/Object.hpp>
#include <IL2CPP.Module/include/Unity/Component.hpp>
#include <IL2CPP.Module/include/Reflection.hpp>
#include <IL2CPP.Module/include/MethodHandler.hpp>
#include <Bootstrap.Module/include/VRChat/VRCPlayerApi.hpp>
#include <Bootstrap.Module/include/VRChat/VRCPlayer.hpp>

#include <cmath>
#include <algorithm>

using namespace IL2CPP::Module;
using namespace IL2CPP::Module::Unity;

namespace UNIx {

    static constexpr float kPi = 3.14159265f;
    static constexpr float kDeg2Rad = kPi / 180.f;

    OrbitCameraModule::OrbitCameraModule()
        : BaseModule("Orbit Camera", "Hold Mouse4 to orbit around your body (Minecraft style)", 0, "Visual") {
        m_enabled = true;
        m_showInQuickMenu = true;
    }

    void OrbitCameraModule::CreateCamera() {
        if (m_camCreated) return;

        auto mainCam = Camera::GetMain();
        if (!mainCam.valid()) return;
        auto mainT = mainCam.GetTransform();
        if (!mainT.valid()) return;
        auto parentT = mainT.GetParent();
        if (!parentT.valid()) return;

        auto camClass = Class::find("UnityEngine.Camera");
        if (!camClass) return;

        auto mainGO = mainT.GetGameObject();
        if (!mainGO.valid()) return;

        auto clone = mainGO.Instantiate();
        if (!clone.raw() || !clone.IsValid()) return;

        GameObject go(clone.raw());
        go.SetName(std::string("nyx_OrbitCam"));

        auto goT = go.GetTransform();
        for (int i = goT.GetChildCount() - 1; i >= 0; --i) {
            auto childT = goT.GetChild(i);
            if (childT.valid()) {
                auto childGO = childT.GetGameObject();
                if (childGO.valid()) Object(childGO.raw()).Destroy();
            }
        }

        const char* stripComps[] = {
            "VRC.UserCamera.CameraFlip",
            "UnityEngine.AudioListener",
            "VRC.UserCamera",
            "UnityEngine.FlareLayer",
        };
        for (auto* comp : stripComps) {
            auto c = go.GetComponentByName(comp);
            if (c.valid()) Object(c.raw()).Destroy();
        }

        goT.SetParent(parentT, false);

        auto camComp = go.GetComponent(camClass);
        if (!camComp.valid()) camComp = go.AddComponent(camClass);
        if (!camComp.valid()) { Object(clone.raw()).Destroy(); return; }

        static auto setEnabled = MethodHandler::resolve("UnityEngine.Behaviour", "set_enabled", 1);
        if (setEnabled) {
            bool off = false;
            void* p[] = { &off };
            MethodHandler::invoke(setEnabled, camComp.raw(), p);
        }

        static auto setFov = MethodHandler::resolve("UnityEngine.Camera", "set_fieldOfView", 1);
        if (setFov) {
            float fov = 75.f;
            void* p[] = { &fov };
            MethodHandler::invoke(setFov, camComp.raw(), p);
        }

        static auto setNear = MethodHandler::resolve("UnityEngine.Camera", "set_nearClipPlane", 1);
        if (setNear) {
            float val = 0.01f;
            void* p[] = { &val };
            MethodHandler::invoke(setNear, camComp.raw(), p);
        }

        static auto setDepth = MethodHandler::resolve("UnityEngine.Camera", "set_depth", 1);
        if (setDepth) {
            float depth = 100.f;
            void* p[] = { &depth };
            MethodHandler::invoke(setDepth, camComp.raw(), p);
        }

        static auto setCull = MethodHandler::resolve("UnityEngine.Camera", "set_cullingMask", 1);
        if (setCull) {
            int mask = -1;
            void* p[] = { &mask };
            MethodHandler::invoke(setCull, camComp.raw(), p);
        }

        go.SetActive(true);
        m_cam = camComp.raw();
        m_camCreated = true;
    }

    void OrbitCameraModule::DestroyCamera() {
        if (!m_cam) return;
        try {
            Component comp(m_cam);
            if (comp.valid()) {
                static auto getGO = MethodHandler::resolve("UnityEngine.Component", "get_gameObject", 0);
                if (getGO) {
                    void* goRaw = MethodHandler::invoke<void*>(getGO, m_cam);
                    if (goRaw) Object(goRaw).Destroy();
                }
            }
        } catch (...) {}
        m_cam = nullptr;
        m_camCreated = false;
    }

    void OrbitCameraModule::OnUpdate() {
        if (!InRoom()) {
            if (m_orbiting) {
                m_orbiting = false;
                m_cam = nullptr;
                m_camCreated = false;
            }
            return;
        }

        bool sideButtonHeld = (GetAsyncKeyState(VK_XBUTTON1) & 0x8000) != 0;

        static auto setEnabled = MethodHandler::resolve("UnityEngine.Behaviour", "set_enabled", 1);

        if (sideButtonHeld && !m_orbiting) {
            CreateCamera();
            if (!m_camCreated || !m_cam) return;

            auto mainCam = Camera::GetMain();
            if (!mainCam.valid()) return;
            auto mainT = mainCam.GetTransform();
            if (!mainT.valid()) return;

            auto fwd = mainT.GetForward();
            m_yaw = std::atan2(fwd.x, fwd.z) / kDeg2Rad;
            m_pitch = 15.f;

            auto vrcPlayer = IL2CPP::VRChat::VRCPlayer::GetLocalPlayer();
            if (vrcPlayer.valid()) {
                auto go = vrcPlayer.GetGameObject();
                if (go.valid()) {
                    auto playerT = go.GetTransform();
                    if (playerT.valid())
                        m_savedPlayerRot = playerT.GetRotation();
                }
            }

            if (setEnabled) {
                bool on = true;
                void* p[] = { &on };
                MethodHandler::invoke(setEnabled, m_cam, p);
            }

            m_orbiting = true;
        }

        if (!sideButtonHeld && m_orbiting) {
            m_orbiting = false;
            if (m_cam && setEnabled) {
                bool off = false;
                void* p[] = { &off };
                MethodHandler::invoke(setEnabled, m_cam, p);
            }
            return;
        }

        if (!m_orbiting || !m_cam) return;

        float mouseX = Input::GetAxisRaw("Mouse X");
        float mouseY = Input::GetAxisRaw("Mouse Y");

        m_yaw += mouseX * m_sensitivity;
        m_pitch -= mouseY * m_sensitivity;
        m_pitch = std::clamp(m_pitch, -80.f, 80.f);

        float scroll = Input::GetAxisRaw("Mouse ScrollWheel");
        if (scroll != 0.f) {
            m_distance -= scroll * 2.f;
            m_distance = std::clamp(m_distance, 0.5f, 15.f);
        }

        auto api = GetLocalPlayerApi();
        if (!api.valid()) return;
        IL2CPP::Vector3 playerPos = api.GetPosition();
        IL2CPP::Vector3 center = { playerPos.x, playerPos.y + m_heightOffset, playerPos.z };

        float yawRad = m_yaw * kDeg2Rad;
        float pitchRad = m_pitch * kDeg2Rad;

        float cosPitch = std::cos(pitchRad);
        IL2CPP::Vector3 camPos = {
            center.x - std::sin(yawRad) * cosPitch * m_distance,
            center.y + std::sin(pitchRad) * m_distance,
            center.z - std::cos(yawRad) * cosPitch * m_distance,
        };

        static auto getGO = MethodHandler::resolve("UnityEngine.Component", "get_gameObject", 0);
        if (!getGO) return;
        void* camGORaw = MethodHandler::invoke<void*>(getGO, m_cam);
        if (!camGORaw) return;

        GameObject camGO(camGORaw);
        auto camT = camGO.GetTransform();
        if (!camT.valid()) return;

        camT.SetPosition(camPos);

        IL2CPP::Vector3 dir = {
            center.x - camPos.x,
            center.y - camPos.y,
            center.z - camPos.z
        };
        float len = std::sqrt(dir.x * dir.x + dir.y * dir.y + dir.z * dir.z);
        if (len > 0.001f) {
            dir.x /= len; dir.y /= len; dir.z /= len;
        }

        static auto lookRotation = MethodHandler::resolve("UnityEngine.Quaternion", "LookRotation", 1);
        if (lookRotation) {
            void* p[] = { &dir };
            IL2CPP::Quaternion rot = MethodHandler::invoke<IL2CPP::Quaternion>(lookRotation, nullptr, p);
            camT.SetRotation(rot);
        }
    }

    void OrbitCameraModule::OnLateUpdate() {
        if (!m_orbiting || !InRoom()) {
            if (m_orbiting) {
                m_orbiting = false;
                m_cam = nullptr;
                m_camCreated = false;
            }
            return;
        }

        auto vrcPlayer = IL2CPP::VRChat::VRCPlayer::GetLocalPlayer();
        if (!vrcPlayer.valid()) {
            m_orbiting = false;
            return;
        }
        auto go = vrcPlayer.GetGameObject();
        if (!go.valid()) return;
        auto playerT = go.GetTransform();
        if (!playerT.valid()) return;

        playerT.SetRotation(m_savedPlayerRot);

        auto fwdT = playerT.Find("ForwardDirection");
        if (fwdT.valid())
            fwdT.SetLocalRotation(IL2CPP::Quaternion().Euler(0.f, 0.f, 0.f));
    }

    void OrbitCameraModule::OnDisable() {
        if (m_orbiting && m_cam) {
            static auto setEnabled = MethodHandler::resolve("UnityEngine.Behaviour", "set_enabled", 1);
            if (setEnabled) {
                bool off = false;
                void* p[] = { &off };
                MethodHandler::invoke(setEnabled, m_cam, p);
            }
        }
        m_orbiting = false;
    }

    void OrbitCameraModule::OnSceneLoad(int, int) {
        m_cam = nullptr;
        m_camCreated = false;
        m_orbiting = false;
        m_yaw = 0.f;
        m_pitch = 15.f;
        m_distance = 3.f;
    }

} // namespace UNIx
