#define WIN32_LEAN_AND_MEAN
#include <Windows.h>

#include <Core/NameplateConfigManager/NameplateConfigManager.hpp>
#include <Core/ApiClient/ApiClient.hpp>
#include <Core/FileLog/FileLog.hpp>
#include <algorithm>
#include <cstdlib>
#include <cstring>
#include <string_view>

namespace UNIx {

    NameplateConfigManager& NameplateConfigManager::Get() {
        static NameplateConfigManager instance;
        return instance;
    }

    NameplateConfigManager::~NameplateConfigManager() {
        Stop();
    }

    void NameplateConfigManager::Start() {
        if (m_running.exchange(true)) return;
        FLOG("[NameplateConfigManager] Starting fetch thread");
        m_thread = std::thread(&NameplateConfigManager::FetchLoop, this);
    }

    void NameplateConfigManager::Stop() {
        FLOG("[NameplateConfigManager] Stopping fetch thread");
        m_running = false;
        if (m_thread.joinable())
            m_thread.join();
    }

    std::optional<NameplateConfig> NameplateConfigManager::GetConfigForUser(const std::string& userId) const {
        std::shared_lock lock(m_mutex);
        auto it = m_configs.find(userId);
        if (it != m_configs.end())
            return it->second;
        return std::nullopt;
    }

    void NameplateConfigManager::RequestRefresh() {
        m_refreshRequested = true;
    }

    void NameplateConfigManager::FetchLoop() {
        for (int i = 0; i < 100 && m_running && !m_refreshRequested; ++i)
            Sleep(100);
        if (m_running) FetchConfigs();
        while (m_running) {
            if (m_refreshRequested.exchange(false)) {
                FetchConfigs();
            } else {
                std::string ver = FetchVersion();
                if (!ver.empty() && ver != m_lastVersion) {
                    FLOG("[NameplateConfigManager] Version changed: {} -> {}", m_lastVersion, ver);
                    m_lastVersion = ver;
                    FetchConfigs();
                }
            }
            for (int i = 0; i < 50 && m_running; ++i) {
                if (m_refreshRequested) break;
                Sleep(100);
            }
        }
    }

    std::string NameplateConfigManager::FetchVersion() {
        return ApiClient::Get().Get("/api/nameplates/version");
    }

    void NameplateConfigManager::FetchConfigs() {
        FLOG("[NameplateConfigManager] Fetching configs...");

        std::string body = ApiClient::Get().Get("/api/nameplates", ApiAuth::Client);

        if (!body.empty()) {
            FLOG("[NameplateConfigManager] Got {} bytes, parsing", body.size());
            ParseResponse(body);
        } else {
            FLOG("[NameplateConfigManager] Empty response body");
        }
    }

    static size_t FindKey(std::string_view json, std::string_view key, char suffix) {
        size_t pos = 0;
        while (pos < json.size()) {
            size_t q = json.find('"', pos);
            if (q == std::string_view::npos) return std::string_view::npos;
            std::string_view candidate = json.substr(q + 1);
            if (candidate.size() > key.size() && candidate.substr(0, key.size()) == key) {
                size_t afterKey = q + 1 + key.size();
                if (afterKey + 1 < json.size() && json[afterKey] == '"' && json[afterKey + 1] == ':') {
                    size_t valueStart = afterKey + 2;
                    if (valueStart < json.size() && json[valueStart] == suffix)
                        return valueStart;
                }
            }
            pos = q + 1;
        }
        return std::string_view::npos;
    }

    static std::string ExtractStr(std::string_view json, std::string_view key) {
        size_t s = FindKey(json, key, '"');
        if (s == std::string_view::npos) return "";
        s += 1;
        size_t e = json.find('"', s);
        if (e == std::string_view::npos) return "";
        return std::string(json.substr(s, e - s));
    }

    static float ExtractFloat(std::string_view json, std::string_view key, float def = 0.f) {
        size_t pos = 0;
        while (pos < json.size()) {
            size_t q = json.find('"', pos);
            if (q == std::string_view::npos) return def;
            std::string_view candidate = json.substr(q + 1);
            if (candidate.size() > key.size() && candidate.substr(0, key.size()) == key) {
                size_t afterKey = q + 1 + key.size();
                if (afterKey + 1 < json.size() && json[afterKey] == '"' && json[afterKey + 1] == ':') {
                    size_t s = afterKey + 2;
                    while (s < json.size() && json[s] == ' ') s++;
                    return static_cast<float>(std::atof(json.data() + s));
                }
            }
            pos = q + 1;
        }
        return def;
    }

    static bool ExtractBool(std::string_view json, std::string_view key, bool def = false) {
        size_t pos = 0;
        while (pos < json.size()) {
            size_t q = json.find('"', pos);
            if (q == std::string_view::npos) return def;
            std::string_view candidate = json.substr(q + 1);
            if (candidate.size() > key.size() && candidate.substr(0, key.size()) == key) {
                size_t afterKey = q + 1 + key.size();
                if (afterKey + 1 < json.size() && json[afterKey] == '"' && json[afterKey + 1] == ':') {
                    size_t s = afterKey + 2;
                    while (s < json.size() && json[s] == ' ') s++;
                    if (s + 4 <= json.size())
                        return json.substr(s, 4) == "true";
                    return def;
                }
            }
            pos = q + 1;
        }
        return def;
    }

    static std::array<float, 4> ExtractColorArray(std::string_view json, std::string_view key, std::array<float, 4> def = {1.f, 1.f, 1.f, 1.f}) {
        size_t s = FindKey(json, key, '[');
        if (s == std::string_view::npos) return def;
        s += 1;
        size_t e = json.find(']', s);
        if (e == std::string_view::npos) return def;

        std::string_view arr = json.substr(s, e - s);
        std::array<float, 4> result = def;
        int idx = 0;
        while (!arr.empty() && idx < 4) {
            while (!arr.empty() && arr[0] == ' ') arr.remove_prefix(1);
            result[idx++] = static_cast<float>(std::atof(arr.data()));
            size_t comma = arr.find(',');
            if (comma == std::string_view::npos) break;
            arr.remove_prefix(comma + 1);
        }
        return result;
    }

    void NameplateConfigManager::ParseResponse(const std::string& body) {
        std::unordered_map<std::string, NameplateConfig> newConfigs;

        std::string_view view(body);
        size_t pos = 0;
        while (pos < view.size()) {
            size_t keyStart = view.find("\"usr_", pos);
            if (keyStart == std::string_view::npos) break;

            keyStart += 1;
            size_t keyEnd = view.find('"', keyStart);
            if (keyEnd == std::string_view::npos) break;
            std::string userId(view.substr(keyStart, keyEnd - keyStart));

            size_t objStart = view.find('{', keyEnd);
            if (objStart == std::string_view::npos) break;

            int depth = 0;
            size_t objEnd = objStart;
            for (size_t i = objStart; i < view.size(); ++i) {
                if (view[i] == '{') depth++;
                else if (view[i] == '}') {
                    depth--;
                    if (depth == 0) { objEnd = i; break; }
                }
            }

            std::string_view obj = view.substr(objStart, objEnd - objStart + 1);
            newConfigs[userId] = ParseSingleConfig(obj);
            pos = objEnd + 1;
        }

        FLOG("[NameplateConfigManager] Parsed {} user configs", newConfigs.size());

        std::unique_lock lock(m_mutex);
        m_configs = std::move(newConfigs);
    }

    NameplateConfig NameplateConfigManager::ParseSingleConfig(std::string_view json) {
        NameplateConfig cfg;
        cfg.enabled = ExtractBool(json, "enabled", true);
        cfg.tagColor = ExtractColorArray(json, "tagColor");
        cfg.bgColor = ExtractColorArray(json, "bgColor");
        cfg.borderColor = ExtractColorArray(json, "borderColor");
        cfg.bgScrollX = ExtractFloat(json, "bgScrollX");
        cfg.bgScrollY = ExtractFloat(json, "bgScrollY");
        cfg.autoHueShift = ExtractBool(json, "autoHueShift");
        cfg.hueShiftSpeed = ExtractFloat(json, "hueShiftSpeed", 0.25f);
        cfg.hue = ExtractFloat(json, "hue");
        cfg.saturation = ExtractFloat(json, "saturation", 1.f);
        cfg.luminance = ExtractFloat(json, "luminance");
        cfg.useTag = ExtractBool(json, "useTag", true);
        cfg.useBackground = ExtractBool(json, "useBackground", true);
        cfg.borderHueShift = ExtractBool(json, "borderHueShift");
        cfg.borderScrollX = ExtractFloat(json, "borderScrollX");
        cfg.borderScrollY = ExtractFloat(json, "borderScrollY");
        return cfg;
    }

} // namespace UNIx
