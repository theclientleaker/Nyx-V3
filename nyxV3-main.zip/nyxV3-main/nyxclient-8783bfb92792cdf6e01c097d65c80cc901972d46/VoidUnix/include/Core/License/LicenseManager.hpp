#pragma once

#include <string>

namespace UNIx {

    class LicenseManager {
    public:
        static LicenseManager& Get();

        bool Validate();

    private:
        LicenseManager() = default;

        std::string GenerateHWID();
        std::string SHA256(const std::string& input);

        struct CachedLicense {
            std::string key;
            std::string type;
            int64_t expiresAt = 0;
            int64_t lastValidated = 0;
        };

        bool ReadCache(const std::string& hwid, CachedLicense& out);
        void WriteCache(const std::string& hwid, const CachedLicense& data);
        void DeleteCache();

        std::string Encrypt(const std::string& data, const std::string& hwid);
        std::string Decrypt(const std::string& data, const std::string& hwid);

        bool ActivateOnline(const std::string& key, const std::string& hwid, CachedLicense& out, std::string& error);

        std::string PromptKey();

        std::string m_hwid;
    };

} // namespace UNIx
