#include <Modules/UI/ScreenConsole/ScreenConsoleModule.hpp>
#include <Core/QuickMenuEx.hpp>
#include <Core/Theme.hpp>
#include <algorithm>
#include <cstring>

namespace UNIx {

    ScreenConsoleModule* ScreenConsoleModule::s_instance = nullptr;

    ScreenConsoleModule::ScreenConsoleModule()
        : BaseModule("Screen Console", "On-screen log overlay", 0, "UI") {
        m_enabled = true;
        m_showInQuickMenu = true;
    }

    void __cdecl ScreenConsoleModule::QmMaxLinesCb(uint32_t, float val) {
        if (s_instance) s_instance->m_maxLines = static_cast<int>(val);
    }
    void __cdecl ScreenConsoleModule::QmFontSizeCb(uint32_t, float val) {
        if (s_instance) s_instance->m_fontSize = val;
    }
    void __cdecl ScreenConsoleModule::QmOpacityCb(uint32_t, float val) {
        if (s_instance) s_instance->m_opacity = val;
    }

    void ScreenConsoleModule::OnSetupQuickMenu(uint32_t moduleId, uint32_t categoryPageId) {
        s_instance = this;
        auto& qmEx = QuickMenuEx::Get();
        uint32_t fold = qmEx.add_foldout(moduleId, categoryPageId, "Screen Console", false, true);
        qmEx.add_slider(moduleId, fold, "Max Lines", 10.f, 80.f, static_cast<float>(m_maxLines),
            QmMaxLinesCb, "screenconsole_maxlines", "%.0f");
        qmEx.add_slider(moduleId, fold, "Font Size", 8.f, 20.f, m_fontSize,
            QmFontSizeCb, "screenconsole_fontsize", "%.0f");
        qmEx.add_slider(moduleId, fold, "Opacity", 0.1f, 1.0f, m_opacity,
            QmOpacityCb, "screenconsole_opacity", "%.2f");
    }

    void ScreenConsoleModule::PushLine(const std::string& timestamp, const std::string& message) {
        ConsoleLine line;
        line.timestamp = timestamp;
        line.message = message;
        line.level = ClassifyMessage(message);
        line.age = 0.f;

        std::lock_guard lock(m_mutex);
        m_lines.push_back(std::move(line));
        while (static_cast<int>(m_lines.size()) > m_maxLines)
            m_lines.pop_front();
    }

    ScreenConsoleModule::LogLevel ScreenConsoleModule::ClassifyMessage(const std::string& msg) {
        if (msg.find("FAILED") != std::string::npos ||
            msg.find("Failed") != std::string::npos ||
            msg.find("failed") != std::string::npos ||
            msg.find("ERROR") != std::string::npos ||
            msg.find("error") != std::string::npos ||
            msg.find("ACCESS_VIOLATION") != std::string::npos ||
            msg.find("crash") != std::string::npos)
            return LogLevel::Error;

        if (msg.find("WARN") != std::string::npos ||
            msg.find("warn") != std::string::npos ||
            msg.find("Warning") != std::string::npos ||
            msg.find("timeout") != std::string::npos ||
            msg.find("retry") != std::string::npos)
            return LogLevel::Warning;

        if (msg.find("[Debug]") != std::string::npos ||
            msg.find("debug") != std::string::npos)
            return LogLevel::Debug;

        return LogLevel::Info;
    }

    ImU32 ScreenConsoleModule::LevelColor(LogLevel level, float alpha) {
        uint8_t a = static_cast<uint8_t>(alpha * 255.f);
        switch (level) {
            case LogLevel::Error:   return IM_COL32(255, 80, 80, a);
            case LogLevel::Warning: return IM_COL32(255, 200, 60, a);
            case LogLevel::Debug:   return IM_COL32(130, 170, 255, a);
            default:                return IM_COL32(210, 215, 225, a);
        }
    }

    void ScreenConsoleModule::OnOverlay() {
        float dt = ImGui::GetIO().DeltaTime;
        float duration, fade;

        {
            std::lock_guard lock(m_mutex);
            duration = m_lineDuration;
            fade = m_fadeDuration;

            for (auto& line : m_lines)
                line.age += dt;

            while (!m_lines.empty() && m_lines.front().age >= duration + fade)
                m_lines.pop_front();
        }

        std::deque<ConsoleLine> snapshot;
        int maxLines;
        float fontSize, opacity;
        {
            std::lock_guard lock(m_mutex);
            snapshot = m_lines;
            maxLines = m_maxLines;
            fontSize = m_fontSize;
            opacity = m_opacity;
        }

        if (snapshot.empty()) return;

        auto* drawList = ImGui::GetBackgroundDrawList();
        if (!drawList) return;

        ImGuiIO& io = ImGui::GetIO();
        ImFont* font = g_fontSmallBold ? g_fontSmallBold : ImGui::GetFont();

        constexpr float kPadX = 8.f;
        constexpr float kPadY = 4.f;
        constexpr float kLineSpacing = 2.f;
        constexpr float kTimestampWidth = 75.f;

        float lineH = fontSize + kLineSpacing;
        float maxMsgW = io.DisplaySize.x * 0.42f - kPadX * 2.f - kTimestampWidth;

        struct DisplayLine {
            const ConsoleLine* src;
            std::string truncated;
            float textWidth;
        };
        std::vector<DisplayLine> display;
        display.reserve(snapshot.size());

        float widestMsg = 0.f;
        for (auto& line : snapshot) {
            DisplayLine dl;
            dl.src = &line;

            ImVec2 fullSz = font->CalcTextSizeA(fontSize, FLT_MAX, 0.f, line.message.c_str());
            if (fullSz.x <= maxMsgW) {
                dl.textWidth = fullSz.x;
            } else {
                const char* ellipsis = "...";
                ImVec2 eSz = font->CalcTextSizeA(fontSize, FLT_MAX, 0.f, ellipsis);
                float budget = maxMsgW - eSz.x;
                if (budget < 0.f) budget = 0.f;

                size_t fit = 0;
                for (size_t i = 1; i <= line.message.size(); ++i) {
                    ImVec2 sz = font->CalcTextSizeA(fontSize, FLT_MAX, 0.f,
                        line.message.c_str(), line.message.c_str() + i);
                    if (sz.x > budget) break;
                    fit = i;
                }
                dl.truncated = line.message.substr(0, fit) + ellipsis;
                dl.textWidth = font->CalcTextSizeA(fontSize, FLT_MAX, 0.f, dl.truncated.c_str()).x;
            }

            if (dl.textWidth > widestMsg) widestMsg = dl.textWidth;
            display.push_back(std::move(dl));
        }

        int lineCount = static_cast<int>(display.size());
        float totalH = lineCount * lineH + kPadY * 2.f;
        float panelW = kPadX * 2.f + kTimestampWidth + widestMsg + 10.f;
        panelW = (std::min)(panelW, io.DisplaySize.x * 0.45f);

        float panelX = io.DisplaySize.x - panelW;
        float panelY = 0.f;

        float maxAlpha = 0.f;
        for (auto& dl : display) {
            float a = 1.f;
            if (dl.src->age > duration)
                a = 1.f - (dl.src->age - duration) / fade;
            if (a > maxAlpha) maxAlpha = a;
        }

        float bgOpacity = opacity * maxAlpha;
        uint8_t bgAlpha = static_cast<uint8_t>(bgOpacity * 140.f);
        drawList->AddRectFilled(
            ImVec2(panelX, panelY),
            ImVec2(panelX + panelW, panelY + totalH),
            IM_COL32(12, 12, 18, bgAlpha), 4.f, ImDrawFlags_RoundCornersBottomLeft);

        uint8_t borderAlpha = static_cast<uint8_t>(bgOpacity * 100.f);
        drawList->AddLine(
            ImVec2(panelX, panelY),
            ImVec2(panelX, panelY + totalH),
            IM_COL32(60, 65, 90, borderAlpha), 1.f);
        drawList->AddLine(
            ImVec2(panelX, panelY + totalH),
            ImVec2(panelX + panelW, panelY + totalH),
            IM_COL32(60, 65, 90, borderAlpha), 1.f);

        float y = panelY + kPadY;
        for (auto& dl : display) {
            float lineAlpha = 1.f;
            if (dl.src->age > duration)
                lineAlpha = 1.f - (dl.src->age - duration) / fade;
            lineAlpha = (std::max)(lineAlpha, 0.f);

            float a = opacity * lineAlpha;
            float x = panelX + kPadX;

            ImU32 tsColor = IM_COL32(90, 95, 115, static_cast<uint8_t>(a * 200.f));
            drawList->AddText(font, fontSize, ImVec2(x, y), tsColor, dl.src->timestamp.c_str());

            ImU32 msgColor = LevelColor(dl.src->level, a);
            const char* text = dl.truncated.empty() ? dl.src->message.c_str() : dl.truncated.c_str();
            drawList->AddText(font, fontSize, ImVec2(x + kTimestampWidth, y), msgColor, text);

            y += lineH;
        }
    }

} // namespace UNIx
