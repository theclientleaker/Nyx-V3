#pragma once
#include <Core/BaseModule.hpp>
#include <ThirdParty/imgui/imgui.h>
#include <Bootstrap.Module/include/VRChat/APIUser.hpp>
#include <vector>
#include <string>
#include <mutex>

namespace UNIx {

    class ESPModule : public BaseModule {
    public:
        ESPModule() : BaseModule("Box ESP", "Player box ESP overlay", 0, "Visual") {}

        void OnRender() override;
        void OnOverlay() override;
        void OnUpdate() override;
        void OnSetupQuickMenu(uint32_t moduleId, uint32_t categoryPageId) override;

        static ESPModule* s_instance;
        static void __cdecl QmRenderModeCb(uint32_t id, int val);

    private:
        static ImU32 RankToESPColor(IL2CPP::VRChat::PlayerRank rank);

        enum class RenderMode : int { Box3D = 0, Box2D = 1 };
        RenderMode m_renderMode = RenderMode::Box3D;

        struct ESPEntry {
            ImVec2 corners[8];
            bool   visible[8];
            ImVec2 boxMin;
            ImVec2 boxMax;
            ImU32  color;
            std::string name;
            float distance;
        };

        std::mutex m_dataMutex;
        std::vector<ESPEntry> m_entries;
    };

} // namespace UNIx
