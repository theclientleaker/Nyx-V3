#include <Modules/UI/UIRemover/UIRemoverModule.hpp>
#include <Core/FileLog/FileLog.hpp>
#include <Core/SpriteLoader/SpriteLoader.hpp>

#include <IL2CPP.Module/include/il2cpp_module.hpp>
#include <IL2CPP.Module/include/Unity/GameObject.hpp>
#include <IL2CPP.Module/include/Unity/Transform.hpp>
#include <IL2CPP.Module/include/Unity/RectTransform.hpp>
#include <IL2CPP.Module/include/Unity/Object.hpp>
#include <IL2CPP.Module/include/Unity/Component.hpp>
#include <IL2CPP.Module/include/Unity/Behaviour.hpp>
#include <IL2CPP.Module/include/Unity/TMP_Text.hpp>
#include <IL2CPP.Module/include/ManagedObject.hpp>
#include "resource.h"

#include <string>

namespace UNIx {

    using namespace IL2CPP::Module::Unity;
    using namespace IL2CPP::Module;

    void UIRemoverModule::CreateNyxButton() {
        if (m_nyxBtnCreated) {
            if (m_nyxBtnGO) {
                GameObject go(m_nyxBtnGO);
                if (go.IsValid()) return;
            }
            m_nyxBtnGO = nullptr;
            m_nyxBtnCreated = false;
        }

        auto existing = GameObject::Find(
            "Canvas_QuickMenu(Clone)/CanvasGroup/Container/Window/QMParent/Body/Menu_QM_Launchpad/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_Nyx");
        if (existing.IsValid()) {
            m_nyxBtnGO = existing.raw();
            m_nyxBtnCreated = true;
            return;
        }

        auto shop = GameObject::Find(
            "Canvas_QuickMenu(Clone)/CanvasGroup/Container/Window/QMParent/Body/Menu_QM_Launchpad/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_Shop");
        if (!shop.IsValid()) return;

        auto shopT = shop.GetTransform();
        auto parentT = shopT.GetParent();
        if (!parentT.valid()) return;

        auto clone = shop.Instantiate();
        if (!clone.raw() || !clone.IsValid()) return;

        GameObject cloneGO(clone.raw());
        auto cloneT = cloneGO.GetTransform();
        cloneT.SetParent(parentT, false);

        cloneGO.SetName("Button_Nyx");
        cloneGO.SetActive(true);

        // Strip Shop onClick so it doesn't open the store
        auto btnClass = Class::find("UnityEngine.UI.Button");
        if (btnClass) {
            auto btnComp = cloneGO.GetComponent(btnClass);
            if (btnComp.valid()) {
                static auto getOnClick = MethodHandler::resolve("UnityEngine.UI.Button", "get_onClick", 0);
                static auto removeAll = MethodHandler::resolve("UnityEngine.Events.UnityEventBase", "RemoveAllListeners", 0);
                if (getOnClick && removeAll) {
                    auto onClick = MethodHandler::invoke<void*>(getOnClick, btnComp.raw());
                    if (onClick) MethodHandler::invoke(removeAll, onClick);
                }
            }
        }

        // Disable StyleElement on clone and children
        auto compClass = Class::find("UnityEngine.Component");
        if (compClass) {
            auto allComps = cloneGO.GetComponentsInChildren(compClass, true);
            for (auto& comp : allComps) {
                if (!comp || !comp.raw()) continue;
                try {
                    std::string className = comp.get_class_name();
                    if (className.find("StyleElement") != std::string::npos) {
                        Behaviour beh(comp.raw());
                        beh.SetEnabled(false);
                    }
                } catch (...) { continue; }
            }
        }

        // Swap icon to logo.png via ImageEx overrideSprite
        auto& sprites = SpriteLoader::Get();
        void* logoSprite = sprites.LoadFromResource(IDR_ICON_LOGO, "nyx_btn_logo");
        if (logoSprite) {
            auto iconsT = cloneT.Find("Icons/Icon");
            if (iconsT.valid()) {
                auto iconGO = iconsT.GetGameObject();
                if (iconGO.valid() && iconGO.IsValid()) {
                    auto imageExClass = Class::find("VRC.UI.ImageEx");
                    if (imageExClass) {
                        auto imageComp = iconGO.GetComponent(imageExClass);
                        if (imageComp.valid()) {
                            static auto setOverride = MethodHandler::resolve("UnityEngine.UI.Image", "set_overrideSprite", 1);
                            if (setOverride) {
                                void* sprP[] = { logoSprite };
                                MethodHandler::invoke(setOverride, imageComp.raw(), sprP);
                                FLOG("[UIRemover] Logo set via ImageEx overrideSprite");
                            }
                        }
                    }
                }
            }
        }

        // Set label
        auto tmpClass = Class::find("TMPro.TextMeshProUGUI");
        if (tmpClass) {
            auto tmpComp = cloneGO.GetComponentInChildren(tmpClass, true);
            if (tmpComp.valid()) {
                TMP_Text tmp(tmpComp.raw());
                tmp.SetText("Nyx");
            }
        }

        shop.SetActive(false);
        m_nyxBtnGO = cloneGO.raw();
        m_nyxBtnCreated = true;
        FLOG("[UIRemover] Nyx button created");
    }

    void UIRemoverModule::ApplyRemovals() {
        if (!InRoom()) return;
        if (m_applied) return;

        auto chinGO = GameObject::Find(
            "Canvas_QuickMenu(Clone)/CanvasGroup/Container/Window/QMParent/Body/Menu_QM_Launchpad/Chin");
        if (!chinGO.IsValid()) return;

        try {
            auto chinImageEx = chinGO.GetComponentByName("VRC.UI.ImageEx");
            if (chinImageEx.valid()) {
                Object(chinImageEx.raw()).Destroy();
            }

            auto headerBg = GameObject::Find(
                "Canvas_QuickMenu(Clone)/CanvasGroup/Container/Window/QMParent/Menu_QM_SocialIdentity/HeaderBackground");
            if (headerBg.IsValid()) headerBg.Destroy();

            auto safeModeGO = GameObject::Find(
                "Canvas_QuickMenu(Clone)/CanvasGroup/Container/Window/Toggle_SafeMode");
            if (safeModeGO.IsValid()) safeModeGO.SetActive(false);

            auto wallet = GameObject::Find(
                "Canvas_QuickMenu(Clone)/CanvasGroup/Container/Window/QMParent/Menu_QM_SocialIdentity/Layout/Panel_MM_Wallet/Cell_Wallet_Contents");
            if (wallet.IsValid()) wallet.SetActive(false);

            auto groups = GameObject::Find(
                "Canvas_QuickMenu(Clone)/CanvasGroup/Container/Window/QMParent/Body/Menu_QM_Launchpad/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_ViewGroups");
            if (groups.IsValid()) groups.SetActive(false);

            auto livenow = GameObject::Find(
                "Canvas_QuickMenu(Clone)/CanvasGroup/Container/Window/QMParent/Body/Menu_QM_Launchpad/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_LiveNow");
            if (livenow.IsValid()) livenow.SetActive(false);

            auto buttonlinks = GameObject::Find(
                "Canvas_QuickMenu(Clone)/CanvasGroup/Container/Window/QMParent/Body/Menu_QM_Launchpad/Header_H1/LeftItemContainer/Text_Title");
            if (buttonlinks.IsValid()) buttonlinks.SetActive(false);

            auto cat = GameObject::Find(
                "Canvas_QuickMenu(Clone)/CanvasGroup/Container/ThankYouCharacter/Character");
            if (cat.IsValid()) cat.SetActive(false);

            auto inve = GameObject::Find(
                "Canvas_QuickMenu(Clone)/CanvasGroup/Container/Window/QMParent/Body/Menu_QM_Launchpad/Header_H1/RightItemContainer/Button_QM_Inventory");
            if (inve.IsValid()) inve.SetActive(false);

            auto report = GameObject::Find(
                "Canvas_QuickMenu(Clone)/CanvasGroup/Container/Window/QMParent/Body/Menu_QM_Launchpad/Header_H1/RightItemContainer/Button_QM_Report");
            if (report.IsValid()) report.SetActive(false);

            auto pageUnix = GameObject::Find(
                "Canvas_QuickMenu(Clone)/CanvasGroup/Container/Window/Page_Buttons_QM/HorizontalLayoutGroup/Page_UNIx_UNIx");
            if (pageUnix.IsValid()) pageUnix.Destroy();

            CreateNyxButton();

            auto nyx = GameObject::Find(
                "Canvas_QuickMenu(Clone)/CanvasGroup/Container/Window/QMParent/Body/Menu_QM_Launchpad/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_Nyx");
            if (nyx.IsValid()) {
                auto tf = nyx.GetTransform();
                if (tf.valid() && tf.raw()) {
                    RectTransform rt(tf.raw());
                    rt.SetLocalPosition({ 0.0f, -94.0f, 0.0f });
                }
            }

            auto worlds = GameObject::Find(
                "Canvas_QuickMenu(Clone)/CanvasGroup/Container/Window/QMParent/Body/Menu_QM_Launchpad/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_Worlds");
            if (worlds.IsValid()) {
                auto tf = worlds.GetTransform();
                if (tf.valid() && tf.raw()) {
                    RectTransform rt(tf.raw());
                    rt.SetLocalPosition({ -315.40f, 102.f, 0.f });
                }
            }

            auto social = GameObject::Find(
                "Canvas_QuickMenu(Clone)/CanvasGroup/Container/Window/QMParent/Body/Menu_QM_Launchpad/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_Social");
            if (social.IsValid()) {
                auto tf = social.GetTransform();
                if (tf.valid() && tf.raw()) {
                    RectTransform rt(tf.raw());
                    rt.SetLocalPosition({ 315.40f, 102.f, 0.f });
                }
            }

            auto avatars = GameObject::Find(
                "Canvas_QuickMenu(Clone)/CanvasGroup/Container/Window/QMParent/Body/Menu_QM_Launchpad/ScrollRect/Viewport/VerticalLayoutGroup/Buttons_QuickLinks/Button_Avatars");
            if (avatars.IsValid()) {
                auto tf = avatars.GetTransform();
                if (tf.valid() && tf.raw()) {
                    RectTransform rt(tf.raw());
                    rt.SetLocalPosition({ 0.0f, 102.f, 0.f });
                }
            }



            m_applied = true;
        } catch (...) {
            FLOG("[UIRemover] Exception in ApplyRemovals");
        }
    }

 


    void UIRemoverModule::OnUpdate() {
        ApplyRemovals();
    }

    void UIRemoverModule::OnSceneLoad(int, int loadMode) {
        if (loadMode == 0) {
            m_applied = false;
            m_nyxBtnCreated = false;
            m_nyxBtnGO = nullptr;
        }
    }

    void UIRemoverModule::OnEnable() {
        m_applied = false;
        m_nyxBtnCreated = false;
        m_nyxBtnGO = nullptr;
        FLOG("[UIRemover] Enabled");
    }

    void UIRemoverModule::OnDisable() {
        FLOG("[UIRemover] Disabled");
    }

} // namespace UNIx
