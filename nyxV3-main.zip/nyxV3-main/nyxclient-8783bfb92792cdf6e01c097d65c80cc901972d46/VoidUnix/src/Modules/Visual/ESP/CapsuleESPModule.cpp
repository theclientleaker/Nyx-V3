#include <Modules/Visual/ESP/CapsuleESPModule.hpp>
#include <Core/ModuleManager.hpp>
#include <IL2CPP.Module/include/Unity/GameObject.hpp>
#include <IL2CPP.Module/include/Unity/Material.hpp>
#include <IL2CPP.Module/include/Unity/Renderer.hpp>
#include <IL2CPP.Module/include/Unity/Camera.hpp>
#include <IL2CPP.Module/include/Reflection.hpp>
#include <IL2CPP.Module/include/MethodHandler.hpp>
#include <IL2CPP.Module/include/il2cpp_module.hpp>
#include <Bootstrap.Module/include/VRChat/VRCPlayerApi.hpp>
#include <string>

namespace UNIx {

    using namespace IL2CPP::Module;
    using namespace IL2CPP::Module::Unity;
    using UnityRenderer = IL2CPP::Module::Unity::Renderer;

    IL2CPP::Color CapsuleESPModule::RankToColor(IL2CPP::VRChat::PlayerRank rank) {
        using R = IL2CPP::VRChat::PlayerRank;
        switch (rank) {
            case R::Visitor:       return IL2CPP::Color(0.80f, 0.80f, 0.80f, 1.f);
            case R::NewUser:         return IL2CPP::Color(0.17f, 0.81f, 0.36f, 1.f);
            case R::User:         return IL2CPP::Color(1.00f, 0.48f, 0.26f, 1.f);
            case R::Known:       return IL2CPP::Color(0.78f, 0.24f, 1.00f, 1.f);
            case R::Trusted:       return IL2CPP::Color(1.00f, 0.40f, 0.40f, 1.f);
            case R::Administrator: return IL2CPP::Color(0.55f, 0.00f, 0.00f, 1.f);
            case R::Troll:         return IL2CPP::Color(0.50f, 0.50f, 0.50f, 1.f);
            default:               return IL2CPP::Color(1.00f, 1.00f, 1.00f, 1.f);
        }
    }

    static void SetNamedColor(void* matRaw, const char* name, IL2CPP::Color color) {
        static auto setColorNamed = MethodHandler::resolve("UnityEngine.Material", "SetColor", 2);
        if (!setColorNamed || !matRaw) return;
        void* str = IL2CPP::Module::StringNew(name);
        if (!str) return;
        void* params[] = { str, &color };
        MethodHandler::invoke(setColorNamed, matRaw, params);
    }

    struct HighlightMethods {
        Method addColor;
        Method remove;
    };

    static HighlightMethods FindHighlightMethods() {
        HighlightMethods result;
        auto parentClass = Class::find("MonoBehaviourPublicAbstractDiDiShMaInCoUnique");
        if (!parentClass) return result;

        Method firstMeshFilter1{};
        bool foundFirst1Param = false;

        for (auto& m : parentClass.get_methods()) {
            if (!m) continue;
            if (!m.is_public() || m.is_static()) continue;

            if (m.param_count() == 2) {
                auto p0 = m.get_param_type(0);
                auto p1 = m.get_param_type(1);
                if (!p0 || !p1) continue;
                std::string p0Name = p0.name() ? p0.name() : "";
                std::string p1Name = p1.name() ? p1.name() : "";
                if (p0Name == "MeshFilter" && p1Name == "Color")
                    result.addColor = m;
            }

            if (m.param_count() == 1) {
                auto p0 = m.get_param_type(0);
                if (!p0) continue;
                std::string p0Name = p0.name() ? p0.name() : "";
                if (p0Name == "MeshFilter") {
                    if (!foundFirst1Param) {
                        foundFirst1Param = true;
                    } else {
                        result.remove = m;
                    }
                }
            }
        }
        return result;
    }

    void CapsuleESPModule::CleanupAll() {
        if (m_highlightComponent && m_removeHighlightMethod) {
            for (auto& [pid, entry] : m_entries) {
                if (!entry.goRaw) continue;
                GameObject srGo{ entry.goRaw };
                if (!srGo.valid()) continue;

                auto meshFilter = srGo.GetComponent(Class::find("UnityEngine.MeshFilter"));
                if (meshFilter.valid()) {
                    void* params[] = { meshFilter.raw() };
                    m_removeHighlightMethod.invoke(m_highlightComponent, params);
                }

                UnityRenderer renderer{ srGo.GetComponent(Class::find("UnityEngine.MeshRenderer")).raw() };
                if (renderer.valid())
                    renderer.SetEnabled(false);

            }
        }
        m_entries.clear();
    }

    void CapsuleESPModule::OnDisable() {
        CleanupAll();
    }

    void CapsuleESPModule::OnSceneLoad(int, int) {
        m_entries.clear();
        m_highlightComponent = nullptr;
        m_highlightResolved = false;
    }

    void CapsuleESPModule::OnUpdate() {
        if (!InRoom()) {
            if (!m_entries.empty()) {
                m_entries.clear();
                m_highlightComponent = nullptr;
                m_highlightResolved = false;
            }
            return;
        }

        if (!m_highlightResolved) {
            m_highlightResolved = true;

            auto hlMethods = FindHighlightMethods();
            m_addHighlightMethod = hlMethods.addColor;
            m_removeHighlightMethod = hlMethods.remove;

            auto cam = Camera::GetMain();
            if (cam.IsValid()) {
                auto camGo = cam.GetGameObject();
                if (camGo.valid()) {
                    auto hlClass = Class::find("MonoBehaviourPublicSealedInInInSiInCoInInInInInMaUnique");
                    if (hlClass) {
                        auto comp = camGo.GetComponent(hlClass);
                        if (comp.valid())
                            m_highlightComponent = comp.raw();
                    }
                }
            }
        }
        if (!m_highlightComponent || !m_addHighlightMethod) return;

        {
            Object hlChk(m_highlightComponent);
            if (!hlChk.IsValid()) {
                m_highlightComponent = nullptr;
                m_highlightResolved = false;
                m_entries.clear();
                return;
            }
        }

        auto players = ModuleManager::Get().GetPlayerCache().GetPlayers();

        std::unordered_map<int, bool> activePlayers;
        for (auto& p : *players) {
            if (!p.isLocal)
                activePlayers[p.playerId] = true;
        }

        std::vector<int> toRemove;
        for (auto& [pid, entry] : m_entries) {
            if (!activePlayers.contains(pid))
                toRemove.push_back(pid);
        }
        for (int pid : toRemove)
            m_entries.erase(pid);

        for (auto& playerEntry : *players) {
            if (playerEntry.isLocal) continue;

            auto api = IL2CPP::VRChat::VRCPlayerApi::GetPlayerById(playerEntry.playerId);
            if (!api.IsValid()) continue;

            auto playerGo = api.GetGameObject();
            if (!playerGo.valid()) continue;

            auto playerTransform = playerGo.GetTransform();
            if (!playerTransform.valid()) continue;

            auto selectRegion = playerTransform.Find("SelectRegion");
            if (!selectRegion.valid()) continue;

            auto srGo = selectRegion.GetGameObject();
            if (!srGo.valid()) continue;

            auto& entry = m_entries[playerEntry.playerId];
            entry.goRaw = srGo.raw();

            UnityRenderer renderer{ srGo.GetComponent(Class::find("UnityEngine.MeshRenderer")).raw() };
            if (!renderer.valid()) continue;

            renderer.SetEnabled(true);

            auto meshFilter = srGo.GetComponent(Class::find("UnityEngine.MeshFilter"));
            if (!meshFilter.valid()) continue;

            auto color = RankToColor(playerEntry.rank);

            void* hlParams[] = { meshFilter.raw(), &color };
            m_addHighlightMethod.invoke(m_highlightComponent, hlParams);

            Material mat{ renderer.GetMaterial() };
            if (mat.valid()) {
                mat.SetColor(color);
                SetNamedColor(mat.raw(), "_RimColor", color);
                SetNamedColor(mat.raw(), "_EmissionColor", color);
            }
        }
    }

} // namespace UNIx
