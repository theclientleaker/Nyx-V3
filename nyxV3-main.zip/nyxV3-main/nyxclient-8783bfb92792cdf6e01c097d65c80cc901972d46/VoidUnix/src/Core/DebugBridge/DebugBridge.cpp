#include <Core/DebugBridge/DebugBridge.hpp>
#include <Core/FileLog/FileLog.hpp>
#include <Core/ModuleManager.hpp>
#include <Core/PlayerCache/PlayerCache.hpp>
#include <Core/Globals.hpp>

#include <IL2CPP.Module/include/il2cpp_module.hpp>
#include <IL2CPP.Module/include/ManagedObject.hpp>
#include <IL2CPP.Module/include/Reflection.hpp>
#include <IL2CPP.Module/include/MethodHandler.hpp>
#include <IL2CPP.Module/include/Unity/Object.hpp>
#include <IL2CPP.Module/include/Unity/GameObject.hpp>
#include <IL2CPP.Module/include/Unity/Transform.hpp>
#include <IL2CPP.Module/include/Unity/Component.hpp>
#include <IL2CPP.Module/include/Unity/Camera.hpp>
#include <IL2CPP.Module/include/Unity/Screen.hpp>
#include <IL2CPP.Module/include/Unity/Time.hpp>
#include <IL2CPP.Module/include/Unity/Physics.hpp>
#include <IL2CPP.Module/include/Unity/Animator.hpp>
#include <IL2CPP.Module/include/Unity/Renderer.hpp>
#include <IL2CPP.Module/include/Unity/Material.hpp>
#include <IL2CPP.Module/include/Unity/AudioSource.hpp>
#include <IL2CPP.Module/include/Unity/Rigidbody.hpp>
#include <IL2CPP.Module/include/Unity/Input.hpp>
#include <IL2CPP.Module/include/Unity/Behaviour.hpp>
#include <IL2CPP.Module/include/Unity/Collider.hpp>

#include <Bootstrap.Module/include/VRChat/VRCPlayerApi.hpp>
#include <Bootstrap.Module/include/VRChat/UdonBehaviour.hpp>
#include <Bootstrap.Module/include/VRChat/VRCPlayer.hpp>
#include <Bootstrap.Module/include/VRChat/Player.hpp>
#include <Bootstrap.Module/include/VRChat/APIUser.hpp>
#include <Bootstrap.Module/include/VRChat/Networking.hpp>
#include <Bootstrap.Module/include/bootstrap_module.hpp>

#include <WinSock2.h>
#include <WS2tcpip.h>
#pragma comment(lib, "ws2_32.lib")

#include <chrono>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <vector>
#include <deque>
#include <charconv>

namespace Hooking::Module {
    extern const Hooking::HookVtable* get_connection_vtable() noexcept;
}

using namespace IL2CPP::Module::Unity;
using namespace IL2CPP::Module;
using IL2CPP::Vector3;
using IL2CPP::Quaternion;
using IL2CPP::RaycastHit;
using IL2CPP::Color;
using IL2CPP::LayerMask;
using IL2CPP::Ray;

namespace {

    constexpr int BRIDGE_PORT = 29150;

    std::string JsonEscape(const std::string& s) {
        std::string out;
        out.reserve(s.size() + 16);
        for (char c : s) {
            switch (c) {
            case '"':  out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if (static_cast<unsigned char>(c) < 0x20)
                    out += ' ';
                else
                    out += c;
            }
        }
        return out;
    }

    std::string ExtractJsonString(const std::string& json, const std::string& key) {
        std::string search = "\"" + key + "\"";
        auto pos = json.find(search);
        if (pos == std::string::npos) return "";

        pos = json.find(':', pos + search.size());
        if (pos == std::string::npos) return "";
        pos++;

        while (pos < json.size() && (json[pos] == ' ' || json[pos] == '\t')) pos++;
        if (pos >= json.size()) return "";

        if (json[pos] == '"') {
            pos++;
            std::string result;
            while (pos < json.size() && json[pos] != '"') {
                if (json[pos] == '\\' && pos + 1 < json.size()) {
                    pos++;
                    switch (json[pos]) {
                    case '"': result += '"'; break;
                    case '\\': result += '\\'; break;
                    case 'n': result += '\n'; break;
                    case 'r': result += '\r'; break;
                    case 't': result += '\t'; break;
                    default: result += json[pos]; break;
                    }
                } else {
                    result += json[pos];
                }
                pos++;
            }
            return result;
        }

        std::string token;
        while (pos < json.size() && json[pos] != ',' && json[pos] != '}' && json[pos] != ' ') {
            token += json[pos++];
        }
        return token;
    }

    int ExtractJsonInt(const std::string& json, const std::string& key, int def) {
        std::string val = ExtractJsonString(json, key);
        if (val.empty()) return def;
        try { return std::stoi(val); }
        catch (...) { return def; }
    }

    float ExtractJsonFloat(const std::string& json, const std::string& key, float def) {
        std::string val = ExtractJsonString(json, key);
        if (val.empty()) return def;
        try { return std::stof(val); }
        catch (...) { return def; }
    }

    bool ExtractJsonBool(const std::string& json, const std::string& key, bool def) {
        std::string val = ExtractJsonString(json, key);
        if (val == "true") return true;
        if (val == "false") return false;
        return def;
    }

    std::vector<std::string> ExtractJsonStringArray(const std::string& json, const std::string& key) {
        std::vector<std::string> result;
        std::string search = "\"" + key + "\"";
        auto pos = json.find(search);
        if (pos == std::string::npos) return result;

        pos = json.find('[', pos + search.size());
        if (pos == std::string::npos) return result;
        pos++;

        while (pos < json.size()) {
            while (pos < json.size() && (json[pos] == ' ' || json[pos] == ',' || json[pos] == '\t' || json[pos] == '\n' || json[pos] == '\r')) pos++;
            if (pos >= json.size() || json[pos] == ']') break;

            if (json[pos] == '"') {
                pos++;
                std::string item;
                while (pos < json.size() && json[pos] != '"') {
                    if (json[pos] == '\\' && pos + 1 < json.size()) {
                        pos++;
                        item += json[pos];
                    } else {
                        item += json[pos];
                    }
                    pos++;
                }
                if (pos < json.size()) pos++;
                result.push_back(item);
            } else {
                std::string item;
                while (pos < json.size() && json[pos] != ',' && json[pos] != ']' && json[pos] != ' ') {
                    item += json[pos++];
                }
                result.push_back(item);
            }
        }

        return result;
    }

    bool SendAll(SOCKET s, const char* data, int len) {
        int sent = 0;
        while (sent < len) {
            int r = send(s, data + sent, len - sent, 0);
            if (r <= 0) return false;
            sent += r;
        }
        return true;
    }

    bool RecvAll(SOCKET s, char* buf, int len) {
        int got = 0;
        while (got < len) {
            int r = recv(s, buf + got, len - got, 0);
            if (r <= 0) return false;
            got += r;
        }
        return true;
    }

    std::string BuildPath(Transform t) {
        std::string path;
        std::vector<std::string> parts;
        Transform cur = t;
        while (cur.valid()) {
            Object obj(cur.raw());
            parts.push_back(obj.GetName());
            cur = cur.GetParent();
        }
        for (int i = static_cast<int>(parts.size()) - 1; i >= 0; i--) {
            if (!path.empty()) path += "/";
            path += parts[i];
        }
        return path;
    }

    std::string ReadIl2CppString(void* strObj) {
        if (!strObj) return "";
        int32_t len = *reinterpret_cast<int32_t*>(reinterpret_cast<char*>(strObj) + 0x10);
        if (len <= 0 || len > 8192) return "";
        wchar_t* chars = reinterpret_cast<wchar_t*>(reinterpret_cast<char*>(strObj) + 0x14);
        std::string result;
        result.reserve(len);
        for (int i = 0; i < len; i++) {
            wchar_t wc = chars[i];
            if (wc < 128) result += static_cast<char>(wc);
            else result += '?';
        }
        return result;
    }

    std::string FieldValueToJson(void* obj, const Field& field) {
        const char* tn = field.type_name();
        if (!tn) return "null";
        std::string typeName(tn);

        try {
            if (typeName == "System.Boolean" || typeName == "Boolean" || typeName == "bool") {
                bool val = false;
                if (field.is_static()) field.get_static_value(&val);
                else field.get_value(obj, &val);
                return val ? "true" : "false";
            }
            if (typeName == "System.Byte" || typeName == "Byte") {
                uint8_t val = 0;
                if (field.is_static()) field.get_static_value(&val);
                else field.get_value(obj, &val);
                return std::to_string(val);
            }
            if (typeName == "System.Int32" || typeName == "Int32" || typeName == "int") {
                int32_t val = 0;
                if (field.is_static()) field.get_static_value(&val);
                else field.get_value(obj, &val);
                return std::to_string(val);
            }
            if (typeName == "System.Int64" || typeName == "Int64" || typeName == "long") {
                int64_t val = 0;
                if (field.is_static()) field.get_static_value(&val);
                else field.get_value(obj, &val);
                return std::to_string(val);
            }
            if (typeName == "System.Single" || typeName == "Single" || typeName == "float") {
                float val = 0;
                if (field.is_static()) field.get_static_value(&val);
                else field.get_value(obj, &val);
                return std::to_string(val);
            }
            if (typeName == "System.Double" || typeName == "Double" || typeName == "double") {
                double val = 0;
                if (field.is_static()) field.get_static_value(&val);
                else field.get_value(obj, &val);
                return std::to_string(val);
            }
            if (typeName == "System.String" || typeName == "String") {
                void* strPtr = nullptr;
                if (field.is_static()) field.get_static_value(&strPtr);
                else field.get_value(obj, &strPtr);
                if (!strPtr) return "null";
                return "\"" + JsonEscape(ReadIl2CppString(strPtr)) + "\"";
            }
            if (typeName == "UnityEngine.Vector2" || typeName == "Vector2") {
                float vals[2] = {0};
                if (field.is_static()) field.get_static_value(vals);
                else field.get_value(obj, vals);
                return "{\"x\":" + std::to_string(vals[0]) + ",\"y\":" + std::to_string(vals[1]) + "}";
            }
            if (typeName == "UnityEngine.Vector3" || typeName == "Vector3") {
                float vals[3] = {0};
                if (field.is_static()) field.get_static_value(vals);
                else field.get_value(obj, vals);
                return "{\"x\":" + std::to_string(vals[0]) + ",\"y\":" + std::to_string(vals[1]) + ",\"z\":" + std::to_string(vals[2]) + "}";
            }
            if (typeName == "UnityEngine.Vector4" || typeName == "Vector4") {
                float vals[4] = {0};
                if (field.is_static()) field.get_static_value(vals);
                else field.get_value(obj, vals);
                return "{\"x\":" + std::to_string(vals[0]) + ",\"y\":" + std::to_string(vals[1]) + ",\"z\":" + std::to_string(vals[2]) + ",\"w\":" + std::to_string(vals[3]) + "}";
            }
            if (typeName == "UnityEngine.Color" || typeName == "Color") {
                float vals[4] = {0};
                if (field.is_static()) field.get_static_value(vals);
                else field.get_value(obj, vals);
                return "{\"r\":" + std::to_string(vals[0]) + ",\"g\":" + std::to_string(vals[1]) + ",\"b\":" + std::to_string(vals[2]) + ",\"a\":" + std::to_string(vals[3]) + "}";
            }
            if (typeName == "UnityEngine.Quaternion" || typeName == "Quaternion") {
                float vals[4] = {0};
                if (field.is_static()) field.get_static_value(vals);
                else field.get_value(obj, vals);
                return "{\"x\":" + std::to_string(vals[0]) + ",\"y\":" + std::to_string(vals[1]) + ",\"z\":" + std::to_string(vals[2]) + ",\"w\":" + std::to_string(vals[3]) + "}";
            }

            void* ptr = nullptr;
            if (field.is_static()) field.get_static_value(&ptr);
            else field.get_value(obj, &ptr);
            if (!ptr) return "null";

            std::ostringstream oss;
            oss << "\"<" << JsonEscape(typeName) << " @ 0x" << std::hex << reinterpret_cast<uintptr_t>(ptr) << ">\"";
            return oss.str();
        } catch (...) {
            return "\"<error>\"";
        }
    }

    std::string UnboxedValueToJson(void* boxedObj) {
        if (!boxedObj) return "null";
        try {
            ManagedObject managed(boxedObj);
            Class cls = managed.get_class();
            if (!cls) return "\"<unknown>\"";
            const char* name = cls.name();
            if (!name) return "\"<unknown>\"";
            std::string typeName(name);

            char* data = reinterpret_cast<char*>(boxedObj) + 0x10;

            if (typeName == "Boolean") return *reinterpret_cast<bool*>(data) ? "true" : "false";
            if (typeName == "Byte") return std::to_string(*reinterpret_cast<uint8_t*>(data));
            if (typeName == "Int32") return std::to_string(*reinterpret_cast<int32_t*>(data));
            if (typeName == "Int64") return std::to_string(*reinterpret_cast<int64_t*>(data));
            if (typeName == "Single") return std::to_string(*reinterpret_cast<float*>(data));
            if (typeName == "Double") return std::to_string(*reinterpret_cast<double*>(data));
            if (typeName == "String") return "\"" + JsonEscape(ReadIl2CppString(boxedObj)) + "\"";
            if (typeName == "Vector3") {
                float* v = reinterpret_cast<float*>(data);
                return "{\"x\":" + std::to_string(v[0]) + ",\"y\":" + std::to_string(v[1]) + ",\"z\":" + std::to_string(v[2]) + "}";
            }
            if (typeName == "Vector2") {
                float* v = reinterpret_cast<float*>(data);
                return "{\"x\":" + std::to_string(v[0]) + ",\"y\":" + std::to_string(v[1]) + "}";
            }
            if (typeName == "Color") {
                float* v = reinterpret_cast<float*>(data);
                return "{\"r\":" + std::to_string(v[0]) + ",\"g\":" + std::to_string(v[1]) + ",\"b\":" + std::to_string(v[2]) + ",\"a\":" + std::to_string(v[3]) + "}";
            }
            if (typeName == "Quaternion") {
                float* v = reinterpret_cast<float*>(data);
                return "{\"x\":" + std::to_string(v[0]) + ",\"y\":" + std::to_string(v[1]) + ",\"z\":" + std::to_string(v[2]) + ",\"w\":" + std::to_string(v[3]) + "}";
            }

            std::ostringstream oss;
            oss << "\"<" << JsonEscape(typeName) << " @ 0x" << std::hex << reinterpret_cast<uintptr_t>(boxedObj) << ">\"";
            return oss.str();
        } catch (...) {
            return "\"<error>\"";
        }
    }

    void BuildHierarchyJson(Transform t, std::string& result, int depth, int maxDepth, int& totalCount, int maxTotal) {
        int childCount = t.GetChildCount();
        bool first = true;
        for (int i = 0; i < childCount && totalCount < maxTotal; i++) {
            Transform child = t.GetChild(i);
            if (!child.valid()) continue;

            Object nameObj(child.raw());
            std::string name = nameObj.GetName();
            GameObject go = child.GetGameObject();
            bool active = go.valid() ? go.GetActiveSelf() : false;
            int cc = child.GetChildCount();

            if (!first) result += ",";
            first = false;
            totalCount++;

            result += "{\"name\":\"" + JsonEscape(name) + "\""
                + ",\"active\":" + (active ? "true" : "false")
                + ",\"childCount\":" + std::to_string(cc);

            if (cc > 0 && depth + 1 <= maxDepth && totalCount < maxTotal) {
                result += ",\"children\":[";
                BuildHierarchyJson(child, result, depth + 1, maxDepth, totalCount, maxTotal);
                result += "]";
            }

            result += "}";
        }
    }

}

namespace UNIx {

    DebugBridge& DebugBridge::Get() {
        static DebugBridge inst;
        return inst;
    }

    void DebugBridge::Start() {
        if (m_running.exchange(true)) return;
        FLOG("[DebugBridge] Starting");
        m_thread = std::thread([this] { ServerLoop(); });
    }

    void DebugBridge::Stop() {
        if (!m_running.exchange(false)) return;
        FLOG("[DebugBridge] Stopping");
        if (m_thread.joinable()) m_thread.join();
        FLOG("[DebugBridge] Stopped");
    }

    void DebugBridge::ProcessCommands() {
        while (true) {
            PendingCommand cmd;
            {
                std::lock_guard lock(m_queueMutex);
                if (m_commandQueue.empty()) return;
                cmd = std::move(m_commandQueue.front());
                m_commandQueue.pop();
            }

            std::string result;
            try {
                result = ExecuteCommand(cmd.method, cmd.json);
            } catch (const std::exception& e) {
                result = "{\"error\":\"" + JsonEscape(e.what()) + "\"}";
            } catch (...) {
                result = "{\"error\":\"unknown exception\"}";
            }

            cmd.result.set_value(std::move(result));
        }
    }

    void DebugBridge::ServerLoop() {
        WSADATA wsa;
        if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
            FLOG("[DebugBridge] WSAStartup failed");
            m_running = false;
            return;
        }

        SOCKET listenSock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        if (listenSock == INVALID_SOCKET) {
            FLOG("[DebugBridge] socket() failed");
            WSACleanup();
            m_running = false;
            return;
        }

        int opt = 1;
        setsockopt(listenSock, SOL_SOCKET, SO_REUSEADDR, (const char*)&opt, sizeof(opt));

        u_long nonBlock = 1;
        ioctlsocket(listenSock, FIONBIO, &nonBlock);

        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_port = htons(BRIDGE_PORT);
        inet_pton(AF_INET, "127.0.0.1", &addr.sin_addr);

        if (bind(listenSock, (sockaddr*)&addr, sizeof(addr)) == SOCKET_ERROR) {
            FLOG("[DebugBridge] bind() failed: {}", WSAGetLastError());
            closesocket(listenSock);
            WSACleanup();
            m_running = false;
            return;
        }

        if (listen(listenSock, 5) == SOCKET_ERROR) {
            FLOG("[DebugBridge] listen() failed");
            closesocket(listenSock);
            WSACleanup();
            m_running = false;
            return;
        }

        FLOG("[DebugBridge] Listening on 127.0.0.1:{}", BRIDGE_PORT);

        while (m_running) {
            SOCKET client = accept(listenSock, nullptr, nullptr);
            if (client == INVALID_SOCKET) {
                Sleep(100);
                continue;
            }

            FLOG("[DebugBridge] Client connected");

            u_long blocking = 0;
            ioctlsocket(client, FIONBIO, &blocking);

            DWORD timeout = 500;
            setsockopt(client, SOL_SOCKET, SO_RCVTIMEO, (const char*)&timeout, sizeof(timeout));

            {
                std::lock_guard lock(m_clientsMutex);
                m_clientThreads.emplace_back([this, client] {
                    HandleClient(static_cast<uintptr_t>(client));
                    closesocket(client);
                    FLOG("[DebugBridge] Client disconnected");
                });
            }
        }

        closesocket(listenSock);

        {
            std::lock_guard lock(m_clientsMutex);
            for (auto& t : m_clientThreads) {
                if (t.joinable()) t.join();
            }
            m_clientThreads.clear();
        }

        WSACleanup();
        FLOG("[DebugBridge] Server loop exited");
    }

    void DebugBridge::HandleClient(uintptr_t clientSock) {
        SOCKET sock = static_cast<SOCKET>(clientSock);

        while (m_running) {
            uint32_t msgLen = 0;
            if (!RecvAll(sock, reinterpret_cast<char*>(&msgLen), 4)) {
                int err = WSAGetLastError();
                if (err == WSAETIMEDOUT) continue;
                break;
            }

            if (msgLen == 0 || msgLen > 1024 * 1024) break;

            std::string json(msgLen, '\0');
            if (!RecvAll(sock, json.data(), msgLen)) break;

            std::string method = ExtractJsonString(json, "method");
            int id = ExtractJsonInt(json, "id", 0);

            std::string response;

            if (method == "ping") {
                response = "{\"id\":" + std::to_string(id) + ",\"result\":{\"status\":\"ok\"}}";
            } else if (method == "read_log") {
                try {
                    response = "{\"id\":" + std::to_string(id) + ",\"result\":" + CmdReadLog(json) + "}";
                } catch (...) {
                    response = "{\"id\":" + std::to_string(id) + ",\"error\":\"read_log failed\"}";
                }
            } else if (method == "send_log") {
                try {
                    response = "{\"id\":" + std::to_string(id) + ",\"result\":" + CmdSendLog(json) + "}";
                } catch (...) {
                    response = "{\"id\":" + std::to_string(id) + ",\"error\":\"send_log failed\"}";
                }
            } else {
                PendingCommand cmd;
                cmd.method = method;
                cmd.json = json;
                auto future = cmd.result.get_future();

                {
                    std::lock_guard lock(m_queueMutex);
                    m_commandQueue.push(std::move(cmd));
                }

                auto status = future.wait_for(std::chrono::seconds(10));
                if (status == std::future_status::ready) {
                    response = "{\"id\":" + std::to_string(id) + ",\"result\":" + future.get() + "}";
                } else {
                    response = "{\"id\":" + std::to_string(id) + ",\"error\":\"timeout waiting for Unity thread\"}";
                }
            }

            uint32_t respLen = static_cast<uint32_t>(response.size());
            if (!SendAll(sock, reinterpret_cast<const char*>(&respLen), 4)) break;
            if (!SendAll(sock, response.data(), respLen)) break;
        }
    }

    std::string DebugBridge::ExecuteCommand(const std::string& method, const std::string& json) {
        if (method == "list_gameobjects") return CmdListGameObjects(json);
        if (method == "inspect_gameobject") return CmdInspectGameObject(json);
        if (method == "search_scene") return CmdSearchScene(json);
        if (method == "set_gameobject_active") return CmdSetGameObjectActive(json);
        if (method == "get_hierarchy") return CmdGetHierarchy(json);
        if (method == "find_objects_of_type") return CmdFindObjectsOfType(json);
        if (method == "get_materials") return CmdGetMaterials(json);
        if (method == "inspect_component") return CmdInspectComponent(json);

        if (method == "find_class") return CmdFindClass(json);
        if (method == "filter_class") return CmdFilterClass(json);
        if (method == "inspect_class") return CmdInspectClass(json);
        if (method == "call_method") return CmdCallMethod(json);
        if (method == "read_field") return CmdReadField(json);
        if (method == "set_field") return CmdSetField(json);

        if (method == "list_players") return CmdListPlayers(json);
        if (method == "get_player_info") return CmdGetPlayerInfo(json);
        if (method == "get_avatar_info") return CmdGetAvatarInfo(json);
        if (method == "teleport") return CmdTeleport(json);
        if (method == "set_movement") return CmdSetMovement(json);

        if (method == "get_world_info") return CmdGetWorldInfo(json);
        if (method == "get_network_info") return CmdGetNetworkInfo(json);
        if (method == "get_photon_info") return CmdGetPhotonInfo(json);

        if (method == "list_udon_behaviours") return CmdListUdonBehaviours(json);
        if (method == "get_udon_variables") return CmdGetUdonVariables(json);
        if (method == "send_udon_event") return CmdSendUdonEvent(json);
        if (method == "start_udon_monitor") return CmdStartUdonMonitor(json);
        if (method == "stop_udon_monitor") return CmdStopUdonMonitor(json);
        if (method == "get_udon_events") return CmdGetUdonEvents(json);

        if (method == "raycast") return CmdRaycast(json);
        if (method == "list_animations") return CmdListAnimations(json);

        if (method == "get_screen_info") return CmdGetScreenInfo(json);
        if (method == "get_camera_info") return CmdGetCameraInfo(json);
        if (method == "set_camera") return CmdSetCamera(json);
        if (method == "get_time_info") return CmdGetTimeInfo(json);
        if (method == "get_audio_sources") return CmdGetAudioSources(json);

        if (method == "list_modules") return CmdListModules(json);
        if (method == "toggle_module") return CmdToggleModule(json);
        if (method == "get_config") return CmdGetConfig(json);
        if (method == "set_config") return CmdSetConfig(json);

        if (method == "player_action") return CmdPlayerAction(json);
        if (method == "teleport_to_player") return CmdTeleportToPlayer(json);
        if (method == "set_animator_param") return CmdSetAnimatorParam(json);
        if (method == "take_ownership") return CmdTakeOwnership(json);
        if (method == "get_ownership") return CmdGetOwnership(json);
        if (method == "set_rigidbody") return CmdSetRigidbody(json);
        if (method == "add_force") return CmdAddForce(json);
        if (method == "set_transform") return CmdSetTransform(json);
        if (method == "send_network_udon_event") return CmdSendNetworkUdonEvent(json);
        if (method == "set_udon_variable") return CmdSetUdonVariable(json);
        if (method == "go_to_room") return CmdGoToRoom(json);
        if (method == "batch") return CmdBatch(json);
        if (method == "get_input") return CmdGetInput(json);
        if (method == "set_time_scale") return CmdSetTimeScale(json);
        if (method == "destroy_object") return CmdDestroyObject(json);
        if (method == "instantiate_object") return CmdInstantiateObject(json);
        if (method == "find_by_tag") return CmdFindByTag(json);
        if (method == "set_component_enabled") return CmdSetComponentEnabled(json);
        if (method == "set_layer") return CmdSetLayer(json);
        if (method == "set_parent") return CmdSetParent(json);
        if (method == "world_to_screen") return CmdWorldToScreen(json);
        if (method == "set_material") return CmdSetMaterial(json);
        if (method == "audio_control") return CmdAudioControl(json);
        if (method == "overlap_sphere") return CmdOverlapSphere(json);
        if (method == "screen_to_ray") return CmdScreenToRay(json);
        if (method == "get_all_bones") return CmdGetAllBones(json);
        if (method == "set_shader") return CmdSetShader(json);
        if (method == "get_player_by_name") return CmdGetPlayerByName(json);

        return "{\"error\":\"unknown method: " + JsonEscape(method) + "\"}";
    }

    // ========================================================================
    //  Scene
    // ========================================================================

    std::string DebugBridge::CmdListGameObjects(const std::string& json) {
        std::string path = ExtractJsonString(json, "path");
        int limit = ExtractJsonInt(json, "limit", 100);
        if (path.empty()) path = "/";

        std::string result = "[";
        int count = 0;

        if (path == "/") {
            auto transforms = Object::FindObjectsOfType("UnityEngine.Transform");
            for (auto& obj : transforms) {
                if (count >= limit) break;
                Transform t(obj.raw());
                if (!t.valid()) continue;
                Transform parent = t.GetParent();
                if (parent.valid()) continue;

                Object nameObj(t.raw());
                std::string name = nameObj.GetName();
                GameObject go = t.GetGameObject();
                bool active = go.valid() ? go.GetActiveSelf() : false;
                int childCount = t.GetChildCount();
                int layer = go.valid() ? static_cast<int>(go.GetLayer()) : 0;

                if (count > 0) result += ",";
                result += "{\"name\":\"" + JsonEscape(name) + "\""
                    + ",\"active\":" + (active ? "true" : "false")
                    + ",\"childCount\":" + std::to_string(childCount)
                    + ",\"layer\":" + std::to_string(layer) + "}";
                count++;
            }
        } else {
            GameObject go = GameObject::Find(path);
            if (!go.valid()) return "{\"error\":\"GameObject not found: " + JsonEscape(path) + "\"}";

            Transform t = go.GetTransform();
            if (!t.valid()) return "{\"error\":\"Transform not found\"}";

            int childCount = t.GetChildCount();
            for (int i = 0; i < childCount && count < limit; i++) {
                Transform child = t.GetChild(i);
                if (!child.valid()) continue;

                Object nameObj(child.raw());
                std::string name = nameObj.GetName();
                GameObject childGo = child.GetGameObject();
                bool active = childGo.valid() ? childGo.GetActiveSelf() : false;
                int cc = child.GetChildCount();
                int layer = childGo.valid() ? static_cast<int>(childGo.GetLayer()) : 0;

                if (count > 0) result += ",";
                result += "{\"name\":\"" + JsonEscape(name) + "\""
                    + ",\"active\":" + (active ? "true" : "false")
                    + ",\"childCount\":" + std::to_string(cc)
                    + ",\"layer\":" + std::to_string(layer) + "}";
                count++;
            }
        }

        result += "]";
        return result;
    }

    std::string DebugBridge::CmdInspectGameObject(const std::string& json) {
        std::string path = ExtractJsonString(json, "path");
        if (path.empty()) return "{\"error\":\"path required\"}";

        GameObject go = GameObject::Find(path);
        if (!go.valid()) return "{\"error\":\"GameObject not found: " + JsonEscape(path) + "\"}";

        Transform t = go.GetTransform();
        std::string name = Object(go.raw()).GetName();
        bool active = go.GetActiveSelf();
        int layer = static_cast<int>(go.GetLayer());

        std::string result = "{\"name\":\"" + JsonEscape(name) + "\""
            + ",\"active\":" + (active ? "true" : "false")
            + ",\"layer\":" + std::to_string(layer);

        if (t.valid()) {
            auto pos = t.GetPosition();
            auto rot = t.GetRotation();
            auto scale = t.GetLocalScale();
            result += ",\"position\":{\"x\":" + std::to_string(pos.x) + ",\"y\":" + std::to_string(pos.y) + ",\"z\":" + std::to_string(pos.z) + "}"
                + ",\"rotation\":{\"x\":" + std::to_string(rot.x) + ",\"y\":" + std::to_string(rot.y) + ",\"z\":" + std::to_string(rot.z) + ",\"w\":" + std::to_string(rot.w) + "}"
                + ",\"scale\":{\"x\":" + std::to_string(scale.x) + ",\"y\":" + std::to_string(scale.y) + ",\"z\":" + std::to_string(scale.z) + "}";
        }

        auto components = go.GetComponents("UnityEngine.Component");
        result += ",\"components\":[";
        for (size_t i = 0; i < components.size(); i++) {
            if (i > 0) result += ",";
            auto& comp = components[i];
            if (!comp.valid()) {
                result += "{\"className\":\"null\"}";
                continue;
            }
            ManagedObject managed(comp.raw());
            Class cls = managed.get_class();
            if (!cls) {
                result += "{\"className\":\"unknown\"}";
                continue;
            }
            std::string clsName = cls.name() ? cls.name() : "unknown";
            std::string clsNs = cls.ns() ? cls.ns() : "";
            result += "{\"className\":\"" + JsonEscape(clsName) + "\"";
            if (!clsNs.empty()) result += ",\"namespace\":\"" + JsonEscape(clsNs) + "\"";
            result += ",\"index\":" + std::to_string(i) + "}";
        }
        result += "]}";
        return result;
    }

    std::string DebugBridge::CmdSearchScene(const std::string& json) {
        std::string pattern = ExtractJsonString(json, "pattern");
        int limit = ExtractJsonInt(json, "limit", 50);
        if (pattern.empty()) return "{\"error\":\"pattern required\"}";

        std::string patLower = pattern;
        std::transform(patLower.begin(), patLower.end(), patLower.begin(), ::tolower);

        auto transforms = Object::FindObjectsOfType("UnityEngine.Transform");

        std::string result = "[";
        int count = 0;

        for (auto& obj : transforms) {
            if (count >= limit) break;
            Transform t(obj.raw());
            if (!t.valid()) continue;

            Object nameObj(t.raw());
            std::string name = nameObj.GetName();

            std::string nameLower = name;
            std::transform(nameLower.begin(), nameLower.end(), nameLower.begin(), ::tolower);
            if (nameLower.find(patLower) == std::string::npos) continue;

            std::string path = BuildPath(t);
            GameObject go = t.GetGameObject();
            bool active = go.valid() ? go.GetActiveSelf() : false;
            int childCount = t.GetChildCount();

            if (count > 0) result += ",";
            result += "{\"name\":\"" + JsonEscape(name) + "\""
                + ",\"path\":\"" + JsonEscape(path) + "\""
                + ",\"active\":" + (active ? "true" : "false")
                + ",\"childCount\":" + std::to_string(childCount) + "}";
            count++;
        }

        result += "]";
        return result;
    }

    std::string DebugBridge::CmdSetGameObjectActive(const std::string& json) {
        std::string path = ExtractJsonString(json, "path");
        bool active = ExtractJsonBool(json, "active", true);
        if (path.empty()) return "{\"error\":\"path required\"}";

        GameObject go = GameObject::Find(path);
        if (!go.valid()) return "{\"error\":\"GameObject not found\"}";
        go.SetActive(active);
        return "{\"ok\":true}";
    }

    std::string DebugBridge::CmdGetHierarchy(const std::string& json) {
        std::string path = ExtractJsonString(json, "path");
        int maxDepth = ExtractJsonInt(json, "depth", 3);
        int maxTotal = ExtractJsonInt(json, "limit", 200);
        if (path.empty()) return "{\"error\":\"path required\"}";

        GameObject go = GameObject::Find(path);
        if (!go.valid()) return "{\"error\":\"GameObject not found\"}";
        Transform t = go.GetTransform();
        if (!t.valid()) return "{\"error\":\"Transform not found\"}";

        int totalCount = 0;
        std::string children;
        BuildHierarchyJson(t, children, 0, maxDepth, totalCount, maxTotal);

        std::string name = Object(go.raw()).GetName();
        return "{\"name\":\"" + JsonEscape(name) + "\",\"children\":[" + children + "],\"totalNodes\":" + std::to_string(totalCount) + "}";
    }

    std::string DebugBridge::CmdFindObjectsOfType(const std::string& json) {
        std::string typeName = ExtractJsonString(json, "type");
        int limit = ExtractJsonInt(json, "limit", 50);
        if (typeName.empty()) return "{\"error\":\"type required\"}";

        auto objects = Object::FindObjectsOfType(typeName);

        std::string result = "[";
        int count = 0;
        for (auto& obj : objects) {
            if (count >= limit) break;
            if (!obj.valid()) continue;

            std::string goName;
            std::string path;
            try {
                Component comp(obj.raw());
                if (comp.valid()) {
                    GameObject go = comp.GetGameObject();
                    if (go.valid()) {
                        goName = Object(go.raw()).GetName();
                        Transform t = go.GetTransform();
                        if (t.valid()) path = BuildPath(t);
                    }
                }
                if (goName.empty()) goName = Object(obj.raw()).GetName();
            } catch (...) {
                goName = "?";
            }

            if (count > 0) result += ",";
            result += "{\"name\":\"" + JsonEscape(goName) + "\"";
            if (!path.empty()) result += ",\"path\":\"" + JsonEscape(path) + "\"";
            result += "}";
            count++;
        }
        result += "]";
        return result;
    }

    std::string DebugBridge::CmdGetMaterials(const std::string& json) {
        std::string path = ExtractJsonString(json, "path");
        if (path.empty()) return "{\"error\":\"path required\"}";

        GameObject go = GameObject::Find(path);
        if (!go.valid()) return "{\"error\":\"GameObject not found\"}";

        auto renderers = go.GetComponents("UnityEngine.Renderer");
        if (renderers.empty()) return "{\"error\":\"no Renderer on this GameObject\"}";

        std::string result = "[";
        for (size_t ri = 0; ri < renderers.size(); ri++) {
            if (ri > 0) result += ",";
            ::IL2CPP::Module::Unity::Renderer renderer(renderers[ri].raw());
            if (!renderer.valid()) { result += "{\"error\":\"invalid renderer\"}"; continue; }

            void* matRaw = renderer.GetMaterial();
            result += "{";
            if (matRaw) {
                Material mat(matRaw);
                auto color = mat.GetColor();
                int renderQueue = mat.GetRenderQueue();

                void* shaderRaw = mat.GetShader();
                std::string shaderName = "unknown";
                if (shaderRaw) {
                    try { shaderName = Object(shaderRaw).GetName(); } catch (...) {}
                }

                result += "\"shader\":\"" + JsonEscape(shaderName) + "\""
                    + ",\"color\":{\"r\":" + std::to_string(color.r) + ",\"g\":" + std::to_string(color.g) + ",\"b\":" + std::to_string(color.b) + ",\"a\":" + std::to_string(color.a) + "}"
                    + ",\"renderQueue\":" + std::to_string(renderQueue);
            } else {
                result += "\"material\":null";
            }
            result += "}";
        }
        result += "]";
        return result;
    }

    std::string DebugBridge::CmdInspectComponent(const std::string& json) {
        std::string path = ExtractJsonString(json, "path");
        std::string className = ExtractJsonString(json, "class_name");
        int index = ExtractJsonInt(json, "index", -1);
        if (path.empty()) return "{\"error\":\"path required\"}";

        GameObject go = GameObject::Find(path);
        if (!go.valid()) return "{\"error\":\"GameObject not found\"}";

        void* target = nullptr;
        if (!className.empty()) {
            auto comps = go.GetComponents(className);
            if (comps.empty()) return "{\"error\":\"component not found: " + JsonEscape(className) + "\"}";
            target = comps[0].raw();
        } else if (index >= 0) {
            auto comps = go.GetComponents("UnityEngine.Component");
            if (index >= static_cast<int>(comps.size())) return "{\"error\":\"index out of range\"}";
            target = comps[index].raw();
        } else {
            return "{\"error\":\"class_name or index required\"}";
        }

        if (!target) return "{\"error\":\"null component\"}";

        ManagedObject managed(target);
        Class cls = managed.get_class();
        if (!cls) return "{\"error\":\"could not get class\"}";

        std::string result = "{\"className\":\"" + JsonEscape(cls.name() ? cls.name() : "?") + "\"";
        std::string ns = cls.ns() ? cls.ns() : "";
        if (!ns.empty()) result += ",\"namespace\":\"" + JsonEscape(ns) + "\"";

        result += ",\"fields\":[";
        try {
            auto fields = cls.get_fields();
            for (size_t i = 0; i < fields.size(); i++) {
                if (i > 0) result += ",";
                auto& f = fields[i];
                result += "{\"name\":\"" + JsonEscape(f.name() ? f.name() : "?") + "\""
                    + ",\"type\":\"" + JsonEscape(f.type_name() ? f.type_name() : "?") + "\""
                    + ",\"static\":" + (f.is_static() ? "true" : "false")
                    + ",\"value\":" + FieldValueToJson(target, f) + "}";
            }
        } catch (...) {}
        result += "]}";
        return result;
    }

    // ========================================================================
    //  IL2CPP
    // ========================================================================

    std::string DebugBridge::CmdFindClass(const std::string& json) {
        std::string query = ExtractJsonString(json, "query");
        int limit = ExtractJsonInt(json, "limit", 50);
        if (query.empty()) return "{\"error\":\"query required\"}";

        std::string queryLower = query;
        std::transform(queryLower.begin(), queryLower.end(), queryLower.begin(), ::tolower);

        std::string result = "[";
        int count = 0;

        auto assemblies = Assembly::get_all();
        for (auto& assembly : assemblies) {
            if (count >= limit) break;
            auto image = assembly.get_image();
            if (!image) continue;

            auto classes = image.get_classes();
            for (auto& cls : classes) {
                if (count >= limit) break;
                if (!cls) continue;

                const char* nameRaw = cls.name();
                const char* nsRaw = cls.ns();
                if (!nameRaw) continue;

                std::string fullName;
                if (nsRaw && nsRaw[0] != '\0') {
                    fullName = std::string(nsRaw) + "." + nameRaw;
                } else {
                    fullName = nameRaw;
                }

                std::string fullLower = fullName;
                std::transform(fullLower.begin(), fullLower.end(), fullLower.begin(), ::tolower);

                if (fullLower.find(queryLower) == std::string::npos) continue;

                // Include raw (potentially obfuscated) names for debugging
                const char* rawNameRaw = cls.raw_name();
                const char* rawNsRaw = cls.raw_ns();
                std::string rawFullName;
                if (rawNsRaw && rawNsRaw[0] != '\0')
                    rawFullName = std::string(rawNsRaw) + "." + (rawNameRaw ? rawNameRaw : "");
                else
                    rawFullName = rawNameRaw ? rawNameRaw : "";

                if (count > 0) result += ",";
                result += "{\"fullName\":\"" + JsonEscape(fullName) + "\""
                    + ",\"rawFullName\":\"" + JsonEscape(rawFullName) + "\""
                    + ",\"namespace\":\"" + JsonEscape(nsRaw ? nsRaw : "") + "\""
                    + ",\"name\":\"" + JsonEscape(nameRaw) + "\""
                    + ",\"rawName\":\"" + JsonEscape(rawNameRaw ? rawNameRaw : "") + "\"}";
                count++;
            }
        }

        result += "]";
        return result;
    }

    std::string DebugBridge::CmdFilterClass(const std::string& json) {
        // Search for classes by method/field type characteristics.
        // Params:
        //   assembly (optional, default "Assembly-CSharp") - assembly to search
        //   method_return_type (optional) - substring match on method return type
        //   field_type (optional) - substring match on field type
        //   field_static (optional, bool) - require static fields
        //   method_virtual (optional, bool) - require virtual methods
        //   method_sealed (optional, bool) - require sealed/final methods
        //   method_param_count (optional, int, default -1) - exact method param count
        //   parent (optional) - substring match on parent class name
        //   limit (optional, default 20)
        std::string assembly = ExtractJsonString(json, "assembly");
        if (assembly.empty()) assembly = "Assembly-CSharp";
        std::string methodRetType = ExtractJsonString(json, "method_return_type");
        std::string fieldType = ExtractJsonString(json, "field_type");
        bool filterFieldStatic = json.find("\"field_static\"") != std::string::npos;
        bool fieldStatic = json.find("\"field_static\":true") != std::string::npos;
        bool filterMethodVirtual = json.find("\"method_virtual\"") != std::string::npos;
        bool methodVirtual = json.find("\"method_virtual\":true") != std::string::npos;
        bool filterMethodSealed = json.find("\"method_sealed\"") != std::string::npos;
        bool methodSealed = json.find("\"method_sealed\":true") != std::string::npos;
        int methodParamCount = ExtractJsonInt(json, "method_param_count", -1);
        std::string parentFilter = ExtractJsonString(json, "parent");
        int limit = ExtractJsonInt(json, "limit", 20);

        // Lowercase filters for case-insensitive matching
        auto toLower = [](std::string s) { std::transform(s.begin(), s.end(), s.begin(), ::tolower); return s; };
        std::string methodRetTypeLower = toLower(methodRetType);
        std::string fieldTypeLower = toLower(fieldType);
        std::string parentLower = toLower(parentFilter);

        std::string result = "[";
        int count = 0;

        auto assemblies = Assembly::get_all();
        for (auto& asm_ : assemblies) {
            if (count >= limit) break;
            auto img = asm_.get_image();
            if (!img) continue;
            std::string imgName = img.name() ? img.name() : "";
            if (imgName.find(assembly) == std::string::npos) continue;

            auto classes = img.get_classes();
            for (auto& cls : classes) {
                if (count >= limit) break;
                if (!cls) continue;

                // Parent filter
                if (!parentFilter.empty()) {
                    auto par = cls.parent();
                    if (!par) continue;
                    std::string parName = toLower(par.name() ? par.name() : "");
                    if (parName.find(parentLower) == std::string::npos) continue;
                }

                // Method return type filter
                bool methodMatch = methodRetType.empty();
                if (!methodRetType.empty()) {
                    auto methods = cls.get_methods();
                    for (auto& m : methods) {
                        if (!m) continue;
                        if (filterMethodVirtual && m.is_virtual() != methodVirtual) continue;
                        if (filterMethodSealed && m.is_sealed() != methodSealed) continue;
                        if (methodParamCount >= 0 && m.param_count() != methodParamCount) continue;

                        auto retType = m.return_type();
                        if (!retType) continue;
                        std::string retName = toLower(retType.name() ? retType.name() : "");
                        std::string retFull = toLower(retType.full_name());
                        if (retName.find(methodRetTypeLower) != std::string::npos ||
                            retFull.find(methodRetTypeLower) != std::string::npos) {
                            methodMatch = true;
                            break;
                        }
                    }
                }
                if (!methodMatch) continue;

                // Field type filter
                bool fieldMatch = fieldType.empty();
                if (!fieldType.empty()) {
                    auto fields = cls.get_fields();
                    for (auto& f : fields) {
                        if (!f) continue;
                        if (filterFieldStatic && f.is_static() != fieldStatic) continue;
                        std::string ftName = toLower(f.type_name() ? f.type_name() : "");
                        auto fType = f.type();
                        std::string ftFull = fType ? toLower(fType.full_name()) : "";
                        if (ftName.find(fieldTypeLower) != std::string::npos ||
                            ftFull.find(fieldTypeLower) != std::string::npos) {
                            fieldMatch = true;
                            break;
                        }
                    }
                }
                if (!fieldMatch) continue;

                const char* nameRaw = cls.name();
                const char* nsRaw = cls.ns();
                std::string fullName;
                if (nsRaw && nsRaw[0] != '\0')
                    fullName = std::string(nsRaw) + "." + (nameRaw ? nameRaw : "");
                else
                    fullName = nameRaw ? nameRaw : "";

                const char* rawN = cls.raw_name();
                const char* rawNs = cls.raw_ns();
                std::string rawFullName;
                if (rawNs && rawNs[0] != '\0')
                    rawFullName = std::string(rawNs) + "." + (rawN ? rawN : "");
                else
                    rawFullName = rawN ? rawN : "";

                if (count > 0) result += ",";
                result += "{\"fullName\":\"" + JsonEscape(fullName) + "\""
                    + ",\"rawFullName\":\"" + JsonEscape(rawFullName) + "\""
                    + ",\"name\":\"" + JsonEscape(nameRaw ? nameRaw : "") + "\""
                    + ",\"rawName\":\"" + JsonEscape(rawN ? rawN : "") + "\"}";
                count++;
            }
        }

        result += "]";
        return result;
    }

    std::string DebugBridge::CmdInspectClass(const std::string& json) {
        std::string name = ExtractJsonString(json, "name");
        if (name.empty()) return "{\"error\":\"name required\"}";

        auto cls = Class::find(name);
        if (!cls) return "{\"error\":\"class not found: " + JsonEscape(name) + "\"}";

        std::string result = "{\"fields\":[";
        try {
            auto fields = cls.get_fields();
            for (size_t i = 0; i < fields.size(); i++) {
                if (i > 0) result += ",";
                auto& f = fields[i];
                result += "{\"name\":\"" + JsonEscape(f.name() ? f.name() : "?") + "\""
                    + ",\"rawName\":\"" + JsonEscape(f.raw_name() ? f.raw_name() : "?") + "\""
                    + ",\"type\":\"" + JsonEscape(f.type_name() ? f.type_name() : "?") + "\""
                    + ",\"rawType\":\"" + JsonEscape(f.raw_type_name() ? f.raw_type_name() : "?") + "\""
                    + ",\"offset\":" + std::to_string(f.offset())
                    + ",\"static\":" + (f.is_static() ? "true" : "false")
                    + ",\"access\":\"" + JsonEscape(f.access_modifier() ? f.access_modifier() : "?") + "\"}";
            }
        } catch (...) {}

        result += "],\"methods\":[";
        try {
            auto methods = cls.get_methods();
            for (size_t i = 0; i < methods.size(); i++) {
                if (i > 0) result += ",";
                auto& m = methods[i];
                result += "{\"name\":\"" + JsonEscape(m.name() ? m.name() : "?") + "\""
                    + ",\"rawName\":\"" + JsonEscape(m.raw_name() ? m.raw_name() : "?") + "\""
                    + ",\"returnType\":\"" + JsonEscape(m.return_type_name() ? m.return_type_name() : "?") + "\""
                    + ",\"rawReturnType\":\"" + JsonEscape(m.raw_return_type_name() ? m.raw_return_type_name() : "?") + "\""
                    + ",\"paramCount\":" + std::to_string(m.param_count())
                    + ",\"static\":" + (m.is_static() ? "true" : "false")
                    + ",\"virtual\":" + (m.is_virtual() ? "true" : "false")
                    + ",\"sealed\":" + (m.is_sealed() ? "true" : "false")
                    + ",\"access\":\"" + JsonEscape(m.access_modifier() ? m.access_modifier() : "?") + "\"}";
            }
        } catch (...) {}

        result += "],\"properties\":[";
        try {
            auto props = cls.get_properties();
            for (size_t i = 0; i < props.size(); i++) {
                if (i > 0) result += ",";
                auto& p = props[i];
                result += "{\"name\":\"" + JsonEscape(p.name() ? p.name() : "?") + "\""
                    + ",\"rawName\":\"" + JsonEscape(p.raw_name() ? p.raw_name() : "?") + "\""
                    + ",\"type\":\"" + JsonEscape(p.type_name() ? p.type_name() : "?") + "\""
                    + ",\"rawType\":\"" + JsonEscape(p.raw_type_name() ? p.raw_type_name() : "?") + "\""
                    + ",\"access\":\"" + JsonEscape(p.access_modifier() ? p.access_modifier() : "?") + "\"}";
            }
        } catch (...) {}

        // Include parent class and raw class name
        std::string rawClassName = cls.raw_name() ? cls.raw_name() : "";
        auto parentCls = cls.parent();
        std::string parentName = parentCls ? (parentCls.name() ? parentCls.name() : "") : "";

        result += "],\"rawName\":\"" + JsonEscape(rawClassName) + "\""
            + ",\"parent\":\"" + JsonEscape(parentName) + "\""
            + ",\"instanceSize\":" + std::to_string(cls.instance_size())
            + "}";
        return result;
    }

    std::string DebugBridge::CmdCallMethod(const std::string& json) {
        std::string className = ExtractJsonString(json, "class_name");
        std::string methodName = ExtractJsonString(json, "method_name");
        if (className.empty() || methodName.empty()) return "{\"error\":\"class_name and method_name required\"}";

        auto cls = Class::find(className);
        if (!cls) return "{\"error\":\"class not found\"}";

        auto args = ExtractJsonStringArray(json, "args");
        auto method = cls.get_method(methodName, static_cast<int>(args.size()));
        if (!method) return "{\"error\":\"method not found: " + JsonEscape(methodName) + " with " + std::to_string(args.size()) + " params\"}";
        if (!method.is_static()) return "{\"error\":\"only static methods supported\"}";

        std::vector<void*> paramPtrs;
        std::vector<int32_t> intStore;
        std::vector<float> floatStore;
        std::vector<uint8_t> boolStore;
        intStore.reserve(args.size());
        floatStore.reserve(args.size());
        boolStore.reserve(args.size());

        for (size_t i = 0; i < args.size(); i++) {
            Type paramType = method.get_param_type(static_cast<uint32_t>(i));
            const char* ptn = paramType ? paramType.name() : "";
            std::string pt(ptn ? ptn : "");

            if (pt == "String" || pt == "System.String") {
                void* str = IL2CPP::Module::StringNew(args[i].c_str());
                paramPtrs.push_back(str);
            } else if (pt == "Int32" || pt == "int") {
                intStore.push_back(std::stoi(args[i]));
                paramPtrs.push_back(&intStore.back());
            } else if (pt == "Single" || pt == "float") {
                floatStore.push_back(std::stof(args[i]));
                paramPtrs.push_back(&floatStore.back());
            } else if (pt == "Boolean" || pt == "bool") {
                boolStore.push_back(static_cast<uint8_t>(args[i] == "true" || args[i] == "1"));
                paramPtrs.push_back(&boolStore.back());
            } else {
                return "{\"error\":\"unsupported param type: " + JsonEscape(pt) + "\"}";
            }
        }

        void* exc = nullptr;
        void* ret = method.invoke(nullptr, paramPtrs.empty() ? nullptr : paramPtrs.data(), &exc);

        if (exc) return "{\"error\":\"method threw exception\"}";

        const char* retTypeName = method.return_type_name();
        std::string rtn(retTypeName ? retTypeName : "Void");
        if (rtn == "Void") return "{\"ok\":true}";

        return "{\"value\":" + UnboxedValueToJson(ret) + "}";
    }

    std::string DebugBridge::CmdReadField(const std::string& json) {
        std::string className = ExtractJsonString(json, "class_name");
        std::string fieldName = ExtractJsonString(json, "field_name");
        if (className.empty() || fieldName.empty()) return "{\"error\":\"class_name and field_name required\"}";

        auto cls = Class::find(className);
        if (!cls) return "{\"error\":\"class not found\"}";

        auto field = cls.get_field(fieldName);
        if (!field) return "{\"error\":\"field not found\"}";

        if (field.is_static()) {
            return "{\"value\":" + FieldValueToJson(nullptr, field) + "}";
        }

        std::string addrStr = ExtractJsonString(json, "address");
        if (addrStr.empty()) return "{\"error\":\"address required for instance fields\"}";
        uintptr_t addr = std::stoull(addrStr, nullptr, 0);
        return "{\"value\":" + FieldValueToJson(reinterpret_cast<void*>(addr), field) + "}";
    }

    std::string DebugBridge::CmdSetField(const std::string& json) {
        std::string className = ExtractJsonString(json, "class_name");
        std::string fieldName = ExtractJsonString(json, "field_name");
        std::string value = ExtractJsonString(json, "value");
        if (className.empty() || fieldName.empty()) return "{\"error\":\"class_name and field_name required\"}";

        auto cls = Class::find(className);
        if (!cls) return "{\"error\":\"class not found\"}";

        auto field = cls.get_field(fieldName);
        if (!field) return "{\"error\":\"field not found\"}";

        const char* tn = field.type_name();
        std::string typeName(tn ? tn : "");

        void* target = nullptr;
        if (!field.is_static()) {
            std::string addrStr = ExtractJsonString(json, "address");
            if (addrStr.empty()) return "{\"error\":\"address required for instance fields\"}";
            target = reinterpret_cast<void*>(std::stoull(addrStr, nullptr, 0));
        }

        try {
            if (typeName == "System.Boolean" || typeName == "Boolean" || typeName == "bool") {
                bool v = (value == "true" || value == "1");
                if (field.is_static()) field.set_static_value(&v);
                else field.set_value(target, &v);
            } else if (typeName == "System.Int32" || typeName == "Int32" || typeName == "int") {
                int32_t v = std::stoi(value);
                if (field.is_static()) field.set_static_value(&v);
                else field.set_value(target, &v);
            } else if (typeName == "System.Single" || typeName == "Single" || typeName == "float") {
                float v = std::stof(value);
                if (field.is_static()) field.set_static_value(&v);
                else field.set_value(target, &v);
            } else if (typeName == "System.String" || typeName == "String") {
                void* str = IL2CPP::Module::StringNew(value.c_str());
                if (field.is_static()) field.set_static_value(&str);
                else field.set_value(target, &str);
            } else {
                return "{\"error\":\"unsupported type for set: " + JsonEscape(typeName) + "\"}";
            }
        } catch (...) {
            return "{\"error\":\"set_value failed\"}";
        }

        return "{\"ok\":true}";
    }

    // ========================================================================
    //  Players
    // ========================================================================

    std::string DebugBridge::CmdListPlayers(const std::string& json) {
        (void)json;
        auto playersSnap = ModuleManager::Get().GetPlayerCache().GetPlayers();
        auto& players = *playersSnap;

        auto rankStr = [](IL2CPP::VRChat::PlayerRank r) -> const char* {
            switch (r) {
            case IL2CPP::VRChat::PlayerRank::Visitor: return "Visitor";
            case IL2CPP::VRChat::PlayerRank::NewUser: return "New User";
            case IL2CPP::VRChat::PlayerRank::User: return "User";
            case IL2CPP::VRChat::PlayerRank::Known: return "Known";
            case IL2CPP::VRChat::PlayerRank::Trusted: return "Trusted";
            case IL2CPP::VRChat::PlayerRank::Administrator: return "Administrator";
            case IL2CPP::VRChat::PlayerRank::Troll: return "Troll";
            default: return "Unknown";
            }
        };

        std::string result = "[";
        for (size_t i = 0; i < players.size(); i++) {
            if (i > 0) result += ",";
            auto& p = players[i];
            result += "{\"name\":\"" + JsonEscape(p.displayName) + "\""
                + ",\"userId\":\"" + JsonEscape(p.userId) + "\""
                + ",\"playerId\":" + std::to_string(p.playerId)
                + ",\"rank\":\"" + rankStr(p.rank) + "\""
                + ",\"isVR\":" + (p.isVR ? "true" : "false")
                + ",\"isMaster\":" + (p.isMaster ? "true" : "false")
                + ",\"isLocal\":" + (p.isLocal ? "true" : "false")
                + ",\"isFriend\":" + (p.isFriend ? "true" : "false")
                + ",\"isQuest\":" + (p.isQuest ? "true" : "false") + "}";
        }
        result += "]";
        return result;
    }

    std::string DebugBridge::CmdGetPlayerInfo(const std::string& json) {
        int playerId = ExtractJsonInt(json, "player_id", -1);

        IL2CPP::VRChat::VRCPlayerApi api;
        if (playerId < 0) {
            api = UNIx::BaseModule::GetLocalPlayerApi();
        } else {
            api = IL2CPP::VRChat::VRCPlayerApi::GetPlayerById(playerId);
        }
        if (!api.valid()) return "{\"error\":\"player not found\"}";

        auto pos = api.GetPosition();
        auto rot = api.GetRotation();
        auto vel = api.GetVelocity();
        auto headData = api.GetTrackingData(IL2CPP::VRChat::TrackingDataType::Head);

        std::string result = "{\"displayName\":\"" + JsonEscape(api.GetDisplayName()) + "\""
            + ",\"playerId\":" + std::to_string(api.GetPlayerId())
            + ",\"isLocal\":" + (api.IsLocal() ? "true" : "false")
            + ",\"isMaster\":" + (api.IsMaster() ? "true" : "false")
            + ",\"isVR\":" + (api.IsUserInVR() ? "true" : "false")
            + ",\"isGrounded\":" + (api.IsPlayerGrounded() ? "true" : "false")
            + ",\"position\":{\"x\":" + std::to_string(pos.x) + ",\"y\":" + std::to_string(pos.y) + ",\"z\":" + std::to_string(pos.z) + "}"
            + ",\"rotation\":{\"x\":" + std::to_string(rot.x) + ",\"y\":" + std::to_string(rot.y) + ",\"z\":" + std::to_string(rot.z) + ",\"w\":" + std::to_string(rot.w) + "}"
            + ",\"velocity\":{\"x\":" + std::to_string(vel.x) + ",\"y\":" + std::to_string(vel.y) + ",\"z\":" + std::to_string(vel.z) + "}"
            + ",\"headPosition\":{\"x\":" + std::to_string(headData.position.x) + ",\"y\":" + std::to_string(headData.position.y) + ",\"z\":" + std::to_string(headData.position.z) + "}"
            + ",\"walkSpeed\":" + std::to_string(api.GetWalkSpeed())
            + ",\"runSpeed\":" + std::to_string(api.GetRunSpeed())
            + ",\"strafeSpeed\":" + std::to_string(api.GetStrafeSpeed())
            + ",\"jumpImpulse\":" + std::to_string(api.GetJumpImpulse())
            + ",\"gravityStrength\":" + std::to_string(api.GetGravityStrength())
            + ",\"avatarEyeHeight\":" + std::to_string(api.GetAvatarEyeHeightAsMeters())
            + "}";
        return result;
    }

    std::string DebugBridge::CmdGetAvatarInfo(const std::string& json) {
        int playerId = ExtractJsonInt(json, "player_id", -1);

        IL2CPP::VRChat::VRCPlayerApi api;
        if (playerId < 0) {
            api = UNIx::BaseModule::GetLocalPlayerApi();
        } else {
            api = IL2CPP::VRChat::VRCPlayerApi::GetPlayerById(playerId);
        }
        if (!api.valid()) return "{\"error\":\"player not found\"}";

        auto vrcPlayer = api.GetVRCPlayer();
        if (!vrcPlayer.valid()) return "{\"error\":\"VRCPlayer not found\"}";

        auto player = vrcPlayer.GetPlayer();
        if (!player.valid()) return "{\"error\":\"Player not found\"}";

        auto apiUser = player.GetAPIUser();
        if (!apiUser.valid()) return "{\"error\":\"APIUser not found\"}";

        std::string result = "{\"displayName\":\"" + JsonEscape(apiUser.GetDisplayName()) + "\""
            + ",\"avatarId\":\"" + JsonEscape(apiUser.GetAvatarId()) + "\""
            + ",\"avatarImageUrl\":\"" + JsonEscape(apiUser.GetCurrentAvatarImageUrl()) + "\""
            + ",\"avatarThumbnailUrl\":\"" + JsonEscape(apiUser.GetCurrentAvatarThumbnailImageUrl()) + "\""
            + ",\"allowCopying\":" + (apiUser.GetAllowAvatarCopying() ? "true" : "false")
            + ",\"eyeHeight\":" + std::to_string(api.GetAvatarEyeHeightAsMeters())
            + ",\"platform\":\"" + JsonEscape(apiUser.GetPlatform()) + "\""
            + ",\"profilePicOverride\":\"" + JsonEscape(apiUser.GetProfilePicOverride()) + "\""
            + "}";
        return result;
    }

    std::string DebugBridge::CmdTeleport(const std::string& json) {
        float x = ExtractJsonFloat(json, "x", 0);
        float y = ExtractJsonFloat(json, "y", 0);
        float z = ExtractJsonFloat(json, "z", 0);
        float rx = ExtractJsonFloat(json, "rx", 0);
        float ry = ExtractJsonFloat(json, "ry", 0);
        float rz = ExtractJsonFloat(json, "rz", 0);
        float rw = ExtractJsonFloat(json, "rw", 1);

        auto api = UNIx::BaseModule::GetLocalPlayerApi();
        if (!api.valid()) return "{\"error\":\"not in room\"}";

        Vector3 pos{x, y, z};
        Quaternion rot{rx, ry, rz, rw};
        api.TeleportTo(pos, rot);
        return "{\"ok\":true}";
    }

    std::string DebugBridge::CmdSetMovement(const std::string& json) {
        auto api = UNIx::BaseModule::GetLocalPlayerApi();
        if (!api.valid()) return "{\"error\":\"not in room\"}";

        std::string ws = ExtractJsonString(json, "walk_speed");
        std::string rs = ExtractJsonString(json, "run_speed");
        std::string ss = ExtractJsonString(json, "strafe_speed");
        std::string ji = ExtractJsonString(json, "jump_impulse");
        std::string gs = ExtractJsonString(json, "gravity");

        if (!ws.empty()) api.SetWalkSpeed(std::stof(ws));
        if (!rs.empty()) api.SetRunSpeed(std::stof(rs));
        if (!ss.empty()) api.SetStrafeSpeed(std::stof(ss));
        if (!ji.empty()) api.SetJumpImpulse(std::stof(ji));
        if (!gs.empty()) api.SetGravityStrength(std::stof(gs));

        return "{\"ok\":true,\"walkSpeed\":" + std::to_string(api.GetWalkSpeed())
            + ",\"runSpeed\":" + std::to_string(api.GetRunSpeed())
            + ",\"strafeSpeed\":" + std::to_string(api.GetStrafeSpeed())
            + ",\"jumpImpulse\":" + std::to_string(api.GetJumpImpulse())
            + ",\"gravity\":" + std::to_string(api.GetGravityStrength()) + "}";
    }

    // ========================================================================
    //  World / Network
    // ========================================================================

    std::string DebugBridge::CmdGetWorldInfo(const std::string& json) {
        (void)json;
        auto& cache = ModuleManager::Get().GetPlayerCache();
        auto playersSnap = cache.GetPlayers();

        std::string location;
        try {
            auto vrcPlayer = UNIx::BaseModule::GetLocalVRCPlayer();
            if (vrcPlayer.valid()) {
                auto player = vrcPlayer.GetPlayer();
                if (player.valid()) {
                    auto apiUser = player.GetAPIUser();
                    if (apiUser.valid()) location = apiUser.GetLocation();
                }
            }
        } catch (...) {}

        std::string worldId;
        std::string instanceId;
        if (!location.empty()) {
            auto tilde = location.find('~');
            auto colon = location.find(':');
            if (colon != std::string::npos) {
                worldId = location.substr(0, colon);
                instanceId = location.substr(colon + 1);
            } else if (tilde != std::string::npos) {
                worldId = location.substr(0, tilde);
                instanceId = location.substr(tilde + 1);
            } else {
                worldId = location;
            }
        }

        bool settled = false;
        bool clogged = false;
        bool isMaster = false;
        try {
            settled = IL2CPP::VRChat::Networking::IsNetworkSettled();
            clogged = IL2CPP::VRChat::Networking::IsClogged();
            isMaster = IL2CPP::VRChat::Networking::IsMaster();
        } catch (...) {}

        std::string result = "{\"worldId\":\"" + JsonEscape(worldId) + "\""
            + ",\"instanceId\":\"" + JsonEscape(instanceId) + "\""
            + ",\"playerCount\":" + std::to_string(playersSnap->size())
            + ",\"networkSettled\":" + (settled ? "true" : "false")
            + ",\"isMaster\":" + (isMaster ? "true" : "false")
            + ",\"isClogged\":" + (clogged ? "true" : "false")
            + "}";
        return result;
    }

    std::string DebugBridge::CmdGetNetworkInfo(const std::string& json) {
        (void)json;
        bool settled = false, clogged = false, isMaster = false, isOwner = false;
        double serverTime = 0;
        int serverTimeMs = 0;
        std::string masterName;

        try {
            settled = IL2CPP::VRChat::Networking::IsNetworkSettled();
            clogged = IL2CPP::VRChat::Networking::IsClogged();
            isMaster = IL2CPP::VRChat::Networking::IsMaster();
            isOwner = IL2CPP::VRChat::Networking::IsInstanceOwner();
            serverTime = IL2CPP::VRChat::Networking::GetServerTimeInSeconds();
            serverTimeMs = IL2CPP::VRChat::Networking::GetServerTimeInMilliseconds();

            auto master = IL2CPP::VRChat::Networking::GetMaster();
            if (master.valid()) masterName = master.GetDisplayName();
        } catch (...) {}

        std::string result = "{\"networkSettled\":" + std::string(settled ? "true" : "false")
            + ",\"isClogged\":" + (clogged ? "true" : "false")
            + ",\"isMaster\":" + (isMaster ? "true" : "false")
            + ",\"isInstanceOwner\":" + (isOwner ? "true" : "false")
            + ",\"serverTime\":" + std::to_string(serverTime)
            + ",\"serverTimeMs\":" + std::to_string(serverTimeMs)
            + ",\"masterPlayer\":\"" + JsonEscape(masterName) + "\""
            + "}";
        return result;
    }

    std::string DebugBridge::CmdGetPhotonInfo(const std::string& json) {
        std::string path = ExtractJsonString(json, "path");
        if (path.empty()) return "{\"error\":\"path required\"}";

        GameObject go = GameObject::Find(path);
        if (!go.valid()) return "{\"error\":\"GameObject not found\"}";

        auto photonComps = go.GetComponents("PhotonView");
        if (photonComps.empty()) return "{\"error\":\"no PhotonView on this GameObject\"}";

        void* pv = photonComps[0].raw();
        ManagedObject managed(pv);
        Class cls = managed.get_class();
        if (!cls) return "{\"error\":\"could not get PhotonView class\"}";

        std::string result = "{";
        try {
            auto viewIdField = cls.get_field("ViewID");
            if (viewIdField) {
                int viewId = 0;
                viewIdField.get_value(pv, &viewId);
                result += "\"viewID\":" + std::to_string(viewId);
            }
            auto ownerField = cls.get_field("OwnerActorNr");
            if (ownerField) {
                int owner = 0;
                ownerField.get_value(pv, &owner);
                result += ",\"ownerActorNr\":" + std::to_string(owner);
            }
            auto creatorField = cls.get_field("CreatorActorNr");
            if (creatorField) {
                int creator = 0;
                creatorField.get_value(pv, &creator);
                result += ",\"creatorActorNr\":" + std::to_string(creator);
            }
        } catch (...) {}

        result += "}";
        return result;
    }

    // ========================================================================
    //  Udon
    // ========================================================================

    std::string DebugBridge::CmdListUdonBehaviours(const std::string& json) {
        int limit = ExtractJsonInt(json, "limit", 100);

        auto objects = Object::FindObjectsOfType("VRC.Udon.UdonBehaviour");

        std::string result = "[";
        int count = 0;
        for (auto& obj : objects) {
            if (count >= limit) break;
            if (!obj.valid()) continue;

            try {
                Component comp(obj.raw());
                if (!comp.valid()) continue;
                GameObject go = comp.GetGameObject();
                if (!go.valid()) continue;
                Transform t = go.GetTransform();
                std::string path = t.valid() ? BuildPath(t) : "?";
                std::string goName = Object(go.raw()).GetName();
                bool active = go.GetActiveSelf();

                if (count > 0) result += ",";
                result += "{\"name\":\"" + JsonEscape(goName) + "\""
                    + ",\"path\":\"" + JsonEscape(path) + "\""
                    + ",\"active\":" + (active ? "true" : "false") + "}";
                count++;
            } catch (...) {}
        }
        result += "]";
        return result;
    }

    std::string DebugBridge::CmdGetUdonVariables(const std::string& json) {
        std::string path = ExtractJsonString(json, "path");
        auto names = ExtractJsonStringArray(json, "names");
        if (path.empty()) return "{\"error\":\"path required\"}";
        if (names.empty()) return "{\"error\":\"names array required (list of variable names to read)\"}";

        GameObject go = GameObject::Find(path);
        if (!go.valid()) return "{\"error\":\"GameObject not found\"}";

        auto udons = go.GetComponents("VRC.Udon.UdonBehaviour");
        if (udons.empty()) return "{\"error\":\"no UdonBehaviour on this GameObject\"}";

        void* udon = udons[0].raw();
        ManagedObject managed(udon);
        Class cls = managed.get_class();
        if (!cls) return "{\"error\":\"could not get UdonBehaviour class\"}";

        auto getVarMethod = cls.get_method("GetProgramVariable", 1);
        if (!getVarMethod) return "{\"error\":\"GetProgramVariable method not found\"}";

        std::string result = "{\"variables\":{";
        for (size_t i = 0; i < names.size(); i++) {
            if (i > 0) result += ",";
            result += "\"" + JsonEscape(names[i]) + "\":";

            try {
                void* nameStr = IL2CPP::Module::StringNew(names[i].c_str());
                void* params[] = { nameStr };
                void* exc = nullptr;
                void* value = getVarMethod.invoke(udon, params, &exc);
                if (exc) {
                    result += "\"<exception>\"";
                } else {
                    result += UnboxedValueToJson(value);
                }
            } catch (...) {
                result += "\"<error>\"";
            }
        }
        result += "}}";
        return result;
    }

    std::string DebugBridge::CmdSendUdonEvent(const std::string& json) {
        std::string path = ExtractJsonString(json, "path");
        std::string eventName = ExtractJsonString(json, "event");
        if (path.empty() || eventName.empty()) return "{\"error\":\"path and event required\"}";

        GameObject go = GameObject::Find(path);
        if (!go.valid()) return "{\"error\":\"GameObject not found\"}";

        auto udons = go.GetComponents("VRC.Udon.UdonBehaviour");
        if (udons.empty()) return "{\"error\":\"no UdonBehaviour on this GameObject\"}";

        void* udon = udons[0].raw();
        ManagedObject managed(udon);
        Class cls = managed.get_class();
        if (!cls) return "{\"error\":\"could not get class\"}";

        auto sendMethod = cls.get_method("SendCustomEvent", 1);
        if (!sendMethod) return "{\"error\":\"SendCustomEvent not found\"}";

        void* nameStr = IL2CPP::Module::StringNew(eventName.c_str());
        void* params[] = { nameStr };
        void* exc = nullptr;
        sendMethod.invoke(udon, params, &exc);

        if (exc) return "{\"error\":\"event threw exception\"}";
        return "{\"ok\":true}";
    }

    // ========================================================================
    //  Udon Event Monitor
    // ========================================================================

    bool DebugBridge::PrefixUdonSendCustomEvent(void* thisPtr, void* eventNameStr) {
        auto& db = DebugBridge::Get();
        if (!db.m_udonMonitorActive.load(std::memory_order_relaxed)) return true;

        std::string eventName = ReadIl2CppString(eventNameStr);
        std::string goName = "?";

        try {
            ManagedObject managed(thisPtr);
            Class cls = managed.get_class();
            if (cls) {
                auto goMethod = cls.get_method("get_gameObject", 0);
                if (goMethod) {
                    void* exc = nullptr;
                    void* goPtr = goMethod.invoke(thisPtr, nullptr, &exc);
                    if (goPtr && !exc) {
                        Object goObj(goPtr);
                        goName = goObj.GetName();
                    }
                }
            }
        } catch (...) {}

        auto now = std::chrono::steady_clock::now();
        auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch()).count();

        std::lock_guard lock(db.m_udonEventsMutex);
        db.m_udonEvents.push_back({ goName, eventName, static_cast<uint64_t>(ms) });
        if (db.m_udonEvents.size() > 500)
            db.m_udonEvents.pop_front();

        return true;
    }

    std::string DebugBridge::CmdStartUdonMonitor(const std::string& json) {
        if (!m_udonHookInstalled) {
            auto method = MethodHandler::resolve("VRC.Udon.UdonBehaviour", "SendCustomEvent", 1);
            if (!method) return "{\"error\":\"SendCustomEvent method not found\"}";

            void* ptr = method.pointer();
            if (!ptr) return "{\"error\":\"could not get method pointer\"}";

            if (!UNIx::g_hook || !UNIx::g_hook->valid())
                return "{\"error\":\"hooking not available\"}";

            m_udonHookId = UNIx::g_hook->create_prefix(
                "UdonMonitor_SendCustomEvent", ptr, PrefixUdonSendCustomEvent);

            if (m_udonHookId == Hooking::invalid_id)
                return "{\"error\":\"failed to install hook\"}";

            m_udonHookInstalled = true;
        }

        {
            std::lock_guard lock(m_udonEventsMutex);
            m_udonEvents.clear();
        }

        m_udonMonitorActive = true;
        return "{\"ok\":true}";
    }

    std::string DebugBridge::CmdStopUdonMonitor(const std::string& json) {
        m_udonMonitorActive = false;
        return "{\"ok\":true}";
    }

    std::string DebugBridge::CmdGetUdonEvents(const std::string& json) {
        uint64_t since = static_cast<uint64_t>(ExtractJsonInt(json, "since", 0));

        std::lock_guard lock(m_udonEventsMutex);
        std::string result = "[";
        bool first = true;
        for (auto& ev : m_udonEvents) {
            if (ev.timestamp <= since) continue;
            if (!first) result += ",";
            first = false;
            result += "{\"gameObject\":\"" + JsonEscape(ev.gameObject) + "\""
                    + ",\"event\":\"" + JsonEscape(ev.eventName) + "\""
                    + ",\"timestamp\":" + std::to_string(ev.timestamp) + "}";
        }
        result += "]";
        return result;
    }

    // ========================================================================
    //  Physics
    // ========================================================================

    std::string DebugBridge::CmdRaycast(const std::string& json) {
        float ox = ExtractJsonFloat(json, "origin_x", 0);
        float oy = ExtractJsonFloat(json, "origin_y", 0);
        float oz = ExtractJsonFloat(json, "origin_z", 0);
        float dx = ExtractJsonFloat(json, "direction_x", 0);
        float dy = ExtractJsonFloat(json, "direction_y", -1);
        float dz = ExtractJsonFloat(json, "direction_z", 0);
        float maxDist = ExtractJsonFloat(json, "max_distance", 1000.0f);
        int layerMask = ExtractJsonInt(json, "layer_mask", -1);

        Vector3 origin{ox, oy, oz};
        Vector3 direction{dx, dy, dz};
        RaycastHit hit{};

        bool didHit = Physics::Raycast(origin, direction, hit, maxDist, layerMask);

        std::string result = "{\"hit\":" + std::string(didHit ? "true" : "false");
        if (didHit) {
            result += ",\"point\":{\"x\":" + std::to_string(hit.point.x) + ",\"y\":" + std::to_string(hit.point.y) + ",\"z\":" + std::to_string(hit.point.z) + "}"
                + ",\"normal\":{\"x\":" + std::to_string(hit.normal.x) + ",\"y\":" + std::to_string(hit.normal.y) + ",\"z\":" + std::to_string(hit.normal.z) + "}"
                + ",\"distance\":" + std::to_string(hit.distance);
        }
        result += "}";
        return result;
    }

    // ========================================================================
    //  Animation
    // ========================================================================

    std::string DebugBridge::CmdListAnimations(const std::string& json) {
        std::string path = ExtractJsonString(json, "path");
        if (path.empty()) return "{\"error\":\"path required\"}";

        GameObject go = GameObject::Find(path);
        if (!go.valid()) return "{\"error\":\"GameObject not found\"}";

        auto animators = go.GetComponents("UnityEngine.Animator");
        if (animators.empty()) return "{\"error\":\"no Animator on this GameObject\"}";

        Animator animator(animators[0].raw());
        if (!animator.valid()) return "{\"error\":\"invalid Animator\"}";

        std::string result = "{\"isHuman\":" + std::string(animator.GetIsHuman() ? "true" : "false")
            + ",\"speed\":" + std::to_string(animator.GetSpeed())
            + ",\"hasRootMotion\":" + (animator.GetHasRootMotion() ? "true" : "false")
            + ",\"applyRootMotion\":" + (animator.GetApplyRootMotion() ? "true" : "false");

        result += ",\"parameters\":[";
        try {
            auto animClass = ManagedObject(animator.raw()).get_class();
            auto getParamsMethod = animClass.get_method("get_parameters", 0);
            if (getParamsMethod) {
                void* paramsArray = getParamsMethod.invoke(animator.raw(), nullptr);
                if (paramsArray) {
                    size_t length = *reinterpret_cast<size_t*>(reinterpret_cast<char*>(paramsArray) + 0x18);
                    void** elements = reinterpret_cast<void**>(reinterpret_cast<char*>(paramsArray) + 0x20);

                    for (size_t i = 0; i < length && i < 100; i++) {
                        void* param = elements[i];
                        if (!param) continue;

                        ManagedObject paramObj(param);
                        auto paramClass = paramObj.get_class();
                        if (!paramClass) continue;

                        auto nameField = paramClass.get_field("m_Name");
                        auto typeField = paramClass.get_field("m_Type");

                        std::string paramName;
                        int paramType = 0;
                        if (nameField) {
                            void* nameStr = nullptr;
                            nameField.get_value(param, &nameStr);
                            paramName = ReadIl2CppString(nameStr);
                        }
                        if (typeField) {
                            typeField.get_value(param, &paramType);
                        }

                        const char* typeStr = "Unknown";
                        switch (paramType) {
                        case 1: typeStr = "Float"; break;
                        case 3: typeStr = "Int"; break;
                        case 4: typeStr = "Bool"; break;
                        case 9: typeStr = "Trigger"; break;
                        }

                        if (i > 0) result += ",";
                        result += "{\"name\":\"" + JsonEscape(paramName) + "\",\"type\":\"" + typeStr + "\"";

                        try {
                            if (paramType == 1) result += ",\"value\":" + std::to_string(animator.GetFloat(paramName));
                            else if (paramType == 3) result += ",\"value\":" + std::to_string(animator.GetInteger(paramName));
                            else if (paramType == 4) result += ",\"value\":" + std::string(animator.GetBool(paramName) ? "true" : "false");
                        } catch (...) {}

                        result += "}";
                    }
                }
            }
        } catch (...) {}

        result += "]}";
        return result;
    }

    // ========================================================================
    //  Debug / Info
    // ========================================================================

    std::string DebugBridge::CmdReadLog(const std::string& json) {
        int lines = ExtractJsonInt(json, "lines", 50);
        if (lines < 1) lines = 1;
        if (lines > 1000) lines = 1000;

        std::ifstream file("C:\\nyx\\nyx_debug.log");
        if (!file.is_open()) return "{\"error\":\"cannot open log file\"}";

        std::deque<std::string> buffer;
        std::string line;
        while (std::getline(file, line)) {
            buffer.push_back(line);
            if (static_cast<int>(buffer.size()) > lines) buffer.pop_front();
        }

        std::string result = "{\"lines\":[";
        for (size_t i = 0; i < buffer.size(); i++) {
            if (i > 0) result += ",";
            result += "\"" + JsonEscape(buffer[i]) + "\"";
        }
        result += "]}";
        return result;
    }

    std::string DebugBridge::CmdSendLog(const std::string& json) {
        std::string message = ExtractJsonString(json, "message");
        if (message.empty()) return "{\"error\":\"message required\"}";
        FLOG("[MCP] {}", message);
        return "{\"ok\":true}";
    }

    std::string DebugBridge::CmdGetScreenInfo(const std::string& json) {
        (void)json;
        int w = Screen::GetWidth();
        int h = Screen::GetHeight();
        float dpi = Screen::GetDpi();
        bool fullScreen = Screen::GetFullScreen();

        return "{\"width\":" + std::to_string(w)
            + ",\"height\":" + std::to_string(h)
            + ",\"dpi\":" + std::to_string(dpi)
            + ",\"fullScreen\":" + (fullScreen ? "true" : "false")
            + "}";
    }

    std::string DebugBridge::CmdGetCameraInfo(const std::string& json) {
        (void)json;
        auto cam = Camera::GetMain();
        if (!cam.valid()) return "{\"error\":\"no main camera\"}";

        float fov = cam.GetFieldOfView();
        float nearClip = cam.GetNearClipPlane();
        float farClip = cam.GetFarClipPlane();
        bool ortho = cam.GetOrthographic();
        float depth = cam.GetDepth();

        Component camComp(cam.raw());
        Transform t;
        if (camComp.valid()) {
            GameObject go = camComp.GetGameObject();
            if (go.valid()) t = go.GetTransform();
        }

        std::string result = "{\"fov\":" + std::to_string(fov)
            + ",\"nearClip\":" + std::to_string(nearClip)
            + ",\"farClip\":" + std::to_string(farClip)
            + ",\"orthographic\":" + (ortho ? "true" : "false")
            + ",\"depth\":" + std::to_string(depth);

        if (t.valid()) {
            auto pos = t.GetPosition();
            auto rot = t.GetRotation();
            result += ",\"position\":{\"x\":" + std::to_string(pos.x) + ",\"y\":" + std::to_string(pos.y) + ",\"z\":" + std::to_string(pos.z) + "}"
                + ",\"rotation\":{\"x\":" + std::to_string(rot.x) + ",\"y\":" + std::to_string(rot.y) + ",\"z\":" + std::to_string(rot.z) + ",\"w\":" + std::to_string(rot.w) + "}";
        }

        result += "}";
        return result;
    }

    std::string DebugBridge::CmdSetCamera(const std::string& json) {
        auto cam = Camera::GetMain();
        if (!cam.valid()) return "{\"error\":\"no main camera\"}";

        std::string fovStr = ExtractJsonString(json, "fov");
        std::string nearStr = ExtractJsonString(json, "near_clip");
        std::string farStr = ExtractJsonString(json, "far_clip");

        if (!fovStr.empty()) cam.SetFieldOfView(std::stof(fovStr));
        if (!nearStr.empty()) cam.SetNearClipPlane(std::stof(nearStr));
        if (!farStr.empty()) cam.SetFarClipPlane(std::stof(farStr));

        return "{\"ok\":true,\"fov\":" + std::to_string(cam.GetFieldOfView())
            + ",\"nearClip\":" + std::to_string(cam.GetNearClipPlane())
            + ",\"farClip\":" + std::to_string(cam.GetFarClipPlane()) + "}";
    }

    std::string DebugBridge::CmdGetTimeInfo(const std::string& json) {
        (void)json;
        return "{\"time\":" + std::to_string(Time::GetTime())
            + ",\"deltaTime\":" + std::to_string(Time::GetDeltaTime())
            + ",\"fixedDeltaTime\":" + std::to_string(Time::GetFixedDeltaTime())
            + ",\"timeScale\":" + std::to_string(Time::GetTimeScale())
            + ",\"frameCount\":" + std::to_string(Time::GetFrameCount())
            + ",\"realtimeSinceStartup\":" + std::to_string(Time::GetRealtimeSinceStartup())
            + ",\"smoothDeltaTime\":" + std::to_string(Time::GetSmoothDeltaTime())
            + "}";
    }

    std::string DebugBridge::CmdGetAudioSources(const std::string& json) {
        int limit = ExtractJsonInt(json, "limit", 50);
        bool playingOnly = ExtractJsonBool(json, "playing_only", false);

        auto objects = Object::FindObjectsOfType("UnityEngine.AudioSource");

        std::string result = "[";
        int count = 0;
        for (auto& obj : objects) {
            if (count >= limit) break;
            if (!obj.valid()) continue;

            AudioSource src(obj.raw());
            if (!src.valid()) continue;

            bool isPlaying = src.GetIsPlaying();
            if (playingOnly && !isPlaying) continue;

            std::string goName;
            try {
                Component comp(obj.raw());
                if (comp.valid()) {
                    GameObject go = comp.GetGameObject();
                    if (go.valid()) goName = Object(go.raw()).GetName();
                }
            } catch (...) {}

            if (count > 0) result += ",";
            result += "{\"name\":\"" + JsonEscape(goName) + "\""
                + ",\"isPlaying\":" + (isPlaying ? "true" : "false")
                + ",\"volume\":" + std::to_string(src.GetVolume())
                + ",\"pitch\":" + std::to_string(src.GetPitch())
                + ",\"loop\":" + (src.GetLoop() ? "true" : "false")
                + ",\"mute\":" + (src.GetMute() ? "true" : "false")
                + ",\"spatialBlend\":" + std::to_string(src.GetSpatialBlend())
                + "}";
            count++;
        }
        result += "]";
        return result;
    }

    // ========================================================================
    //  Module Management
    // ========================================================================

    std::string DebugBridge::CmdListModules(const std::string& json) {
        (void)json;
        auto& modules = ModuleManager::Get().GetModules();

        std::string result = "[";
        for (size_t i = 0; i < modules.size(); i++) {
            if (i > 0) result += ",";
            auto& mod = modules[i];
            result += "{\"name\":\"" + JsonEscape(std::string(mod->GetName())) + "\""
                + ",\"description\":\"" + JsonEscape(std::string(mod->GetDescription())) + "\""
                + ",\"category\":\"" + JsonEscape(std::string(mod->GetCategory())) + "\""
                + ",\"enabled\":" + (mod->IsEnabled() ? "true" : "false")
                + ",\"keybind\":" + std::to_string(mod->GetKeybind())
                + ",\"showInQuickMenu\":" + (mod->ShowInQuickMenu() ? "true" : "false")
                + "}";
        }
        result += "]";
        return result;
    }

    std::string DebugBridge::CmdToggleModule(const std::string& json) {
        std::string name = ExtractJsonString(json, "name");
        if (name.empty()) return "{\"error\":\"name required\"}";

        auto* mod = ModuleManager::Get().FindModuleByName(name);
        if (!mod) return "{\"error\":\"module not found: " + JsonEscape(name) + "\"}";

        std::string enabledStr = ExtractJsonString(json, "enabled");
        if (enabledStr.empty()) {
            mod->Toggle();
        } else {
            mod->SetEnabled(enabledStr == "true");
        }

        return "{\"ok\":true,\"name\":\"" + JsonEscape(std::string(mod->GetName()))
            + "\",\"enabled\":" + (mod->IsEnabled() ? "true" : "false") + "}";
    }

    std::string DebugBridge::CmdGetConfig(const std::string& json) {
        std::string key = ExtractJsonString(json, "key");
        std::string type = ExtractJsonString(json, "type");
        if (key.empty()) return "{\"error\":\"key required\"}";
        if (type.empty()) type = "string";

        Bootstrap::Module::ModuleConfig config(g_mod->id());

        if (type == "int") {
            int def = ExtractJsonInt(json, "default", 0);
            int val = config.get_int(key, def);
            return "{\"value\":" + std::to_string(val) + "}";
        }
        if (type == "float") {
            float def = ExtractJsonFloat(json, "default", 0.f);
            float val = config.get_float(key, def);
            return "{\"value\":" + std::to_string(val) + "}";
        }
        if (type == "bool") {
            bool def = ExtractJsonBool(json, "default", false);
            bool val = config.get_bool(key, def);
            return "{\"value\":" + std::string(val ? "true" : "false") + "}";
        }

        std::string def = ExtractJsonString(json, "default");
        std::string val = config.get_string(key, def);
        return "{\"value\":\"" + JsonEscape(val) + "\"}";
    }

    std::string DebugBridge::CmdSetConfig(const std::string& json) {
        std::string key = ExtractJsonString(json, "key");
        std::string value = ExtractJsonString(json, "value");
        std::string type = ExtractJsonString(json, "type");
        if (key.empty()) return "{\"error\":\"key required\"}";
        if (type.empty()) type = "string";

        Bootstrap::Module::ModuleConfig config(g_mod->id());

        if (type == "int") {
            config.set_int(key, std::stoi(value));
        } else if (type == "float") {
            config.set_float(key, std::stof(value));
        } else if (type == "bool") {
            config.set_bool(key, value == "true" || value == "1");
        } else {
            config.set_string(key, value);
        }
        config.save();

        return "{\"ok\":true}";
    }

    // ========================================================================
    //  Player Actions
    // ========================================================================

    std::string DebugBridge::CmdPlayerAction(const std::string& json) {
        int playerId = ExtractJsonInt(json, "player_id", -1);
        std::string action = ExtractJsonString(json, "action");
        if (action.empty()) return "{\"error\":\"action required\"}";

        IL2CPP::VRChat::VRCPlayerApi api;
        if (playerId < 0) {
            api = UNIx::BaseModule::GetLocalPlayerApi();
        } else {
            api = IL2CPP::VRChat::VRCPlayerApi::GetPlayerById(playerId);
        }
        if (!api.valid()) return "{\"error\":\"player not found\"}";

        try {
            if (action == "set_voice_gain") {
                api.SetVoiceGain(ExtractJsonFloat(json, "value", 15.0f));
            } else if (action == "set_voice_distance_near") {
                api.SetVoiceDistanceNear(ExtractJsonFloat(json, "value", 0.0f));
            } else if (action == "set_voice_distance_far") {
                api.SetVoiceDistanceFar(ExtractJsonFloat(json, "value", 25.0f));
            } else if (action == "set_voice_volumetric_radius") {
                api.SetVoiceVolumetricRadius(ExtractJsonFloat(json, "value", 0.0f));
            } else if (action == "set_voice_lowpass") {
                api.SetVoiceLowpass(ExtractJsonBool(json, "value", true));
            } else if (action == "set_avatar_audio_gain") {
                api.SetAvatarAudioGain(ExtractJsonFloat(json, "value", 10.0f));
            } else if (action == "set_avatar_audio_far_radius") {
                api.SetAvatarAudioFarRadius(ExtractJsonFloat(json, "value", 40.0f));
            } else if (action == "set_avatar_audio_near_radius") {
                api.SetAvatarAudioNearRadius(ExtractJsonFloat(json, "value", 0.0f));
            } else if (action == "set_avatar_audio_volumetric_radius") {
                api.SetAvatarAudioVolumetricRadius(ExtractJsonFloat(json, "value", 0.0f));
            } else if (action == "set_avatar_audio_force_spatial") {
                api.SetAvatarAudioForceSpatial(ExtractJsonBool(json, "value", false));
            } else if (action == "set_avatar_audio_custom_curve") {
                api.SetAvatarAudioCustomCurve(ExtractJsonBool(json, "value", false));
            } else if (action == "immobilize") {
                api.Immobilize(ExtractJsonBool(json, "value", true));
            } else if (action == "respawn") {
                int idx = ExtractJsonInt(json, "spawn_index", -1);
                if (idx >= 0) api.Respawn(idx);
                else api.Respawn();
            } else if (action == "set_velocity") {
                float vx = ExtractJsonFloat(json, "x", 0);
                float vy = ExtractJsonFloat(json, "y", 0);
                float vz = ExtractJsonFloat(json, "z", 0);
                api.SetVelocity(Vector3{vx, vy, vz});
            } else if (action == "set_nameplate_color") {
                float r = ExtractJsonFloat(json, "r", 1);
                float g = ExtractJsonFloat(json, "g", 1);
                float b = ExtractJsonFloat(json, "b", 1);
                float a = ExtractJsonFloat(json, "a", 1);
                api.SetNamePlateColor(Color{r, g, b, a});
            } else if (action == "restore_nameplate_color") {
                api.RestoreNamePlateColor();
            } else if (action == "set_nameplate_visibility") {
                api.SetNamePlateVisibility(ExtractJsonBool(json, "value", true));
            } else if (action == "restore_nameplate_visibility") {
                api.RestoreNamePlateVisibility();
            } else if (action == "set_avatar_eye_height") {
                api.SetAvatarEyeHeightByMeters(ExtractJsonFloat(json, "value", 1.65f));
            } else if (action == "set_avatar_eye_height_multiplier") {
                api.SetAvatarEyeHeightByMultiplier(ExtractJsonFloat(json, "value", 1.0f));
            } else if (action == "set_avatar_scaling_allowed") {
                api.SetManualAvatarScalingAllowed(ExtractJsonBool(json, "value", true));
            } else if (action == "enable_pickups") {
                api.EnablePickups(ExtractJsonBool(json, "value", true));
            } else if (action == "use_legacy_locomotion") {
                api.UseLegacyLocomotion();
            } else if (action == "set_display_name") {
                api.SetDisplayName(ExtractJsonString(json, "value"));
            } else if (action == "get_bone_position") {
                int bone = ExtractJsonInt(json, "bone", 0);
                auto pos = api.GetBonePosition(static_cast<IL2CPP::VRChat::HumanBodyBones>(bone));
                return "{\"x\":" + std::to_string(pos.x) + ",\"y\":" + std::to_string(pos.y) + ",\"z\":" + std::to_string(pos.z) + "}";
            } else if (action == "get_bone_rotation") {
                int bone = ExtractJsonInt(json, "bone", 0);
                auto rot = api.GetBoneRotation(static_cast<IL2CPP::VRChat::HumanBodyBones>(bone));
                return "{\"x\":" + std::to_string(rot.x) + ",\"y\":" + std::to_string(rot.y) + ",\"z\":" + std::to_string(rot.z) + ",\"w\":" + std::to_string(rot.w) + "}";
            } else if (action == "get_tracking_data") {
                int tt = ExtractJsonInt(json, "tracking_type", 0);
                auto data = api.GetTrackingData(static_cast<IL2CPP::VRChat::TrackingDataType>(tt));
                return "{\"position\":{\"x\":" + std::to_string(data.position.x) + ",\"y\":" + std::to_string(data.position.y) + ",\"z\":" + std::to_string(data.position.z) + "}"
                    + ",\"rotation\":{\"x\":" + std::to_string(data.rotation.x) + ",\"y\":" + std::to_string(data.rotation.y) + ",\"z\":" + std::to_string(data.rotation.z) + ",\"w\":" + std::to_string(data.rotation.w) + "}}";
            } else if (action == "get_voice_info") {
                return "{\"gain\":" + std::to_string(api.GetVoiceGain())
                    + ",\"distanceNear\":" + std::to_string(api.GetVoiceDistanceNear())
                    + ",\"distanceFar\":" + std::to_string(api.GetVoiceDistanceFar())
                    + ",\"volumetricRadius\":" + std::to_string(api.GetVoiceVolumetricRadius())
                    + ",\"lowpass\":" + (api.GetVoiceLowpass() ? "true" : "false") + "}";
            } else {
                return "{\"error\":\"unknown action: " + JsonEscape(action) + "\"}";
            }
        } catch (...) {
            return "{\"error\":\"action failed: " + JsonEscape(action) + "\"}";
        }

        return "{\"ok\":true}";
    }

    std::string DebugBridge::CmdTeleportToPlayer(const std::string& json) {
        int targetId = ExtractJsonInt(json, "target_player_id", -1);
        if (targetId < 0) return "{\"error\":\"target_player_id required\"}";

        auto target = IL2CPP::VRChat::VRCPlayerApi::GetPlayerById(targetId);
        if (!target.valid()) return "{\"error\":\"target player not found\"}";

        auto local = UNIx::BaseModule::GetLocalPlayerApi();
        if (!local.valid()) return "{\"error\":\"not in room\"}";

        auto pos = target.GetPosition();
        auto rot = target.GetRotation();

        float offsetX = ExtractJsonFloat(json, "offset_x", 0);
        float offsetY = ExtractJsonFloat(json, "offset_y", 0);
        float offsetZ = ExtractJsonFloat(json, "offset_z", 0);
        pos.x += offsetX;
        pos.y += offsetY;
        pos.z += offsetZ;

        local.TeleportTo(pos, rot);
        return "{\"ok\":true,\"position\":{\"x\":" + std::to_string(pos.x) + ",\"y\":" + std::to_string(pos.y) + ",\"z\":" + std::to_string(pos.z) + "}}";
    }

    // ========================================================================
    //  Animator
    // ========================================================================

    std::string DebugBridge::CmdSetAnimatorParam(const std::string& json) {
        std::string path = ExtractJsonString(json, "path");
        std::string paramName = ExtractJsonString(json, "name");
        std::string type = ExtractJsonString(json, "type");
        if (path.empty() || paramName.empty()) return "{\"error\":\"path and name required\"}";

        GameObject go = GameObject::Find(path);
        if (!go.valid()) return "{\"error\":\"GameObject not found\"}";

        auto animators = go.GetComponents("UnityEngine.Animator");
        if (animators.empty()) return "{\"error\":\"no Animator on this GameObject\"}";

        Animator animator(animators[0].raw());
        if (!animator.valid()) return "{\"error\":\"invalid Animator\"}";

        try {
            if (type == "float") {
                animator.SetFloat(paramName, ExtractJsonFloat(json, "value", 0));
            } else if (type == "int") {
                animator.SetInteger(paramName, ExtractJsonInt(json, "value", 0));
            } else if (type == "bool") {
                animator.SetBool(paramName, ExtractJsonBool(json, "value", false));
            } else if (type == "trigger") {
                animator.SetTrigger(paramName);
            } else if (type == "reset_trigger") {
                animator.ResetTrigger(paramName);
            } else if (type == "play") {
                animator.Play(paramName);
                return "{\"ok\":true}";
            } else if (type == "crossfade") {
                float duration = ExtractJsonFloat(json, "duration", 0.25f);
                animator.CrossFade(paramName, duration);
                return "{\"ok\":true}";
            } else if (type == "speed") {
                animator.SetSpeed(ExtractJsonFloat(json, "value", 1.0f));
                return "{\"ok\":true,\"speed\":" + std::to_string(animator.GetSpeed()) + "}";
            } else {
                return "{\"error\":\"unknown type, use: float, int, bool, trigger, reset_trigger, play, crossfade, speed\"}";
            }
        } catch (...) {
            return "{\"error\":\"set animator param failed\"}";
        }

        return "{\"ok\":true}";
    }

    // ========================================================================
    //  Ownership
    // ========================================================================

    std::string DebugBridge::CmdTakeOwnership(const std::string& json) {
        std::string path = ExtractJsonString(json, "path");
        if (path.empty()) return "{\"error\":\"path required\"}";

        GameObject go = GameObject::Find(path);
        if (!go.valid()) return "{\"error\":\"GameObject not found\"}";

        auto local = UNIx::BaseModule::GetLocalPlayerApi();
        if (!local.valid()) return "{\"error\":\"not in room\"}";

        try {
            IL2CPP::VRChat::Networking::SetOwner(local, go);
        } catch (...) {
            return "{\"error\":\"SetOwner failed\"}";
        }

        return "{\"ok\":true}";
    }

    std::string DebugBridge::CmdGetOwnership(const std::string& json) {
        std::string path = ExtractJsonString(json, "path");
        if (path.empty()) return "{\"error\":\"path required\"}";

        GameObject go = GameObject::Find(path);
        if (!go.valid()) return "{\"error\":\"GameObject not found\"}";

        try {
            auto owner = IL2CPP::VRChat::Networking::GetOwner(go);
            if (!owner.valid()) return "{\"error\":\"no owner\"}";
            return "{\"ownerName\":\"" + JsonEscape(owner.GetDisplayName()) + "\",\"ownerId\":" + std::to_string(owner.GetPlayerId()) + "}";
        } catch (...) {
            return "{\"error\":\"GetOwner failed\"}";
        }
    }

    // ========================================================================
    //  Rigidbody
    // ========================================================================

    std::string DebugBridge::CmdSetRigidbody(const std::string& json) {
        std::string path = ExtractJsonString(json, "path");
        if (path.empty()) return "{\"error\":\"path required\"}";

        GameObject go = GameObject::Find(path);
        if (!go.valid()) return "{\"error\":\"GameObject not found\"}";

        auto rbs = go.GetComponents("UnityEngine.Rigidbody");
        if (rbs.empty()) return "{\"error\":\"no Rigidbody on this GameObject\"}";

        Rigidbody rb(rbs[0].raw());
        if (!rb.valid()) return "{\"error\":\"invalid Rigidbody\"}";

        try {
            std::string vx = ExtractJsonString(json, "velocity_x");
            if (!vx.empty()) {
                float vy = ExtractJsonFloat(json, "velocity_y", 0);
                float vz = ExtractJsonFloat(json, "velocity_z", 0);
                rb.SetVelocity(Vector3{std::stof(vx), vy, vz});
            }
            std::string avx = ExtractJsonString(json, "angular_velocity_x");
            if (!avx.empty()) {
                float avy = ExtractJsonFloat(json, "angular_velocity_y", 0);
                float avz = ExtractJsonFloat(json, "angular_velocity_z", 0);
                rb.SetAngularVelocity(Vector3{std::stof(avx), avy, avz});
            }
            std::string massStr = ExtractJsonString(json, "mass");
            if (!massStr.empty()) rb.SetMass(std::stof(massStr));
            std::string dragStr = ExtractJsonString(json, "drag");
            if (!dragStr.empty()) rb.SetDrag(std::stof(dragStr));
            std::string adragStr = ExtractJsonString(json, "angular_drag");
            if (!adragStr.empty()) rb.SetAngularDrag(std::stof(adragStr));
            std::string gravStr = ExtractJsonString(json, "use_gravity");
            if (!gravStr.empty()) rb.SetUseGravity(gravStr == "true");
            std::string kinStr = ExtractJsonString(json, "is_kinematic");
            if (!kinStr.empty()) rb.SetIsKinematic(kinStr == "true");
            std::string freezeStr = ExtractJsonString(json, "freeze_rotation");
            if (!freezeStr.empty()) rb.SetFreezeRotation(freezeStr == "true");
            std::string detectStr = ExtractJsonString(json, "detect_collisions");
            if (!detectStr.empty()) rb.SetDetectCollisions(detectStr == "true");
        } catch (...) {
            return "{\"error\":\"set rigidbody failed\"}";
        }

        auto vel = rb.GetVelocity();
        return "{\"ok\":true"
            ",\"velocity\":{\"x\":" + std::to_string(vel.x) + ",\"y\":" + std::to_string(vel.y) + ",\"z\":" + std::to_string(vel.z) + "}"
            ",\"mass\":" + std::to_string(rb.GetMass()) +
            ",\"drag\":" + std::to_string(rb.GetDrag()) +
            ",\"isKinematic\":" + (rb.GetIsKinematic() ? "true" : "false") +
            ",\"useGravity\":" + (rb.GetUseGravity() ? "true" : "false") + "}";
    }

    std::string DebugBridge::CmdAddForce(const std::string& json) {
        std::string path = ExtractJsonString(json, "path");
        if (path.empty()) return "{\"error\":\"path required\"}";

        GameObject go = GameObject::Find(path);
        if (!go.valid()) return "{\"error\":\"GameObject not found\"}";

        auto rbs = go.GetComponents("UnityEngine.Rigidbody");
        if (rbs.empty()) return "{\"error\":\"no Rigidbody on this GameObject\"}";

        Rigidbody rb(rbs[0].raw());
        if (!rb.valid()) return "{\"error\":\"invalid Rigidbody\"}";

        float fx = ExtractJsonFloat(json, "x", 0);
        float fy = ExtractJsonFloat(json, "y", 0);
        float fz = ExtractJsonFloat(json, "z", 0);
        int mode = ExtractJsonInt(json, "force_mode", 0);
        std::string forceType = ExtractJsonString(json, "force_type");

        try {
            if (forceType == "explosion") {
                float radius = ExtractJsonFloat(json, "radius", 5.0f);
                float upMod = ExtractJsonFloat(json, "upwards_modifier", 0.0f);
                rb.AddExplosionForce(ExtractJsonFloat(json, "force", 100.0f), Vector3{fx, fy, fz}, radius, upMod, static_cast<IL2CPP::ForceMode>(mode));
            } else if (forceType == "at_position") {
                float px = ExtractJsonFloat(json, "pos_x", 0);
                float py = ExtractJsonFloat(json, "pos_y", 0);
                float pz = ExtractJsonFloat(json, "pos_z", 0);
                rb.AddForceAtPosition(Vector3{fx, fy, fz}, Vector3{px, py, pz}, static_cast<IL2CPP::ForceMode>(mode));
            } else if (forceType == "torque") {
                rb.AddTorque(Vector3{fx, fy, fz}, static_cast<IL2CPP::ForceMode>(mode));
            } else {
                rb.AddForce(Vector3{fx, fy, fz}, static_cast<IL2CPP::ForceMode>(mode));
            }
        } catch (...) {
            return "{\"error\":\"add force failed\"}";
        }

        return "{\"ok\":true}";
    }

    // ========================================================================
    //  Transform
    // ========================================================================

    std::string DebugBridge::CmdSetTransform(const std::string& json) {
        std::string path = ExtractJsonString(json, "path");
        if (path.empty()) return "{\"error\":\"path required\"}";

        GameObject go = GameObject::Find(path);
        if (!go.valid()) return "{\"error\":\"GameObject not found\"}";

        Transform t = go.GetTransform();
        if (!t.valid()) return "{\"error\":\"no Transform\"}";

        bool local = ExtractJsonBool(json, "local", false);

        try {
            std::string px = ExtractJsonString(json, "pos_x");
            if (!px.empty()) {
                float py = ExtractJsonFloat(json, "pos_y", 0);
                float pz = ExtractJsonFloat(json, "pos_z", 0);
                if (local) t.SetLocalPosition(Vector3{std::stof(px), py, pz});
                else t.SetPosition(Vector3{std::stof(px), py, pz});
            }
            std::string rx = ExtractJsonString(json, "rot_x");
            if (!rx.empty()) {
                float ry = ExtractJsonFloat(json, "rot_y", 0);
                float rz = ExtractJsonFloat(json, "rot_z", 0);
                float rw = ExtractJsonFloat(json, "rot_w", 1);
                if (local) t.SetLocalRotation(Quaternion{std::stof(rx), ry, rz, rw});
                else t.SetRotation(Quaternion{std::stof(rx), ry, rz, rw});
            }
            std::string sx = ExtractJsonString(json, "scale_x");
            if (!sx.empty()) {
                float sy = ExtractJsonFloat(json, "scale_y", 1);
                float sz = ExtractJsonFloat(json, "scale_z", 1);
                t.SetLocalScale(Vector3{std::stof(sx), sy, sz});
            }
            std::string lookX = ExtractJsonString(json, "look_at_x");
            if (!lookX.empty()) {
                float lookY = ExtractJsonFloat(json, "look_at_y", 0);
                float lookZ = ExtractJsonFloat(json, "look_at_z", 0);
                t.LookAt(Vector3{std::stof(lookX), lookY, lookZ});
            }
        } catch (...) {
            return "{\"error\":\"set transform failed\"}";
        }

        auto pos = t.GetPosition();
        auto rot = t.GetRotation();
        auto scale = t.GetLocalScale();
        return "{\"ok\":true"
            ",\"position\":{\"x\":" + std::to_string(pos.x) + ",\"y\":" + std::to_string(pos.y) + ",\"z\":" + std::to_string(pos.z) + "}"
            ",\"rotation\":{\"x\":" + std::to_string(rot.x) + ",\"y\":" + std::to_string(rot.y) + ",\"z\":" + std::to_string(rot.z) + ",\"w\":" + std::to_string(rot.w) + "}"
            ",\"scale\":{\"x\":" + std::to_string(scale.x) + ",\"y\":" + std::to_string(scale.y) + ",\"z\":" + std::to_string(scale.z) + "}}";
    }

    // ========================================================================
    //  Network Udon
    // ========================================================================

    std::string DebugBridge::CmdSendNetworkUdonEvent(const std::string& json) {
        std::string path = ExtractJsonString(json, "path");
        std::string eventName = ExtractJsonString(json, "event");
        std::string targetStr = ExtractJsonString(json, "target");
        if (path.empty() || eventName.empty()) return "{\"error\":\"path and event required\"}";

        GameObject go = GameObject::Find(path);
        if (!go.valid()) return "{\"error\":\"GameObject not found\"}";

        auto udons = go.GetComponents("VRC.Udon.UdonBehaviour");
        if (udons.empty()) return "{\"error\":\"no UdonBehaviour on this GameObject\"}";

        IL2CPP::VRChat::UdonBehaviour udon(udons[0].raw());
        if (!udon.valid()) return "{\"error\":\"invalid UdonBehaviour\"}";

        IL2CPP::VRChat::NetworkEventTarget target = IL2CPP::VRChat::NetworkEventTarget::All;
        if (targetStr == "others" || targetStr == "Others") target = IL2CPP::VRChat::NetworkEventTarget::Others;

        try {
            udon.SendCustomNetworkEvent(target, eventName);
        } catch (...) {
            return "{\"error\":\"SendCustomNetworkEvent failed\"}";
        }

        return "{\"ok\":true}";
    }

    std::string DebugBridge::CmdSetUdonVariable(const std::string& json) {
        std::string path = ExtractJsonString(json, "path");
        std::string varName = ExtractJsonString(json, "name");
        std::string value = ExtractJsonString(json, "value");
        std::string type = ExtractJsonString(json, "type");
        if (path.empty() || varName.empty()) return "{\"error\":\"path and name required\"}";

        GameObject go = GameObject::Find(path);
        if (!go.valid()) return "{\"error\":\"GameObject not found\"}";

        auto udons = go.GetComponents("VRC.Udon.UdonBehaviour");
        if (udons.empty()) return "{\"error\":\"no UdonBehaviour on this GameObject\"}";

        void* udon = udons[0].raw();
        ManagedObject managed(udon);
        Class cls = managed.get_class();
        if (!cls) return "{\"error\":\"could not get class\"}";

        auto setVarMethod = cls.get_method("SetProgramVariable", 2);
        if (!setVarMethod) return "{\"error\":\"SetProgramVariable not found\"}";

        try {
            void* nameStr = IL2CPP::Module::StringNew(varName.c_str());
            void* boxedValue = nullptr;

            if (type == "int") {
                int32_t v = std::stoi(value);
                auto intCls = Class::find("System.Int32");
                boxedValue = intCls.new_object().raw();
                *reinterpret_cast<int32_t*>(reinterpret_cast<char*>(boxedValue) + 0x10) = v;
            } else if (type == "float") {
                float v = std::stof(value);
                auto floatCls = Class::find("System.Single");
                boxedValue = floatCls.new_object().raw();
                *reinterpret_cast<float*>(reinterpret_cast<char*>(boxedValue) + 0x10) = v;
            } else if (type == "bool") {
                bool v = (value == "true" || value == "1");
                auto boolCls = Class::find("System.Boolean");
                boxedValue = boolCls.new_object().raw();
                *reinterpret_cast<bool*>(reinterpret_cast<char*>(boxedValue) + 0x10) = v;
            } else if (type == "string") {
                boxedValue = IL2CPP::Module::StringNew(value.c_str());
            } else {
                return "{\"error\":\"unsupported type, use: int, float, bool, string\"}";
            }

            void* params[] = { nameStr, boxedValue };
            void* exc = nullptr;
            setVarMethod.invoke(udon, params, &exc);
            if (exc) return "{\"error\":\"SetProgramVariable threw exception\"}";
        } catch (...) {
            return "{\"error\":\"set udon variable failed\"}";
        }

        return "{\"ok\":true}";
    }

    // ========================================================================
    //  World Navigation
    // ========================================================================

    std::string DebugBridge::CmdGoToRoom(const std::string& json) {
        std::string roomId = ExtractJsonString(json, "room_id");
        if (roomId.empty()) return "{\"error\":\"room_id required (e.g. wrld_xxx:12345~region(us))\"}";

        try {
            bool ok = IL2CPP::VRChat::Networking::GoToRoom(roomId);
            if (!ok) return "{\"error\":\"GoToRoom returned false\"}";
        } catch (...) {
            return "{\"error\":\"GoToRoom failed\"}";
        }

        return "{\"ok\":true}";
    }

    // ========================================================================
    //  Batch
    // ========================================================================

    std::string DebugBridge::CmdBatch(const std::string& json) {
        std::string cmdsRaw = ExtractJsonString(json, "commands");
        if (cmdsRaw.empty()) {
            auto pos = json.find("\"commands\"");
            if (pos == std::string::npos) return "{\"error\":\"commands array required\"}";

            pos = json.find('[', pos);
            if (pos == std::string::npos) return "{\"error\":\"commands must be an array\"}";

            int depth = 0;
            size_t start = pos;
            std::vector<std::string> commands;
            size_t objStart = 0;

            for (size_t i = pos; i < json.size(); i++) {
                if (json[i] == '{') {
                    if (depth == 1) objStart = i;
                    depth++;
                } else if (json[i] == '}') {
                    depth--;
                    if (depth == 1) {
                        commands.push_back(json.substr(objStart, i - objStart + 1));
                    }
                } else if (json[i] == '[') {
                    if (depth == 0) depth = 1;
                    else depth++;
                } else if (json[i] == ']') {
                    depth--;
                    if (depth == 0) break;
                }
            }

            std::string result = "[";
            for (size_t i = 0; i < commands.size(); i++) {
                if (i > 0) result += ",";
                std::string method = ExtractJsonString(commands[i], "method");
                if (method.empty()) {
                    result += "{\"error\":\"missing method\"}";
                    continue;
                }
                try {
                    std::string cmdResult = ExecuteCommand(method, commands[i]);
                    result += cmdResult;
                } catch (const std::exception& e) {
                    result += "{\"error\":\"" + JsonEscape(e.what()) + "\"}";
                } catch (...) {
                    result += "{\"error\":\"unknown exception\"}";
                }
            }
            result += "]";
            return result;
        }
        return "{\"error\":\"commands must be an array of objects\"}";
    }

    // ========================================================================
    //  Input
    // ========================================================================

    std::string DebugBridge::CmdGetInput(const std::string& json) {
        std::string type = ExtractJsonString(json, "type");
        if (type.empty()) type = "mouse_position";

        try {
            if (type == "mouse_position") {
                auto pos = Input::GetMousePosition();
                return "{\"x\":" + std::to_string(pos.x) + ",\"y\":" + std::to_string(pos.y) + ",\"z\":" + std::to_string(pos.z) + "}";
            } else if (type == "mouse_scroll") {
                auto delta = Input::GetMouseScrollDelta();
                return "{\"x\":" + std::to_string(delta.x) + ",\"y\":" + std::to_string(delta.y) + "}";
            } else if (type == "mouse_button") {
                int button = ExtractJsonInt(json, "button", 0);
                return "{\"pressed\":" + std::string(Input::GetMouseButton(button) ? "true" : "false")
                    + ",\"down\":" + (Input::GetMouseButtonDown(button) ? "true" : "false")
                    + ",\"up\":" + (Input::GetMouseButtonUp(button) ? "true" : "false") + "}";
            } else if (type == "key") {
                int keyCode = ExtractJsonInt(json, "key_code", 0);
                return "{\"pressed\":" + std::string(Input::GetKey(static_cast<IL2CPP::KeyCode>(keyCode)) ? "true" : "false")
                    + ",\"down\":" + (Input::GetKeyDown(static_cast<IL2CPP::KeyCode>(keyCode)) ? "true" : "false")
                    + ",\"up\":" + (Input::GetKeyUp(static_cast<IL2CPP::KeyCode>(keyCode)) ? "true" : "false") + "}";
            } else if (type == "axis") {
                std::string axisName = ExtractJsonString(json, "axis_name");
                if (axisName.empty()) return "{\"error\":\"axis_name required\"}";
                float val = Input::GetAxis(axisName);
                float raw = Input::GetAxisRaw(axisName);
                return "{\"value\":" + std::to_string(val) + ",\"raw\":" + std::to_string(raw) + "}";
            } else if (type == "any_key") {
                return "{\"anyKey\":" + std::string(Input::GetAnyKey() ? "true" : "false")
                    + ",\"anyKeyDown\":" + (Input::GetAnyKeyDown() ? "true" : "false") + "}";
            }
        } catch (...) {
            return "{\"error\":\"get input failed\"}";
        }

        return "{\"error\":\"unknown input type\"}";
    }

    // ========================================================================
    //  Time Scale
    // ========================================================================

    std::string DebugBridge::CmdSetTimeScale(const std::string& json) {
        float scale = ExtractJsonFloat(json, "scale", 1.0f);
        Time::SetTimeScale(scale);
        return "{\"ok\":true,\"timeScale\":" + std::to_string(Time::GetTimeScale()) + "}";
    }

    // ========================================================================
    //  Object Lifecycle
    // ========================================================================

    std::string DebugBridge::CmdDestroyObject(const std::string& json) {
        std::string path = ExtractJsonString(json, "path");
        if (path.empty()) return "{\"error\":\"path required\"}";

        GameObject go = GameObject::Find(path);
        if (!go.valid()) return "{\"error\":\"GameObject not found\"}";

        float delay = ExtractJsonFloat(json, "delay", 0.0f);
        try {
            Object obj(go.raw());
            obj.Destroy(delay);
        } catch (...) {
            return "{\"error\":\"destroy failed\"}";
        }

        return "{\"ok\":true}";
    }

    std::string DebugBridge::CmdInstantiateObject(const std::string& json) {
        std::string path = ExtractJsonString(json, "path");
        if (path.empty()) return "{\"error\":\"path required (source object)\"}";

        GameObject go = GameObject::Find(path);
        if (!go.valid()) return "{\"error\":\"GameObject not found\"}";

        try {
            Object src(go.raw());
            auto clone = src.Instantiate();
            if (!clone.valid()) return "{\"error\":\"instantiate returned null\"}";

            std::string cloneName = clone.GetName();

            std::string px = ExtractJsonString(json, "pos_x");
            if (!px.empty()) {
                Component comp(clone.raw());
                if (comp.valid()) {
                    GameObject cloneGo = comp.GetGameObject();
                    if (!cloneGo.valid()) cloneGo = GameObject(clone.raw());
                    Transform t = cloneGo.GetTransform();
                    if (t.valid()) {
                        t.SetPosition(Vector3{std::stof(px), ExtractJsonFloat(json, "pos_y", 0), ExtractJsonFloat(json, "pos_z", 0)});
                    }
                }
            }

            std::ostringstream oss;
            oss << "{\"ok\":true,\"name\":\"" << JsonEscape(cloneName) << "\",\"address\":\"0x" << std::hex << reinterpret_cast<uintptr_t>(clone.raw()) << "\"}";
            return oss.str();
        } catch (...) {
            return "{\"error\":\"instantiate failed\"}";
        }
    }

    std::string DebugBridge::CmdFindByTag(const std::string& json) {
        std::string tag = ExtractJsonString(json, "tag");
        int limit = ExtractJsonInt(json, "limit", 50);
        if (tag.empty()) return "{\"error\":\"tag required\"}";

        auto objects = GameObject::FindGameObjectsWithTag(tag);

        std::string result = "[";
        int count = 0;
        for (auto& go : objects) {
            if (count >= limit) break;
            if (!go.valid()) continue;

            std::string name = Object(go.raw()).GetName();
            Transform t = go.GetTransform();
            std::string path = t.valid() ? BuildPath(t) : name;
            bool active = go.GetActiveSelf();

            if (count > 0) result += ",";
            result += "{\"name\":\"" + JsonEscape(name) + "\""
                + ",\"path\":\"" + JsonEscape(path) + "\""
                + ",\"active\":" + (active ? "true" : "false") + "}";
            count++;
        }
        result += "]";
        return result;
    }

    // ========================================================================
    //  Component Enable/Disable
    // ========================================================================

    std::string DebugBridge::CmdSetComponentEnabled(const std::string& json) {
        std::string path = ExtractJsonString(json, "path");
        std::string className = ExtractJsonString(json, "class_name");
        int index = ExtractJsonInt(json, "index", -1);
        bool enabled = ExtractJsonBool(json, "enabled", true);
        if (path.empty()) return "{\"error\":\"path required\"}";

        GameObject go = GameObject::Find(path);
        if (!go.valid()) return "{\"error\":\"GameObject not found\"}";

        void* target = nullptr;
        std::string resolvedClass;

        if (!className.empty()) {
            auto comps = go.GetComponents(className);
            if (comps.empty()) return "{\"error\":\"component not found: " + JsonEscape(className) + "\"}";
            target = comps[0].raw();
            resolvedClass = className;
        } else if (index >= 0) {
            auto comps = go.GetComponents("UnityEngine.Component");
            if (index >= static_cast<int>(comps.size())) return "{\"error\":\"index out of range\"}";
            target = comps[index].raw();
        } else {
            return "{\"error\":\"class_name or index required\"}";
        }

        if (!target) return "{\"error\":\"null component\"}";

        try {
            ManagedObject managed(target);
            Class cls = managed.get_class();
            if (!cls) return "{\"error\":\"could not get class\"}";

            auto setMethod = cls.get_method("set_enabled", 1);
            if (!setMethod) {
                auto parentCls = Class::find("UnityEngine.Behaviour");
                if (parentCls) setMethod = parentCls.get_method("set_enabled", 1);
            }
            if (!setMethod) {
                auto colliderCls = Class::find("UnityEngine.Collider");
                if (colliderCls) setMethod = colliderCls.get_method("set_enabled", 1);
            }
            if (!setMethod) {
                auto rendererCls = Class::find("UnityEngine.Renderer");
                if (rendererCls) setMethod = rendererCls.get_method("set_enabled", 1);
            }

            if (!setMethod) return "{\"error\":\"component does not support enabled property\"}";

            void* params[] = { &enabled };
            void* exc = nullptr;
            setMethod.invoke(target, params, &exc);
            if (exc) return "{\"error\":\"set_enabled threw exception\"}";
        } catch (...) {
            return "{\"error\":\"set component enabled failed\"}";
        }

        return "{\"ok\":true,\"enabled\":" + std::string(enabled ? "true" : "false") + "}";
    }

    // ========================================================================
    //  Layer
    // ========================================================================

    std::string DebugBridge::CmdSetLayer(const std::string& json) {
        std::string path = ExtractJsonString(json, "path");
        int layer = ExtractJsonInt(json, "layer", -1);
        bool recursive = ExtractJsonBool(json, "recursive", false);
        if (path.empty()) return "{\"error\":\"path required\"}";
        if (layer < 0 || layer > 31) return "{\"error\":\"layer must be 0-31\"}";

        GameObject go = GameObject::Find(path);
        if (!go.valid()) return "{\"error\":\"GameObject not found\"}";

        go.SetLayer(static_cast<unsigned int>(layer));

        if (recursive) {
            Transform t = go.GetTransform();
            if (t.valid()) {
                std::vector<Transform> stack;
                stack.push_back(t);
                while (!stack.empty()) {
                    Transform cur = stack.back();
                    stack.pop_back();
                    int cc = cur.GetChildCount();
                    for (int i = 0; i < cc; i++) {
                        Transform child = cur.GetChild(i);
                        if (!child.valid()) continue;
                        GameObject childGo = child.GetGameObject();
                        if (childGo.valid()) childGo.SetLayer(static_cast<unsigned int>(layer));
                        stack.push_back(child);
                    }
                }
            }
        }

        return "{\"ok\":true,\"layer\":" + std::to_string(layer) + "}";
    }

    // ========================================================================
    //  Parent
    // ========================================================================

    std::string DebugBridge::CmdSetParent(const std::string& json) {
        std::string childPath = ExtractJsonString(json, "path");
        std::string parentPath = ExtractJsonString(json, "parent_path");
        bool worldPositionStays = ExtractJsonBool(json, "world_position_stays", true);
        if (childPath.empty()) return "{\"error\":\"path required\"}";

        GameObject child = GameObject::Find(childPath);
        if (!child.valid()) return "{\"error\":\"child GameObject not found\"}";

        Transform childT = child.GetTransform();
        if (!childT.valid()) return "{\"error\":\"child has no Transform\"}";

        if (parentPath.empty()) {
            childT.SetParent(Transform(), worldPositionStays);
        } else {
            GameObject parent = GameObject::Find(parentPath);
            if (!parent.valid()) return "{\"error\":\"parent GameObject not found\"}";
            Transform parentT = parent.GetTransform();
            if (!parentT.valid()) return "{\"error\":\"parent has no Transform\"}";
            childT.SetParent(parentT, worldPositionStays);
        }

        return "{\"ok\":true}";
    }

    // ========================================================================
    //  World To Screen
    // ========================================================================

    std::string DebugBridge::CmdWorldToScreen(const std::string& json) {
        float wx = ExtractJsonFloat(json, "x", 0);
        float wy = ExtractJsonFloat(json, "y", 0);
        float wz = ExtractJsonFloat(json, "z", 0);
        bool reverse = ExtractJsonBool(json, "screen_to_world", false);

        auto cam = Camera::GetMain();
        if (!cam.valid()) return "{\"error\":\"no main camera\"}";

        try {
            if (reverse) {
                auto world = cam.ScreenToWorldPoint(Vector3{wx, wy, wz});
                return "{\"x\":" + std::to_string(world.x) + ",\"y\":" + std::to_string(world.y) + ",\"z\":" + std::to_string(world.z) + "}";
            } else {
                auto screen = cam.WorldToScreenPoint(Vector3{wx, wy, wz});
                bool behind = screen.z < 0;
                return "{\"x\":" + std::to_string(screen.x) + ",\"y\":" + std::to_string(screen.y) + ",\"z\":" + std::to_string(screen.z) + ",\"behind\":" + (behind ? "true" : "false") + "}";
            }
        } catch (...) {
            return "{\"error\":\"projection failed\"}";
        }
    }

    // ========================================================================
    //  Material
    // ========================================================================

    std::string DebugBridge::CmdSetMaterial(const std::string& json) {
        std::string path = ExtractJsonString(json, "path");
        if (path.empty()) return "{\"error\":\"path required\"}";

        GameObject go = GameObject::Find(path);
        if (!go.valid()) return "{\"error\":\"GameObject not found\"}";

        auto renderers = go.GetComponents("UnityEngine.Renderer");
        if (renderers.empty()) return "{\"error\":\"no Renderer on this GameObject\"}";

        ::IL2CPP::Module::Unity::Renderer renderer(renderers[0].raw());
        if (!renderer.valid()) return "{\"error\":\"invalid Renderer\"}";

        void* matRaw = renderer.GetMaterial();
        if (!matRaw) return "{\"error\":\"no material\"}";

        Material mat(matRaw);

        try {
            std::string rStr = ExtractJsonString(json, "r");
            if (!rStr.empty()) {
                float r = std::stof(rStr);
                float g = ExtractJsonFloat(json, "g", 1);
                float b = ExtractJsonFloat(json, "b", 1);
                float a = ExtractJsonFloat(json, "a", 1);
                mat.SetColor(Color{r, g, b, a});
            }

            std::string rqStr = ExtractJsonString(json, "render_queue");
            if (!rqStr.empty()) {
                mat.SetRenderQueue(std::stoi(rqStr));
            }
        } catch (...) {
            return "{\"error\":\"set material failed\"}";
        }

        auto color = mat.GetColor();
        int rq = mat.GetRenderQueue();
        void* shaderRaw = mat.GetShader();
        std::string shaderName = "unknown";
        if (shaderRaw) {
            try { shaderName = Object(shaderRaw).GetName(); } catch (...) {}
        }

        return "{\"ok\":true,\"shader\":\"" + JsonEscape(shaderName) + "\""
            + ",\"color\":{\"r\":" + std::to_string(color.r) + ",\"g\":" + std::to_string(color.g) + ",\"b\":" + std::to_string(color.b) + ",\"a\":" + std::to_string(color.a) + "}"
            + ",\"renderQueue\":" + std::to_string(rq) + "}";
    }

    // ========================================================================
    //  Audio Control
    // ========================================================================

    std::string DebugBridge::CmdAudioControl(const std::string& json) {
        std::string path = ExtractJsonString(json, "path");
        std::string action = ExtractJsonString(json, "action");
        if (path.empty() || action.empty()) return "{\"error\":\"path and action required\"}";

        GameObject go = GameObject::Find(path);
        if (!go.valid()) return "{\"error\":\"GameObject not found\"}";

        auto sources = go.GetComponents("UnityEngine.AudioSource");
        if (sources.empty()) return "{\"error\":\"no AudioSource on this GameObject\"}";

        AudioSource src(sources[0].raw());
        if (!src.valid()) return "{\"error\":\"invalid AudioSource\"}";

        try {
            if (action == "play") {
                src.Play();
            } else if (action == "stop") {
                src.Stop();
            } else if (action == "pause") {
                src.Pause();
            } else if (action == "unpause") {
                src.UnPause();
            } else if (action == "set_volume") {
                src.SetVolume(ExtractJsonFloat(json, "value", 1.0f));
            } else if (action == "set_pitch") {
                src.SetPitch(ExtractJsonFloat(json, "value", 1.0f));
            } else if (action == "set_loop") {
                src.SetLoop(ExtractJsonBool(json, "value", false));
            } else if (action == "set_mute") {
                src.SetMute(ExtractJsonBool(json, "value", false));
            } else if (action == "set_spatial_blend") {
                src.SetSpatialBlend(ExtractJsonFloat(json, "value", 0.0f));
            } else if (action == "set_time") {
                src.SetTime(ExtractJsonFloat(json, "value", 0.0f));
            } else {
                return "{\"error\":\"unknown action: " + JsonEscape(action) + "\"}";
            }
        } catch (...) {
            return "{\"error\":\"audio control failed\"}";
        }

        return "{\"ok\":true,\"isPlaying\":" + std::string(src.GetIsPlaying() ? "true" : "false")
            + ",\"volume\":" + std::to_string(src.GetVolume())
            + ",\"pitch\":" + std::to_string(src.GetPitch())
            + ",\"loop\":" + (src.GetLoop() ? "true" : "false")
            + ",\"mute\":" + (src.GetMute() ? "true" : "false")
            + ",\"time\":" + std::to_string(src.GetTime()) + "}";
    }

    // ========================================================================
    //  Overlap Sphere
    // ========================================================================

    std::string DebugBridge::CmdOverlapSphere(const std::string& json) {
        float cx = ExtractJsonFloat(json, "x", 0);
        float cy = ExtractJsonFloat(json, "y", 0);
        float cz = ExtractJsonFloat(json, "z", 0);
        float radius = ExtractJsonFloat(json, "radius", 5.0f);
        int layerMask = ExtractJsonInt(json, "layer_mask", -1);
        int limit = ExtractJsonInt(json, "limit", 50);

        try {
            auto physicsCls = Class::find("UnityEngine.Physics");
            if (!physicsCls) return "{\"error\":\"Physics class not found\"}";

            auto overlapMethod = physicsCls.get_method("OverlapSphere", 3);
            if (!overlapMethod) return "{\"error\":\"OverlapSphere not found\"}";

            Vector3 center{cx, cy, cz};
            void* params[] = { &center, &radius, &layerMask };
            void* exc = nullptr;
            void* result = overlapMethod.invoke(nullptr, params, &exc);
            if (exc) return "{\"error\":\"OverlapSphere threw exception\"}";
            if (!result) return "[]";

            size_t length = *reinterpret_cast<size_t*>(reinterpret_cast<char*>(result) + 0x18);
            void** elements = reinterpret_cast<void**>(reinterpret_cast<char*>(result) + 0x20);

            std::string out = "[";
            int count = 0;
            for (size_t i = 0; i < length && count < limit; i++) {
                void* collider = elements[i];
                if (!collider) continue;

                std::string goName;
                std::string goPath;
                try {
                    Component comp(collider);
                    if (comp.valid()) {
                        GameObject go = comp.GetGameObject();
                        if (go.valid()) {
                            goName = Object(go.raw()).GetName();
                            Transform t = go.GetTransform();
                            if (t.valid()) {
                                goPath = BuildPath(t);
                                auto pos = t.GetPosition();
                                if (count > 0) out += ",";
                                out += "{\"name\":\"" + JsonEscape(goName) + "\""
                                    + ",\"path\":\"" + JsonEscape(goPath) + "\""
                                    + ",\"position\":{\"x\":" + std::to_string(pos.x) + ",\"y\":" + std::to_string(pos.y) + ",\"z\":" + std::to_string(pos.z) + "}}";
                                count++;
                            }
                        }
                    }
                } catch (...) {}
            }
            out += "]";
            return out;
        } catch (...) {
            return "{\"error\":\"overlap sphere failed\"}";
        }
    }

    // ========================================================================
    //  Screen To Ray
    // ========================================================================

    std::string DebugBridge::CmdScreenToRay(const std::string& json) {
        float sx = ExtractJsonFloat(json, "x", 0);
        float sy = ExtractJsonFloat(json, "y", 0);
        float maxDist = ExtractJsonFloat(json, "max_distance", 1000.0f);
        int layerMask = ExtractJsonInt(json, "layer_mask", -1);

        auto cam = Camera::GetMain();
        if (!cam.valid()) return "{\"error\":\"no main camera\"}";

        try {
            Ray ray = cam.ScreenPointToRay(Vector3{sx, sy, 0});

            std::string result = "{\"ray\":{\"origin\":{\"x\":" + std::to_string(ray.origin.x) + ",\"y\":" + std::to_string(ray.origin.y) + ",\"z\":" + std::to_string(ray.origin.z) + "}"
                + ",\"direction\":{\"x\":" + std::to_string(ray.direction.x) + ",\"y\":" + std::to_string(ray.direction.y) + ",\"z\":" + std::to_string(ray.direction.z) + "}}";

            RaycastHit hit{};
            bool didHit = Physics::Raycast(ray.origin, ray.direction, hit, maxDist, layerMask);

            result += ",\"hit\":" + std::string(didHit ? "true" : "false");
            if (didHit) {
                result += ",\"point\":{\"x\":" + std::to_string(hit.point.x) + ",\"y\":" + std::to_string(hit.point.y) + ",\"z\":" + std::to_string(hit.point.z) + "}"
                    + ",\"normal\":{\"x\":" + std::to_string(hit.normal.x) + ",\"y\":" + std::to_string(hit.normal.y) + ",\"z\":" + std::to_string(hit.normal.z) + "}"
                    + ",\"distance\":" + std::to_string(hit.distance);

                if (hit.collider) {
                    try {
                        void* colliderPtr = reinterpret_cast<void*>(static_cast<uintptr_t>(hit.collider));
                        Component comp(colliderPtr);
                        if (comp.valid()) {
                            GameObject hitGo = comp.GetGameObject();
                            if (hitGo.valid()) {
                                std::string hitName = Object(hitGo.raw()).GetName();
                                Transform hitT = hitGo.GetTransform();
                                std::string hitPath = hitT.valid() ? BuildPath(hitT) : hitName;
                                int hitLayer = static_cast<int>(hitGo.GetLayer());
                                result += ",\"gameObject\":\"" + JsonEscape(hitName) + "\""
                                    + ",\"path\":\"" + JsonEscape(hitPath) + "\""
                                    + ",\"layer\":" + std::to_string(hitLayer);
                            }
                        }
                    } catch (...) {}
                }
            }

            result += "}";
            return result;
        } catch (...) {
            return "{\"error\":\"screen to ray failed\"}";
        }
    }

    // ========================================================================
    //  Get All Bones
    // ========================================================================

    std::string DebugBridge::CmdGetAllBones(const std::string& json) {
        int playerId = ExtractJsonInt(json, "player_id", -1);

        IL2CPP::VRChat::VRCPlayerApi api;
        if (playerId < 0) {
            api = UNIx::BaseModule::GetLocalPlayerApi();
        } else {
            api = IL2CPP::VRChat::VRCPlayerApi::GetPlayerById(playerId);
        }
        if (!api.valid()) return "{\"error\":\"player not found\"}";

        static const char* boneNames[] = {
            "Hips", "LeftUpperLeg", "RightUpperLeg", "LeftLowerLeg", "RightLowerLeg",
            "LeftFoot", "RightFoot", "Spine", "Chest", "Neck",
            "Head", "LeftShoulder", "RightShoulder", "LeftUpperArm", "RightUpperArm",
            "LeftLowerArm", "RightLowerArm", "LeftHand", "RightHand"
        };

        std::string result = "{\"bones\":{";
        for (int i = 0; i < 19; i++) {
            if (i > 0) result += ",";
            try {
                auto pos = api.GetBonePosition(static_cast<IL2CPP::VRChat::HumanBodyBones>(i));
                auto rot = api.GetBoneRotation(static_cast<IL2CPP::VRChat::HumanBodyBones>(i));
                result += "\"" + std::string(boneNames[i]) + "\":{"
                    "\"position\":{\"x\":" + std::to_string(pos.x) + ",\"y\":" + std::to_string(pos.y) + ",\"z\":" + std::to_string(pos.z) + "},"
                    "\"rotation\":{\"x\":" + std::to_string(rot.x) + ",\"y\":" + std::to_string(rot.y) + ",\"z\":" + std::to_string(rot.z) + ",\"w\":" + std::to_string(rot.w) + "}}";
            } catch (...) {
                result += "\"" + std::string(boneNames[i]) + "\":null";
            }
        }
        result += "}}";
        return result;
    }

    // ========================================================================
    //  Set Shader
    // ========================================================================

    std::string DebugBridge::CmdSetShader(const std::string& json) {
        std::string path = ExtractJsonString(json, "path");
        std::string shaderName = ExtractJsonString(json, "shader");
        if (path.empty() || shaderName.empty()) return "{\"error\":\"path and shader required\"}";

        GameObject go = GameObject::Find(path);
        if (!go.valid()) return "{\"error\":\"GameObject not found\"}";

        auto renderers = go.GetComponents("UnityEngine.Renderer");
        if (renderers.empty()) return "{\"error\":\"no Renderer on this GameObject\"}";

        ::IL2CPP::Module::Unity::Renderer renderer(renderers[0].raw());
        if (!renderer.valid()) return "{\"error\":\"invalid Renderer\"}";

        void* matRaw = renderer.GetMaterial();
        if (!matRaw) return "{\"error\":\"no material\"}";

        Material mat(matRaw);

        try {
            auto shaderCls = Class::find("UnityEngine.Shader");
            if (!shaderCls) return "{\"error\":\"Shader class not found\"}";

            auto findMethod = shaderCls.get_method("Find", 1);
            if (!findMethod) return "{\"error\":\"Shader.Find not found\"}";

            void* nameStr = IL2CPP::Module::StringNew(shaderName.c_str());
            void* params[] = { nameStr };
            void* exc = nullptr;
            void* shader = findMethod.invoke(nullptr, params, &exc);
            if (exc || !shader) return "{\"error\":\"shader not found: " + JsonEscape(shaderName) + "\"}";

            mat.SetShader(shader);
        } catch (...) {
            return "{\"error\":\"set shader failed\"}";
        }

        void* newShader = mat.GetShader();
        std::string currentShader = "unknown";
        if (newShader) {
            try { currentShader = Object(newShader).GetName(); } catch (...) {}
        }

        return "{\"ok\":true,\"shader\":\"" + JsonEscape(currentShader) + "\"}";
    }

    // ========================================================================
    //  Get Player By Name
    // ========================================================================

    std::string DebugBridge::CmdGetPlayerByName(const std::string& json) {
        std::string name = ExtractJsonString(json, "name");
        if (name.empty()) return "{\"error\":\"name required\"}";

        std::string nameLower = name;
        std::transform(nameLower.begin(), nameLower.end(), nameLower.begin(), ::tolower);

        auto playersSnap = ModuleManager::Get().GetPlayerCache().GetPlayers();

        std::string result = "[";
        int count = 0;

        for (auto& p : *playersSnap) {
            std::string dispLower = p.displayName;
            std::transform(dispLower.begin(), dispLower.end(), dispLower.begin(), ::tolower);

            if (dispLower.find(nameLower) == std::string::npos) continue;

            if (count > 0) result += ",";
            result += "{\"name\":\"" + JsonEscape(p.displayName) + "\""
                + ",\"userId\":\"" + JsonEscape(p.userId) + "\""
                + ",\"playerId\":" + std::to_string(p.playerId)
                + ",\"isLocal\":" + (p.isLocal ? "true" : "false")
                + ",\"isMaster\":" + (p.isMaster ? "true" : "false")
                + ",\"isVR\":" + (p.isVR ? "true" : "false") + "}";
            count++;
        }

        result += "]";
        return result;
    }

}
