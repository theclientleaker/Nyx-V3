#include <Modules/Utility/Performance/PerformanceModule.hpp>
#include <Bootstrap.Module/include/bootstrap_module.hpp>
#include <Core/QuickMenuEx.hpp>
#include <Core/Globals.hpp>

namespace UNIx {

PerformanceModule* PerformanceModule::s_instance = nullptr;

PerformanceModule::PerformanceModule()
    : BaseModule("Performance", "Graphics quality & memory controls", 0, "Utility") {
    m_showInQuickMenu = false;
}

static constexpr int32_t kAAValues[] = { 0, 2, 4, 8 };

static int32_t AAValueToIndex(int32_t val) {
    for (int32_t i = 0; i < 4; ++i)
        if (kAAValues[i] == val) return i;
    return 0;
}

void __cdecl PerformanceModule::QmTextureLimitCb(uint32_t, int32_t index) {
    Bootstrap::Module::Performance::Get().set_int(0, index);
}

void __cdecl PerformanceModule::QmAntiAliasingCb(uint32_t, int32_t index) {
    if (index >= 0 && index < 4)
        Bootstrap::Module::Performance::Get().set_int(1, kAAValues[index]);
}

void __cdecl PerformanceModule::QmShadowResCb(uint32_t, int32_t index) {
    Bootstrap::Module::Performance::Get().set_int(2, index);
}

void __cdecl PerformanceModule::QmVSyncCb(uint32_t, int32_t index) {
    Bootstrap::Module::Performance::Get().set_int(5, index);
}

void __cdecl PerformanceModule::QmLodBiasCb(uint32_t, float val) {
    Bootstrap::Module::Performance::Get().set_float(101, val);
}

void __cdecl PerformanceModule::QmMipmapBudgetCb(uint32_t, float val) {
    Bootstrap::Module::Performance::Get().set_float(100, val);
}

void __cdecl PerformanceModule::QmForceGcCb(uint32_t) {
    Bootstrap::Module::Performance::Get().force_gc(2);
}

void __cdecl PerformanceModule::QmFullCleanupCb(uint32_t) {
    Bootstrap::Module::Performance::Get().full_cleanup();
}

void PerformanceModule::OnSetupQuickMenu(uint32_t moduleId, uint32_t categoryPageId) {
    s_instance = this;
    auto& qm = Bootstrap::Module::QuickMenu::Get();
    auto& qmEx = QuickMenuEx::Get();
    auto& perf = Bootstrap::Module::Performance::Get();

    uint32_t fold = qmEx.add_foldout(moduleId, categoryPageId, "Performance", false, true);

    const char* texOpts[] = { "Full", "Half", "Quarter", "Eighth" };
    qmEx.add_enum_selector(moduleId, fold, "Texture Quality", texOpts, 4,
        perf.get_int(0), QmTextureLimitCb, "perf_texture_limit");

    const char* aaOpts[] = { "Off", "2x", "4x", "8x" };
    qmEx.add_enum_selector(moduleId, fold, "Anti-Aliasing", aaOpts, 4,
        AAValueToIndex(perf.get_int(1)), QmAntiAliasingCb, "perf_anti_aliasing");

    const char* shadowOpts[] = { "Low", "Medium", "High", "Very High" };
    qmEx.add_enum_selector(moduleId, fold, "Shadow Resolution", shadowOpts, 4,
        perf.get_int(2), QmShadowResCb, "perf_shadow_res");

    const char* vsyncOpts[] = { "Off", "Every VBlank", "Every Other" };
    qmEx.add_enum_selector(moduleId, fold, "VSync", vsyncOpts, 3,
        perf.get_int(5), QmVSyncCb, "perf_vsync");

    qmEx.add_slider(moduleId, fold, "LOD Bias", 0.5f, 4.0f, perf.get_float(101),
        QmLodBiasCb, "perf_lod_bias", "%.1f");

    qmEx.add_slider(moduleId, fold, "Mipmap Budget (MB)", 32.0f, 512.0f, perf.get_float(100),
        QmMipmapBudgetCb, "perf_mipmap_budget", "%.0f");

    qmEx.add_separator(moduleId, fold);

    qm.add_button(moduleId, fold, "Force GC", QmForceGcCb);
    qm.add_button(moduleId, fold, "Full Cleanup", QmFullCleanupCb);
}

} // namespace UNIx
