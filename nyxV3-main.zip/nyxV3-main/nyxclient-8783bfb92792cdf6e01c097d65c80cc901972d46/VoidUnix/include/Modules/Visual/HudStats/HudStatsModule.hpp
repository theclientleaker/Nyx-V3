#pragma once

#include <Core/BaseModule.hpp>

namespace UNIx {

    class HudStatsModule : public BaseModule {
    public:
        HudStatsModule();

        void OnUpdate() override;
        void OnSceneLoad(int scene, int loadMode) override;
        void OnSceneUnload(int scene, int loadMode) override;
        void OnSetupQuickMenu(uint32_t moduleId, uint32_t categoryPageId) override;

        static HudStatsModule* s_instance;

    private:
        void CreateHud();
        void Cleanup();

        int m_fps = 0;
        int m_ping = 0;
        float m_fpsAccum = 0.f;
        int m_fpsFrames = 0;
        float m_fpsTimer = 0.f;

        void* m_fpsRowGO = nullptr;
        void* m_pingRowGO = nullptr;
        void* m_fpsTMP = nullptr;
        void* m_pingTMP = nullptr;

        bool m_hudCreated = false;
        float m_initDelay = 6.f;

        bool m_showFps = true;
        bool m_showPing = true;

        static void __cdecl QmShowFpsCb(uint32_t, bool val);
        static void __cdecl QmShowPingCb(uint32_t, bool val);
    };

} // namespace UNIx
