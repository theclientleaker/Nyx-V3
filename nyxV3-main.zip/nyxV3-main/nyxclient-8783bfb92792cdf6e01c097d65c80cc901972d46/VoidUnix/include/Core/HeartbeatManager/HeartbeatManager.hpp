#pragma once

#include <string>
#include <vector>
#include <mutex>
#include <memory>
#include <thread>
#include <atomic>

namespace UNIx {

    struct ActiveUser {
        std::string userId;
        std::string displayName;
        std::string clientVersion;
        std::string worldId;
        std::string worldName;
        int fps = 0;
        bool isDev = false;
        std::vector<std::string> modules;
    };

    using ActiveUserSnapshot = std::shared_ptr<const std::vector<ActiveUser>>;

    class HeartbeatManager {
    public:
        static HeartbeatManager& Get();

        void Start();
        void Stop();

        bool IsDev() const { return m_isDev; }
        std::string GetLocalUserId() const { std::lock_guard lock(m_mutex); return m_localUserId; }
        std::string GetLocalWorldId() const { std::lock_guard lock(m_mutex); return m_localWorldId; }
        ActiveUserSnapshot GetActiveUsers() const;

        void SetLocalUserId(const std::string& userId);
        void SetLocalDisplayName(const std::string& name);
        void UpdateLocalInfo(int fps, const std::string& worldId, const std::string& worldName);

        void RequestRefresh();
        void ApiSetTag(const std::string& userId, const std::string& tagData);
        void ApiRemoveTag(const std::string& userId);
        void ApiGrantDev(const std::string& userId);
        void ApiRevokeDev(const std::string& userId);
        void ApiSendCommand(const std::string& userId, const std::string& type, const std::string& worldId = "");
        bool HasPendingCommand() const;
        std::pair<std::string, std::string> ConsumePendingCommand();
        void RefreshTags();

    private:
        HeartbeatManager() = default;
        ~HeartbeatManager();

        void WorkerLoop();
        void SendHeartbeat();
        void SendWebSocketHeartbeat();
        void FetchActiveUsers();
        void CheckDevStatus();
        void OnWebSocketMessage(const std::string& message);

        struct LocalData {
            std::string userId;
            std::string displayName;
            int fps = 0;
            std::string worldId;
            std::string worldName;
        };
        LocalData SnapshotLocalData() const;
        std::string BuildHeartbeatJson(const LocalData& data) const;
        std::vector<ActiveUser> ParseUserArray(const std::string& json, size_t searchStart = 0) const;

        mutable std::mutex m_mutex;
        std::shared_ptr<std::vector<ActiveUser>> m_activeUsers = std::make_shared<std::vector<ActiveUser>>();
        std::string m_localUserId;
        std::string m_localDisplayName;
        int m_localFps = 0;
        std::string m_localWorldId;
        std::string m_localWorldName;
        std::atomic<bool> m_isDev{false};

        std::string m_pendingCommandType;
        std::string m_pendingCommandWorldId;

        std::thread m_thread;
        std::atomic<bool> m_running{false};
        std::atomic<bool> m_refreshRequested{false};
    };

} // namespace UNIx
