#include <Modules/Visual/ThirdPerson/ThirdPersonModule.hpp>
#include <Core/FileLog/FileLog.hpp>

#include <IL2CPP.Module/include/Unity/Camera.hpp>
#include <IL2CPP.Module/include/Unity/GameObject.hpp>
#include <IL2CPP.Module/include/Unity/Transform.hpp>
#include <IL2CPP.Module/include/Unity/Input.hpp>
#include <IL2CPP.Module/include/Unity/Object.hpp>
#include <IL2CPP.Module/include/Unity/Component.hpp>
#include <IL2CPP.Module/include/Reflection.hpp>
#include <IL2CPP.Module/include/MethodHandler.hpp>
#include <Bootstrap.Module/include/VRChat/VRCPlayer.hpp>

using namespace IL2CPP::Module;
using namespace IL2CPP::Module::Unity;

namespace UNIx {

    ThirdPersonModule::ThirdPersonModule()
        : BaseModule("Third Person", "Third person camera (Ctrl+T)", 0, "Visual") {
        m_enabled = true;
        m_showInQuickMenu = false;
    }

    void ThirdPersonModule::ShowHead(bool) {
    }

    void ThirdPersonModule::CreateCameras() {
        if (m_camerasCreated) return;

        auto mainCam = Camera::GetMain();
        if (!mainCam.valid()) return;

        auto mainT = mainCam.GetTransform();
        if (!mainT.valid()) return;

        auto parentT = mainT.GetParent();
        if (!parentT.valid()) return;

        auto camClass = Class::find("UnityEngine.Camera");
        if (!camClass) return;

        auto mainGO = mainT.GetGameObject();
        if (!mainGO.valid()) return;

        auto createCam = [&](const char* name) -> void* {
            auto clone = mainGO.Instantiate();
            if (!clone.raw() || !clone.IsValid()) return nullptr;

            GameObject go(clone.raw());
            go.SetName(std::string(name));

            auto goT = go.GetTransform();
            for (int i = goT.GetChildCount() - 1; i >= 0; --i) {
                auto childT = goT.GetChild(i);
                if (childT.valid()) {
                    auto childGO = childT.GetGameObject();
                    if (childGO.valid()) Object(childGO.raw()).Destroy();
                }
            }

            const char* stripComps[] = {
                "VRC.UserCamera.CameraFlip",
                "UnityEngine.AudioListener",
                "VRC.UserCamera",
                "UnityEngine.FlareLayer",
            };
            for (auto* comp : stripComps) {
                auto c = go.GetComponentByName(comp);
                if (c.valid()) Object(c.raw()).Destroy();
            }

            goT.SetParent(parentT, false);
            goT.SetPosition(mainT.GetPosition());
            goT.SetRotation(mainT.GetRotation());

            auto camComp = go.GetComponent(camClass);
            if (!camComp.valid()) {
                camComp = go.AddComponent(camClass);
            }
            if (!camComp.valid()) { Object(clone.raw()).Destroy(); return nullptr; }

            static auto setEnabled = MethodHandler::resolve("UnityEngine.Behaviour", "set_enabled", 1);
            if (setEnabled) {
                bool off = false;
                void* p[] = { &off };
                MethodHandler::invoke(setEnabled, camComp.raw(), p);
            }

            static auto setFov = MethodHandler::resolve("UnityEngine.Camera", "set_fieldOfView", 1);
            if (setFov) {
                float fov = 75.f;
                void* p[] = { &fov };
                MethodHandler::invoke(setFov, camComp.raw(), p);
            }

            static auto setNear = MethodHandler::resolve("UnityEngine.Camera", "set_nearClipPlane", 1);
            if (setNear) {
                float val = 0.01f;
                void* p[] = { &val };
                MethodHandler::invoke(setNear, camComp.raw(), p);
            }

            static auto setDepth = MethodHandler::resolve("UnityEngine.Camera", "set_depth", 1);
            if (setDepth) {
                float depth = 100.f;
                void* p[] = { &depth };
                MethodHandler::invoke(setDepth, camComp.raw(), p);
            }

            static auto setCull = MethodHandler::resolve("UnityEngine.Camera", "set_cullingMask", 1);
            if (setCull) {
                int mask = -1;
                void* p[] = { &mask };
                MethodHandler::invoke(setCull, camComp.raw(), p);
            }

            go.SetActive(true);
            return camComp.raw();
        };

        m_camBack = createCam("nyx_3P_Back");
        m_camFront = createCam("nyx_3P_Front");

        if (m_camBack && m_camFront) {
            m_camerasCreated = true;
            FLOG("[ThirdPerson] Cameras created");
        }
    }

    void ThirdPersonModule::DestroyCameras() {
        auto destroyCam = [](void*& camComp) {
            if (!camComp) return;
            try {
                Component comp(camComp);
                if (comp.valid()) {
                    static auto getGO = MethodHandler::resolve("UnityEngine.Component", "get_gameObject", 0);
                    if (getGO) {
                        void* goRaw = MethodHandler::invoke<void*>(getGO, camComp);
                        if (goRaw) Object(goRaw).Destroy();
                    }
                }
            } catch (...) {}
            camComp = nullptr;
        };

        destroyCam(m_camBack);
        destroyCam(m_camFront);
        m_camerasCreated = false;
    }

    void ThirdPersonModule::OnUpdate() {
        bool ctrl = (GetAsyncKeyState(VK_CONTROL) & 0x8000) != 0;
        bool tPressed = (GetAsyncKeyState('T') & 0x0001) != 0;

        if (ctrl && tPressed) {
            CreateCameras();
            if (!m_camerasCreated) return;

            static auto setEnabled = MethodHandler::resolve("UnityEngine.Behaviour", "set_enabled", 1);
            if (!setEnabled) return;

            if (m_mode == CameraMode::Normal) {
                m_mode = CameraMode::Behind;
                m_distance = 3.0f;
                ShowHead(true);

                bool on = true, off = false;
                void* onP[] = { &on };
                void* offP[] = { &off };
                MethodHandler::invoke(setEnabled, m_camBack, onP);
                MethodHandler::invoke(setEnabled, m_camFront, offP);

            } else if (m_mode == CameraMode::Behind) {
                m_mode = CameraMode::InFront;
                m_distance = 3.0f;

                bool on = true, off = false;
                void* onP[] = { &on };
                void* offP[] = { &off };
                MethodHandler::invoke(setEnabled, m_camBack, offP);
                MethodHandler::invoke(setEnabled, m_camFront, onP);

            } else {
                m_mode = CameraMode::Normal;
                ShowHead(false);

                bool off = false;
                void* offP[] = { &off };
                MethodHandler::invoke(setEnabled, m_camBack, offP);
                MethodHandler::invoke(setEnabled, m_camFront, offP);

            }
        }

        if (m_mode == CameraMode::Normal) return;
        if (!m_camerasCreated) return;

        ShowHead(true);

        float scroll = Input::GetAxisRaw("Mouse ScrollWheel");
        if (scroll != 0.f) {
            m_distance -= scroll * 2.f;
            if (m_distance < 0.5f) m_distance = 0.5f;
            if (m_distance > 20.f) m_distance = 20.f;
        }

        auto mainCam = Camera::GetMain();
        if (!mainCam.valid()) return;
        auto mainT = mainCam.GetTransform();
        if (!mainT.valid()) return;

        IL2CPP::Vector3 mainPos = mainT.GetPosition();
        IL2CPP::Vector3 mainFwd = mainT.GetForward();
        IL2CPP::Quaternion mainRot = mainT.GetRotation();

        void* activeCam = (m_mode == CameraMode::Behind) ? m_camBack : m_camFront;
        if (!activeCam) return;

        static auto getGO = MethodHandler::resolve("UnityEngine.Component", "get_gameObject", 0);
        if (!getGO) return;
        void* camGORaw = MethodHandler::invoke<void*>(getGO, activeCam);
        if (!camGORaw) return;

        GameObject camGO(camGORaw);
        auto camT = camGO.GetTransform();
        if (!camT.valid()) return;

        if (m_mode == CameraMode::Behind) {
            IL2CPP::Vector3 pos = {
                mainPos.x - mainFwd.x * m_distance,
                mainPos.y - mainFwd.y * m_distance,
                mainPos.z - mainFwd.z * m_distance
            };
            camT.SetPosition(pos);
            camT.SetRotation(mainRot);
        } else {
            IL2CPP::Vector3 pos = {
                mainPos.x + mainFwd.x * m_distance,
                mainPos.y + mainFwd.y * m_distance,
                mainPos.z + mainFwd.z * m_distance
            };
            camT.SetPosition(pos);
            camT.SetRotation(mainRot);

            static auto rotate = MethodHandler::resolve("UnityEngine.Transform", "Rotate", 3);
            if (rotate) {
                float rx = 0.f, ry = 180.f, rz = 0.f;
                void* rp[] = { &rx, &ry, &rz };
                MethodHandler::invoke(rotate, camT.raw(), rp);
            }
        }
    }

    void ThirdPersonModule::OnDisable() {
        if (m_mode != CameraMode::Normal) {
            ShowHead(false);

            if (m_camerasCreated) {
                static auto setEnabled = MethodHandler::resolve("UnityEngine.Behaviour", "set_enabled", 1);
                if (setEnabled) {
                    bool off = false;
                    void* offP[] = { &off };
                    if (m_camBack) MethodHandler::invoke(setEnabled, m_camBack, offP);
                    if (m_camFront) MethodHandler::invoke(setEnabled, m_camFront, offP);
                }
            }
        }
        m_mode = CameraMode::Normal;
    }

    void ThirdPersonModule::OnSceneLoad(int, int) {
        if (m_headShown) {
            ShowHead(false);
        }
        m_mode = CameraMode::Normal;
        m_headBone = nullptr;
        m_headShown = false;
        m_camBack = nullptr;
        m_camFront = nullptr;
        m_camerasCreated = false;
        m_distance = 3.0f;
    }

} // namespace UNIx
