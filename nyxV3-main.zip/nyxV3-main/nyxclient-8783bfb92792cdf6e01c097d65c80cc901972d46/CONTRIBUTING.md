# Contributing to VoidUnix (nyx)

## Branch Workflow

**Never push directly to `master`.** Use your personal branch and open a Pull Request.

### Your branches

| Person | Branch |
|---|---|
| Lexie (AiLexie) | `lexie/dev` |
| Bats (kittybats) | `bats/dev` |

### Daily workflow

```bash
# 1. Switch to your branch
git checkout lexie/dev  # or bats/dev

# 2. Pull latest master into your branch
git pull origin master

# 3. Do your work, commit
git add <files>
git commit -m "Add cool feature"

# 4. Push your branch
git push -u origin lexie/dev

# 5. Open a Pull Request on GitHub: your branch -> master
#    Get a teammate to review, then merge
```

### Starting a new feature

If you want a separate branch for a specific feature:

```bash
git checkout master
git pull origin master
git checkout -b lexie/nameplate-fix
# work, commit, push, open PR
```

### Avoiding conflicts

- **Pull master often** — don't let your branch get stale
- **Keep commits small** — easier to merge
- **Communicate** — if two people need to edit the same file (especially `dllmain.cpp`), coordinate
- **Register modules in order** — when adding to `dllmain.cpp`, add your `mgr.Register<>()` line at the end to reduce merge conflicts

### If you get a merge conflict

```bash
git pull origin master
# Git will tell you which files conflict
# Open the file, look for <<<<<<< / ======= / >>>>>>>
# Keep both sides (or pick the right one), remove the markers
git add <fixed-files>
git commit
```

## Adding a New Module

1. Create `include/Modules/<Category>/MyModule.hpp` and `src/Modules/<Category>/MyModule.cpp`
2. Inherit from `UNIx::BaseModule`
3. Register in `dllmain.cpp`: `mgr.Register<UNIx::MyModule>();`
4. Add files to `VoidUnix.vcxproj` (`<ClCompile>` for .cpp, `<ClInclude>` for .hpp)

## Branch Protection (for repo admin)

Go to GitHub → **Settings → Branches → Add rule**:
- Branch name pattern: `master`
- Check **"Require a pull request before merging"**
- Check **"Require approvals"** (set to 1)
- This prevents accidental direct pushes to master
