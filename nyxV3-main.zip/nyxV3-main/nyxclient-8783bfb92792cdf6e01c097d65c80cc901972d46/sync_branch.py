import subprocess, time, sys, os

BRANCH = "lexie/dev"
REMOTE = "origin"
BASE = "master"
INTERVAL = 60
REPO_DIR = os.path.dirname(os.path.abspath(__file__))

def log(msg):
    print(msg, flush=True)

def run(cmd, label=None):
    if label:
        log(f"[sync] {label}: {cmd}")
    r = subprocess.run(cmd, capture_output=True, text=True, shell=True, cwd=REPO_DIR)
    if r.stdout.strip():
        log(f"  stdout: {r.stdout.strip()}")
    if r.stderr.strip():
        log(f"  stderr: {r.stderr.strip()}")
    return r.returncode, r.stdout.strip(), r.stderr.strip()

def sync():
    log(f"[sync] checking for updates...")
    code, _, err = run(f"git fetch {REMOTE} {BASE}", "fetch")
    if code != 0:
        log(f"[sync] fetch failed: {err}")
        return
    code, behind, err = run(f"git rev-list --count HEAD..{REMOTE}/{BASE}", "rev-list")
    if code != 0:
        log(f"[sync] rev-list failed: {err}")
        return
    count = int(behind)
    if count == 0:
        log(f"[sync] {BRANCH} is up to date with {BASE}")
        return
    log(f"[sync] {BRANCH} is {count} commit(s) behind {BASE}, merging...")
    code, out, err = run(f"git merge {REMOTE}/{BASE} --no-edit", "merge")
    if code != 0:
        log(f"[sync] merge failed, aborting")
        run("git merge --abort")
        return
    code, out, err = run(f"git push {REMOTE} HEAD:{BRANCH}", "push")
    if code != 0:
        log(f"[sync] push failed: {err}")
        return
    log(f"[sync] {BRANCH} synced and pushed")

if __name__ == "__main__":
    print(f"Watching {BASE} -> {BRANCH} every {INTERVAL}s (Ctrl+C to stop)")
    while True:
        try:
            sync()
            time.sleep(INTERVAL)
        except KeyboardInterrupt:
            print("\nStopped.")
            sys.exit(0)
