#pragma once
#include <Core/BaseModule.hpp>

namespace UNIx {

class PerformanceModule : public BaseModule {
public:
    PerformanceModule();

    void OnSetupQuickMenu(uint32_t moduleId, uint32_t categoryPageId) override;

private:
    static PerformanceModule* s_instance;
    static void __cdecl QmTextureLimitCb(uint32_t id, int32_t index);
    static void __cdecl QmAntiAliasingCb(uint32_t id, int32_t index);
    static void __cdecl QmShadowResCb(uint32_t id, int32_t index);
    static void __cdecl QmVSyncCb(uint32_t id, int32_t index);
    static void __cdecl QmLodBiasCb(uint32_t id, float val);
    static void __cdecl QmMipmapBudgetCb(uint32_t id, float val);
    static void __cdecl QmForceGcCb(uint32_t id);
    static void __cdecl QmFullCleanupCb(uint32_t id);
};

} // namespace UNIx
