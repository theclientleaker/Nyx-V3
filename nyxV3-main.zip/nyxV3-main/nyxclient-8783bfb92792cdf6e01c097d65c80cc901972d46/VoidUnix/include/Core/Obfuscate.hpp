#pragma once
#include <string>

#define OBF(s) s
#define OBFW(s) s
