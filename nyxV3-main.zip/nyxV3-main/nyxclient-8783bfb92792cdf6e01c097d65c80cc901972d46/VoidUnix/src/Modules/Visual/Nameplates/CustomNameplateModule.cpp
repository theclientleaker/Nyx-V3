#define WIN32_LEAN_AND_MEAN
#include <Windows.h>

#include <Modules/Visual/Nameplates/CustomNameplateModule.hpp>
#include <Core/FileLog/FileLog.hpp>
#include <Core/Globals.hpp>
#include <Core/SpriteLoader/SpriteLoader.hpp>

#include <IL2CPP.Module/include/il2cpp_module.hpp>
#include <IL2CPP.Module/include/MethodHandler.hpp>
#include <IL2CPP.Module/include/Unity/GameObject.hpp>
#include <IL2CPP.Module/include/Unity/Object.hpp>
#include <IL2CPP.Module/include/Unity/Transform.hpp>
#include <IL2CPP.Module/include/Unity/Component.hpp>
#include <IL2CPP.Module/include/Unity/Image.hpp>
#include <IL2CPP.Module/include/Unity/Sprite.hpp>

#include <Bootstrap.Module/include/VRChat/VRCPlayer.hpp>
#include <Bootstrap.Module/include/VRChat/PlayerNameplate.hpp>
#include <Bootstrap.Module/include/VRChat/VRCPlayerApi.hpp>

#include <ThirdParty/imgui/imgui.h>
#include <cmath>
#include <functional>

namespace UNIx {

    static constexpr float kInitDelay = 3.0f;
    static constexpr float kRetryDelay = 2.0f;
    static constexpr int kMaxRetries = 5;

    CustomNameplateModule::CustomNameplateModule()
        : BaseModule("Custom Nameplates", "Custom nameplate visuals from cloud config", VK_F7, "Visual") {
    }

    bool CustomNameplateModule::LoadTextures() {
        if (m_texturesLoaded) return true;
        if (m_texturesFailed) return false;

        auto& loader = SpriteLoader::Get();
        m_bgSprite = loader.LoadFromFile("C:/nyx/nameplate/DefaultBackground.png");
        m_borderSprite = loader.LoadFromFile("C:/nyx/nameplate/Border.png");

        if (!m_bgSprite && !m_borderSprite) {
            FLOG("[CustomNameplate] Failed to load any textures from C:/nyx/nameplate/");
            m_texturesFailed = true;
            return false;
        }

        FLOG("[CustomNameplate] Textures loaded: bg={} border={}", m_bgSprite != nullptr, m_borderSprite != nullptr);
        m_texturesLoaded = true;
        return true;
    }

    void CustomNameplateModule::OnPlayerJoinComplete(IL2CPP::VRChat::Player player) {
        if (!player) return;
        auto api = player.GetVRCPlayerApi();
        if (!api) return;
        auto user = player.GetAPIUser();

        CustomNameplateState state;
        state.playerId = api.GetPlayerId();
        state.pendingTimer = kInitDelay;
        if (user.valid())
            state.userId = user.GetId();

        m_states.push_back(std::move(state));
    }

    void CustomNameplateModule::OnPlayerLeave(IL2CPP::VRChat::Player player) {
        if (!player) return;
        auto api = player.GetVRCPlayerApi();
        if (!api) return;
        int id = api.GetPlayerId();

        for (auto it = m_states.begin(); it != m_states.end(); ++it) {
            if (it->playerId == id) {
                CleanupState(*it);
                m_states.erase(it);
                return;
            }
        }
    }

    void CustomNameplateModule::OnSceneLoad(int, int) {
        CleanupAll();
    }

    void CustomNameplateModule::InitializeNameplate(CustomNameplateState& state) {
        auto playerApi = IL2CPP::VRChat::VRCPlayerApi::GetPlayerById(state.playerId);
        if (!playerApi.raw()) { state.pendingTimer = kRetryDelay; state.retryCount++; return; }

        auto vrcPlayer = playerApi.GetVRCPlayer();
        if (!vrcPlayer.raw()) { state.pendingTimer = kRetryDelay; state.retryCount++; return; }

        auto nameplate = vrcPlayer.GetNameplate();
        if (!nameplate.raw()) { state.pendingTimer = kRetryDelay; state.retryCount++; return; }

        auto contentsGO = nameplate.GetContents();
        if (!contentsGO.valid()) { state.pendingTimer = kRetryDelay; state.retryCount++; return; }

        auto bgComp = contentsGO.GetComponentByName("UnityEngine.UI.Image");
        if (!bgComp.valid() || !bgComp.raw()) { state.pendingTimer = kRetryDelay; state.retryCount++; return; }

        state.bgImage = bgComp.raw();
        state.initialized = true;
        state.appliedConfigHash = 0;
        FLOG("[CustomNameplate] Initialized for player {}", state.playerId);
    }

    void CustomNameplateModule::ApplyConfig(CustomNameplateState& state, const NameplateConfig& cfg) {
        if (!state.bgImage) return;

        IL2CPP::Module::Unity::Object bgObj(state.bgImage);
        if (!bgObj.IsValid()) { state.bgImage = nullptr; return; }

        IL2CPP::Module::Unity::Image bgImg(state.bgImage);

        if (m_bgSprite)
            bgImg.SetSprite(m_bgSprite);

        if (!cfg.autoHueShift)
            bgImg.SetColor(IL2CPP::Color(cfg.bgColor[0], cfg.bgColor[1], cfg.bgColor[2], cfg.bgColor[3]));
    }

    void CustomNameplateModule::RestoreOriginal(CustomNameplateState& state) {
        if (!state.bgImage || state.appliedConfigHash == 0) return;
        state.appliedConfigHash = 0;
    }

    void CustomNameplateModule::OnUpdate() {
        if (m_states.empty()) return;
        if (!InRoom()) return;
        if (!LoadTextures()) return;

        float dt = 1.f / 90.f;
        m_globalTime += dt;

        for (auto& state : m_states) {
            if (!state.initialized && state.retryCount < kMaxRetries && state.pendingTimer > 0.f) {
                state.pendingTimer -= dt;
                if (state.pendingTimer <= 0.f)
                    InitializeNameplate(state);
            }
        }

        auto& cfgMgr = NameplateConfigManager::Get();
        for (auto& state : m_states) {
            if (!state.initialized || !state.bgImage) continue;

            auto opt = cfgMgr.GetConfigForUser(state.userId);
            if (!opt.has_value()) continue;

            auto& cfg = opt.value();
            if (!cfg.enabled) continue;

            uint64_t hash = HashConfig(cfg);
            if (hash != state.appliedConfigHash) {
                ApplyConfig(state, cfg);
                state.appliedConfigHash = hash;
            }

            if (cfg.autoHueShift) {
                IL2CPP::Module::Unity::Object bgCheck(state.bgImage);
                if (!bgCheck.IsValid()) { state.bgImage = nullptr; continue; }

                float hue = std::fmod(m_globalTime * cfg.hueShiftSpeed, 1.f);
                float c = 1.f;
                float x = c * (1.f - std::fabs(std::fmod(hue * 6.f, 2.f) - 1.f));
                float r, g, b;
                int hi = static_cast<int>(hue * 6.f) % 6;
                switch (hi) {
                    case 0: r = c; g = x; b = 0; break;
                    case 1: r = x; g = c; b = 0; break;
                    case 2: r = 0; g = c; b = x; break;
                    case 3: r = 0; g = x; b = c; break;
                    case 4: r = x; g = 0; b = c; break;
                    default: r = c; g = 0; b = x; break;
                }
                IL2CPP::Module::Unity::Image bgImg(state.bgImage);
                bgImg.SetColor(IL2CPP::Color(r, g, b, cfg.bgColor[3]));
            }
        }
    }

    void CustomNameplateModule::OnEnable() {
    }

    void CustomNameplateModule::OnDisable() {
    }

    void CustomNameplateModule::OnRender() {
    }

    uint64_t CustomNameplateModule::HashConfig(const NameplateConfig& cfg) {
        uint64_t h = 0;
        auto hashCombine = [&](uint64_t val) {
            h ^= val + 0x9e3779b97f4a7c15ULL + (h << 6) + (h >> 2);
        };
        hashCombine(std::hash<bool>{}(cfg.enabled));
        for (float f : cfg.bgColor) hashCombine(std::hash<float>{}(f));
        for (float f : cfg.borderColor) hashCombine(std::hash<float>{}(f));
        hashCombine(std::hash<bool>{}(cfg.autoHueShift));
        hashCombine(std::hash<float>{}(cfg.hueShiftSpeed));
        hashCombine(std::hash<bool>{}(cfg.borderHueShift));
        return h;
    }

    void CustomNameplateModule::CleanupState(CustomNameplateState& state) {
        state.bgImage = nullptr;
        state.borderImage = nullptr;
        state.borderObject = nullptr;
        state.originalBgSprite = nullptr;
        state.appliedConfigHash = 0;
    }

    void CustomNameplateModule::CleanupAll() {
        for (auto& state : m_states)
            CleanupState(state);
        m_states.clear();
    }

} // namespace UNIx
