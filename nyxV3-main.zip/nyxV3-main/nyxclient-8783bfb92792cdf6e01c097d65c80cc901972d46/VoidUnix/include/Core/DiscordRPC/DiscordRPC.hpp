#pragma once

#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#include <string>
#include <cstdint>
#include <atomic>
#include <thread>

namespace UNIx {

    class DiscordRPC {
    public:
        static DiscordRPC& Get();

        void Start();
        void Stop();
        void Update();

        void SetWorld(const std::string& worldName, const std::string& instanceId,
                      const std::string& accessType, int playerCount,
                      const std::string& thumbnailUrl = "", int maxPlayers = 0);
        void SetLobby();
        void SetUsername(const std::string& name);

    private:
        DiscordRPC() = default;

        bool Connect();
        void Disconnect();
        bool Send(int opcode, const std::string& json);
        bool Recv();
        void UpdatePresence();

        std::string BuildPresenceJson();
        static std::string JsonEscape(const std::string& s);

        static std::string GetApplicationId() { return "1482495821009387520"; }

        HANDLE m_pipe = INVALID_HANDLE_VALUE;
        bool m_connected = false;
        bool m_started = false;
        int64_t m_startTime = 0;
        int m_nonce = 1;

        std::string m_username;
        std::string m_worldName;
        std::string m_instanceId;
        std::string m_accessType;
        std::string m_thumbnailUrl;
        int m_playerCount = 0;
        int m_maxPlayers = 0;
        bool m_inWorld = false;
        bool m_dirty = true;
    };

} // namespace UNIx
