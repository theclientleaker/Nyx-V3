#pragma once
#include <Core/BaseModule.hpp>
#include <Hooking.Common/hook_shared.hpp>
#include <cstdint>

namespace UNIx {

    class BundleDecryptModule : public BaseModule {
    public:
        BundleDecryptModule()
            : BaseModule("Bundle Decrypt", "Strips asset bundle encryption", 0, "Utility") {
            m_enabled = true;
        }

        void OnEnable() override;
        void OnDisable() override;

    private:
        void InstallHook();
        void RemoveHook();

        uint32_t m_hookId = Hooking::invalid_id;
        bool m_hookActive = false;

        // Prefix hook: takes the original params, modifies encKey in-place,
        // returns true to continue to original (now with nulled key).
        // Static method so no thisPtr. Params match IL2CPP native order.
        // __retval for UnityWebRequest* return value.
        static bool PrefixStripEncryption(void* url, void* cachedBundle,
                                          uint32_t crc, bool loadType,
                                          void* encKey, void*& __retval);
    };

} // namespace UNIx
