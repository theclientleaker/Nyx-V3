#pragma once
#include <Core/BaseModule.hpp>
#include <ThirdParty/imgui/imgui.h>
#include <string>
#include <vector>
#include <mutex>
#include <deque>

namespace UNIx {

    class ScreenConsoleModule : public BaseModule {
    public:
        ScreenConsoleModule();

        void OnOverlay() override;
        void OnSetupQuickMenu(uint32_t moduleId, uint32_t categoryPageId) override;

        static ScreenConsoleModule* s_instance;
        static void __cdecl QmMaxLinesCb(uint32_t id, float val);
        static void __cdecl QmFontSizeCb(uint32_t id, float val);
        static void __cdecl QmOpacityCb(uint32_t id, float val);

        void PushLine(const std::string& timestamp, const std::string& message);

    private:
        enum class LogLevel { Info, Warning, Error, Debug };
        static LogLevel ClassifyMessage(const std::string& msg);
        static ImU32 LevelColor(LogLevel level, float alpha);

        struct ConsoleLine {
            std::string timestamp;
            std::string message;
            LogLevel level;
            float age = 0.f;
        };

        std::mutex m_mutex;
        std::deque<ConsoleLine> m_lines;
        int   m_maxLines = 40;
        float m_fontSize = 13.f;
        float m_opacity = 0.65f;
        float m_lineDuration = 8.f;
        float m_fadeDuration = 2.f;
    };

} // namespace UNIx
