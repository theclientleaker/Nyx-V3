#pragma once

#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#include <string>
#include <format>
#include <mutex>
#include <fstream>

namespace UNIx {

    using LogCallback = void(*)(const std::string& timestamp, const std::string& message);

    class FileLog {
    public:
        static FileLog& Get();

        void Init(HMODULE hModule);
        void Shutdown();

        void Log(const std::string& msg);

        template<typename... Args>
        void Log(std::format_string<Args...> fmt, Args&&... args) {
            Log(std::format(fmt, std::forward<Args>(args)...));
        }

        void SetCallback(LogCallback cb) { m_callback = cb; }
        void SetConsoleHandle(HANDLE h) { m_console = h; }

    private:
        FileLog() = default;
        std::mutex m_mutex;
        std::ofstream m_file;
        bool m_open = false;
        HANDLE m_console = INVALID_HANDLE_VALUE;
        LogCallback m_callback = nullptr;
    };

    inline void FLOG(const std::string& msg) { FileLog::Get().Log(msg); }

    template<typename... Args>
    void FLOG(std::format_string<Args...> fmt, Args&&... args) {
        FileLog::Get().Log(fmt, std::forward<Args>(args)...);
    }

} // namespace UNIx
