#pragma once
#include <Core/BaseModule.hpp>

namespace UNIx {

    class NoclipModule : public BaseModule {
    public:
        NoclipModule();

        void OnUpdate() override;
        void OnRender() override;
        void OnDisable() override;
        void OnSetupQuickMenu(uint32_t moduleId, uint32_t categoryPageId) override;

    private:
        void SetCharacterControllerEnabled(bool enabled);

        bool m_wasActive = false;
        float m_flySpeed = 15.0f;
        float m_flySpeedMultiplier = 3.0f;

        static NoclipModule* s_instance;
        static void __cdecl QmFlySpeedCb(uint32_t id, float val);
        static void __cdecl QmSprintMultCb(uint32_t id, float val);
    };

} // namespace UNIx
