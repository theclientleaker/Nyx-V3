#pragma once
#include <Core/BaseModule.hpp>

namespace UNIx {

    class PlayerListModule : public BaseModule {
    public:
        PlayerListModule() : BaseModule("Player List", "Tracks players in the room", 0, "UI") {
            m_showInQuickMenu = false;
        }

        void OnRender() override;
    };

} // namespace UNIx
