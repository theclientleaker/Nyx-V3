#pragma once

#include <Core/BaseModule.hpp>

#include <IL2CPP.Module/include/Unity/GameObject.hpp>
#include <IL2CPP.Module/include/Unity/Object.hpp>

#include <vector>

namespace UNIx {

    struct CrashDetectionState {
        int playerId = 0;
        bool isCrashed = false;
        bool initialized = false;
        float pendingTimer = 0.f;
        int retryCount = 0;
        void* statusTextObject = nullptr;

        IL2CPP::Vector3 lastPos = { 0.f, 0.f, 0.f };
        float frozenTimer = 0.f;
        bool hasFirstSample = false;
        int validSampleCount = 0;
    };

    class CrashDetectionModule : public BaseModule {
    public:
        CrashDetectionModule();

        void OnPlayerJoinComplete(IL2CPP::VRChat::Player player) override;
        void OnPlayerLeave(IL2CPP::VRChat::Player player) override;
        void OnSceneLoad(int scene, int loadMode) override;
        void OnUpdate() override;
        void OnRender() override;
        void OnEnable() override;
        void OnDisable() override;

    private:
        void InitializePlayer(CrashDetectionState& state);
        void UpdateStatusText(CrashDetectionState& state);
        void CleanupState(CrashDetectionState& state);
        void CleanupAll();

        std::vector<CrashDetectionState> m_states;
        float m_crashThreshold = 12.f;
    };

} // namespace UNIx
