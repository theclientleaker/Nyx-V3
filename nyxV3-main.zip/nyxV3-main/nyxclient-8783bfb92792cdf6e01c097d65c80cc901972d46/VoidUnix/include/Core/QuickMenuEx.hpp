#pragma once

#include <Bootstrap.Common/include/bootstrap_shared.hpp>
#include <Bootstrap.Module/include/bootstrap_internal.hpp>
#include <string_view>
#include <cstdint>

namespace UNIx {

    class QuickMenuEx {
    public:
        static QuickMenuEx& Get() {
            static QuickMenuEx instance;
            return instance;
        }

        bool valid() const noexcept {
            return Bootstrap::Module::is_connected() && vtable();
        }

        // v7
        void set_button_enabled(uint32_t mid, uint32_t button_id, bool enabled) {
            auto vt = vtable(); if (!vt) return;
            vt->qm_set_button_enabled(mid, button_id, enabled);
        }

        void set_button_visible(uint32_t mid, uint32_t button_id, bool visible) {
            auto vt = vtable(); if (!vt) return;
            vt->qm_set_button_visible(mid, button_id, visible);
        }

        uint32_t get_subpage_nav_button(uint32_t mid, uint32_t sub_page_id) {
            auto vt = vtable(); if (!vt) return Bootstrap::invalid_id;
            return vt->qm_get_subpage_nav_button(mid, sub_page_id);
        }

        void set_subpage_nav_text(uint32_t mid, uint32_t sub_page_id, std::string_view text) {
            auto vt = vtable(); if (!vt) return;
            vt->qm_set_subpage_nav_text(mid, sub_page_id, text.data(), static_cast<uint32_t>(text.size()));
        }

        void set_subpage_nav_icon_vrc(uint32_t mid, uint32_t sub_page_id, Bootstrap::Sprite sprite) {
            auto vt = vtable(); if (!vt) return;
            vt->qm_set_subpage_nav_icon_vrc(mid, sub_page_id, static_cast<int32_t>(sprite));
        }

        // v8
        uint32_t add_foldout(uint32_t mid, uint32_t page_id, std::string_view title,
                             bool default_expanded = true, bool show_background = true,
                             bool auto_separators = false) {
            auto vt = vtable(); if (!vt) return Bootstrap::invalid_id;
            return vt->qm_add_foldout(mid, page_id,
                title.data(), static_cast<uint32_t>(title.size()),
                default_expanded, show_background, auto_separators);
        }

        uint32_t add_settings_toggle(uint32_t mid, uint32_t foldout_id, std::string_view text,
                                     bool default_state, Bootstrap::fn_menu_toggle_callback callback,
                                     std::string_view config_key = "", bool show_indicator = false) {
            auto vt = vtable(); if (!vt) return Bootstrap::invalid_id;
            return vt->qm_add_settings_toggle(mid, foldout_id,
                text.data(), static_cast<uint32_t>(text.size()),
                default_state, callback,
                config_key.data(), static_cast<uint32_t>(config_key.size()),
                show_indicator);
        }

        uint32_t add_enum_selector(uint32_t mid, uint32_t foldout_id, std::string_view label,
                                   const char* const* options, uint32_t option_count,
                                   int32_t default_index, Bootstrap::fn_menu_enum_callback callback,
                                   std::string_view config_key = "", bool show_indicator = false) {
            auto vt = vtable(); if (!vt) return Bootstrap::invalid_id;
            return vt->qm_add_enum_selector(mid, foldout_id,
                label.data(), static_cast<uint32_t>(label.size()),
                options, option_count, default_index, callback,
                config_key.data(), static_cast<uint32_t>(config_key.size()),
                show_indicator);
        }

        void set_enum_index(uint32_t mid, uint32_t selector_id, int32_t index) {
            auto vt = vtable(); if (!vt) return;
            vt->qm_set_enum_index(mid, selector_id, index);
        }

        int32_t get_enum_index(uint32_t mid, uint32_t selector_id) {
            auto vt = vtable(); if (!vt) return 0;
            return vt->qm_get_enum_index(mid, selector_id);
        }

        uint32_t add_slider(uint32_t mid, uint32_t foldout_id, std::string_view label,
                            float min_val, float max_val, float default_val,
                            Bootstrap::fn_menu_slider_callback callback,
                            std::string_view config_key = "", std::string_view format = "",
                            bool show_indicator = false, float power = 1.0f) {
            auto vt = vtable(); if (!vt) return Bootstrap::invalid_id;
            return vt->qm_add_slider(mid, foldout_id,
                label.data(), static_cast<uint32_t>(label.size()),
                min_val, max_val, default_val, callback,
                config_key.data(), static_cast<uint32_t>(config_key.size()),
                format.data(), static_cast<uint32_t>(format.size()),
                show_indicator, power);
        }

        void set_slider_value(uint32_t mid, uint32_t slider_id, float value) {
            auto vt = vtable(); if (!vt) return;
            vt->qm_set_slider_value(mid, slider_id, value);
        }

        float get_slider_value(uint32_t mid, uint32_t slider_id) {
            auto vt = vtable(); if (!vt) return 0.f;
            return vt->qm_get_slider_value(mid, slider_id);
        }

        uint32_t add_separator(uint32_t mid, uint32_t foldout_id) {
            auto vt = vtable(); if (!vt) return Bootstrap::invalid_id;
            return vt->qm_add_separator(mid, foldout_id);
        }

    private:
        QuickMenuEx() = default;

        static const Bootstrap::BootstrapVtable* vtable() noexcept {
            return Bootstrap::Module::get_vtable();
        }
    };

} // namespace UNIx
