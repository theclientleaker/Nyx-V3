#pragma once

#define WIN32_LEAN_AND_MEAN
#include <Windows.h>

#include <string>
#include <vector>
#include <mutex>
#include <thread>
#include <atomic>
#include <chrono>
#include <cstdint>

namespace UNIx {

    class Playback {
    public:
        struct MediaInfo {
            std::string title;
            std::string artist;
            std::string album;
            double positionSeconds = 0.0;
            double durationSeconds = 0.0;
            bool isPlaying = false;
            std::vector<uint8_t> thumbnailData;
            uint64_t thumbnailHash = 0;
            std::chrono::steady_clock::time_point lastUpdate{};
        };

        static Playback& Get();

        void Start();
        void Stop();

        MediaInfo GetMediaInfo();
        bool HasSession() const { return m_hasSession.load(std::memory_order_relaxed); }

    private:
        Playback() = default;
        void WorkerThread();

        std::thread m_thread;
        std::atomic<bool> m_running{false};
        std::atomic<bool> m_hasSession{false};
        std::mutex m_mutex;
        MediaInfo m_info;
    };

}
