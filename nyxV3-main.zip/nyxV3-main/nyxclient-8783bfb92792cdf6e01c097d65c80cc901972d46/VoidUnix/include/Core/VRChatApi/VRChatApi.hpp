#pragma once

#include <string>
#include <mutex>
#include <thread>
#include <atomic>
#include <functional>
#include <vector>
#include <deque>
#include <set>
#include <unordered_set>
#include <unordered_map>

namespace UNIx {

    class VRChatApi {
    public:
        static VRChatApi& Get();

        std::string GetAuthToken();

        void SendInvite(const std::string& targetUserId, const std::string& instanceId);
        void RequestInvite(const std::string& targetUserId);

        void StartNotificationPoller();
        void StopNotificationPoller();

        using InviteCallback = std::function<void(const std::string& worldId)>;
        void SetInviteAcceptedCallback(InviteCallback cb);

        using FriendStatusCallback = std::function<void(const std::string& displayName, bool online)>;
        void SetFriendStatusCallback(FriendStatusCallback cb);

        void ExpectInviteFrom(const std::string& userId);

    private:
        VRChatApi() = default;
        ~VRChatApi();

        void PollLoop();
        void PollFriendStatus();
        void StartWebSocket();
        void StopWebSocket();
        void WebSocketLoop();
        void HandlePipelineEvent(const std::string& type, const std::string& content);
        static std::string UnescapeJson(const std::string& s);
        std::string VrcApiRequest(const wchar_t* method, const std::string& path, const std::string& body = "");
        void HideNotification(const std::string& notificationId);
        void EnsureHttpSession();
        void CloseHttpSession();
        void TrackNotification(const std::string& id);
        void JoinFireThreads();

        static std::string ExtractJsonString(const std::string& json, const std::string& key);
        static std::vector<std::pair<std::string, std::string>> ExtractFriends(const std::string& json);

        std::mutex m_mutex;
        std::thread m_pollThread;
        std::atomic<bool> m_polling{false};
        std::thread m_wsThread;
        std::atomic<bool> m_wsRunning{false};
        void* m_wsHandle = nullptr;
        InviteCallback m_inviteCallback;
        FriendStatusCallback m_friendStatusCallback;
        std::deque<std::string> m_handledNotifOrder;
        std::unordered_set<std::string> m_handledNotifSet;
        std::set<std::string> m_expectedInviteFrom;
        std::set<std::string> m_onlineFriends;
        std::unordered_map<std::string, std::string> m_friendNames;
        bool m_friendsInitialized = false;

        std::mutex m_sessionMutex;
        void* m_hSession = nullptr;
        void* m_hConnect = nullptr;

        std::mutex m_fireThreadMutex;
        std::vector<std::thread> m_fireThreads;
    };

} // namespace UNIx
