#pragma once
#include <Core/BaseModule.hpp>
#include <string>
#include <vector>

namespace UNIx {

    struct PlaylistEntry {
        std::string source;
        bool isUrl = false;
    };

    class LoadingMusic : public BaseModule {
    public:
        LoadingMusic() : BaseModule("Loading Music", "Replace loading music from C:/nyx/music or URLs", 0, "UI") {
            m_enabled = true;
        }

        void OnSceneLoad(int scene, int loadMode) override;
        void OnUpdate() override;
        void OnLateUpdate() override;
        void OnRender() override;

    private:
        enum class State { Idle, WaitForSource, StreamingUrl, Applied };

        State m_state = State::Idle;
        void* m_clip = nullptr;
        size_t m_fileIndex = 0;
        int m_applyFrame = 0;
        int m_goneFrames = 0;
        std::vector<PlaylistEntry> m_playlist;
        std::string m_currentSource;
        bool m_currentIsUrl = false;
        void* m_webRequest = nullptr;
        bool m_playlistLoaded = false;

        // Cached clip to avoid re-decoding the same file every scene load
        std::string m_cachedClipSource;
        void* m_cachedClip = nullptr;

        // Original clip from VRChat's AudioSource — must be restored when loading
        // screen dismisses so VRChat's UnloadAsset() doesn't fail on our runtime clip
        void* m_originalClip = nullptr;
        void* m_audioSourceRaw = nullptr;  // cached raw pointer to AudioSource component

        void LoadPlaylist();
        void ScanFolder();
        void CleanupWebRequest();
        void* LoadAudioAsClip(const std::string& path);
        void* CreateClipFromFloats(float* samples, int totalSamples, int channels, int sampleRate);
        void* CreateClipFromShorts(short* samples, int totalSamples, int channels, int sampleRate);
    };

} // namespace UNIx
