#include <Modules/UI/PlayerList/PlayerListModule.hpp>
#include <ThirdParty/imgui/imgui.h>

namespace UNIx {

    void PlayerListModule::OnRender() {
        ImGui::TextDisabled("player tracking active");
    }

} // namespace UNIx
