#include <Modules/UI/SettingsMenu/SettingsMenuModule.hpp>
#include <Core/FileLog/FileLog.hpp>
#include <Core/DashboardConsole/DashboardConsole.hpp>
#include <Core/ModuleManager.hpp>
#include <Modules/UI/Notifier/NotifierModule.hpp>

#include <IL2CPP.Module/include/il2cpp_module.hpp>
#include <IL2CPP.Common/il2cpp_shared.hpp>
#include <IL2CPP.Module/include/Unity/GameObject.hpp>
#include <IL2CPP.Module/include/Unity/Transform.hpp>
#include <IL2CPP.Module/include/Unity/RectTransform.hpp>
#include <IL2CPP.Module/include/Unity/Object.hpp>
#include <IL2CPP.Module/include/Unity/Component.hpp>
#include <IL2CPP.Module/include/Unity/TMP_Text.hpp>
#include <IL2CPP.Module/include/Unity/Canvas.hpp>
#include <IL2CPP.Module/include/Unity/CanvasGroup.hpp>
#include <IL2CPP.Module/include/Unity/AudioSource.hpp>
#include <IL2CPP.Module/include/Unity/Input.hpp>
#include <IL2CPP.Module/include/Reflection.hpp>
#include <IL2CPP.Module/include/MethodHandler.hpp>

namespace UNIx {

using namespace IL2CPP::Module;
using namespace IL2CPP::Module::Unity;

SettingsMenuModule* SettingsMenuModule::s_instance = nullptr;

SettingsMenuModule::SettingsMenuModule()
    : BaseModule("Settings Menu", "Custom main menu page", 0, "UI")
{
    m_showInQuickMenu = false;
    m_enabled = true;
}

void __cdecl SettingsMenuModule::QmSettingsButtonCb(uint32_t) {
    if (s_instance) s_instance->m_pendingShow = true;
}

void SettingsMenuModule::SetTMPText(void* tmpComp, const char* text) {
    if (!tmpComp) return;
    *reinterpret_cast<void**>(static_cast<char*>(tmpComp) + 0x7a8) = nullptr;

    static auto setAutoSize = MethodHandler::resolve("TMPro.TMP_Text", "set_enableAutoSizing", 1);
    if (setAutoSize) {
        bool val = false;
        void* args[] = { &val };
        MethodHandler::invoke<void>(setAutoSize, tmpComp, args);
    }

    TMP_Text tmp(tmpComp);
    tmp.SetText(text);
}

void SettingsMenuModule::StripVRCLogicComponents(void* goRaw) {
    if (!goRaw) return;
    GameObject go(goRaw);
    auto componentClass = Class::find("UnityEngine.Component");
    if (!componentClass) return;

    auto allComps = go.GetComponents(componentClass);
    for (auto& comp : allComps) {
        if (!comp.valid()) continue;
        try {
            auto klass = comp.get_class();
            if (!klass) continue;
            std::string name = klass.name();

            if (name == "DynamicSidePanelController" ||
                name == "SettingsMenuController" ||
                name == "SectionSelector") {
                Object(comp.raw()).DestroyImmediate();
            }
        } catch (...) {}
    }
}

void SettingsMenuModule::EnableAllBehaviours(void* goRaw) {
    if (!goRaw) return;
    GameObject go(goRaw);

    static auto setEnabled = MethodHandler::resolve("UnityEngine.Behaviour", "set_enabled", 1);
    if (!setEnabled) return;

    auto componentClass = Class::find("UnityEngine.Component");
    if (!componentClass) return;

    auto comps = go.GetComponents(componentClass);
    for (auto& comp : comps) {
        if (!comp.valid()) continue;
        try {
            bool val = true;
            void* args[] = { &val };
            MethodHandler::invoke(setEnabled, comp.raw(), args);
        } catch (...) {}
    }
}

void SettingsMenuModule::EnableAllBehavioursRecursive(void* transformRaw) {
    if (!transformRaw) return;
    Transform t(transformRaw);

    auto go = t.GetGameObject();
    if (go.valid()) EnableAllBehaviours(go.raw());

    int childCount = t.GetChildCount();
    for (int i = 0; i < childCount; ++i) {
        try {
            auto childT = t.GetChild(i);
            if (childT.valid())
                EnableAllBehavioursRecursive(childT.raw());
        } catch (...) {}
    }
}

void SettingsMenuModule::PlayClickSound() {
    try {
        auto soundPlayerGO = GameObject::Find("SoundPlayer");
        if (!soundPlayerGO.IsValid()) return;

        auto asComp = soundPlayerGO.GetComponentByName("UnityEngine.AudioSource");
        if (!asComp.valid()) return;

        AudioSource src(asComp.raw());
        if (m_clickAudioClip) {
            src.PlayOneShot(m_clickAudioClip, 1.0f);
        } else {
            static auto getClip = MethodHandler::resolve("UnityEngine.AudioSource", "get_clip", 0);
            if (getClip) {
                void* clip = MethodHandler::invoke<void*>(getClip, asComp.raw());
                if (clip) src.PlayOneShot(clip, 1.0f);
            }
        }
    } catch (...) {}
}

// ---- lifecycle ----

void SettingsMenuModule::OnEnable() {
    s_instance = this;
    m_initialized = false;
    m_initDelay = 0;
    m_visible = false;
    m_pendingShow = false;
    m_showCooldown = 0;
    m_tabWasSelected = false;
}

void SettingsMenuModule::OnDisable() {
    if (m_visible) HideNyxPage();
    CleanupMenu();
}

void SettingsMenuModule::OnSceneLoad(int, int) {
    m_menuGO = nullptr;
    m_tabButtonGO = nullptr;
    m_headerOffsetT = nullptr;
    m_navVLG = nullptr;
    m_contentViewport = nullptr;
    m_menuCanvasGroup = nullptr;
    m_menuCanvas = nullptr;
    m_tabBarParent = nullptr;
    m_mscComponent = nullptr;
    m_clickAudioClip = nullptr;
    m_navButtons.clear();
    m_contentButtons.clear();
    m_initialized = false;
    m_initDelay = 0;
    m_visible = false;
    m_pendingShow = false;
    m_showCooldown = 0;
    m_tabWasSelected = false;
}

void SettingsMenuModule::CleanupMenu() {
    if (m_menuGO) {
        try {
            GameObject go(m_menuGO);
            if (go.valid() && go.IsValid()) go.Destroy();
        } catch (...) {}
    }
    if (m_tabButtonGO) {
        try {
            GameObject go(m_tabButtonGO);
            if (go.valid() && go.IsValid()) go.Destroy();
        } catch (...) {}
    }
    m_menuGO = nullptr;
    m_tabButtonGO = nullptr;
    m_headerOffsetT = nullptr;
    m_navVLG = nullptr;
    m_contentViewport = nullptr;
    m_menuCanvasGroup = nullptr;
    m_menuCanvas = nullptr;
    m_tabBarParent = nullptr;
    m_mscComponent = nullptr;
    m_clickAudioClip = nullptr;
    m_navButtons.clear();
    m_contentButtons.clear();
    m_initialized = false;
    m_visible = false;
    m_pendingShow = false;
    m_showCooldown = 0;
    m_tabWasSelected = false;
}

// ---- Init ----

void SettingsMenuModule::InitMenu() {
    if (m_menuGO) return;

    auto existingNyx = GameObject::Find("Menu_Nyx");
    if (existingNyx.IsValid()) return;

    auto worldsGO = GameObject::Find("Menu_MM_Worlds(Clone)");
    if (!worldsGO.IsValid()) return;

    auto worldsT = worldsGO.GetTransform();
    if (!worldsT.valid()) return;

    auto headerOffsetT = worldsT.GetParent();
    if (!headerOffsetT.valid()) return;
    m_headerOffsetT = headerOffsetT.raw();

    static auto instantiate1 = MethodHandler::resolve("UnityEngine.Object", "Instantiate", 1);

    void* cloneParams[] = { worldsGO.raw() };
    void* clonedRaw = MethodHandler::invoke<void*>(instantiate1, nullptr, cloneParams);

    m_menuGO = clonedRaw;
    GameObject menuGO(m_menuGO);
    menuGO.SetName("Menu_Nyx");

    auto menuT = menuGO.GetTransform();
    menuT.SetParent(headerOffsetT, false);
    menuT.SetLocalPosition({ 0.f, 0.f, 0.f });
    menuT.SetLocalRotation({ 0.f, 0.f, 0.f, 1.f });
    menuT.SetLocalScale({ 1.f, 1.f, 1.f });

    StripVRCLogicComponents(m_menuGO);

    auto cgComp = menuGO.GetComponentByName("UnityEngine.CanvasGroup");
    if (!cgComp.valid()) {
        auto cgClass = Class::find("UnityEngine.CanvasGroup");
        if (cgClass) cgComp = menuGO.AddComponent(cgClass);
    }
    if (cgComp.valid()) {
        m_menuCanvasGroup = cgComp.raw();
        CanvasGroup cg(m_menuCanvasGroup);
        cg.SetAlpha(0.f);
        cg.SetInteractable(false);
        cg.SetBlocksRaycasts(false);
    }

    auto canvasComp = menuGO.GetComponentByName("UnityEngine.Canvas");
    if (canvasComp.valid()) {
        m_menuCanvas = canvasComp.raw();
    }

    auto grComp = menuGO.GetComponentByName("UnityEngine.UI.GraphicRaycaster");
    if (!grComp.valid()) {
        auto grClass = Class::find("UnityEngine.UI.GraphicRaycaster");
        if (grClass) menuGO.AddComponent(grClass);
    }

    menuGO.SetActive(false);

    InitPageContent();
    InitContentButtons();
    InitTabButton();

    auto mmCanvas = GameObject::Find("Canvas_MainMenu(Clone)");
    if (mmCanvas.IsValid()) {
        auto componentClass = Class::find("UnityEngine.Component");
        if (componentClass) {
            auto allComps = mmCanvas.GetComponents(componentClass);
            for (auto& comp : allComps) {
                if (!comp.valid()) continue;
                try {
                    auto klass = comp.get_class();
                    if (klass && klass.name() == std::string("MenuStateController")) {
                        m_mscComponent = comp.raw();
                        break;
                    }
                } catch (...) {}
            }
        }
    }

    try {
        auto soundPlayerGO = GameObject::Find("SoundPlayer");
        if (soundPlayerGO.IsValid()) {
            auto asComp = soundPlayerGO.GetComponentByName("UnityEngine.AudioSource");
            if (asComp.valid()) {
                static auto getClip = MethodHandler::resolve("UnityEngine.AudioSource", "get_clip", 0);
                if (getClip) {
                    m_clickAudioClip = MethodHandler::invoke<void*>(getClip, asComp.raw());
                }
            }
        }
    } catch (...) {}

    m_initialized = true;
    m_visible = false;
}

void SettingsMenuModule::InitPageContent() {
    GameObject menuGO(m_menuGO);
    auto menuT = menuGO.GetTransform();

    auto panelT = menuT.Find("Panel_SectionList");
    StripVRCLogicComponents(panelT.GetGameObject().raw());

    auto navContainerT = panelT.Find("ScrollRect_Navigation_Container");

    auto headerT = navContainerT.Find("DynamicSidePanel_Header");
    if (headerT.valid()) {
        auto titleTextT = headerT.Find("TitleContainer/Text_Name");
        if (titleTextT.valid()) {
            auto tmpComp = titleTextT.GetGameObject().GetComponentByName("TMPro.TextMeshProUGUI");
            if (!tmpComp.valid()) tmpComp = titleTextT.GetGameObject().GetComponentByName("TMPro.TMP_Text");
            if (tmpComp.valid()) {
                try {
                    auto se = titleTextT.GetGameObject().GetComponentByName("VRC.UI.Core.Styles.StyleElement");
                    if (se.valid()) Object(se.raw()).DestroyImmediate();
                } catch (...) {}
                SetTMPText(tmpComp.raw(), "Nyx Settings");
            }
        }

        for (const char* hide : { "SearchBtn", "Field_CurrentWorld", "Field_Search",
                                   "SidePanelHeaderScrollResetButton", "Separator" }) {
            auto childT = headerT.Find(hide);
            if (childT.valid()) childT.GetGameObject().SetActive(false);
        }
    }

    auto header2T = navContainerT.Find("Header");
    if (header2T.valid()) header2T.GetGameObject().SetActive(false);

    auto scrollNavT = navContainerT.Find("ScrollRect_Navigation");
    if (scrollNavT.valid()) {
        auto navScrollbarT = scrollNavT.Find("Scrollbar");
        if (navScrollbarT.valid()) navScrollbarT.GetGameObject().SetActive(false);

        auto vlgT = scrollNavT.Find("Viewport/VerticalLayoutGroup");
        if (vlgT.valid()) {
            m_navVLG = vlgT.raw();
            int childCount = vlgT.GetChildCount();
            for (int i = childCount - 1; i >= 0; --i) {
                try {
                    auto childGO = vlgT.GetChild(i).GetGameObject();
                    if (childGO.valid()) Object(childGO.raw()).DestroyImmediate();
                } catch (...) {}
            }
        }
    }

    auto scrollContentT = navContainerT.Find("ScrollRect_Content");
    if (scrollContentT.valid()) {
        auto contentScrollbarT = scrollContentT.Find("Scrollbar");
        if (contentScrollbarT.valid()) contentScrollbarT.GetGameObject().SetActive(false);

        auto vpT = scrollContentT.Find("Viewport");
        if (vpT.valid()) {
            m_contentViewport = vpT.raw();
            for (int i = vpT.GetChildCount() - 1; i >= 0; --i) {
                try {
                    auto childGO = vpT.GetChild(i).GetGameObject();
                    if (childGO.valid()) Object(childGO.raw()).DestroyImmediate();
                } catch (...) {}
            }
        }
    }

    auto worldsGO = GameObject::Find("Menu_MM_Worlds(Clone)");
    if (!worldsGO.IsValid() || !m_navVLG) return;

    auto worldsNavVLG = worldsGO.GetTransform().Find(
        "Panel_SectionList/ScrollRect_Navigation_Container/ScrollRect_Navigation/Viewport/VerticalLayoutGroup");
    if (!worldsNavVLG.valid()) return;

    void* btnTemplate = nullptr;
    for (int i = 0; i < worldsNavVLG.GetChildCount(); ++i) {
        auto childT = worldsNavVLG.GetChild(i);
        if (childT.valid()) {
            auto childGO = childT.GetGameObject();
            if (childGO.valid() && childGO.GetActiveSelf()) {
                btnTemplate = childGO.raw();
                break;
            }
        }
    }


    static auto instantiate1 = MethodHandler::resolve("UnityEngine.Object", "Instantiate", 1);
    if (!instantiate1) return;

    Transform navVLG(m_navVLG);
    const char* categories[] = { "Movement", "Visual", "UI", "Exploits", "Safety", "Utility" };
    for (const char* cat : categories) {
        void* cloneP[] = { btnTemplate };
        void* clonedRaw = MethodHandler::invoke<void*>(instantiate1, nullptr, cloneP);
        if (!clonedRaw) continue;

        GameObject btnGO(clonedRaw);
        btnGO.SetName((std::string("Nyx_Nav_") + cat).c_str());

        auto btnT = btnGO.GetTransform();
        btnT.SetParent(navVLG, false);

        auto arrowT = btnT.Find("Arrow");
        if (arrowT.valid()) arrowT.GetGameObject().SetActive(false);

        auto labelT = btnT.Find("Label");
        if (labelT.valid()) {
            auto tmpComp = labelT.GetGameObject().GetComponentByName("TMPro.TextMeshProUGUI");
            if (!tmpComp.valid()) tmpComp = labelT.GetGameObject().GetComponentByName("TMPro.TMP_Text");
            if (tmpComp.valid()) {
                try {
                    auto se = labelT.GetGameObject().GetComponentByName("VRC.UI.Core.Styles.StyleElement");
                    if (se.valid()) Object(se.raw()).DestroyImmediate();
                } catch (...) {}
                SetTMPText(tmpComp.raw(), cat);
            }
        }

        btnGO.SetActive(true);
        m_navButtons.push_back({ clonedRaw, cat });
    }
}

void SettingsMenuModule::InitContentButtons() {
    if (!m_contentViewport) return;

    auto worldsGO = GameObject::Find("Menu_MM_Worlds(Clone)");
    if (!worldsGO.IsValid()) return;

    auto btnTemplateT = worldsGO.GetTransform().Find(
        "Panel_SectionList/ScrollRect_Navigation_Container/ScrollRect_Content/Viewport/"
        "VerticalLayoutGroup/Content_WorldCategory/CommunityLabsPanel/Button_Text");

    void* btnTemplate = btnTemplateT.GetGameObject().raw();

    static auto instantiate1 = MethodHandler::resolve("UnityEngine.Object", "Instantiate", 1);
    if (!instantiate1) return;

    void* vlgCloneP[] = { btnTemplate };
    void* vlgCloneRaw = MethodHandler::invoke<void*>(instantiate1, nullptr, vlgCloneP);
    if (!vlgCloneRaw) return;

    GameObject vlgGO(vlgCloneRaw);
    vlgGO.SetName("Nyx_ContentVLG");
    auto vlgT = vlgGO.GetTransform();
    Transform viewport(m_contentViewport);
    vlgT.SetParent(viewport, false);

    for (int i = vlgT.GetChildCount() - 1; i >= 0; --i) {
        try {
            auto childGO = vlgT.GetChild(i).GetGameObject();
            if (childGO.valid()) Object(childGO.raw()).DestroyImmediate();
        } catch (...) {}
    }

    {
        auto componentClass = Class::find("UnityEngine.Component");
        if (componentClass) {
            auto allComps = vlgGO.GetComponents(componentClass);
            for (auto& comp : allComps) {
                if (!comp.valid()) continue;
                try {
                    auto klass = comp.get_class();
                    if (!klass) continue;
                    std::string name = klass.name();
                    if (name != "RectTransform" && name != "CanvasRenderer")
                        Object(comp.raw()).DestroyImmediate();
                } catch (...) {}
            }
        }
    }

    auto vlgClass = Class::find("UnityEngine.UI.VerticalLayoutGroup");
    if (vlgClass) {
        auto vlgComp = vlgGO.AddComponent(vlgClass);
        if (vlgComp.valid()) {
            static auto setSpacing = MethodHandler::resolve(
                "UnityEngine.UI.HorizontalOrVerticalLayoutGroup", "set_spacing", 1);
            if (setSpacing) {
                float spacing = 8.f;
                void* args[] = { &spacing };
                MethodHandler::invoke(setSpacing, vlgComp.raw(), args);
            }
            static auto setChildAlign = MethodHandler::resolve(
                "UnityEngine.UI.LayoutGroup", "set_childAlignment", 1);
            if (setChildAlign) {
                int upperLeft = 0;
                void* args[] = { &upperLeft };
                MethodHandler::invoke(setChildAlign, vlgComp.raw(), args);
            }
            static auto setChildForceW = MethodHandler::resolve(
                "UnityEngine.UI.HorizontalOrVerticalLayoutGroup", "set_childForceExpandWidth", 1);
            if (setChildForceW) {
                bool val = true;
                void* args[] = { &val };
                MethodHandler::invoke(setChildForceW, vlgComp.raw(), args);
            }
            static auto setChildForceH = MethodHandler::resolve(
                "UnityEngine.UI.HorizontalOrVerticalLayoutGroup", "set_childForceExpandHeight", 1);
            if (setChildForceH) {
                bool val = false;
                void* args[] = { &val };
                MethodHandler::invoke(setChildForceH, vlgComp.raw(), args);
            }
        }
    }

    auto csfClass = Class::find("UnityEngine.UI.ContentSizeFitter");
    if (csfClass) {
        auto csf = vlgGO.AddComponent(csfClass);
        if (csf.valid()) {
            static auto setVertFit = MethodHandler::resolve(
                "UnityEngine.UI.ContentSizeFitter", "set_verticalFit", 1);
            if (setVertFit) {
                int preferredSize = 2;
                void* args[] = { &preferredSize };
                MethodHandler::invoke(setVertFit, csf.raw(), args);
            }
        }
    }

    static auto setAnchorMin = MethodHandler::resolve("UnityEngine.RectTransform", "set_anchorMin", 1);
    static auto setAnchorMax = MethodHandler::resolve("UnityEngine.RectTransform", "set_anchorMax", 1);
    static auto setSizeDelta = MethodHandler::resolve("UnityEngine.RectTransform", "set_sizeDelta", 1);
    static auto setAnchoredPos = MethodHandler::resolve("UnityEngine.RectTransform", "set_anchoredPosition", 1);
    static auto setPivot = MethodHandler::resolve("UnityEngine.RectTransform", "set_pivot", 1);
    if (setAnchorMin && setAnchorMax && setSizeDelta && setAnchoredPos && setPivot) {
        IL2CPP::Vector2 zero{ 0.f, 0.f };
        IL2CPP::Vector2 one{ 1.f, 1.f };
        IL2CPP::Vector2 topLeft{ 0.f, 1.f };
        void* pMin[] = { &zero };
        void* pMax[] = { &one };
        void* pSize[] = { &zero };
        void* pPos[] = { &zero };
        void* pPivot[] = { &topLeft };
        MethodHandler::invoke(setAnchorMin, vlgT.raw(), pMin);
        MethodHandler::invoke(setAnchorMax, vlgT.raw(), pMax);
        MethodHandler::invoke(setSizeDelta, vlgT.raw(), pSize);
        MethodHandler::invoke(setAnchoredPos, vlgT.raw(), pPos);
        MethodHandler::invoke(setPivot, vlgT.raw(), pPivot);
    }

    vlgGO.SetActive(true);

    const char* testButtons[] = { "Test Button" };
    for (const char* label : testButtons) {
        void* cloneP[] = { btnTemplate };
        void* clonedRaw = MethodHandler::invoke<void*>(instantiate1, nullptr, cloneP);
        if (!clonedRaw) continue;

        GameObject btnGO(clonedRaw);
        btnGO.SetName((std::string("Nyx_Btn_") + label).c_str());

        auto btnT = btnGO.GetTransform();
        btnT.SetParent(vlgT, false);

        {
            auto componentClass = Class::find("UnityEngine.Component");
            if (componentClass) {
                auto allComps = btnGO.GetComponents(componentClass);
                for (auto& comp : allComps) {
                    if (!comp.valid()) continue;
                    try {
                        auto klass = comp.get_class();
                        if (!klass) continue;
                        std::string cname = klass.name();
                        if (cname.find("ButtonPublic") == 0 ||
                            cname == "StyleElement" ||
                            cname == "Tooltip" ||
                            cname.find("MonoBehaviourPublic") == 0) {
                            Object(comp.raw()).DestroyImmediate();
                        }
                    } catch (...) {}
                }
            }
        }

        auto buttonClass = Class::find("UnityEngine.UI.Button");
        if (buttonClass) {
            auto btnComp = btnGO.AddComponent(buttonClass);
            if (btnComp.valid()) {
                static auto setTransition = MethodHandler::resolve(
                    "UnityEngine.UI.Selectable", "set_transition", 1);
                if (setTransition) {
                    int none = 0;
                    void* args[] = { &none };
                    MethodHandler::invoke(setTransition, btnComp.raw(), args);
                }
            }
        }

        auto textChildT = btnT.Find("Text_MM_H3");
        if (textChildT.valid()) {
            auto textGO = textChildT.GetGameObject();
            auto tmpComp = textGO.GetComponentByName("TMPro.TextMeshProUGUI");
            if (!tmpComp.valid()) tmpComp = textGO.GetComponentByName("TMPro.TMP_Text");
            if (tmpComp.valid()) {
                try {
                    auto se = textGO.GetComponentByName("VRC.UI.Core.Styles.StyleElement");
                    if (se.valid()) Object(se.raw()).DestroyImmediate();
                } catch (...) {}
                SetTMPText(tmpComp.raw(), label);
            }
        }

        btnGO.SetActive(true);
        m_contentButtons.push_back({ clonedRaw, label });
    }
}

void SettingsMenuModule::InitTabButton() {
    if (m_tabButtonGO) return;

    auto mmCanvas = GameObject::Find("Canvas_MainMenu(Clone)");

    auto mmT = mmCanvas.GetTransform();
    auto hlgT = mmT.Find("Container/PageButtons/HorizontalLayoutGroup");
    m_tabBarParent = hlgT.raw();

    auto existingTab = hlgT.Find("Nyx_Button_Tab");
    if (existingTab.valid()) {
        m_tabButtonGO = existingTab.GetGameObject().raw();
        return;
    }

    auto worldsTabT = hlgT.Find("Worlds_Button_Tab");

    static auto instantiate2 = MethodHandler::resolve("UnityEngine.Object", "Internal_CloneSingleWithParent", 3);
    void* clonedRaw = nullptr;
    if (instantiate2) {
        auto worldsTabGO = worldsTabT.GetGameObject();
        bool worldPositionStays = false;
        void* params[] = { worldsTabGO.raw(), hlgT.raw(), &worldPositionStays };
        clonedRaw = MethodHandler::invoke<void*>(instantiate2, nullptr, params);
    }
    if (!clonedRaw) {
        static auto instantiate1 = MethodHandler::resolve("UnityEngine.Object", "Instantiate", 1);
        if (!instantiate1) return;
        auto worldsTabGO = worldsTabT.GetGameObject();
        void* cloneParams[] = { worldsTabGO.raw() };
        clonedRaw = MethodHandler::invoke<void*>(instantiate1, nullptr, cloneParams);
        GameObject(clonedRaw).GetTransform().SetParent(hlgT, false);
    }

    m_tabButtonGO = clonedRaw;
    GameObject tabGO(m_tabButtonGO);
    tabGO.SetName("Nyx_Button_Tab");
    auto tabT = tabGO.GetTransform();

    {
        auto componentClass = Class::find("UnityEngine.Component");
        if (componentClass) {
            auto allComps = tabGO.GetComponents(componentClass);
            for (auto& comp : allComps) {
                if (!comp.valid()) continue;
                try {
                    auto klass = comp.get_class();
                    if (!klass) continue;
                    std::string className = klass.name();

                    if (className == "PageButton" ||
                        className == "StyleElement" || className == "Tooltip" ||
                        className == "MonoBehaviourPublicEnBoObUnique" ||
                        className == "MonoBehaviourPublicBoUnique") {
                        Object(comp.raw()).DestroyImmediate();
                    }
                } catch (...) {}
            }
        }
    }

    {
        auto buttonClass = Class::find("UnityEngine.UI.Button");
        if (buttonClass) {
            auto btnComp = tabGO.AddComponent(buttonClass);
            if (btnComp.valid()) {
                static auto setTransition = MethodHandler::resolve(
                    "UnityEngine.UI.Selectable", "set_transition", 1);
                if (setTransition) {
                    int none = 0;
                    void* args[] = { &none };
                    MethodHandler::invoke(setTransition, btnComp.raw(), args);
                }
            } else {
                auto selClass = Class::find("UnityEngine.UI.Selectable");
                if (selClass) tabGO.AddComponent(selClass);
            }
        }
    }

    auto badge1T = tabT.Find("Tab_Badge");
    if (badge1T.valid()) badge1T.GetGameObject().SetActive(false);
    auto badge2T = tabT.Find("Tab_Badge_Yellow");
    if (badge2T.valid()) badge2T.GetGameObject().SetActive(false);

    auto textT = tabT.Find("Text_H4");
    if (textT.valid()) {
        auto textGO = textT.GetGameObject();
        auto tmpComp = textGO.GetComponentByName("TMPro.TextMeshProUGUI");
        if (!tmpComp.valid()) tmpComp = textGO.GetComponentByName("TMPro.TMP_Text");
        if (tmpComp.valid()) {
            try {
                auto se = textGO.GetComponentByName("VRC.UI.Core.Styles.StyleElement");
                if (se.valid()) Object(se.raw()).Destroy();
            } catch (...) {}
            SetTMPText(tmpComp.raw(), "Nyx");
        }
    }

    for (const char* childName : { "Icon", "Background" }) {
        auto childT = tabT.Find(childName);
        if (childT.valid()) {
            try {
                auto se = childT.GetGameObject().GetComponentByName("VRC.UI.Core.Styles.StyleElement");
                if (se.valid()) Object(se.raw()).Destroy();
            } catch (...) {}
        }
    }

    tabGO.SetActive(false);
    tabGO.SetActive(true);

}

// ---- Show/Hide ----

void SettingsMenuModule::ShowNyxPage() {
    if (!m_menuCanvasGroup || !m_headerOffsetT) return;

    try {
        if (m_mscComponent) {
            static auto setEnabled = MethodHandler::resolve("UnityEngine.Behaviour", "set_enabled", 1);
            if (setEnabled) {
                bool off = false;
                void* args[] = { &off };
                MethodHandler::invoke(setEnabled, m_mscComponent, args);
            }
        }

        Transform headerOffset(m_headerOffsetT);
        int childCount = headerOffset.GetChildCount();
        for (int i = 0; i < childCount; ++i) {
            try {
                auto childT = headerOffset.GetChild(i);
                if (!childT.valid()) continue;
                auto childGO = childT.GetGameObject();
                if (!childGO.valid()) continue;
                if (childGO.raw() == m_menuGO) continue;
                childGO.SetActive(false);
            } catch (...) {}
        }

        GameObject menuGO(m_menuGO);
        menuGO.SetActive(true);

        EnableAllBehavioursRecursive(menuGO.GetTransform().raw());

        CanvasGroup cg(m_menuCanvasGroup);
        cg.SetAlpha(1.f);
        cg.SetInteractable(true);
        cg.SetBlocksRaycasts(true);

        m_visible = true;
        m_showCooldown = 30;
    } catch (...) {
    }
}

void SettingsMenuModule::HideNyxPage() {
    if (!m_menuCanvasGroup || !m_headerOffsetT) return;

    try {
        CanvasGroup cg(m_menuCanvasGroup);
        cg.SetAlpha(0.f);
        cg.SetInteractable(false);
        cg.SetBlocksRaycasts(false);

        GameObject menuGO(m_menuGO);
        menuGO.SetActive(false);

        Transform headerOffset(m_headerOffsetT);
        int childCount = headerOffset.GetChildCount();
        for (int i = 0; i < childCount; ++i) {
            try {
                auto childT = headerOffset.GetChild(i);
                if (!childT.valid()) continue;
                auto childGO = childT.GetGameObject();
                if (!childGO.valid()) continue;
                if (childGO.raw() == m_menuGO) continue;
                childGO.SetActive(true);
            } catch (...) {}
        }

        if (m_mscComponent) {
            static auto setEnabled = MethodHandler::resolve("UnityEngine.Behaviour", "set_enabled", 1);
            if (setEnabled) {
                bool on = true;
                void* args[] = { &on };
                MethodHandler::invoke(setEnabled, m_mscComponent, args);
            }
        }

        m_visible = false;
    } catch (...) {
    }
}

// ---- Input ----

bool SettingsMenuModule::OnEvent(UINT msg, WPARAM wParam, LPARAM) {
    if (msg == WM_KEYDOWN && wParam == VK_ESCAPE && m_visible) {
        HideNyxPage();
        return true;
    }
    return false;
}

// ---- Main Update Loop ----

void SettingsMenuModule::OnUpdate() {
    if (!m_initialized) {
        if (++m_initDelay > 180) {
            try { InitMenu(); } catch (...) {}
            if (!m_initialized) m_initDelay = 120;
        }
        return;
    }

    if (m_menuGO) {
        try {
            GameObject go(m_menuGO);
            if (!go.valid() || !go.IsValid()) {
                m_initialized = false;
                m_initDelay = 120;
                m_menuGO = nullptr;
                m_tabButtonGO = nullptr;
                m_headerOffsetT = nullptr;
                m_navVLG = nullptr;
                m_contentViewport = nullptr;
                m_menuCanvasGroup = nullptr;
                m_menuCanvas = nullptr;
                m_tabBarParent = nullptr;
                m_mscComponent = nullptr;
                m_navButtons.clear();
                m_contentButtons.clear();
                return;
            }
        } catch (...) {
            m_initialized = false;
            m_initDelay = 120;
            m_menuGO = nullptr;
            m_tabButtonGO = nullptr;
            m_headerOffsetT = nullptr;
            m_navVLG = nullptr;
            m_contentViewport = nullptr;
            m_menuCanvasGroup = nullptr;
            m_menuCanvas = nullptr;
            m_tabBarParent = nullptr;
            m_mscComponent = nullptr;
            m_navButtons.clear();
            m_contentButtons.clear();
            return;
        }
    }

    if (m_showCooldown > 0) m_showCooldown--;

    if (m_tabButtonGO) {
        static auto getCurrent = MethodHandler::resolve(
            "UnityEngine.EventSystems.EventSystem", "get_current", 0);
        static auto getSelectedGO = MethodHandler::resolve(
            "UnityEngine.EventSystems.EventSystem", "get_currentSelectedGameObject", 0);

        if (getCurrent && getSelectedGO) {
            try {
                void* eventSystem = MethodHandler::invoke<void*>(getCurrent, nullptr);
                if (eventSystem) {
                    void* selectedGO = MethodHandler::invoke<void*>(getSelectedGO, eventSystem, nullptr);

                    bool tabSelectedNow = (selectedGO == m_tabButtonGO);

                    if (tabSelectedNow && !m_tabWasSelected && !m_visible) {
                        PlayClickSound();
                        ShowNyxPage();
                    }

                    if (m_visible && m_showCooldown == 0 && selectedGO != nullptr && !tabSelectedNow) {
                        bool isOtherTab = false;
                        if (m_tabBarParent) {
                            try {
                                GameObject selGO(selectedGO);
                                auto selT = selGO.GetTransform();
                                auto selParent = selT.GetParent();
                                if (selParent.valid() && selParent.raw() == m_tabBarParent) {
                                    isOtherTab = true;
                                }
                            } catch (...) {}
                        }
                        if (isOtherTab) {
                            HideNyxPage();
                        }
                    }

                    m_tabWasSelected = tabSelectedNow;

                    for (auto& btn : m_navButtons) {
                        if (selectedGO == btn.goRaw) {
                        }
                    }

                    for (auto& btn : m_contentButtons) {
                        if (selectedGO == btn.goRaw) {
                            DashboardConsole::Get().AddLog(
                                "test button clicked from Nyx settings",
                                DashboardConsole::LogColor::System);
                        }
                    }
                }
            } catch (...) {}
        }
    }

    if (m_pendingShow) {
        m_pendingShow = false;
        if (m_visible)
            HideNyxPage();
        else
            ShowNyxPage();
    }
}

void SettingsMenuModule::OnLateUpdate() {
    if (!m_initialized || !m_visible || !m_menuCanvasGroup) return;

    try {
        CanvasGroup cg(m_menuCanvasGroup);
        cg.SetAlpha(1.f);
        cg.SetInteractable(true);
        cg.SetBlocksRaycasts(true);
    } catch (...) {}
}

} // namespace UNIx
