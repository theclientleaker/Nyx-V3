#pragma once

#include <string>
#include <string_view>
#include <vector>
#include <unordered_map>
#include <mutex>
#include <shared_mutex>
#include <thread>
#include <atomic>

namespace UNIx {

    enum AnimationFlags : uint16_t {
        Anim_None          = 0,
        Anim_Rainbow       = 1 << 0,
        Anim_SmoothRainbow = 1 << 1,
        Anim_Blink         = 1 << 2,
        Anim_Scroll        = 1 << 3,
        Anim_Cylinder      = 1 << 4,
        Anim_Pulse         = 1 << 5,
        Anim_Glitch        = 1 << 6,
        Anim_Jump          = 1 << 7,
        Anim_Shake         = 1 << 8,
        Anim_GhostTrail    = 1 << 9,
        Anim_LetterByLetter = 1 << 10,
    };

    enum class AnimationType : uint8_t {
        None,
        Rainbow,
        SmoothRainbow,
        Blink,
        Scroll,
        Cylinder,
        Pulse,
        Glitch,
        Jump,
        Shake,
        GhostTrail,
        LetterByLetter,
    };

    struct Color4 {
        float r = 1.f, g = 1.f, b = 1.f, a = 1.f;
    };

    inline uint16_t AnimTypeToFlag(AnimationType t) {
        switch (t) {
            case AnimationType::Rainbow:       return Anim_Rainbow;
            case AnimationType::SmoothRainbow: return Anim_SmoothRainbow;
            case AnimationType::Blink:         return Anim_Blink;
            case AnimationType::Scroll:        return Anim_Scroll;
            case AnimationType::Cylinder:      return Anim_Cylinder;
            case AnimationType::Pulse:         return Anim_Pulse;
            case AnimationType::Glitch:        return Anim_Glitch;
            case AnimationType::Jump:          return Anim_Jump;
            case AnimationType::Shake:         return Anim_Shake;
            case AnimationType::GhostTrail:    return Anim_GhostTrail;
            case AnimationType::LetterByLetter: return Anim_LetterByLetter;
            default: return Anim_None;
        }
    }

    struct ParsedTag {
        std::string text;
        Color4 color;
        AnimationType animation = AnimationType::None;
        uint16_t animFlags = Anim_None;
        std::string iconName;
        bool isRichText = false;
    };

    class TagManager {
    public:
        static TagManager& Get();

        void Start();
        void Stop();

        std::vector<ParsedTag> GetParsedTagsForUser(const std::string& userId) const;
        std::string GetRawTagsForUser(const std::string& userId) const;
        void RequestRefresh();
        bool IsDevUser() const { return m_isDev; }
        void SetDevUser(bool dev) { m_isDev = dev; }

    private:
        TagManager() = default;
        ~TagManager();

        void FetchLoop();
        void FetchTags();
        std::string FetchVersion();
        void ParseResponse(const std::string& body);
        static ParsedTag ParseSingleTag(std::string_view raw);
        static AnimationType ParseAnimation(std::string_view prefix);
        static Color4 ParseColor(std::string_view hex);

        mutable std::shared_mutex m_mutex;
        std::unordered_map<std::string, std::vector<ParsedTag>> m_tags;
        std::unordered_map<std::string, std::string> m_rawTags;

        std::thread m_thread;
        std::atomic<bool> m_running{false};
        std::atomic<bool> m_refreshRequested{false};
        bool m_isDev = false;
        std::string m_lastVersion;
    };

} // namespace UNIx
