#include <Modules/Movement/Speed/MovementModule.hpp>
#include <ThirdParty/imgui/imgui.h>
#include <Bootstrap.Module/include/bootstrap_module.hpp>
#include <Core/QuickMenuEx.hpp>
#include <Core/Globals.hpp>

namespace UNIx {

    static constexpr float DEFAULT_RUN_SPEED = 4.0f;
    static constexpr float DEFAULT_WALK_SPEED = 2.0f;
    static constexpr float DEFAULT_STRAFE_SPEED = 2.0f;
    static constexpr float DEFAULT_JUMP_IMPULSE = 3.0f;
    static constexpr float DEFAULT_GRAVITY = 1.0f;

    MovementModule* MovementModule::s_instance = nullptr;

    MovementModule::MovementModule()
        : BaseModule("Movement", "Override movement speed, jump, and gravity", VK_F2, "Movement") {}

    void __cdecl MovementModule::QmRunSpeedCb(uint32_t, float val) { if (s_instance) s_instance->m_runSpeed = val; }
    void __cdecl MovementModule::QmWalkSpeedCb(uint32_t, float val) { if (s_instance) s_instance->m_walkSpeed = val; }
    void __cdecl MovementModule::QmStrafeSpeedCb(uint32_t, float val) { if (s_instance) s_instance->m_strafeSpeed = val; }
    void __cdecl MovementModule::QmJumpCb(uint32_t, float val) { if (s_instance) s_instance->m_jumpImpulse = val; }
    void __cdecl MovementModule::QmGravityCb(uint32_t, float val) { if (s_instance) s_instance->m_gravity = val; }

    void MovementModule::OnSetupQuickMenu(uint32_t moduleId, uint32_t categoryPageId) {
        s_instance = this;
        auto& qmEx = QuickMenuEx::Get();

        // Speed foldout (collapsed by default to keep it tidy)
        uint32_t speedFold = qmEx.add_foldout(moduleId, categoryPageId, "Speed", false, true);
        qmEx.add_slider(moduleId, speedFold, "Run Speed", 1.0f, 30.0f, m_runSpeed,
            QmRunSpeedCb, "movement_run_speed", "");
        qmEx.add_slider(moduleId, speedFold, "Walk Speed", 1.0f, 20.0f, m_walkSpeed,
            QmWalkSpeedCb, "movement_walk_speed", "");
        qmEx.add_slider(moduleId, speedFold, "Strafe Speed", 1.0f, 20.0f, m_strafeSpeed,
            QmStrafeSpeedCb, "movement_strafe_speed", "");
        qmEx.add_separator(moduleId, speedFold);
        qmEx.add_slider(moduleId, speedFold, "Jump Impulse", 1.0f, 20.0f, m_jumpImpulse,
            QmJumpCb, "movement_jump_impulse", "");
        qmEx.add_slider(moduleId, speedFold, "Gravity", 0.0f, 5.0f, m_gravity,
            QmGravityCb, "movement_gravity", "");
    }

    void MovementModule::OnDisable() {
        if (m_wasActive) {
            auto api = GetLocalPlayerApi();
            if (api.valid()) {
                api.SetRunSpeed(DEFAULT_RUN_SPEED);
                api.SetWalkSpeed(DEFAULT_WALK_SPEED);
                api.SetStrafeSpeed(DEFAULT_STRAFE_SPEED);
                api.SetJumpImpulse(DEFAULT_JUMP_IMPULSE);
                api.SetGravityStrength(DEFAULT_GRAVITY);
            }
            m_wasActive = false;
        }
    }

    void MovementModule::OnUpdate() {
        auto api = GetLocalPlayerApi();
        if (!api.valid()) return;

        m_wasActive = true;
        api.SetRunSpeed(m_runSpeed);
        api.SetWalkSpeed(m_walkSpeed);
        api.SetStrafeSpeed(m_strafeSpeed);
        api.SetJumpImpulse(m_jumpImpulse);
        api.SetGravityStrength(m_gravity);
    }

    void MovementModule::OnRender() {
        ImGui::SliderFloat("Run Speed", &m_runSpeed, 1.0f, 30.0f);
        ImGui::SliderFloat("Walk Speed", &m_walkSpeed, 1.0f, 20.0f);
        ImGui::SliderFloat("Strafe Speed", &m_strafeSpeed, 1.0f, 20.0f);
        ImGui::SliderFloat("Jump Impulse", &m_jumpImpulse, 1.0f, 20.0f);
        ImGui::SliderFloat("Gravity", &m_gravity, 0.0f, 5.0f);
    }

} // namespace UNIx
