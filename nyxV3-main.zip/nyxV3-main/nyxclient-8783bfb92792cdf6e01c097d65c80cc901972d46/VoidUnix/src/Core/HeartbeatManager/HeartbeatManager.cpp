#define WIN32_LEAN_AND_MEAN
#include <Windows.h>

#include <Core/HeartbeatManager/HeartbeatManager.hpp>
#include <Core/ApiClient/ApiClient.hpp>
#include <Core/TagManager/TagManager.hpp>
#include <Core/NameplateConfigManager/NameplateConfigManager.hpp>
#include <Core/FileLog/FileLog.hpp>

namespace UNIx {

    static const char* kClientVersion = "1.0.0";

    static std::string EscapeJson(const std::string& s) {
        std::string out;
        out.reserve(s.size());
        for (char c : s) {
            switch (c) {
                case '"':  out += "\\\""; break;
                case '\\': out += "\\\\"; break;
                case '\n': out += "\\n"; break;
                case '\r': out += "\\r"; break;
                case '\t': out += "\\t"; break;
                default: out += c;
            }
        }
        return out;
    }

    HeartbeatManager& HeartbeatManager::Get() {
        static HeartbeatManager instance;
        return instance;
    }

    HeartbeatManager::~HeartbeatManager() {
        Stop();
    }

    void HeartbeatManager::Start() {
        if (m_running.exchange(true)) return;

        ApiClient::Get().SetWebSocketHandler([this](const std::string& msg) {
            OnWebSocketMessage(msg);
        });

        m_thread = std::thread(&HeartbeatManager::WorkerLoop, this);
    }

    void HeartbeatManager::Stop() {
        m_running = false;
        ApiClient::Get().DisconnectWebSocket();
        if (m_thread.joinable())
            m_thread.join();
    }

    void HeartbeatManager::SetLocalUserId(const std::string& userId) {
        bool firstSet = false;
        {
            std::lock_guard lock(m_mutex);
            firstSet = m_localUserId.empty();
            m_localUserId = userId;
        }
        if (firstSet) {
            CheckDevStatus();
            ApiClient::Get().ConnectWebSocket(userId);
        }
    }

    void HeartbeatManager::SetLocalDisplayName(const std::string& name) {
        std::lock_guard lock(m_mutex);
        m_localDisplayName = name;
    }

    void HeartbeatManager::UpdateLocalInfo(int fps, const std::string& worldId, const std::string& worldName) {
        std::lock_guard lock(m_mutex);
        m_localFps = fps;
        m_localWorldId = worldId;
        m_localWorldName = worldName;
    }

    HeartbeatManager::LocalData HeartbeatManager::SnapshotLocalData() const {
        std::lock_guard lock(m_mutex);
        return { m_localUserId, m_localDisplayName, m_localFps, m_localWorldId, m_localWorldName };
    }

    std::string HeartbeatManager::BuildHeartbeatJson(const LocalData& data) const {
        std::string json = "{";
        json += "\"userId\":\"" + EscapeJson(data.userId) + "\",";
        json += "\"displayName\":\"" + EscapeJson(data.displayName) + "\",";
        json += "\"clientVersion\":\"" + std::string(kClientVersion) + "\",";
        json += "\"worldId\":\"" + EscapeJson(data.worldId) + "\",";
        json += "\"worldName\":\"" + EscapeJson(data.worldName) + "\",";
        json += "\"fps\":" + std::to_string(data.fps);
        json += "}";
        return json;
    }

    std::vector<ActiveUser> HeartbeatManager::ParseUserArray(const std::string& json, size_t searchStart) const {
        std::vector<ActiveUser> users;
        size_t pos = searchStart;
        while (pos < json.size()) {
            size_t objStart = json.find('{', pos);
            if (objStart == std::string::npos) break;

            int depth = 0;
            size_t objEnd = objStart;
            for (size_t i = objStart; i < json.size(); ++i) {
                if (json[i] == '{') depth++;
                else if (json[i] == '}') {
                    depth--;
                    if (depth == 0) { objEnd = i; break; }
                }
            }

            std::string obj = json.substr(objStart, objEnd - objStart + 1);
            ActiveUser user;

            auto extractStr = [&](const std::string& key) -> std::string {
                std::string needle = "\"" + key + "\":\"";
                size_t s = obj.find(needle);
                if (s == std::string::npos) return "";
                s += needle.size();
                size_t e = obj.find('"', s);
                if (e == std::string::npos) return "";
                return obj.substr(s, e - s);
            };
            auto extractInt = [&](const std::string& key) -> int {
                std::string needle = "\"" + key + "\":";
                size_t s = obj.find(needle);
                if (s == std::string::npos) return 0;
                s += needle.size();
                return std::atoi(obj.c_str() + s);
            };
            auto extractBool = [&](const std::string& key) -> bool {
                std::string needle = "\"" + key + "\":";
                size_t s = obj.find(needle);
                if (s == std::string::npos) return false;
                s += needle.size();
                return obj.substr(s, 4) == "true";
            };

            user.userId = extractStr("userId");
            user.displayName = extractStr("displayName");
            user.clientVersion = extractStr("clientVersion");
            user.worldId = extractStr("worldId");
            user.worldName = extractStr("worldName");
            user.fps = extractInt("fps");
            user.isDev = extractBool("isDev");

            if (!user.userId.empty())
                users.push_back(std::move(user));
            pos = objEnd + 1;
        }
        return users;
    }

    ActiveUserSnapshot HeartbeatManager::GetActiveUsers() const {
        std::lock_guard lock(m_mutex);

        if (!m_localUserId.empty() && !m_localDisplayName.empty()) {
            auto result = std::make_shared<std::vector<ActiveUser>>(*m_activeUsers);
            bool found = false;
            for (auto& u : *result) {
                if (u.userId == m_localUserId) {
                    u.fps = m_localFps;
                    u.worldId = m_localWorldId;
                    u.worldName = m_localWorldName;
                    u.displayName = m_localDisplayName;
                    u.isDev = m_isDev;
                    found = true;
                    break;
                }
            }
            if (!found) {
                ActiveUser local;
                local.userId = m_localUserId;
                local.displayName = m_localDisplayName;
                local.clientVersion = kClientVersion;
                local.worldId = m_localWorldId;
                local.worldName = m_localWorldName;
                local.fps = m_localFps;
                local.isDev = m_isDev;
                result->insert(result->begin(), local);
            }
            return result;
        }

        return m_activeUsers;
    }

    void HeartbeatManager::RequestRefresh() {
        m_refreshRequested = true;
    }

    void HeartbeatManager::WorkerLoop() {
        int cycle = 0;
        while (m_running) {
            if (ApiClient::Get().IsWebSocketConnected()) {
                SendWebSocketHeartbeat();
            } else {
                SendHeartbeat();
                if (cycle % 6 == 0)
                    FetchActiveUsers();
            }
            cycle++;

            for (int i = 0; i < 50 && m_running; ++i) {
                if (m_refreshRequested.exchange(false)) {
                    if (!ApiClient::Get().IsWebSocketConnected())
                        FetchActiveUsers();
                }
                Sleep(100);
            }
        }
    }

    void HeartbeatManager::SendWebSocketHeartbeat() {
        auto data = SnapshotLocalData();
        if (data.userId.empty()) return;

        std::string msg = "{\"type\":\"heartbeat\"," + BuildHeartbeatJson(data).substr(1);
        ApiClient::Get().WebSocketSend(msg);
    }

    void HeartbeatManager::SendHeartbeat() {
        auto data = SnapshotLocalData();
        if (data.userId.empty()) return;

        std::string body = BuildHeartbeatJson(data);
        std::string response = ApiClient::Get().Post("/api/heartbeat", body, ApiAuth::Client);

        if (response.find("\"command\":{") != std::string::npos) {
            auto extractStr = [&](const std::string& key) -> std::string {
                std::string needle = "\"" + key + "\":\"";
                size_t s = response.find(needle);
                if (s == std::string::npos) return "";
                s += needle.size();
                size_t e = response.find('"', s);
                if (e == std::string::npos) return "";
                return response.substr(s, e - s);
            };

            std::string type = extractStr("type");
            if (!type.empty()) {
                std::lock_guard lock(m_mutex);
                m_pendingCommandType = type;
                m_pendingCommandWorldId = extractStr("worldId");
            }
        }
    }

    void HeartbeatManager::OnWebSocketMessage(const std::string& message) {
        auto extractStr = [&](const std::string& json, const std::string& key) -> std::string {
            std::string needle = "\"" + key + "\":\"";
            size_t s = json.find(needle);
            if (s == std::string::npos) return "";
            s += needle.size();
            size_t e = json.find('"', s);
            if (e == std::string::npos) return "";
            return json.substr(s, e - s);
        };

        std::string type = extractStr(message, "type");

        if (type == "users") {
            size_t usersStart = message.find("\"users\":[");
            if (usersStart != std::string::npos) {
                auto users = ParseUserArray(message, usersStart);
                auto next = std::make_shared<std::vector<ActiveUser>>(std::move(users));
                std::lock_guard lock(m_mutex);
                m_activeUsers = std::move(next);
            }
        } else if (type == "command") {
            size_t cmdStart = message.find("\"command\":{");
            if (cmdStart != std::string::npos) {
                std::string cmdObj = message.substr(cmdStart);
                std::string cmdType = extractStr(cmdObj, "type");
                std::string cmdWorldId = extractStr(cmdObj, "worldId");
                if (!cmdType.empty()) {
                    std::lock_guard lock(m_mutex);
                    m_pendingCommandType = cmdType;
                    m_pendingCommandWorldId = cmdWorldId;
                }
            }
        } else if (type == "auth_ok") {
            std::string isDev = extractStr(message, "isDev");
            if (message.find("\"isDev\":true") != std::string::npos) {
                m_isDev = true;
            } else {
            }
        } else if (type == "tags_updated") {
            TagManager::Get().RequestRefresh();
        } else if (type == "nameplates_updated") {
            NameplateConfigManager::Get().RequestRefresh();
        } else if (type == "auth_fail") {
        }
    }

    void HeartbeatManager::FetchActiveUsers() {
        std::string response = ApiClient::Get().Get("/api/users");
        if (response.empty()) return;

        auto users = ParseUserArray(response);
        auto next = std::make_shared<std::vector<ActiveUser>>(std::move(users));
        std::lock_guard lock(m_mutex);
        m_activeUsers = std::move(next);
    }

    void HeartbeatManager::CheckDevStatus() {
        std::string userId;
        {
            std::lock_guard lock(m_mutex);
            userId = m_localUserId;
        }
        if (userId.empty()) return;

        std::string response = ApiClient::Get().Get("/api/dev/" + userId);
        m_isDev = response.find("true") != std::string::npos;
    }

    bool HeartbeatManager::HasPendingCommand() const {
        std::lock_guard lock(m_mutex);
        return !m_pendingCommandType.empty();
    }

    std::pair<std::string, std::string> HeartbeatManager::ConsumePendingCommand() {
        std::lock_guard lock(m_mutex);
        auto result = std::make_pair(std::move(m_pendingCommandType), std::move(m_pendingCommandWorldId));
        m_pendingCommandType.clear();
        m_pendingCommandWorldId.clear();
        return result;
    }

    void HeartbeatManager::ApiSetTag(const std::string& userId, const std::string& tagData) {
        std::string body = tagData + ":" + userId;
        ApiClient::Get().PostAsync("/api/tags", body, nullptr, ApiAuth::Admin);
    }

    void HeartbeatManager::ApiRemoveTag(const std::string& userId) {
        ApiClient::Get().DeleteAsync("/api/tags/" + userId);
    }

    void HeartbeatManager::ApiGrantDev(const std::string& userId) {
        ApiClient::Get().PostAsync("/api/dev/" + userId, "", nullptr, ApiAuth::Admin);
    }

    void HeartbeatManager::ApiRevokeDev(const std::string& userId) {
        ApiClient::Get().DeleteAsync("/api/dev/" + userId);
    }

    void HeartbeatManager::ApiSendCommand(const std::string& userId, const std::string& type, const std::string& worldId) {
        std::string body = "{\"type\":\"" + EscapeJson(type) + "\"";
        if (!worldId.empty())
            body += ",\"worldId\":\"" + EscapeJson(worldId) + "\"";
        body += "}";
        ApiClient::Get().PostAsync("/api/command/" + userId, body, nullptr, ApiAuth::Admin);
    }

    void HeartbeatManager::RefreshTags() {
    }

} // namespace UNIx
