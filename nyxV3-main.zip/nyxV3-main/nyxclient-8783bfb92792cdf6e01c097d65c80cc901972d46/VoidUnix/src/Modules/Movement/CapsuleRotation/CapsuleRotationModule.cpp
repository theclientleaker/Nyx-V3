#include <Modules/Movement/CapsuleRotation/CapsuleRotationModule.hpp>
#include <Modules/Movement/Flight/NoclipModule.hpp>
#include <Core/ModuleManager.hpp>
#include <Core/QuickMenuEx.hpp>
#include <Core/FileLog/FileLog.hpp>
#include <Core/Globals.hpp>
#include <ThirdParty/imgui/imgui.h>

#include <IL2CPP.Module/include/Unity/Transform.hpp>
#include <IL2CPP.Module/include/Unity/GameObject.hpp>
#include <IL2CPP.Module/include/Unity/Input.hpp>
#include <IL2CPP.Module/include/Unity/Time.hpp>
#include <IL2CPP.Module/include/Unity/Component.hpp>
#include <IL2CPP.Module/include/Unity/Behaviour.hpp>
#include <IL2CPP.Module/include/Unity/Camera.hpp>
#include <IL2CPP.Module/include/Unity/Object.hpp>
#include <IL2CPP.Module/include/Reflection.hpp>
#include <IL2CPP.Module/include/MethodHandler.hpp>
#include <Bootstrap.Module/include/VRChat/VRCPlayer.hpp>
#include <Bootstrap.Module/include/VRChat/VRCPlayerApi.hpp>

#include <string>
#include <cmath>

using namespace IL2CPP::Module::Unity;
using namespace IL2CPP::Module;

namespace UNIx {

    CapsuleRotationModule* CapsuleRotationModule::s_instance = nullptr;

    bool __cdecl CapsuleRotationModule::PrefixBlockInput(void*) {
        return true;
    }

    void __cdecl CapsuleRotationModule::QmRotSpeedCb(uint32_t, float val) { if (s_instance) s_instance->m_rotationSpeed = val; }

    void CapsuleRotationModule::OnSetupQuickMenu(uint32_t moduleId, uint32_t categoryPageId) {
        s_instance = this;
        auto& qmEx = QuickMenuEx::Get();
        uint32_t fold = qmEx.add_foldout(moduleId, categoryPageId, "Capsule Rotation", false, true);
        qmEx.add_slider(moduleId, fold, "Rotation Speed", 25.0f, 500.0f, m_rotationSpeed,
            QmRotSpeedCb, "capsule_rot_speed", "%.0f");
    }

    bool CapsuleRotationModule::IsNoclipActive() const {
        if (!m_noclipModule) return false;
        return m_noclipModule->IsEnabled();
    }

    IL2CPP::Quaternion CapsuleRotationModule::GetAppliedRotation() const {
        if (!m_active || !m_playerRoot) return IL2CPP::Quaternion{ 0.f, 0.f, 0.f, 1.f };
        Transform playerT(m_playerRoot);
        return playerT.GetRotation();
    }

    void CapsuleRotationModule::InstallInputHook() {
        if (m_hookInstalled) return;

        auto vrcPlayer = IL2CPP::VRChat::VRCPlayer::GetLocalPlayer();
        if (!vrcPlayer.valid()) return;

        auto go = vrcPlayer.GetGameObject();
        if (!go.valid()) return;

        auto inputClass = Class::find("MonoBehaviourPublicSiTrBoUnique");
        if (inputClass) {
            auto comp = go.GetComponent(inputClass);
            if (comp.valid()) {
                m_inputController = comp.raw();
                static auto setEnabled = MethodHandler::resolve("UnityEngine.Behaviour", "set_enabled", 1);
                if (setEnabled) {
                    bool off = false;
                    void* p[] = { &off };
                    MethodHandler::invoke<void>(setEnabled, m_inputController, p);
                    FLOG("[CapsuleRotation] Disabled GamelikeInputController");
                }
            }
        }

        m_hookInstalled = true;
    }

    void CapsuleRotationModule::RemoveInputHook() {
        if (!m_hookInstalled) return;

        if (m_inputController) {
            static auto setEnabled = MethodHandler::resolve("UnityEngine.Behaviour", "set_enabled", 1);
            if (setEnabled) {
                bool on = true;
                void* p[] = { &on };
                MethodHandler::invoke<void>(setEnabled, m_inputController, p);
                FLOG("[CapsuleRotation] Re-enabled GamelikeInputController");
            }
            m_inputController = nullptr;
        }

        m_hookInstalled = false;
    }

    void CapsuleRotationModule::SetMovementEnabled(bool enabled) {
        if (!enabled && IsNoclipActive()) return;

        auto vrcPlayer = IL2CPP::VRChat::VRCPlayer::GetLocalPlayer();
        if (!vrcPlayer.valid()) return;

        auto go = vrcPlayer.GetGameObject();
        if (!go.valid()) return;

        static auto setCharEnabled = MethodHandler::resolve("UnityEngine.Behaviour", "set_enabled", 1);
        if (setCharEnabled) {
            auto cc = go.GetComponentByName("CharacterController");
            if (cc.valid()) {
                bool val = enabled ? m_origCharControllerEnabled : false;
                void* p[] = { &val };
                MethodHandler::invoke<void>(setCharEnabled, cc.raw(), p);
            }
        }

        static auto setKinematic = MethodHandler::resolve("UnityEngine.Rigidbody", "set_isKinematic", 1);
        auto rb = go.GetComponentByName("Rigidbody");
        if (rb.valid() && setKinematic) {
            bool val = enabled ? m_origRigidbodyKinematic : true;
            void* p[] = { &val };
            MethodHandler::invoke<void>(setKinematic, rb.raw(), p);
        }
    }

    void CapsuleRotationModule::StoreComponentStates() {
        auto vrcPlayer = IL2CPP::VRChat::VRCPlayer::GetLocalPlayer();
        if (!vrcPlayer.valid()) return;

        auto go = vrcPlayer.GetGameObject();
        if (!go.valid()) return;

        static auto getCharEnabled = MethodHandler::resolve("UnityEngine.Behaviour", "get_enabled", 0);
        if (getCharEnabled) {
            auto cc = go.GetComponentByName("CharacterController");
            if (cc.valid()) {
                m_origCharControllerEnabled = MethodHandler::invoke<bool>(getCharEnabled, cc.raw());
            }
        }

        static auto getKinematic = MethodHandler::resolve("UnityEngine.Rigidbody", "get_isKinematic", 0);
        auto rb = go.GetComponentByName("Rigidbody");
        if (rb.valid() && getKinematic) {
            m_origRigidbodyKinematic = MethodHandler::invoke<bool>(getKinematic, rb.raw());
        }
    }

    void CapsuleRotationModule::OnEnable() {
        s_instance = this;

        m_noclipModule = ModuleManager::Get().FindModule<NoclipModule>();

        if (!InRoom()) { m_active = false; return; }

        auto vrcPlayer = IL2CPP::VRChat::VRCPlayer::GetLocalPlayer();
        if (!vrcPlayer.valid()) { m_active = false; return; }

        auto go = vrcPlayer.GetGameObject();
        if (!go.valid()) { m_active = false; return; }

        auto playerT = go.GetTransform();
        if (!playerT.valid()) { m_active = false; return; }

        m_playerRoot = playerT.raw();
        m_originalPosition = playerT.GetPosition();
        m_originalRotation = playerT.GetRotation();

        m_forwardDir = nullptr;
        m_avatarRoot = nullptr;

        auto fwdT = playerT.Find("ForwardDirection");
        if (fwdT.valid()) {
            m_forwardDir = fwdT.raw();

            IL2CPP::Quaternion pInv = playerT.GetRotation().Inverse();

            m_fwdDirRelativePos = pInv * (fwdT.GetPosition() - playerT.GetPosition());
            m_fwdDirRelativeRot = pInv * fwdT.GetRotation();

            auto avatarT = fwdT.Find("Avatar");
            if (avatarT.valid()) {
                m_avatarRoot = avatarT.raw();

                m_avatarRelativePos = pInv * (avatarT.GetPosition() - playerT.GetPosition());
                m_avatarRelativeRot = pInv * avatarT.GetRotation();
            }
        }

        m_cameraTransform = nullptr;
        auto cam = Camera::GetMain();
        if (cam.valid()) {
            auto camT = cam.GetTransform();
            if (camT.valid()) {
                m_cameraTransform = camT.raw();

                IL2CPP::Vector3 camDiff = camT.GetPosition() - playerT.GetPosition();
                IL2CPP::Quaternion pInv = playerT.GetRotation().Inverse();

                m_cameraRelativePos = pInv * camDiff;
                m_cameraRelativeRot = pInv * camT.GetRotation();
            }
        }

        StoreComponentStates();
        InstallInputHook();
        SetMovementEnabled(false);

        m_active = true;
    }

    void CapsuleRotationModule::OnDisable() {
        if (!m_active) return;

        RemoveInputHook();
        SetMovementEnabled(true);

        if (InRoom() && m_playerRoot) {
            Transform playerT(m_playerRoot);
            playerT.SetPosition(m_originalPosition);
            playerT.SetRotation(m_originalRotation);

            if (m_forwardDir) {
                Transform fwdT(m_forwardDir);
                fwdT.SetPosition(m_originalPosition + m_originalRotation * m_fwdDirRelativePos);
                fwdT.SetRotation(m_originalRotation * m_fwdDirRelativeRot);
            }

            if (m_avatarRoot) {
                Transform avatarT(m_avatarRoot);
                avatarT.SetPosition(m_originalPosition + m_originalRotation * m_avatarRelativePos);
                avatarT.SetRotation(m_originalRotation * m_avatarRelativeRot);
            }

            if (m_cameraTransform) {
                Transform camT(m_cameraTransform);
                camT.SetPosition(m_originalPosition + m_originalRotation * m_cameraRelativePos);
                camT.SetRotation(m_originalRotation * m_cameraRelativeRot);
            }
        }

        m_playerRoot = nullptr;
        m_forwardDir = nullptr;
        m_avatarRoot = nullptr;
        m_cameraTransform = nullptr;
        m_inputController = nullptr;
        m_hookInstalled = false;
        m_active = false;

        FLOG("[CapsuleRotation] Disabled");
    }

    void CapsuleRotationModule::OnUpdate() {
        if (!m_active || !m_playerRoot || !InRoom()) return;

        float dt = Time::GetDeltaTime();

        IL2CPP::Vector3 rot{};

        if (Input::GetKey(IL2CPP::KeyCode::UpArrow))    rot.x += 1.f;
        if (Input::GetKey(IL2CPP::KeyCode::DownArrow))  rot.x -= 1.f;
        if (Input::GetKey(IL2CPP::KeyCode::LeftArrow))  rot.y -= 1.f;
        if (Input::GetKey(IL2CPP::KeyCode::RightArrow)) rot.y += 1.f;

        if (!IsNoclipActive()) {
            if (Input::GetKey(IL2CPP::KeyCode::Q)) rot.z += 1.f;
            if (Input::GetKey(IL2CPP::KeyCode::E)) rot.z -= 1.f;
        }

        if (rot.x != 0.f || rot.y != 0.f || rot.z != 0.f) {
            float speed = m_rotationSpeed * dt;
            IL2CPP::Vector3 eulers{ rot.x * speed, rot.y * speed, rot.z * speed };

            Transform playerT(m_playerRoot);
            playerT.Rotate(eulers, IL2CPP::Space::World);

            if (m_forwardDir) {
                Transform fwdT(m_forwardDir);
                fwdT.Rotate(eulers, IL2CPP::Space::World);
            }

            if (m_avatarRoot) {
                Transform avatarT(m_avatarRoot);
                avatarT.Rotate(eulers, IL2CPP::Space::World);
            }

            if (m_cameraTransform) {
                Transform camT(m_cameraTransform);
                camT.Rotate(eulers, IL2CPP::Space::World);
            }
        }

        if (Input::GetKeyDown(IL2CPP::KeyCode::R)) {
            Transform playerT(m_playerRoot);
            playerT.SetRotation(m_originalRotation);
            if (m_forwardDir) {
                Transform fwdT(m_forwardDir);
                fwdT.SetRotation(m_originalRotation * m_fwdDirRelativeRot);
            }
            if (m_avatarRoot) {
                Transform avatarT(m_avatarRoot);
                avatarT.SetRotation(m_originalRotation * m_avatarRelativeRot);
            }
            if (m_cameraTransform) {
                Transform camT(m_cameraTransform);
                camT.SetRotation(m_originalRotation * m_cameraRelativeRot);
            }
            FLOG("[CapsuleRotation] Reset");
        }

        if (IsNoclipActive()) {
            Transform playerT(m_playerRoot);
            m_originalPosition = playerT.GetPosition();
        }
    }
    void CapsuleRotationModule::OnLateUpdate() {
        if (!m_active || !m_playerRoot || !InRoom()) return;

        Transform playerT(m_playerRoot);

        if (!IsNoclipActive()) {
            playerT.SetPosition(m_originalPosition);
        }

        IL2CPP::Quaternion pRot = playerT.GetRotation();
        IL2CPP::Vector3 playerPos = playerT.GetPosition();

        if (m_forwardDir) {
            Transform fwdT(m_forwardDir);
            fwdT.SetPosition(playerPos + pRot * m_fwdDirRelativePos);
            fwdT.SetRotation(pRot * m_fwdDirRelativeRot);
        }

        if (m_avatarRoot) {
            Transform avatarT(m_avatarRoot);
            avatarT.SetPosition(playerPos + pRot * m_avatarRelativePos);
            avatarT.SetRotation(pRot * m_avatarRelativeRot);
        }

        if (m_cameraTransform) {
            Transform camT(m_cameraTransform);
            camT.SetPosition(playerPos + pRot * m_cameraRelativePos);
            camT.SetRotation(pRot * m_cameraRelativeRot);
        }

        if (!IsNoclipActive()) {
            auto vrcPlayer = IL2CPP::VRChat::VRCPlayer::GetLocalPlayer();
            if (vrcPlayer.valid()) {
                auto go = vrcPlayer.GetGameObject();
                if (go.valid()) {
                    auto rb = go.GetComponentByName("Rigidbody");
                    if (rb.valid()) {
                        static auto setVel = MethodHandler::resolve("UnityEngine.Rigidbody", "set_velocity", 1);
                        static auto setAngVel = MethodHandler::resolve("UnityEngine.Rigidbody", "set_angularVelocity", 1);
                        IL2CPP::Vector3 zero{0.f, 0.f, 0.f};
                        if (setVel) { void* p[] = { &zero }; MethodHandler::invoke<void>(setVel, rb.raw(), p); }
                        if (setAngVel) { void* p[] = { &zero }; MethodHandler::invoke<void>(setAngVel, rb.raw(), p); }
                    }
                }
            }
        }
    }

    void CapsuleRotationModule::OnRender() {
        ImGui::SliderFloat("Rotation Speed", &m_rotationSpeed, 25.0f, 500.0f);
        ImGui::Text("Arrow Keys: Pitch/Yaw");
        if (!IsNoclipActive())
            ImGui::Text("Q/E: Roll");
        else
            ImGui::Text("Q/E: Roll (disabled - Noclip active)");
        ImGui::Text("R: Reset Rotation");
    }

    void CapsuleRotationModule::OnSceneLoad(int, int) {
        RemoveInputHook();
        SetMovementEnabled(true);

        m_active = false;
        m_playerRoot = nullptr;
        m_forwardDir = nullptr;
        m_avatarRoot = nullptr;
        m_cameraTransform = nullptr;
    }

}
