#pragma once
#include <cstddef>
#include <cstdint>

namespace UNIx { namespace EmbeddedIcons {

struct QMBackgroundEntry {
    const char* name;
    uint32_t resourceId;
};

constexpr size_t k_qm_background_count = 0;

inline const QMBackgroundEntry k_qm_backgrounds[] = {
    { nullptr, 0 }, // placeholder so array is non-empty for compilation
};

}} // namespace UNIx::EmbeddedIcons
