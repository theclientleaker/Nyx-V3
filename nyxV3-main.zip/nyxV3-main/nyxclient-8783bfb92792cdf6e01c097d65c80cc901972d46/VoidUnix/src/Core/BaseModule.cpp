#include <Core/BaseModule.hpp>
#include <Core/DashboardConsole/DashboardConsole.hpp>

namespace UNIx {

    BaseModule::BaseModule(std::string_view name,
                           std::string_view description,
                           uint32_t keybind,
                           std::string_view category)
        : m_name(name)
        , m_description(description)
        , m_category(category)
        , m_keybind(keybind)
    {}

    BaseModule::~BaseModule() = default;

    // ---- Static Local Player Helpers ----

    IL2CPP::VRChat::Player BaseModule::GetLocalPlayer() {
        return IL2CPP::VRChat::Player::GetLocalPlayer();
    }

    IL2CPP::VRChat::VRCPlayer BaseModule::GetLocalVRCPlayer() {
        return IL2CPP::VRChat::VRCPlayer::GetLocalPlayer();
    }

    IL2CPP::VRChat::VRCPlayerApi BaseModule::GetLocalPlayerApi() {
        return IL2CPP::VRChat::VRCPlayerApi::GetLocalPlayer();
    }

    bool BaseModule::InRoom() {
        return GetLocalPlayerApi() && GetLocalVRCPlayer();
    }

    // ---- Default no-op implementations ----

    void BaseModule::OnAwake(IL2CPP::VRChat::Player)              {}
    void BaseModule::OnPlayerJoin(IL2CPP::VRChat::Player)         {}
    void BaseModule::OnPlayerJoinComplete(IL2CPP::VRChat::Player) {}
    void BaseModule::OnPlayerLeave(IL2CPP::VRChat::Player)        {}

    void BaseModule::OnUpdate()      {}
    void BaseModule::OnLateUpdate()  {}
    void BaseModule::OnFixedUpdate() {}

    void BaseModule::OnSceneLoad(int, int)   {}
    void BaseModule::OnSceneUnload(int, int) {}

    void BaseModule::OnRender() {}
    void BaseModule::OnOverlay() {}

    bool BaseModule::OnEvent(uint32_t, uintptr_t, intptr_t) { return false; }

    void BaseModule::OnSetupQuickMenu(uint32_t, uint32_t) {}
    void BaseModule::OnEnable()  {}
    void BaseModule::OnDisable() {}

    void BaseModule::Toggle() {
        SetEnabled(!m_enabled.load(std::memory_order_relaxed));
    }

    void BaseModule::SetEnabled(bool enabled) {
        m_enabled.store(enabled, std::memory_order_relaxed);
    }

    void BaseModule::ProcessPendingToggle() {
        bool current = m_enabled.load(std::memory_order_relaxed);
        if (current == m_committedEnabled) return;
        m_committedEnabled = current;
        if (m_committedEnabled) {
            OnEnable();
            DashboardConsole::Get().AddLog(
                "[NYX]: " + m_name + " Enabled",
                DashboardConsole::LogColor::Enabled);
        } else {
            OnDisable();
            DashboardConsole::Get().AddLog(
                "[NYX]: " + m_name + " Disabled",
                DashboardConsole::LogColor::Disabled);
        }
    }

} // namespace UNIx
