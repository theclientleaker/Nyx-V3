#include <Modules/Movement/Rotator/PlayerRotatorModule.hpp>
#include <Bootstrap.Module/include/VRChat/VRCPlayerApi.hpp>
#include <Bootstrap.Module/include/bootstrap_module.hpp>
#include <Core/QuickMenuEx.hpp>
#include <Core/Globals.hpp>

namespace UNIx {

    PlayerRotatorModule* PlayerRotatorModule::s_instance = nullptr;

    void __cdecl PlayerRotatorModule::QmRotXCb(uint32_t, float val) { if (s_instance) s_instance->m_rotX = val; }
    void __cdecl PlayerRotatorModule::QmRotYCb(uint32_t, float val) { if (s_instance) s_instance->m_rotY = val; }
    void __cdecl PlayerRotatorModule::QmRotZCb(uint32_t, float val) { if (s_instance) s_instance->m_rotZ = val; }

    void PlayerRotatorModule::OnSetupQuickMenu(uint32_t moduleId, uint32_t categoryPageId) {
        s_instance = this;
        auto& qmEx = QuickMenuEx::Get();

        uint32_t fold = qmEx.add_foldout(moduleId, categoryPageId, "Rotator", false, true);
        qmEx.add_slider(moduleId, fold, "X (Pitch)", -180.0f, 180.0f, m_rotX,
            QmRotXCb, "rotator_x", "");
        qmEx.add_slider(moduleId, fold, "Y (Yaw)", -180.0f, 180.0f, m_rotY,
            QmRotYCb, "rotator_y", "");
        qmEx.add_slider(moduleId, fold, "Z (Roll)", -180.0f, 180.0f, m_rotZ,
            QmRotZCb, "rotator_z", "");
    }

    void PlayerRotatorModule::OnUpdate() {
        auto api = GetLocalPlayerApi();
        if (!api.valid()) return;

        IL2CPP::Vector3 pos = api.GetPosition();
        IL2CPP::Quaternion rot = IL2CPP::Quaternion().Euler(m_rotX, m_rotY, m_rotZ);

        api.TeleportTo(pos, rot, IL2CPP::VRChat::SpawnOrientation::Default, true);
    }

} // namespace UNIx
