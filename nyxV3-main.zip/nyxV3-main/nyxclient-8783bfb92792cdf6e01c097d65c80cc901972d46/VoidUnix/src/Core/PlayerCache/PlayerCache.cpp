#include <Core/PlayerCache/PlayerCache.hpp>
#include <Core/Globals.hpp>
#include <Core/FileLog/FileLog.hpp>

namespace UNIx {

    void PlayerCache::RebuildIndex() {
        m_idIndex.clear();
        m_idIndex.reserve(m_players->size());
        for (size_t i = 0; i < m_players->size(); ++i)
            m_idIndex[(*m_players)[i].playerId] = i;
    }

    void PlayerCache::OnPlayerJoinComplete(IL2CPP::VRChat::Player player) {
        if (!player) return;

        auto api = player.GetVRCPlayerApi();
        if (!api) return;

        auto user = player.GetAPIUser();

        PlayerEntry entry;
        entry.playerId = api.GetPlayerId();
        entry.displayName = api.GetDisplayName();
        entry.isVR = api.IsUserInVR();
        entry.isMaster = api.IsMaster();
        entry.isLocal = api.IsLocal();

        if (user.valid()) {
            entry.userId = user.GetId();
            entry.isFriend = user.GetIsFriend();
            entry.isQuest = user.GetIsOnMobile();
            entry.rank = user.GetPlayerRank();
        }

        std::lock_guard lock(m_mutex);

        auto it = m_idIndex.find(entry.playerId);
        if (it != m_idIndex.end()) {
            auto next = std::make_shared<std::vector<PlayerEntry>>(*m_players);
            (*next)[it->second] = std::move(entry);
            m_players = std::move(next);
            return;
        }

        if (!entry.userId.empty()) {
            for (size_t i = 0; i < m_players->size(); ++i) {
                if ((*m_players)[i].userId == entry.userId) {
                    auto next = std::make_shared<std::vector<PlayerEntry>>(*m_players);
                    (*next)[i] = std::move(entry);
                    m_players = std::move(next);
                    RebuildIndex();
                    return;
                }
            }
        }

        auto next = std::make_shared<std::vector<PlayerEntry>>(*m_players);
        next->push_back(std::move(entry));
        m_players = std::move(next);
        RebuildIndex();
    }

    void PlayerCache::OnPlayerLeave(IL2CPP::VRChat::Player player) {
        if (!player) return;
        auto api = player.GetVRCPlayerApi();
        if (!api) return;
        int id = api.GetPlayerId();

        std::lock_guard lock(m_mutex);
        auto it = m_idIndex.find(id);
        if (it == m_idIndex.end()) return;

        auto next = std::make_shared<std::vector<PlayerEntry>>(*m_players);
        std::erase_if(*next, [id](const PlayerEntry& e) { return e.playerId == id; });
        m_players = std::move(next);
        RebuildIndex();
    }

    void PlayerCache::OnSceneLoad(int, int) {
        std::lock_guard lock(m_mutex);
        m_players = std::make_shared<std::vector<PlayerEntry>>();
        m_idIndex.clear();
    }

    PlayerSnapshot PlayerCache::GetPlayers() const {
        std::lock_guard lock(m_mutex);
        return m_players;
    }

    std::optional<PlayerEntry> PlayerCache::FindByPlayerId(int id) const {
        std::lock_guard lock(m_mutex);
        auto it = m_idIndex.find(id);
        if (it != m_idIndex.end())
            return (*m_players)[it->second];
        return std::nullopt;
    }

    size_t PlayerCache::GetPlayerCount() const {
        std::lock_guard lock(m_mutex);
        return m_players->size();
    }

} // namespace UNIx
