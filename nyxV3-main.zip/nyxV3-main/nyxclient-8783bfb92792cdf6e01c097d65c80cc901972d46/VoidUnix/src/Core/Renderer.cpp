#include <Core/Renderer.hpp>
#include <Core/Theme.hpp>

#include <ThirdParty/imgui/imgui.h>
#include <ThirdParty/imgui/imgui_internal.h>
#include <ThirdParty/imgui/imgui_impl_dx11.h>
#include <ThirdParty/imgui/imgui_impl_win32.h>

namespace UNIx {

    void Renderer::D3D11StateBackup::Save(ID3D11DeviceContext* ctx) {
        ctx->OMGetRenderTargets(1, &rtv, &dsv);
        numViewports = D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE;
        ctx->RSGetViewports(&numViewports, viewports);
        ctx->OMGetBlendState(&blendState, blendFactor, &sampleMask);
        ctx->OMGetDepthStencilState(&depthStencilState, &stencilRef);
        ctx->RSGetState(&rasterizerState);
    }

    void Renderer::D3D11StateBackup::Restore(ID3D11DeviceContext* ctx) {
        ctx->OMSetRenderTargets(1, &rtv, dsv);
        ctx->RSSetViewports(numViewports, viewports);
        ctx->OMSetBlendState(blendState, blendFactor, sampleMask);
        ctx->OMSetDepthStencilState(depthStencilState, stencilRef);
        ctx->RSSetState(rasterizerState);

        if (rtv)              rtv->Release();
        if (dsv)              dsv->Release();
        if (blendState)       blendState->Release();
        if (depthStencilState) depthStencilState->Release();
        if (rasterizerState)  rasterizerState->Release();
    }

    void Renderer::Initialize(const Hooking::UiRenderContext* ctx) {
        if (s_initialized) return;
        if (!ctx) return;
        if (!ctx->device || !ctx->context || !ctx->window || !ctx->swap_chain) return;

        s_device    = static_cast<ID3D11Device*>(ctx->device);
        s_context   = static_cast<ID3D11DeviceContext*>(ctx->context);
        s_swapChain = static_cast<IDXGISwapChain*>(ctx->swap_chain);
        s_window    = static_cast<HWND>(ctx->window);

        ImGui::CreateContext();

        ImGuiIO& io = ImGui::GetIO();
        io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
        ImGui::GetCurrentContext()->ConfigNavEnableTabbing = false;
        io.IniFilename = nullptr;

        InitializeFonts(io);
        if (g_fontBig) io.FontDefault = g_fontBig;

        ApplyUNIxTheme();

        ImGui_ImplWin32_Init(s_window);
        ImGui_ImplDX11_Init(s_device, s_context);

        s_initialized = true;
    }

    void Renderer::BeginFrame() {
        if (!s_initialized) return;

        // Ensure render target exists
        if (!s_renderTarget) {
            ID3D11Texture2D* backBuffer = nullptr;
            s_swapChain->GetBuffer(0, __uuidof(ID3D11Texture2D),
                                   reinterpret_cast<void**>(&backBuffer));
            if (backBuffer) {
                s_device->CreateRenderTargetView(backBuffer, nullptr, &s_renderTarget);
                backBuffer->Release();
            }
        }

        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();
    }

    void Renderer::EndFrame() {
        if (!s_initialized) return;

        ImGui::Render();

        D3D11StateBackup backup;
        backup.Save(s_context);

        s_context->OMSetRenderTargets(1, &s_renderTarget, nullptr);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());

        backup.Restore(s_context);
    }

    void Renderer::OnResize() {
        if (s_renderTarget) {
            s_renderTarget->Release();
            s_renderTarget = nullptr;
        }
    }

    void Renderer::Shutdown() {
        if (!s_initialized) return;
        ImGui_ImplDX11_Shutdown();
        ImGui_ImplWin32_Shutdown();
        ImGui::DestroyContext();

        if (s_renderTarget) {
            s_renderTarget->Release();
            s_renderTarget = nullptr;
        }

        s_device    = nullptr;
        s_context   = nullptr;
        s_swapChain = nullptr;
        s_window    = nullptr;
        s_initialized = false;
    }

    bool Renderer::IsInitialized() {
        return s_initialized;
    }

} // namespace UNIx
