#pragma once

#include <string>
#include <functional>
#include <mutex>
#include <thread>
#include <atomic>
#include <queue>
#include <condition_variable>

namespace UNIx {

    enum class ApiAuth { None, Client, Admin };

    class ApiClient {
    public:
        static ApiClient& Get();

        void Start();
        void Stop();

        std::string Get(const std::string& path, ApiAuth auth = ApiAuth::None);
        std::string Post(const std::string& path, const std::string& body = "", ApiAuth auth = ApiAuth::Client);
        std::string Delete(const std::string& path, ApiAuth auth = ApiAuth::Admin);

        using Callback = std::function<void(const std::string&)>;
        void GetAsync(const std::string& path, Callback cb = nullptr, ApiAuth auth = ApiAuth::None);
        void PostAsync(const std::string& path, const std::string& body = "", Callback cb = nullptr, ApiAuth auth = ApiAuth::Client);
        void DeleteAsync(const std::string& path, Callback cb = nullptr, ApiAuth auth = ApiAuth::Admin);

        using WsMessageCallback = std::function<void(const std::string&)>;
        void SetWebSocketHandler(WsMessageCallback cb);
        void ConnectWebSocket(const std::string& userId);
        void DisconnectWebSocket();
        bool IsWebSocketConnected() const { return m_wsConnected; }
        void WebSocketSend(const std::string& message);

    private:
        ApiClient() = default;
        ~ApiClient();

        void WorkerLoop();
        bool EnsureConnected();
        std::string DoRequest(const wchar_t* method, const std::string& path, const std::string& body, ApiAuth auth);

        void WebSocketLoop(std::string userId);
        bool DoWebSocketConnect(const std::string& userId);

        struct QueuedRequest {
            const wchar_t* method;
            std::string path;
            std::string body;
            ApiAuth auth;
            Callback callback;
        };

        std::mutex m_queueMutex;
        std::mutex m_connectMutex;
        std::condition_variable m_cv;
        std::queue<QueuedRequest> m_queue;

        void* m_hSession = nullptr;
        void* m_hConnect = nullptr;

        std::thread m_thread;
        std::atomic<bool> m_running{false};

        void* m_hWebSocket = nullptr;
        void* m_hWsConnect = nullptr;
        std::mutex m_wsMutex;
        std::atomic<bool> m_wsConnected{false};
        std::atomic<bool> m_wsRunning{false};
        std::thread m_wsThread;
        WsMessageCallback m_wsHandler;
    };

} // namespace UNIx
