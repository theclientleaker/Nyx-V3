#pragma once
#include <Core/BaseModule.hpp>
#include <IL2CPP.Common/il2cpp_types.hpp>
#include <vector>
#include <string>

namespace UNIx {

    class NoclipModule;

    class CapsuleRotationModule : public BaseModule {
    public:
        CapsuleRotationModule()
            : BaseModule("Capsule Rotation", "Rotate player capsule with arrow keys (Ctrl+X)", 0x10000 | 'X', "Movement") {}

        void OnEnable() override;
        void OnDisable() override;
        void OnUpdate() override;
        void OnLateUpdate() override;
        void OnRender() override;
        void OnSceneLoad(int scene, int loadMode) override;
        void OnSetupQuickMenu(uint32_t moduleId, uint32_t categoryPageId) override;

        bool IsActive() const { return m_active; }
        IL2CPP::Quaternion GetAppliedRotation() const;

    private:
        bool IsNoclipActive() const;
        void InstallInputHook();
        void RemoveInputHook();
        void SetMovementEnabled(bool enabled);
        void StoreComponentStates();

        static void __cdecl QmRotSpeedCb(uint32_t id, float val);

        void* m_playerRoot = nullptr;
        void* m_forwardDir = nullptr;
        void* m_avatarRoot = nullptr;
        void* m_cameraTransform = nullptr;
        void* m_inputController = nullptr;

        IL2CPP::Vector3    m_originalPosition{};
        IL2CPP::Quaternion m_originalRotation{};
        IL2CPP::Vector3    m_fwdDirRelativePos{};
        IL2CPP::Quaternion m_fwdDirRelativeRot{};
        IL2CPP::Vector3    m_avatarRelativePos{};
        IL2CPP::Quaternion m_avatarRelativeRot{};
        IL2CPP::Vector3    m_cameraRelativePos{};
        IL2CPP::Quaternion m_cameraRelativeRot{};

        float m_rotationSpeed = 100.f;
        bool  m_active = false;
        bool  m_hookInstalled = false;

        bool m_origCharControllerEnabled = true;
        bool m_origRigidbodyKinematic = false;

        NoclipModule* m_noclipModule = nullptr;

        static CapsuleRotationModule* s_instance;
        static bool __cdecl PrefixBlockInput(void* thisPtr);
    };

} // namespace UNIx
