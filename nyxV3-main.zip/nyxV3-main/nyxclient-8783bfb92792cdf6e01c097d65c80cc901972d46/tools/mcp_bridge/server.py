import socket
import struct
import json
import sys
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("VoidUnix Debug Bridge")

BRIDGE_HOST = "127.0.0.1"
BRIDGE_PORT = 29150

_sock: socket.socket | None = None
_next_id = 1


def _connect():
    global _sock
    if _sock is not None:
        return
    _sock = socket.create_connection((BRIDGE_HOST, BRIDGE_PORT), timeout=5)
    _sock.settimeout(15)


def _disconnect():
    global _sock
    if _sock is not None:
        try:
            _sock.close()
        except Exception:
            pass
        _sock = None


def _send_command(method: str, **params) -> dict:
    global _next_id, _sock

    try:
        _connect()
    except Exception as e:
        _sock = None
        return {"error": f"Connection failed: {e}"}

    msg = {"id": _next_id, "method": method, **params}
    _next_id += 1

    try:
        data = json.dumps(msg).encode("utf-8")
        _sock.sendall(struct.pack("<I", len(data)))
        _sock.sendall(data)

        length_buf = _recv_all(4)
        if length_buf is None:
            raise ConnectionError("Failed to read response length")
        resp_len = struct.unpack("<I", length_buf)[0]

        resp_buf = _recv_all(resp_len)
        if resp_buf is None:
            raise ConnectionError("Failed to read response body")

        return json.loads(resp_buf.decode("utf-8"))
    except Exception as e:
        _disconnect()
        return {"error": str(e)}


def _recv_all(n: int) -> bytes | None:
    buf = b""
    while len(buf) < n:
        chunk = _sock.recv(n - len(buf))
        if not chunk:
            return None
        buf += chunk
    return buf


def _format_result(resp: dict) -> str:
    if "error" in resp:
        return f"Error: {resp['error']}"
    result = resp.get("result", resp)
    return json.dumps(result, indent=2)


# ============================================================
#  Core
# ============================================================

@mcp.tool()
def ping() -> str:
    """Check if the VoidUnix DLL debug bridge is running."""
    return _format_result(_send_command("ping"))


# ============================================================
#  Scene / GameObjects
# ============================================================

@mcp.tool()
def list_gameobjects(path: str = "/", limit: int = 100) -> str:
    """List GameObjects in the Unity scene. Use '/' for root objects, or a path like 'Canvas/Panel' to list children."""
    return _format_result(_send_command("list_gameobjects", path=path, limit=limit))


@mcp.tool()
def inspect_gameobject(path: str = "") -> str:
    """Inspect a GameObject by path. Returns components, position, rotation, scale."""
    return _format_result(_send_command("inspect_gameobject", path=path))


@mcp.tool()
def search_scene(pattern: str = "", limit: int = 50) -> str:
    """Search all GameObjects in the scene by name substring. Returns matching objects with their full paths."""
    return _format_result(_send_command("search_scene", pattern=pattern, limit=limit))


@mcp.tool()
def set_gameobject_active(path: str = "", active: bool = True) -> str:
    """Enable or disable a GameObject by path."""
    return _format_result(_send_command("set_gameobject_active", path=path, active=active))


@mcp.tool()
def get_hierarchy(path: str = "", depth: int = 3, limit: int = 200) -> str:
    """Get the recursive child hierarchy of a GameObject. Returns a tree structure up to the specified depth."""
    return _format_result(_send_command("get_hierarchy", path=path, depth=depth, limit=limit))


@mcp.tool()
def find_objects_of_type(type: str = "", limit: int = 50) -> str:
    """Find all objects of a specific IL2CPP type (e.g. 'VRC.Udon.UdonBehaviour', 'UnityEngine.AudioSource'). Returns names and paths."""
    return _format_result(_send_command("find_objects_of_type", type=type, limit=limit))


@mcp.tool()
def get_materials(path: str = "") -> str:
    """Get material info (shader, color, render queue) from Renderers on a GameObject."""
    return _format_result(_send_command("get_materials", path=path))


@mcp.tool()
def inspect_component(path: str = "", class_name: str = "", index: int = -1) -> str:
    """Inspect a specific component on a GameObject. Reads all field names, types, and values. Specify either class_name (e.g. 'VRCPlayer') or index from inspect_gameobject."""
    return _format_result(_send_command("inspect_component", path=path, class_name=class_name, index=index))


# ============================================================
#  IL2CPP Reflection
# ============================================================

@mcp.tool()
def find_class(query: str = "", limit: int = 50) -> str:
    """Search IL2CPP classes by name substring. Searches across all loaded assemblies."""
    return _format_result(_send_command("find_class", query=query, limit=limit))


@mcp.tool()
def filter_class(
    method_return_type: str = "",
    field_type: str = "",
    field_static: bool | None = None,
    method_virtual: bool | None = None,
    method_sealed: bool | None = None,
    method_param_count: int = -1,
    parent: str = "",
    assembly: str = "Assembly-CSharp",
    limit: int = 20,
) -> str:
    """Search for IL2CPP classes by method/field characteristics. Useful for finding obfuscated classes.
    - method_return_type: substring match on any method's return type (e.g. 'ReactiveProperty')
    - field_type: substring match on any field's type (e.g. 'ReactiveProperty')
    - field_static: if true, only match static fields
    - method_virtual/method_sealed: filter method modifiers
    - method_param_count: exact param count filter (-1 = any)
    - parent: substring match on parent class name
    """
    params: dict = {"assembly": assembly, "limit": limit}
    if method_return_type:
        params["method_return_type"] = method_return_type
    if field_type:
        params["field_type"] = field_type
    if field_static is not None:
        params["field_static"] = field_static
    if method_virtual is not None:
        params["method_virtual"] = method_virtual
    if method_sealed is not None:
        params["method_sealed"] = method_sealed
    if method_param_count >= 0:
        params["method_param_count"] = method_param_count
    if parent:
        params["parent"] = parent
    return _format_result(_send_command("filter_class", **params))


@mcp.tool()
def inspect_class(name: str = "") -> str:
    """Inspect an IL2CPP class by full name (e.g. 'UnityEngine.GameObject'). Returns fields, methods, properties with raw/deobfuscated names, offsets, and modifiers."""
    return _format_result(_send_command("inspect_class", name=name))


@mcp.tool()
def call_method(class_name: str = "", method_name: str = "", args: list[str] | None = None) -> str:
    """Call a static IL2CPP method. Only static methods with primitive params (int, float, bool, string) are supported. Args is an array of string values."""
    return _format_result(_send_command("call_method", class_name=class_name, method_name=method_name, args=args or []))


@mcp.tool()
def read_field(class_name: str = "", field_name: str = "", address: str = "") -> str:
    """Read an IL2CPP field value. For static fields, omit address. For instance fields, provide the object address as hex (e.g. '0x1234')."""
    return _format_result(_send_command("read_field", class_name=class_name, field_name=field_name, address=address))


@mcp.tool()
def set_field(class_name: str = "", field_name: str = "", value: str = "", address: str = "") -> str:
    """Write an IL2CPP field value. Supports bool, int, float, string types. For instance fields, provide object address."""
    return _format_result(_send_command("set_field", class_name=class_name, field_name=field_name, value=value, address=address))


# ============================================================
#  Players
# ============================================================

@mcp.tool()
def list_players() -> str:
    """List all players currently in the VRChat room."""
    return _format_result(_send_command("list_players"))


@mcp.tool()
def get_player_info(player_id: int = -1) -> str:
    """Get detailed info about a player: position, rotation, velocity, movement speeds, avatar height. Use -1 for local player."""
    return _format_result(_send_command("get_player_info", player_id=player_id))


@mcp.tool()
def get_avatar_info(player_id: int = -1) -> str:
    """Get avatar info for a player: avatar ID, image URLs, eye height, platform. Use -1 for local player."""
    return _format_result(_send_command("get_avatar_info", player_id=player_id))


@mcp.tool()
def teleport(x: float = 0, y: float = 0, z: float = 0, rx: float = 0, ry: float = 0, rz: float = 0, rw: float = 1) -> str:
    """Teleport the local player to a position. Rotation is a quaternion (rx,ry,rz,rw)."""
    return _format_result(_send_command("teleport", x=x, y=y, z=z, rx=rx, ry=ry, rz=rz, rw=rw))


@mcp.tool()
def set_movement(walk_speed: float = -1, run_speed: float = -1, strafe_speed: float = -1, jump_impulse: float = -1, gravity: float = -1) -> str:
    """Set local player movement parameters. Only specified values (>= 0) are applied. Returns current values after changes."""
    params = {}
    if walk_speed >= 0:
        params["walk_speed"] = walk_speed
    if run_speed >= 0:
        params["run_speed"] = run_speed
    if strafe_speed >= 0:
        params["strafe_speed"] = strafe_speed
    if jump_impulse >= 0:
        params["jump_impulse"] = jump_impulse
    if gravity >= 0:
        params["gravity"] = gravity
    return _format_result(_send_command("set_movement", **params))


# ============================================================
#  World / Network
# ============================================================

@mcp.tool()
def get_world_info() -> str:
    """Get current world info: world ID, instance ID, player count, network state."""
    return _format_result(_send_command("get_world_info"))


@mcp.tool()
def get_network_info() -> str:
    """Get network state: settled, clogged, master player, server time, instance ownership."""
    return _format_result(_send_command("get_network_info"))


@mcp.tool()
def get_photon_info(path: str = "") -> str:
    """Get PhotonView info from a GameObject: view ID, owner actor number, creator actor number."""
    return _format_result(_send_command("get_photon_info", path=path))


# ============================================================
#  Udon
# ============================================================

@mcp.tool()
def list_udon_behaviours(limit: int = 100) -> str:
    """Find all UdonBehaviour components in the scene. Returns GameObject names and paths."""
    return _format_result(_send_command("list_udon_behaviours", limit=limit))


@mcp.tool()
def get_udon_variables(path: str = "", names: list[str] | None = None) -> str:
    """Read Udon program variables from an UdonBehaviour on a GameObject. Provide a list of variable names to read."""
    return _format_result(_send_command("get_udon_variables", path=path, names=names or []))


@mcp.tool()
def send_udon_event(path: str = "", event: str = "") -> str:
    """Send a custom Udon event to an UdonBehaviour on a GameObject."""
    return _format_result(_send_command("send_udon_event", path=path, event=event))


# ============================================================
#  Physics
# ============================================================

@mcp.tool()
def raycast(origin_x: float = 0, origin_y: float = 0, origin_z: float = 0,
            direction_x: float = 0, direction_y: float = -1, direction_z: float = 0,
            max_distance: float = 1000, layer_mask: int = -1) -> str:
    """Cast a physics ray. Returns hit point, normal, distance if something was hit."""
    return _format_result(_send_command("raycast",
        origin_x=origin_x, origin_y=origin_y, origin_z=origin_z,
        direction_x=direction_x, direction_y=direction_y, direction_z=direction_z,
        max_distance=max_distance, layer_mask=layer_mask))


# ============================================================
#  Animation
# ============================================================

@mcp.tool()
def list_animations(path: str = "") -> str:
    """Get Animator info from a GameObject: parameters (with current values), speed, humanoid state."""
    return _format_result(_send_command("list_animations", path=path))


# ============================================================
#  Debug / Info
# ============================================================

@mcp.tool()
def read_log(lines: int = 50) -> str:
    """Read the last N lines from the VoidUnix debug log file."""
    return _format_result(_send_command("read_log", lines=lines))


@mcp.tool()
def send_log(message: str = "") -> str:
    """Write a message to the VoidUnix debug log. Shows up as [MCP] prefix."""
    return _format_result(_send_command("send_log", message=message))


@mcp.tool()
def get_screen_info() -> str:
    """Get screen dimensions, DPI, and fullscreen state."""
    return _format_result(_send_command("get_screen_info"))


@mcp.tool()
def get_camera_info() -> str:
    """Get main camera info: FOV, clip planes, position, rotation."""
    return _format_result(_send_command("get_camera_info"))


@mcp.tool()
def set_camera(fov: float = -1, near_clip: float = -1, far_clip: float = -1) -> str:
    """Set main camera properties. Only specified values (>= 0) are applied."""
    params = {}
    if fov >= 0:
        params["fov"] = fov
    if near_clip >= 0:
        params["near_clip"] = near_clip
    if far_clip >= 0:
        params["far_clip"] = far_clip
    return _format_result(_send_command("set_camera", **params))


@mcp.tool()
def get_time_info() -> str:
    """Get Unity time info: time, deltaTime, timeScale, frameCount, realtimeSinceStartup."""
    return _format_result(_send_command("get_time_info"))


@mcp.tool()
def get_audio_sources(limit: int = 50, playing_only: bool = False) -> str:
    """List AudioSource components in the scene. Optionally filter to only playing sources."""
    return _format_result(_send_command("get_audio_sources", limit=limit, playing_only=playing_only))


# ============================================================
#  Module Management
# ============================================================

@mcp.tool()
def list_modules() -> str:
    """List all registered VoidUnix modules with their enabled state, category, keybind, and description."""
    return _format_result(_send_command("list_modules"))


@mcp.tool()
def toggle_module(name: str = "", enabled: str = "") -> str:
    """Toggle a module on/off by name. If enabled is 'true'/'false', sets that state. If omitted, toggles current state."""
    params = {"name": name}
    if enabled:
        params["enabled"] = enabled
    return _format_result(_send_command("toggle_module", **params))


@mcp.tool()
def get_config(key: str = "", type: str = "string", default: str = "") -> str:
    """Read a persistent config value. Type can be 'int', 'float', 'bool', or 'string'."""
    return _format_result(_send_command("get_config", key=key, type=type, default=default))


@mcp.tool()
def set_config(key: str = "", value: str = "", type: str = "string") -> str:
    """Write a persistent config value. Type can be 'int', 'float', 'bool', or 'string'. Saves to disk immediately."""
    return _format_result(_send_command("set_config", key=key, value=value, type=type))


# ============================================================
#  Player Actions
# ============================================================

@mcp.tool()
def player_action(action: str = "", player_id: int = -1, value: float | str | bool = None,
                  x: float = 0, y: float = 0, z: float = 0,
                  r: float = 1, g: float = 1, b: float = 1, a: float = 1,
                  bone: int = 0, tracking_type: int = 0, spawn_index: int = -1) -> str:
    """Perform an action on a player. Use player_id=-1 for local player.

    Actions:
    - Voice: set_voice_gain, set_voice_distance_near, set_voice_distance_far, set_voice_volumetric_radius, set_voice_lowpass, get_voice_info
    - Avatar audio: set_avatar_audio_gain, set_avatar_audio_far_radius, set_avatar_audio_near_radius, set_avatar_audio_volumetric_radius, set_avatar_audio_force_spatial, set_avatar_audio_custom_curve
    - Movement: immobilize (value=true/false), respawn, set_velocity (x,y,z), use_legacy_locomotion
    - Nameplate: set_nameplate_color (r,g,b,a), restore_nameplate_color, set_nameplate_visibility (value), restore_nameplate_visibility
    - Avatar: set_avatar_eye_height (value in meters), set_avatar_eye_height_multiplier, set_avatar_scaling_allowed
    - Interaction: enable_pickups (value=true/false)
    - Display: set_display_name (value=name)
    - Queries: get_bone_position (bone=HumanBodyBones int), get_bone_rotation (bone), get_tracking_data (tracking_type=0-4)
    """
    params = {"action": action, "player_id": player_id}
    if value is not None:
        params["value"] = value
    if x != 0: params["x"] = x
    if y != 0: params["y"] = y
    if z != 0: params["z"] = z
    if r != 1: params["r"] = r
    if g != 1: params["g"] = g
    if b != 1: params["b"] = b
    if a != 1: params["a"] = a
    if bone != 0: params["bone"] = bone
    if tracking_type != 0: params["tracking_type"] = tracking_type
    if spawn_index >= 0: params["spawn_index"] = spawn_index
    return _format_result(_send_command("player_action", **params))


@mcp.tool()
def teleport_to_player(target_player_id: int = -1, offset_x: float = 0, offset_y: float = 0, offset_z: float = 0) -> str:
    """Teleport local player to another player's position. Optional offset to avoid overlapping."""
    return _format_result(_send_command("teleport_to_player",
        target_player_id=target_player_id, offset_x=offset_x, offset_y=offset_y, offset_z=offset_z))


# ============================================================
#  Animator Control
# ============================================================

@mcp.tool()
def set_animator_param(path: str = "", name: str = "", type: str = "float", value: float | int | bool = 0, duration: float = 0.25) -> str:
    """Set an Animator parameter or control playback on a GameObject.

    Types: float, int, bool, trigger, reset_trigger, play (name=state), crossfade (name=state, duration), speed (value)
    """
    params = {"path": path, "name": name, "type": type}
    if type in ("float", "speed"):
        params["value"] = float(value)
    elif type == "int":
        params["value"] = int(value)
    elif type == "bool":
        params["value"] = bool(value)
    if type == "crossfade":
        params["duration"] = duration
    return _format_result(_send_command("set_animator_param", **params))


# ============================================================
#  Ownership
# ============================================================

@mcp.tool()
def take_ownership(path: str = "") -> str:
    """Take network ownership of a GameObject (Networking.SetOwner to local player)."""
    return _format_result(_send_command("take_ownership", path=path))


@mcp.tool()
def get_ownership(path: str = "") -> str:
    """Get the current network owner of a GameObject."""
    return _format_result(_send_command("get_ownership", path=path))


# ============================================================
#  Rigidbody / Physics
# ============================================================

@mcp.tool()
def set_rigidbody(path: str = "",
                  velocity_x: float = None, velocity_y: float = None, velocity_z: float = None,
                  angular_velocity_x: float = None, angular_velocity_y: float = None, angular_velocity_z: float = None,
                  mass: float = None, drag: float = None, angular_drag: float = None,
                  use_gravity: bool = None, is_kinematic: bool = None,
                  freeze_rotation: bool = None, detect_collisions: bool = None) -> str:
    """Set Rigidbody properties on a GameObject. Only specified values are applied. Returns current state after changes."""
    params = {"path": path}
    if velocity_x is not None:
        params["velocity_x"] = velocity_x
        params["velocity_y"] = velocity_y or 0
        params["velocity_z"] = velocity_z or 0
    if angular_velocity_x is not None:
        params["angular_velocity_x"] = angular_velocity_x
        params["angular_velocity_y"] = angular_velocity_y or 0
        params["angular_velocity_z"] = angular_velocity_z or 0
    if mass is not None: params["mass"] = mass
    if drag is not None: params["drag"] = drag
    if angular_drag is not None: params["angular_drag"] = angular_drag
    if use_gravity is not None: params["use_gravity"] = use_gravity
    if is_kinematic is not None: params["is_kinematic"] = is_kinematic
    if freeze_rotation is not None: params["freeze_rotation"] = freeze_rotation
    if detect_collisions is not None: params["detect_collisions"] = detect_collisions
    return _format_result(_send_command("set_rigidbody", **params))


@mcp.tool()
def add_force(path: str = "", x: float = 0, y: float = 0, z: float = 0,
              force_mode: int = 0, force_type: str = "force",
              force: float = 100, radius: float = 5, upwards_modifier: float = 0,
              pos_x: float = 0, pos_y: float = 0, pos_z: float = 0) -> str:
    """Apply force to a Rigidbody. force_type: 'force' (default), 'torque', 'at_position', 'explosion'.
    force_mode: 0=Force, 1=Acceleration, 2=Impulse, 5=VelocityChange.
    For explosion: x,y,z is center, 'force' is magnitude, 'radius' is range.
    For at_position: x,y,z is force, pos_x/y/z is application point."""
    return _format_result(_send_command("add_force",
        path=path, x=x, y=y, z=z, force_mode=force_mode, force_type=force_type,
        force=force, radius=radius, upwards_modifier=upwards_modifier,
        pos_x=pos_x, pos_y=pos_y, pos_z=pos_z))


# ============================================================
#  Transform
# ============================================================

@mcp.tool()
def set_transform(path: str = "", local: bool = False,
                  pos_x: float = None, pos_y: float = None, pos_z: float = None,
                  rot_x: float = None, rot_y: float = None, rot_z: float = None, rot_w: float = None,
                  scale_x: float = None, scale_y: float = None, scale_z: float = None,
                  look_at_x: float = None, look_at_y: float = None, look_at_z: float = None) -> str:
    """Set position, rotation, scale, or look-at on a GameObject's Transform. Only specified values are applied.
    Set local=True for local space. Returns current transform after changes."""
    params = {"path": path, "local": local}
    if pos_x is not None:
        params["pos_x"] = pos_x
        params["pos_y"] = pos_y or 0
        params["pos_z"] = pos_z or 0
    if rot_x is not None:
        params["rot_x"] = rot_x
        params["rot_y"] = rot_y or 0
        params["rot_z"] = rot_z or 0
        params["rot_w"] = rot_w if rot_w is not None else 1
    if scale_x is not None:
        params["scale_x"] = scale_x
        params["scale_y"] = scale_y if scale_y is not None else 1
        params["scale_z"] = scale_z if scale_z is not None else 1
    if look_at_x is not None:
        params["look_at_x"] = look_at_x
        params["look_at_y"] = look_at_y or 0
        params["look_at_z"] = look_at_z or 0
    return _format_result(_send_command("set_transform", **params))


# ============================================================
#  Network Udon
# ============================================================

@mcp.tool()
def send_network_udon_event(path: str = "", event: str = "", target: str = "All") -> str:
    """Send a networked Udon event. target: 'All' or 'Others'."""
    return _format_result(_send_command("send_network_udon_event", path=path, event=event, target=target))


@mcp.tool()
def set_udon_variable(path: str = "", name: str = "", value: str = "", type: str = "string") -> str:
    """Set an Udon program variable. type: 'int', 'float', 'bool', 'string'."""
    return _format_result(_send_command("set_udon_variable", path=path, name=name, value=value, type=type))


# ============================================================
#  World Navigation
# ============================================================

@mcp.tool()
def go_to_room(room_id: str = "") -> str:
    """Join a VRChat room by ID (e.g. 'wrld_xxx:12345~region(us)')."""
    return _format_result(_send_command("go_to_room", room_id=room_id))


# ============================================================
#  Batch Commands
# ============================================================

@mcp.tool()
def batch(commands: list[dict] = None) -> str:
    """Execute multiple commands in a single Unity frame. Each command needs a 'method' key plus its normal parameters.

    Example: [{"method": "teleport", "x": 0, "y": 5, "z": 0}, {"method": "set_movement", "walk_speed": 10}]
    Returns an array of results in the same order."""
    return _format_result(_send_command("batch", commands=commands or []))


# ============================================================
#  Input
# ============================================================

@mcp.tool()
def get_input(type: str = "mouse_position", key_code: int = 0, button: int = 0, axis_name: str = "") -> str:
    """Read Unity input state. type: 'mouse_position', 'mouse_scroll', 'mouse_button' (button=0-2), 'key' (key_code=KeyCode int), 'axis' (axis_name), 'any_key'."""
    params = {"type": type}
    if key_code != 0: params["key_code"] = key_code
    if button != 0: params["button"] = button
    if axis_name: params["axis_name"] = axis_name
    return _format_result(_send_command("get_input", **params))


# ============================================================
#  Time Scale
# ============================================================

@mcp.tool()
def set_time_scale(scale: float = 1.0) -> str:
    """Set Unity's Time.timeScale. 1.0 = normal, 0.5 = half speed, 2.0 = double speed, 0 = paused."""
    return _format_result(_send_command("set_time_scale", scale=scale))


# ============================================================
#  Object Lifecycle
# ============================================================

@mcp.tool()
def destroy_object(path: str = "", delay: float = 0) -> str:
    """Destroy a GameObject. Optional delay in seconds before destruction."""
    return _format_result(_send_command("destroy_object", path=path, delay=delay))


@mcp.tool()
def instantiate_object(path: str = "", pos_x: float = None, pos_y: float = None, pos_z: float = None) -> str:
    """Clone/instantiate a GameObject. Optionally set position. Returns clone name and address."""
    params = {"path": path}
    if pos_x is not None:
        params["pos_x"] = pos_x
        params["pos_y"] = pos_y or 0
        params["pos_z"] = pos_z or 0
    return _format_result(_send_command("instantiate_object", **params))


@mcp.tool()
def find_by_tag(tag: str = "", limit: int = 50) -> str:
    """Find all GameObjects with a specific tag (e.g. 'Player', 'Untagged'). Returns names and paths."""
    return _format_result(_send_command("find_by_tag", tag=tag, limit=limit))


# ============================================================
#  Component Enable/Disable
# ============================================================

@mcp.tool()
def set_component_enabled(path: str = "", class_name: str = "", index: int = -1, enabled: bool = True) -> str:
    """Enable or disable a specific component (Behaviour, Collider, Renderer) on a GameObject. Specify class_name or index."""
    params = {"path": path, "enabled": enabled}
    if class_name: params["class_name"] = class_name
    if index >= 0: params["index"] = index
    return _format_result(_send_command("set_component_enabled", **params))


# ============================================================
#  Layer
# ============================================================

@mcp.tool()
def set_layer(path: str = "", layer: int = 0, recursive: bool = False) -> str:
    """Set the layer (0-31) of a GameObject. Set recursive=True to apply to all children too."""
    return _format_result(_send_command("set_layer", path=path, layer=layer, recursive=recursive))


# ============================================================
#  Parent
# ============================================================

@mcp.tool()
def set_parent(path: str = "", parent_path: str = "", world_position_stays: bool = True) -> str:
    """Reparent a GameObject under another. Leave parent_path empty to unparent (move to root)."""
    return _format_result(_send_command("set_parent", path=path, parent_path=parent_path, world_position_stays=world_position_stays))


# ============================================================
#  World / Screen Projection
# ============================================================

@mcp.tool()
def world_to_screen(x: float = 0, y: float = 0, z: float = 0, screen_to_world: bool = False) -> str:
    """Convert world position to screen coordinates (or reverse with screen_to_world=True). Returns x, y, z and whether the point is behind the camera."""
    return _format_result(_send_command("world_to_screen", x=x, y=y, z=z, screen_to_world=screen_to_world))


# ============================================================
#  Material
# ============================================================

@mcp.tool()
def set_material(path: str = "", r: float = None, g: float = None, b: float = None, a: float = None,
                 render_queue: int = None) -> str:
    """Set material properties on a GameObject's Renderer. Set r,g,b,a for color, render_queue for sorting order. Returns current material state."""
    params = {"path": path}
    if r is not None:
        params["r"] = r
        params["g"] = g if g is not None else 1
        params["b"] = b if b is not None else 1
        params["a"] = a if a is not None else 1
    if render_queue is not None:
        params["render_queue"] = render_queue
    return _format_result(_send_command("set_material", **params))


# ============================================================
#  Audio Control
# ============================================================

@mcp.tool()
def audio_control(path: str = "", action: str = "play", value: float | bool = None) -> str:
    """Control an AudioSource on a GameObject.
    Actions: play, stop, pause, unpause, set_volume (0-1), set_pitch, set_loop (bool), set_mute (bool), set_spatial_blend (0=2D, 1=3D), set_time (seek position)."""
    params = {"path": path, "action": action}
    if value is not None:
        params["value"] = value
    return _format_result(_send_command("audio_control", **params))


# ============================================================
#  Overlap Sphere
# ============================================================

@mcp.tool()
def overlap_sphere(x: float = 0, y: float = 0, z: float = 0, radius: float = 5,
                   layer_mask: int = -1, limit: int = 50) -> str:
    """Find all colliders within a sphere. Returns names, paths, and positions of nearby objects. Useful for finding interactive objects near a point."""
    return _format_result(_send_command("overlap_sphere",
        x=x, y=y, z=z, radius=radius, layer_mask=layer_mask, limit=limit))


# ============================================================
#  Screen To Ray
# ============================================================

@mcp.tool()
def screen_to_ray(x: float = 0, y: float = 0, max_distance: float = 1000, layer_mask: int = -1) -> str:
    """Cast a ray from screen coordinates (pixel x,y) into the world. Returns the ray origin/direction and what it hits (GameObject name, path, layer, hit point). Essential for click-targeting."""
    return _format_result(_send_command("screen_to_ray", x=x, y=y, max_distance=max_distance, layer_mask=layer_mask))


# ============================================================
#  Get All Bones
# ============================================================

@mcp.tool()
def get_all_bones(player_id: int = -1) -> str:
    """Get all 19 bone positions and rotations for a player in one call. Use player_id=-1 for local player. Returns Hips through RightHand with position {x,y,z} and rotation {x,y,z,w}."""
    return _format_result(_send_command("get_all_bones", player_id=player_id))


# ============================================================
#  Set Shader
# ============================================================

@mcp.tool()
def set_shader(path: str = "", shader: str = "") -> str:
    """Change the shader on a GameObject's material. Common shaders: 'Standard', 'Unlit/Color', 'Unlit/Transparent', 'Sprites/Default'. Useful for chams/wallhack effects."""
    return _format_result(_send_command("set_shader", path=path, shader=shader))


# ============================================================
#  Get Player By Name
# ============================================================

@mcp.tool()
def get_player_by_name(name: str = "") -> str:
    """Find players by display name (case-insensitive substring match). Returns matching players with playerId, userId, and status flags."""
    return _format_result(_send_command("get_player_by_name", name=name))


if __name__ == "__main__":
    mcp.run(transport="stdio")
