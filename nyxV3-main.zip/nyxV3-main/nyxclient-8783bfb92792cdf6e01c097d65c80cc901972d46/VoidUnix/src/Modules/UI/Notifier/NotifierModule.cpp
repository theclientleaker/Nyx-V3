#include <Modules/UI/Notifier/NotifierModule.hpp>
#include <Core/ModuleManager.hpp>
#include <Core/QuickMenuEx.hpp>
#include <Core/FileLog/FileLog.hpp>
#include <Core/Globals.hpp>

#include <IL2CPP.Module/include/il2cpp_module.hpp>
#include <IL2CPP.Module/include/Unity/GameObject.hpp>
#include <IL2CPP.Module/include/Unity/Object.hpp>
#include <IL2CPP.Module/include/Unity/AudioSource.hpp>
#include <IL2CPP.Module/include/Unity/AudioClip.hpp>
#include <IL2CPP.Module/include/Reflection.hpp>
#include <IL2CPP.Module/include/MethodHandler.hpp>
#include <IL2CPP.Module/include/ManagedObject.hpp>

#include <Bootstrap.Module/include/VRChat/Player.hpp>
#include <Bootstrap.Module/include/VRChat/VRCPlayerApi.hpp>
#include <Bootstrap.Module/include/VRChat/APIUser.hpp>

#define STB_VORBIS_HEADER_ONLY
#include <ThirdParty/stb/stb_vorbis.c>

#include <filesystem>
#include <cstring>
#include <vector>

namespace UNIx {

using namespace IL2CPP::Module;
using namespace IL2CPP::Module::Unity;

NotifierModule* NotifierModule::s_instance = nullptr;

static constexpr const char* kJoinSound = "C:/nyx/Join/sounds/JN-Join.ogg";
static constexpr const char* kLeaveSound = "C:/nyx/Join/sounds/JN-Leave.ogg";

NotifierModule::NotifierModule()
    : BaseModule("Join Sounds", "Join/leave notification sounds", 0, "UI")
{
    SetEnabled(true);
    m_showInQuickMenu = true;
}

void NotifierModule::OnEnable() {
    s_instance = this;
}

void NotifierModule::OnDisable() {
}

void NotifierModule::OnSceneLoad(int, int) {
    m_sceneLoadTick = GetTickCount();
    m_observedLocalJoin = false;
}

void* NotifierModule::LoadOggAsClip(const char* path, const char* clipName) {
    int channels = 0, sampleRate = 0;
    short* output = nullptr;
    int totalSamples = stb_vorbis_decode_filename(path, &channels, &sampleRate, &output);
    if (totalSamples < 0 || !output) {
        if (output) free(output);
        return nullptr;
    }

    size_t sampleCount = static_cast<size_t>(totalSamples) * channels;
    std::vector<float> floatData(sampleCount);
    for (size_t i = 0; i < sampleCount; i++)
        floatData[i] = static_cast<float>(output[i]) / 32768.0f;
    free(output);

    auto* exports = GetExports();
    if (!exports || !exports->m_stringNew || !exports->m_arrayNew) return nullptr;

    static auto clipCreate = MethodHandler::resolve("UnityEngine.AudioClip", "Create", 5);
    if (!clipCreate) clipCreate = MethodHandler::resolve("UnityEngine.AudioClip", "Create", 4);
    if (!clipCreate) return nullptr;

    void* nameStr = reinterpret_cast<void*(IL2CPP_CALLTYPE)(const char*)>(exports->m_stringNew)(clipName);
    bool stream = false;
    void* createParams[] = { nameStr, &totalSamples, &channels, &sampleRate, &stream };
    void* clip = MethodHandler::invoke<void*>(clipCreate, nullptr, createParams);
    if (!clip) return nullptr;

    auto arrayClass = Class::find("System.Single");
    if (!arrayClass) return nullptr;

    void* il2cppArray = reinterpret_cast<void*(IL2CPP_CALLTYPE)(void*, uintptr_t)>(exports->m_arrayNew)(
        arrayClass.raw(), static_cast<uintptr_t>(sampleCount));
    if (!il2cppArray) return nullptr;

    float* arrayData = reinterpret_cast<float*>(reinterpret_cast<uint8_t*>(il2cppArray) + 0x20);
    std::memcpy(arrayData, floatData.data(), sampleCount * sizeof(float));

    static auto setData = MethodHandler::resolve("UnityEngine.AudioClip", "SetData", 2);
    if (!setData) setData = MethodHandler::resolve("UnityEngine.AudioClip", "SetData");
    if (!setData) return nullptr;

    int offsetSamples = 0;
    void* setDataParams[] = { il2cppArray, &offsetSamples };
    MethodHandler::invoke<bool>(setData, clip, setDataParams);
    return clip;
}

void* NotifierModule::CreateAudioSourceGO(const char* name, void* clip) {
    auto go = GameObject::CreatePrimitive(IL2CPP::PrimitiveType::Cube);
    if (!go.valid()) return nullptr;

    go.SetName(std::string(name));

    const char* stripNames[] = { "UnityEngine.MeshRenderer", "UnityEngine.MeshFilter", "UnityEngine.BoxCollider" };
    for (auto& sn : stripNames) {
        auto sc = go.GetComponentByName(sn);
        if (sc.valid()) Object(sc.raw()).DestroyImmediate();
    }

    Object(go.raw()).DontDestroyOnLoad();

    auto asClass = Class::find("UnityEngine.AudioSource");
    if (!asClass) { Object(go.raw()).Destroy(); return nullptr; }

    auto asComp = go.AddComponent(asClass);
    if (!asComp.valid()) { Object(go.raw()).Destroy(); return nullptr; }

    AudioSource source(asComp.raw());
    source.SetClip(clip);
    source.SetPlayOnAwake(false);
    source.SetLoop(false);
    source.SetSpatialize(false);
    source.SetSpatialBlend(0.0f);
    source.SetVolume(m_volume);

    go.SetActive(true);
    return go.raw();
}

void NotifierModule::LoadAssets() {
    if (m_assetState != AssetState::NotLoaded) return;

    if (std::filesystem::exists(kJoinSound)) {
        m_joinClip = LoadOggAsClip(kJoinSound, "jn_join");
        if (m_joinClip) FLOG("[JoinSounds] Loaded join sound");
    }
    if (std::filesystem::exists(kLeaveSound)) {
        m_leaveClip = LoadOggAsClip(kLeaveSound, "jn_leave");
        if (m_leaveClip) FLOG("[JoinSounds] Loaded leave sound");
    }

    if (m_joinClip)
        m_joinSourceGO = CreateAudioSourceGO("JN_JoinSource", m_joinClip);
    if (m_leaveClip)
        m_leaveSourceGO = CreateAudioSourceGO("JN_LeaveSource", m_leaveClip);

    m_assetState = (m_joinClip || m_leaveClip) ? AssetState::Ready : AssetState::Failed;
    FLOG("[JoinSounds] Assets loaded (join=%p leave=%p)", m_joinClip, m_leaveClip);
}

void NotifierModule::PlayJoinSound() {
    if (!m_playSoundOnJoin || !m_joinSourceGO) return;
    try {
        GameObject go(m_joinSourceGO);
        auto asClass = Class::find("UnityEngine.AudioSource");
        if (!asClass) return;
        auto comp = go.GetComponent(asClass);
        if (!comp.valid()) return;
        AudioSource source(comp.raw());
        source.SetVolume(m_volume);
        source.Play();
    } catch (...) {}
}

void NotifierModule::PlayLeaveSound() {
    if (!m_playSoundOnLeave || !m_leaveSourceGO) return;
    try {
        GameObject go(m_leaveSourceGO);
        auto asClass = Class::find("UnityEngine.AudioSource");
        if (!asClass) return;
        auto comp = go.GetComponent(asClass);
        if (!comp.valid()) return;
        AudioSource source(comp.raw());
        source.SetVolume(m_volume);
        source.Play();
    } catch (...) {}
}

void NotifierModule::OnUpdate() {
    if (m_assetState == AssetState::NotLoaded)
        LoadAssets();
}

void NotifierModule::OnPlayerJoinComplete(IL2CPP::VRChat::Player player) {
    try {
        if (!player) return;
        if (!InRoom()) return;
        auto api = player.GetVRCPlayerApi();
        if (!api) return;
        if (api.IsLocal()) {
            m_observedLocalJoin = true;
            m_sceneLoadTick = GetTickCount();
            return;
        }

        if (!m_observedLocalJoin || (GetTickCount() - m_sceneLoadTick) < 5000) return;

        if (m_friendsOnly) {
            auto apiUser = player.GetAPIUser();
            bool isFriend = apiUser ? apiUser.GetIsFriend() : false;
            if (!isFriend) return;
        }

        PlayJoinSound();
    } catch (...) {}
}

void NotifierModule::OnPlayerLeave(IL2CPP::VRChat::Player player) {
    try {
        if (!player) return;
        if (!InRoom()) return;
        auto api = player.GetVRCPlayerApi();
        if (!api) return;
        if (api.IsLocal()) return;

        if ((GetTickCount() - m_sceneLoadTick) < 5000) return;

        if (m_friendsOnly) {
            auto playersSnap = ModuleManager::Get().GetPlayerCache().GetPlayers();
            int pid = api.GetPlayerId();
            bool isFriend = false;
            for (auto& p : *playersSnap) {
                if (p.playerId == pid) { isFriend = p.isFriend; break; }
            }
            if (!isFriend) return;
        }

        PlayLeaveSound();
    } catch (...) {}
}

void __cdecl NotifierModule::QmVolumeCb(uint32_t, float val) { if (s_instance) s_instance->m_volume = val / 100.f; }
void __cdecl NotifierModule::QmPlayJoinSoundCb(uint32_t, bool val) { if (s_instance) s_instance->m_playSoundOnJoin = val; }
void __cdecl NotifierModule::QmPlayLeaveSoundCb(uint32_t, bool val) { if (s_instance) s_instance->m_playSoundOnLeave = val; }
void __cdecl NotifierModule::QmFriendsOnlyCb(uint32_t, bool val) { if (s_instance) s_instance->m_friendsOnly = val; }

void NotifierModule::OnSetupQuickMenu(uint32_t moduleId, uint32_t categoryPageId) {
    s_instance = this;
    auto& qmEx = QuickMenuEx::Get();

    uint32_t fold = qmEx.add_foldout(moduleId, categoryPageId, "Join Sounds", false, true);

    qmEx.add_slider(moduleId, fold, "Volume", 0.f, 100.f, m_volume * 100.f,
        QmVolumeCb, "joinsounds_volume", "%.0f%%");
    qmEx.add_separator(moduleId, fold);
    qmEx.add_settings_toggle(moduleId, fold, "Join Sound", m_playSoundOnJoin,
        QmPlayJoinSoundCb, "joinsounds_play_join");
    qmEx.add_settings_toggle(moduleId, fold, "Leave Sound", m_playSoundOnLeave,
        QmPlayLeaveSoundCb, "joinsounds_play_leave");
    qmEx.add_separator(moduleId, fold);
    qmEx.add_settings_toggle(moduleId, fold, "Friends Only", m_friendsOnly,
        QmFriendsOnlyCb, "joinsounds_friends_only");

    qmEx.set_subpage_nav_icon_vrc(moduleId, categoryPageId, Bootstrap::Sprite::Bundle_Bell);
}

} // namespace UNIx
