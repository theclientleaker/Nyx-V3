#pragma once
#include <Core/BaseModule.hpp>
#include <IL2CPP.Module/include/Reflection.hpp>
#include <unordered_set>
#include <vector>

namespace UNIx {

    class ItemESPModule : public BaseModule {
    public:
        ItemESPModule() : BaseModule("Item ESP", "Outline ESP for pickups", 0, "Visual") {}

        void OnEnable() override;
        void OnDisable() override;
        void OnUpdate() override;
        void OnSceneLoad(int scene, int loadMode) override;

    private:
        void ResolveHighlight();
        void ApplyHighlights();
        void ClearHighlights();

        void* m_highlightComponent = nullptr;
        IL2CPP::Module::Method m_addMethod;
        IL2CPP::Module::Method m_removeMethod;
        bool m_resolved = false;

        struct TrackedItem {
            void* meshFilter = nullptr;
            void* renderer = nullptr;
        };

        std::vector<TrackedItem> m_tracked;
        std::unordered_set<void*> m_trackedGOs;
        float m_refreshTimer = 0.f;
    };

} // namespace UNIx
