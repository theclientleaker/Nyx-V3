#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#include <winhttp.h>

#include <Core/ApiClient/ApiClient.hpp>
#include <Core/ApiClient/ApiSecrets.hpp>
#include <Core/FileLog/FileLog.hpp>

#pragma comment(lib, "winhttp.lib")

namespace UNIx {

    ApiClient& ApiClient::Get() {
        static ApiClient instance;
        return instance;
    }

    ApiClient::~ApiClient() {
        Stop();
    }

    void ApiClient::Start() {
        if (m_running.exchange(true)) return;

        m_hSession = WinHttpOpen(L"nyx/1.0",
            WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
        if (!m_hSession) {
            FLOG("[ApiClient] WinHttpOpen failed");
            m_running = false;
            return;
        }

        WinHttpSetTimeouts(static_cast<HINTERNET>(m_hSession), 10000, 10000, 10000, 10000);

        m_thread = std::thread(&ApiClient::WorkerLoop, this);
        FLOG("[ApiClient] Started");
    }

    bool ApiClient::EnsureConnected() {
        if (m_hConnect) return true;
        if (!m_hSession) return false;

        std::lock_guard lock(m_connectMutex);
        if (m_hConnect) return true;

        auto host = ApiSecrets::Host();
        m_hConnect = WinHttpConnect(static_cast<HINTERNET>(m_hSession), host.c_str(), INTERNET_DEFAULT_HTTPS_PORT, 0);
        if (!m_hConnect) {
            FLOG("[ApiClient] WinHttpConnect failed ({})", GetLastError());
            return false;
        }
        FLOG("[ApiClient] Connected to API");
        return true;
    }

    void ApiClient::Stop() {
        if (!m_running.exchange(false)) return;

        DisconnectWebSocket();

        m_cv.notify_all();
        if (m_thread.joinable()) m_thread.join();

        if (m_hConnect) { WinHttpCloseHandle(static_cast<HINTERNET>(m_hConnect)); m_hConnect = nullptr; }
        if (m_hSession) { WinHttpCloseHandle(static_cast<HINTERNET>(m_hSession)); m_hSession = nullptr; }
        FLOG("[ApiClient] Stopped");
    }

    std::string ApiClient::DoRequest(const wchar_t* method, const std::string& path, const std::string& body, ApiAuth auth) {
        if (!EnsureConnected()) return "";

        std::wstring wpath(path.begin(), path.end());

        HINTERNET hRequest = WinHttpOpenRequest(
            static_cast<HINTERNET>(m_hConnect), method, wpath.c_str(),
            nullptr, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, WINHTTP_FLAG_SECURE);
        if (!hRequest) return "";

        std::wstring headers;
        if (auth == ApiAuth::Client)
            headers = std::wstring(L"Authorization: ") + ApiSecrets::ClientAuth();
        else if (auth == ApiAuth::Admin)
            headers = std::wstring(L"Authorization: ") + ApiSecrets::AdminAuth();

        if (!body.empty()) {
            if (!headers.empty()) headers += L"\r\n";
            headers += L"Content-Type: application/json";
        }

        LPCWSTR hdrs = headers.empty() ? WINHTTP_NO_ADDITIONAL_HEADERS : headers.c_str();
        DWORD hdrsLen = headers.empty() ? 0 : static_cast<DWORD>(headers.size());

        LPVOID bodyPtr = body.empty() ? WINHTTP_NO_REQUEST_DATA : const_cast<char*>(body.c_str());
        DWORD bodyLen = static_cast<DWORD>(body.size());

        BOOL sent = WinHttpSendRequest(hRequest, hdrs, hdrsLen, bodyPtr, bodyLen, bodyLen, 0);

        std::string response;
        if (sent && WinHttpReceiveResponse(hRequest, nullptr)) {
            DWORD bytesAvailable = 0;
            std::vector<char> buf(8192);
            while (WinHttpQueryDataAvailable(hRequest, &bytesAvailable) && bytesAvailable > 0) {
                if (bytesAvailable > buf.size()) buf.resize(bytesAvailable);
                DWORD bytesRead = 0;
                WinHttpReadData(hRequest, buf.data(), bytesAvailable, &bytesRead);
                response.append(buf.data(), bytesRead);
            }
        }

        WinHttpCloseHandle(hRequest);
        return response;
    }

    std::string ApiClient::Get(const std::string& path, ApiAuth auth) {
        return DoRequest(L"GET", path, "", auth);
    }

    std::string ApiClient::Post(const std::string& path, const std::string& body, ApiAuth auth) {
        return DoRequest(L"POST", path, body, auth);
    }

    std::string ApiClient::Delete(const std::string& path, ApiAuth auth) {
        return DoRequest(L"DELETE", path, "", auth);
    }

    void ApiClient::GetAsync(const std::string& path, Callback cb, ApiAuth auth) {
        std::lock_guard lock(m_queueMutex);
        m_queue.push({ L"GET", path, {}, auth, std::move(cb) });
        m_cv.notify_one();
    }

    void ApiClient::PostAsync(const std::string& path, const std::string& body, Callback cb, ApiAuth auth) {
        std::lock_guard lock(m_queueMutex);
        m_queue.push({ L"POST", path, body, auth, std::move(cb) });
        m_cv.notify_one();
    }

    void ApiClient::DeleteAsync(const std::string& path, Callback cb, ApiAuth auth) {
        std::lock_guard lock(m_queueMutex);
        m_queue.push({ L"DELETE", path, {}, auth, std::move(cb) });
        m_cv.notify_one();
    }

    void ApiClient::WorkerLoop() {
        while (m_running) {
            QueuedRequest req;
            {
                std::unique_lock lock(m_queueMutex);
                m_cv.wait_for(lock, std::chrono::milliseconds(500), [this] { return !m_queue.empty() || !m_running; });
                if (!m_running) break;
                if (m_queue.empty()) continue;
                req = std::move(m_queue.front());
                m_queue.pop();
            }

            std::string response = DoRequest(req.method, req.path, req.body, req.auth);
            if (req.callback) req.callback(response);
        }
    }

    // ── WebSocket ──

    void ApiClient::SetWebSocketHandler(WsMessageCallback cb) {
        m_wsHandler = std::move(cb);
    }

    void ApiClient::ConnectWebSocket(const std::string& userId) {
        if (m_wsRunning) return;
        m_wsRunning = true;
        m_wsThread = std::thread(&ApiClient::WebSocketLoop, this, userId);
    }

    void ApiClient::DisconnectWebSocket() {
        m_wsRunning = false;
        {
            std::lock_guard lock(m_wsMutex);
            if (m_hWebSocket) {
                WinHttpWebSocketClose(static_cast<HINTERNET>(m_hWebSocket),
                    WINHTTP_WEB_SOCKET_SUCCESS_CLOSE_STATUS, nullptr, 0);
                WinHttpCloseHandle(static_cast<HINTERNET>(m_hWebSocket));
                m_hWebSocket = nullptr;
            }
            if (m_hWsConnect) {
                WinHttpCloseHandle(static_cast<HINTERNET>(m_hWsConnect));
                m_hWsConnect = nullptr;
            }
        }
        m_wsConnected = false;
        if (m_wsThread.joinable()) m_wsThread.join();
    }

    void ApiClient::WebSocketSend(const std::string& message) {
        std::lock_guard lock(m_wsMutex);
        if (!m_hWebSocket || !m_wsConnected) return;
        WinHttpWebSocketSend(static_cast<HINTERNET>(m_hWebSocket),
            WINHTTP_WEB_SOCKET_UTF8_MESSAGE_BUFFER_TYPE,
            const_cast<char*>(message.c_str()),
            static_cast<DWORD>(message.size()));
    }

    bool ApiClient::DoWebSocketConnect(const std::string& userId) {
        if (!m_hSession) return false;

        auto wsHost = ApiSecrets::Host();
        HINTERNET hWsConnect = WinHttpConnect(
            static_cast<HINTERNET>(m_hSession), wsHost.c_str(), INTERNET_DEFAULT_HTTPS_PORT, 0);
        if (!hWsConnect) {
            FLOG("[ApiClient] WS: Connect failed ({})", GetLastError());
            return false;
        }

        HINTERNET hRequest = WinHttpOpenRequest(
            hWsConnect, L"GET", L"/ws",
            nullptr, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, WINHTTP_FLAG_SECURE);
        if (!hRequest) {
            FLOG("[ApiClient] WS: OpenRequest failed ({})", GetLastError());
            WinHttpCloseHandle(hWsConnect);
            return false;
        }

        if (!WinHttpSetOption(hRequest, WINHTTP_OPTION_UPGRADE_TO_WEB_SOCKET, nullptr, 0)) {
            FLOG("[ApiClient] WS: SetOption failed ({})", GetLastError());
            WinHttpCloseHandle(hRequest);
            WinHttpCloseHandle(hWsConnect);
            return false;
        }

        BOOL sent = WinHttpSendRequest(hRequest,
            WINHTTP_NO_ADDITIONAL_HEADERS, 0,
            WINHTTP_NO_REQUEST_DATA, 0, 0, 0);
        if (!sent) {
            FLOG("[ApiClient] WS: SendRequest failed ({})", GetLastError());
            WinHttpCloseHandle(hRequest);
            WinHttpCloseHandle(hWsConnect);
            return false;
        }

        if (!WinHttpReceiveResponse(hRequest, nullptr)) {
            FLOG("[ApiClient] WS: ReceiveResponse failed ({})", GetLastError());
            WinHttpCloseHandle(hRequest);
            WinHttpCloseHandle(hWsConnect);
            return false;
        }

        DWORD statusCode = 0;
        DWORD statusSize = sizeof(statusCode);
        WinHttpQueryHeaders(hRequest,
            WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
            WINHTTP_HEADER_NAME_BY_INDEX, &statusCode, &statusSize, WINHTTP_NO_HEADER_INDEX);
        FLOG("[ApiClient] WS: HTTP status {}", statusCode);

        if (statusCode != 101) {
            FLOG("[ApiClient] WS: Expected 101, got {}", statusCode);
            WinHttpCloseHandle(hRequest);
            WinHttpCloseHandle(hWsConnect);
            return false;
        }

        HINTERNET hWebSocket = WinHttpWebSocketCompleteUpgrade(hRequest, 0);
        WinHttpCloseHandle(hRequest);

        if (!hWebSocket) {
            FLOG("[ApiClient] WS: CompleteUpgrade failed ({})", GetLastError());
            WinHttpCloseHandle(hWsConnect);
            return false;
        }

        {
            std::lock_guard lock(m_wsMutex);
            m_hWebSocket = hWebSocket;
            m_hWsConnect = hWsConnect;
        }
        m_wsConnected = true;

        std::string authMsg = "{\"type\":\"auth\",\"token\":\"";
        authMsg += ApiSecrets::ClientSecret();
        authMsg += "\",\"userId\":\"";
        authMsg += userId;
        authMsg += "\"}";
        WebSocketSend(authMsg);

        FLOG("[ApiClient] WS: Connected and auth sent");
        return true;
    }

    void ApiClient::WebSocketLoop(std::string userId) {
        int backoff = 1000;

        while (m_wsRunning && m_running) {
            FLOG("[ApiClient] WS: Connecting...");

            if (!DoWebSocketConnect(userId)) {
                FLOG("[ApiClient] WS: Connect failed, retrying in {}ms", backoff);
                for (int i = 0; i < backoff / 100 && m_wsRunning && m_running; ++i)
                    Sleep(100);
                backoff = (std::min)(backoff * 2, 30000);
                continue;
            }

            backoff = 1000;

            std::vector<char> buf(8192);
            std::string accumulated;
            DWORD lastPing = GetTickCount();

            while (m_wsRunning && m_running) {
                DWORD bytesRead = 0;
                WINHTTP_WEB_SOCKET_BUFFER_TYPE bufType;

                DWORD err = WinHttpWebSocketReceive(
                    static_cast<HINTERNET>(m_hWebSocket),
                    buf.data(), static_cast<DWORD>(buf.size()),
                    &bytesRead, &bufType);

                if (err != ERROR_SUCCESS) {
                    FLOG("[ApiClient] WS: Receive error ({})", err);
                    break;
                }

                if (bufType == WINHTTP_WEB_SOCKET_CLOSE_BUFFER_TYPE) {
                    FLOG("[ApiClient] WS: Server closed connection");
                    break;
                }

                accumulated.append(buf.data(), bytesRead);

                if (bufType == WINHTTP_WEB_SOCKET_UTF8_MESSAGE_BUFFER_TYPE) {
                    if (m_wsHandler)
                        m_wsHandler(accumulated);
                    accumulated.clear();
                }

                DWORD now = GetTickCount();
                if (now - lastPing > 25000) {
                    WebSocketSend("{\"type\":\"ping\"}");
                    lastPing = now;
                }
            }

            {
                std::lock_guard lock(m_wsMutex);
                if (m_hWebSocket) {
                    WinHttpWebSocketClose(static_cast<HINTERNET>(m_hWebSocket),
                        WINHTTP_WEB_SOCKET_SUCCESS_CLOSE_STATUS, nullptr, 0);
                    WinHttpCloseHandle(static_cast<HINTERNET>(m_hWebSocket));
                    m_hWebSocket = nullptr;
                }
                if (m_hWsConnect) {
                    WinHttpCloseHandle(static_cast<HINTERNET>(m_hWsConnect));
                    m_hWsConnect = nullptr;
                }
            }
            m_wsConnected = false;

            if (m_wsRunning && m_running) {
                FLOG("[ApiClient] WS: Reconnecting in {}ms", backoff);
                for (int i = 0; i < backoff / 100 && m_wsRunning && m_running; ++i)
                    Sleep(100);
                backoff = (std::min)(backoff * 2, 30000);
            }
        }

        m_wsConnected = false;
        FLOG("[ApiClient] WS: Loop exited");
    }

} // namespace UNIx
