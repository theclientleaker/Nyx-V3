#include <Modules/Visual/Zoom/ZoomModule.hpp>
#include <IL2CPP.Module/include/Unity/Camera.hpp>
#include <IL2CPP.Module/include/Unity/Time.hpp>
#include <Windows.h>
#include <cmath>

namespace UNIx {

    bool ZoomModule::OnEvent(uint32_t msg, uintptr_t wParam, intptr_t) {
        if (msg == WM_MOUSEWHEEL && m_active) {
            short delta = GET_WHEEL_DELTA_WPARAM(wParam);
            m_zoomFov += (delta > 0) ? -2.f : 2.f;
            if (m_zoomFov < 5.f) m_zoomFov = 5.f;
            if (m_zoomFov > 60.f) m_zoomFov = 60.f;
            return true;
        }
        return false;
    }

    void ZoomModule::OnUpdate() {
        HWND fg = GetForegroundWindow();
        DWORD fgPid = 0;
        GetWindowThreadProcessId(fg, &fgPid);
        bool gameFocused = (fgPid == GetCurrentProcessId());
        bool altHeld = gameFocused && (GetAsyncKeyState(VK_MENU) & 0x8000) != 0;
        float dt = IL2CPP::Module::Unity::Time::GetDeltaTime();

        if (altHeld && !m_active) {
            auto cam = IL2CPP::Module::Unity::Camera::GetMain();
            if (cam.IsValid()) {
                m_originalFov = cam.GetFieldOfView();
                m_zoomFov = 20.f;
                m_currentFov = m_originalFov;
                m_active = true;
            }
        }

        if (!m_active) return;

        float targetFov = altHeld ? m_zoomFov : m_originalFov;
        m_currentFov += (targetFov - m_currentFov) * kLerpSpeed * dt;

        if (std::abs(m_currentFov - targetFov) < 0.05f)
            m_currentFov = targetFov;

        auto cam = IL2CPP::Module::Unity::Camera::GetMain();
        if (!cam.IsValid()) return;

        if (!altHeld && m_currentFov == m_originalFov) {
            cam.ResetProjectionMatrix();
            m_active = false;
            return;
        }

        cam.ResetProjectionMatrix();
        auto proj = cam.GetProjectionMatrix();
        constexpr float kDeg2Rad = 3.14159265f / 180.f;
        float scale = std::tan(m_originalFov * 0.5f * kDeg2Rad) /
                      std::tan(m_currentFov * 0.5f * kDeg2Rad);
        proj[0][0] *= scale;
        proj[1][1] *= scale;
        cam.SetProjectionMatrix(proj);
    }

    void ZoomModule::OnSceneLoad(int, int loadMode) {
        if (loadMode == 0) {
            m_active = false;
        }
    }

} // namespace UNIx
