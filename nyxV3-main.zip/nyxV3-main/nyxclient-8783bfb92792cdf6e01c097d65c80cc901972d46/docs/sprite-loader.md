# SpriteLoader & Icon Resources

## Overview

Icons and images are stored as Win32 resources embedded in the DLL's resource section. At runtime, `SpriteLoader` loads the raw PNG bytes and converts them into Unity `Sprite` objects via IL2CPP calls.

## File Structure

```
VoidUnix/
  resource.h                          # Resource ID defines
  VoidUnix.rc                         # Resource compiler script
  resources/
    icons/
      terminal.png                    # 128x128 PNG icons
      gauge.png
      airplane_tilt.png
      crosshair.png
      identification_card.png
      users_three.png
      music_notes.png
      door.png
  include/Core/SpriteLoader/
    SpriteLoader.hpp                  # SpriteLoader interface
  src/Core/SpriteLoader/
    SpriteLoader.cpp                  # Implementation
```

## Adding a New Icon

### 1. Add the PNG file

Drop your PNG into `VoidUnix/resources/icons/`. Any resolution works, but 128x128 is the standard used by existing icons.

### 2. Define a resource ID

In `resource.h`, add a new define with the next available ID:

```cpp
#define IDR_ICON_MY_NEW_ICON        109
```

### 3. Register in the .rc file

In `VoidUnix.rc`, add a line mapping the ID to the file:

```
IDR_ICON_MY_NEW_ICON         PNG     "resources\\icons\\my_new_icon.png"
```

### 4. Load in code

```cpp
#include <Core/SpriteLoader/SpriteLoader.hpp>
#include "resource.h"

void* sprite = SpriteLoader::Get().LoadFromResource(IDR_ICON_MY_NEW_ICON, "my_icon");
```

The second parameter is a cache key. Subsequent calls with the same key return the cached sprite without reloading.

### 5. Use with a Unity UI.Image component

```cpp
IL2CPP::Module::Unity::Image img(imageComponentPtr);
img.SetSprite(sprite);
img.SetPreserveAspect(true);
```

### 6. Use with QuickMenu buttons

In the `s_moduleIcons` map in `ModuleManager.cpp`:

```cpp
{ "My Module", IDR_ICON_MY_NEW_ICON },
```

The QuickMenu setup code calls `LoadFromResource` and `set_button_icon` automatically for any module name in this map.

## SpriteLoader API

| Method | Description |
|--------|-------------|
| `LoadFromResource(uint32_t id, const std::string& key)` | Load PNG from DLL resource section by ID |
| `LoadFromFile(const std::string& path)` | Load PNG from disk (e.g. user-provided images) |
| `LoadFromMemory(const std::string& key, const uint8_t* data, size_t size)` | Load from raw byte buffer |
| `GetCached(const std::string& key)` | Return previously loaded sprite, or nullptr |

All methods return `void*` (a raw Unity `Sprite` pointer) or `nullptr` on failure. All methods cache automatically by key.

## How It Works Internally

`CreateSpriteFromBytes` converts raw PNG bytes into a Unity Sprite through the IL2CPP runtime:

1. Allocate a managed `System.Byte[]` array and copy the PNG data into it
2. Clone `Texture2D.whiteTexture` via `Object.Instantiate` to get a valid texture
3. Call `ImageConversion.LoadImage(texture, byteArray)` to decode the PNG into the texture
4. Read back width/height from the decoded texture
5. Create a `Sprite` from the texture with full-rect bounds and center pivot
6. Cache the sprite pointer by key

`LoadFromResource` uses the Win32 API to locate and lock the PNG data from the DLL's compiled resource section:

```
FindResourceW(g_hModule, MAKEINTRESOURCEW(id), L"PNG")
  -> LoadResource -> LockResource -> SizeofResource
  -> CreateSpriteFromBytes
```

No memory allocation or file I/O needed -- the data is memory-mapped directly from the DLL.

## Where Icons Are Used

| Consumer | File | What It Does |
|----------|------|-------------|
| ModuleManager | `src/Core/ModuleManager.cpp` | Assigns icons to QuickMenu page and module toggle buttons |
| NameplateTagModule | `src/Modules/Visual/Nameplates/NameplateTagModule.cpp` | Renders tag icons on player nameplates |
| CustomNameplateModule | `src/Modules/Visual/Nameplates/CustomNameplateModule.cpp` | Loads user PNGs from `C:/nyx/nameplate/` via `LoadFromFile` |
| LoadingPopup | `src/Modules/UI/LoadingScreen/LoadingPopup.cpp` | Loads user PNGs from `C:/nyx/loadingscreen/` via `LoadFromFile` |

## Current Icons

| Resource ID | Key | Used By |
|-------------|-----|---------|
| `IDR_ICON_TERMINAL` (101) | terminal | QuickMenu main page |
| `IDR_ICON_GAUGE` (102) | gauge / Movement | Movement module, nameplate tags |
| `IDR_ICON_AIRPLANE_TILT` (103) | airplane / Noclip | Noclip module, nameplate tags |
| `IDR_ICON_CROSSHAIR` (104) | crosshair / ESP | ESP module, nameplate tags |
| `IDR_ICON_IDENTIFICATION_CARD` (105) | id_card / Nameplate Tags | Nameplate Tags module |
| `IDR_ICON_USERS_THREE` (106) | users / Player List | Player List module, nameplate tags |
| `IDR_ICON_MUSIC_NOTES` (107) | music / Loading Music | Loading Music module, nameplate tags |
| `IDR_ICON_DOOR` (108) | door / Portal Spam | Portal Spam module, nameplate tags |
