#include <Core/ModuleManager.hpp>
#include <Core/BaseModule.hpp>
#include <Core/Globals.hpp>
#include <Core/Theme.hpp>
#include <Core/FileLog/FileLog.hpp>
#include <Modules/UI/InstanceHistory/InstanceHistoryModule.hpp>
#include <Modules/Exploits/PickupFling/PickupFlingModule.hpp>
#include <Core/InstanceHistory/InstanceHistory.hpp>
#include <ctime>
#include <set>
#include <fstream>
#include <winhttp.h>

#include <Bootstrap.Module/include/VRChat/VRCPlayerApi.hpp>
#include <Bootstrap.Module/include/VRChat/VRCPlayer.hpp>
#include <Bootstrap.Module/include/VRChat/APIUser.hpp>
#include <Bootstrap.Module/include/VRChat/ApiModel.hpp>
#include <Bootstrap.Module/include/VRChat/Networking.hpp>
#include <IL2CPP.Module/include/il2cpp_module.hpp>
#include <IL2CPP.Module/include/System/String.hpp>
#include <IL2CPP.Module/include/Unity/Time.hpp>
#include <IL2CPP.Module/include/Unity/GameObject.hpp>
#include <IL2CPP.Module/include/Unity/Transform.hpp>
#include <IL2CPP.Module/include/Unity/Component.hpp>
#include <IL2CPP.Module/include/Unity/ScrollRect.hpp>
#include <IL2CPP.Module/include/Unity/RectTransform.hpp>
#include <IL2CPP.Module/include/Unity/ContentSizeFitter.hpp>
#include <IL2CPP.Module/include/Unity/VerticalLayoutGroup.hpp>
#include <IL2CPP.Module/include/Unity/Input.hpp>
#include <IL2CPP.Module/include/Unity/Canvas.hpp>
#include <IL2CPP.Module/include/Unity/Image.hpp>
#include <IL2CPP.Module/include/Unity/TMP_Text.hpp>
#include <IL2CPP.Module/include/Reflection.hpp>
#include <IL2CPP.Module/include/MethodHandler.hpp>
#include <IL2CPP.Module/include/ManagedObject.hpp>
#include <IL2CPP.Module/include/Unity/Object.hpp>
#include <atomic>

namespace Hooking::Module {
    extern const Hooking::HookVtable* get_connection_vtable() noexcept;
}

#include <ThirdParty/imgui/imgui.h>
#include <ThirdParty/imgui/imgui_internal.h>
#include <ThirdParty/imgui/imgui_impl_win32.h>

#include <Modules/Exploits/Portal/PortalSpamModule.hpp>
#include <Modules/Exploits/Portal/PortalOrbitModule.hpp>
#include <Core/DiscordRPC/DiscordRPC.hpp>
#include <Modules/Exploits/LimbSit/LimbSitModule.hpp>
#include <Modules/Exploits/ItemOrbit/ItemOrbitModule.hpp>
#include <Modules/Exploits/ItemClapper/ItemClapperModule.hpp>
#include <Modules/Exploits/ItemLagger/ItemLaggerModule.hpp>

#include <Bootstrap.Module/include/bootstrap_module.hpp>
#include <Core/QuickMenuEx.hpp>
#include <Core/SpriteLoader/SpriteLoader.hpp>
#include <Core/SpriteLoader/EmbeddedQMBackground.hpp>
#include "resource.h"
#include <Core/DashboardConsole/DashboardConsole.hpp>
// #include <Modules/UI/SettingsMenu/SettingsMenuModule.hpp>
#include <Core/HeartbeatManager/HeartbeatManager.hpp>
#include <Core/TagManager/TagManager.hpp>
#include <Core/VRChatApi/VRChatApi.hpp>
#include <Modules/UI/Toasts/ToastModule.hpp>

#include <ctime>
#include <string>
#include <sstream>
#include <algorithm>
#include <cctype>
#include <map>
#include <fstream>
#include <filesystem>
#include <set>
#include <unordered_set>

#include <windows.h>
#include <pdh.h>
#include <pdhmsg.h>

extern LRESULT ImGui_ImplWin32_WndProcHandler(
    HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

namespace UNIx {

    static bool SafeCallModuleOverlay(BaseModule* mod) {
        __try { mod->OnOverlay(); return true; }
        __except(EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    ModuleManager& ModuleManager::Get() {
        static ModuleManager instance;
        return instance;
    }

    // ── Render callbacks ──

    void ModuleManager::Render(const Hooking::UiRenderContext* ctx) {
        if (!ctx || !ctx->swap_chain) return;

        if (!Renderer::IsInitialized()) {
            Renderer::Initialize(ctx);
            if (!Renderer::IsInitialized()) return;
        }

        auto& mgr = Get();

        Renderer::BeginFrame();

        {
            auto* dev = Renderer::GetDevice();
            if (dev) InstanceHistory::Get().ProcessPendingThumbnails(dev);
        }

        ImGuiIO& io = ImGui::GetIO();

        mgr.m_hue += 0.05f * io.DeltaTime;
        if (mgr.m_hue >= 1.0f) mgr.m_hue -= 1.0f;
        ImColor rainbow = ImColor::HSV(mgr.m_hue, 0.6f, 1.0f);

        RenderWatermark(mgr, io, rainbow);

        for (auto& mod : mgr.m_modules) {
            if (mod->IsEnabled())
                SafeCallModuleOverlay(mod.get());
        }

        if (mgr.m_playerlistOpen) {
            RenderPlayerlistOverlay(mgr, io, rainbow);
            if (HeartbeatManager::Get().IsDev())
                RenderAdminPanel(mgr, io);
            DashboardConsole::Get().OnRender();
        }

        Renderer::EndFrame();
    }

    // ── CPU / GPU usage sampling ──

    struct HardwareStats {
        float cpuPercent = 0.f;
        float gpuPercent = 0.f;

        ULONGLONG prevIdle = 0, prevKernel = 0, prevUser = 0;

        PDH_HQUERY  gpuQuery = nullptr;
        PDH_HCOUNTER gpuCounter = nullptr;
        bool gpuInitialized = false;
        bool gpuAvailable = false;

        float updateTimer = 0.f;
        static constexpr float UPDATE_INTERVAL = 1.0f;

        void Init() {
            FILETIME fIdle, fKernel, fUser;
            if (GetSystemTimes(&fIdle, &fKernel, &fUser)) {
                prevIdle   = (ULONGLONG)fIdle.dwHighDateTime << 32 | fIdle.dwLowDateTime;
                prevKernel = (ULONGLONG)fKernel.dwHighDateTime << 32 | fKernel.dwLowDateTime;
                prevUser   = (ULONGLONG)fUser.dwHighDateTime << 32 | fUser.dwLowDateTime;
            }

            if (PdhOpenQueryW(nullptr, 0, &gpuQuery) == ERROR_SUCCESS) {
                if (PdhAddEnglishCounterW(gpuQuery,
                        L"\\GPU Engine(*engtype_3D)\\Utilization Percentage",
                        0, &gpuCounter) == ERROR_SUCCESS) {
                    PdhCollectQueryData(gpuQuery);
                    gpuAvailable = true;
                }
            }
            gpuInitialized = true;
        }

        void Update(float deltaTime) {
            updateTimer += deltaTime;
            if (updateTimer < UPDATE_INTERVAL) return;
            updateTimer = 0.f;

            FILETIME fIdle, fKernel, fUser;
            if (GetSystemTimes(&fIdle, &fKernel, &fUser)) {
                ULONGLONG idle   = (ULONGLONG)fIdle.dwHighDateTime << 32 | fIdle.dwLowDateTime;
                ULONGLONG kernel = (ULONGLONG)fKernel.dwHighDateTime << 32 | fKernel.dwLowDateTime;
                ULONGLONG user   = (ULONGLONG)fUser.dwHighDateTime << 32 | fUser.dwLowDateTime;

                ULONGLONG totalDelta = (kernel - prevKernel) + (user - prevUser);
                ULONGLONG idleDelta  = idle - prevIdle;

                if (totalDelta > 0)
                    cpuPercent = (1.0f - static_cast<float>(idleDelta) / static_cast<float>(totalDelta)) * 100.f;

                prevIdle = idle;
                prevKernel = kernel;
                prevUser = user;
            }

            if (gpuAvailable && gpuQuery) {
                if (PdhCollectQueryData(gpuQuery) == ERROR_SUCCESS) {
                    PDH_FMT_COUNTERVALUE_ITEM_W* items = nullptr;
                    DWORD bufSize = 0, itemCount = 0;
                    PDH_STATUS s = PdhGetFormattedCounterArrayW(gpuCounter, PDH_FMT_DOUBLE,
                        &bufSize, &itemCount, nullptr);
                    if (s == PDH_MORE_DATA && bufSize > 0) {
                        auto buf = std::make_unique<BYTE[]>(bufSize);
                        items = reinterpret_cast<PDH_FMT_COUNTERVALUE_ITEM_W*>(buf.get());
                        if (PdhGetFormattedCounterArrayW(gpuCounter, PDH_FMT_DOUBLE,
                                &bufSize, &itemCount, items) == ERROR_SUCCESS) {
                            double maxVal = 0.0;
                            for (DWORD i = 0; i < itemCount; ++i) {
                                if (items[i].FmtValue.doubleValue > maxVal)
                                    maxVal = items[i].FmtValue.doubleValue;
                            }
                            gpuPercent = static_cast<float>(maxVal);
                        }
                    }
                }
            }
        }

        void Shutdown() {
            if (gpuQuery) {
                PdhCloseQuery(gpuQuery);
                gpuQuery = nullptr;
            }
        }
    };

    static HardwareStats s_hwStats;

    // ── Watermark bar ──

    void ModuleManager::RenderWatermark(ModuleManager& mgr, const ImGuiIO& io, const ImColor& rainbow) {
        if (!mgr.m_showWatermark && !mgr.m_showStats) return;

        if (!s_hwStats.gpuInitialized) s_hwStats.Init();
        s_hwStats.Update(io.DeltaTime);

        ImGui::PushStyleColor(ImGuiCol_MenuBarBg, ImVec4(0.f, 0.f, 0.f, 0.03f));
        ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.f, 0.f, 0.f, 0.03f));

        if (ImGui::BeginMainMenuBar()) {
            if (g_fontSmallBold) ImGui::PushFont(g_fontSmallBold);
            ImGui::Dummy(ImVec2(1, 1));

            const ImVec4 c_highlight(0.549f, 0.157f, 0.882f, 1.0f);

            if (mgr.m_showWatermark) {
                time_t now = time(nullptr);
                struct tm t;
                localtime_s(&t, &now);
                char dateBuf[16], timeBuf[16];
                strftime(dateBuf, sizeof(dateBuf), "%m/%d/%Y", &t);
                strftime(timeBuf, sizeof(timeBuf), "%H:%M:%S", &t);

                char hwBuf[64];
                snprintf(hwBuf, sizeof(hwBuf), "CPU %.0f%%  GPU %.0f%%",
                    s_hwStats.cpuPercent, s_hwStats.gpuPercent);
                float hwW = ImGui::CalcTextSize(hwBuf).x;

                char watermarkText[128];
                snprintf(watermarkText, sizeof(watermarkText), "nyx | %s | %s", dateBuf, timeBuf);
                float textW = ImGui::CalcTextSize(watermarkText).x;

                float rightEdge = ImGui::GetContentRegionAvail().x;
                ImGui::SetCursorPosX(rightEdge - textW - hwW - 20.f);

                ImGui::TextColored(c_highlight, "CPU ");
                ImGui::SameLine(0.f, 0.f);
                ImGui::Text("%.0f%%", s_hwStats.cpuPercent);
                ImGui::SameLine(0.f, 4.f);
                ImGui::TextColored(c_highlight, "GPU ");
                ImGui::SameLine(0.f, 0.f);
                ImGui::Text("%.0f%%", s_hwStats.gpuPercent);

                ImGui::SameLine(0.f, 10.f);

                ImGui::TextColored(c_highlight, "nyx");
                ImGui::SameLine(0.f, 0.f);
                ImGui::TextColored(c_highlight, " | ");
                ImGui::SameLine(0.f, 0.f);
                ImGui::Text("%s", dateBuf);
                ImGui::SameLine(0.f, 0.f);
                ImGui::TextColored(c_highlight, " | ");
                ImGui::SameLine(0.f, 0.f);
                ImGui::Text("%s", timeBuf);
            }

            if (mgr.m_showStats) {
                ImGui::SameLine(10.f);
                char msBuf[32];
                snprintf(msBuf, sizeof(msBuf), "%.3f", 1000.f / io.Framerate);
                ImGui::Text("%s", msBuf);
                ImGui::SameLine(0.f, 0.f);
                ImGui::TextColored(c_highlight, "ms");
                ImGui::SameLine(0.f, 0.f);
                ImGui::Text("/");
                ImGui::SameLine(0.f, 0.f);
                ImGui::TextColored(c_highlight, "frame (");
                ImGui::SameLine(0.f, 0.f);
                ImGui::Text("%d", static_cast<int>(io.Framerate));
                ImGui::SameLine(0.f, 0.f);
                ImGui::TextColored(c_highlight, " fps)");
            }

            if (g_fontSmallBold) ImGui::PopFont();
            ImGui::EndMainMenuBar();
        }

        ImGui::PopStyleColor(2);
    }

    // ── Playerlist overlay ──

    static ImVec4 RankToColor(IL2CPP::VRChat::PlayerRank rank) {
        switch (rank) {
            case IL2CPP::VRChat::PlayerRank::Visitor:       return ImVec4(0.80f, 0.80f, 0.80f, 1.f);
            case IL2CPP::VRChat::PlayerRank::NewUser:         return ImVec4(0.17f, 0.81f, 0.36f, 1.f);
            case IL2CPP::VRChat::PlayerRank::User:         return ImVec4(1.00f, 0.48f, 0.26f, 1.f);
            case IL2CPP::VRChat::PlayerRank::Known:       return ImVec4(0.78f, 0.24f, 1.00f, 1.f);
            case IL2CPP::VRChat::PlayerRank::Trusted:       return ImVec4(1.00f, 0.40f, 0.40f, 1.f);
            case IL2CPP::VRChat::PlayerRank::Administrator: return ImVec4(0.55f, 0.00f, 0.00f, 1.f);
            case IL2CPP::VRChat::PlayerRank::Troll:         return ImVec4(0.50f, 0.50f, 0.50f, 1.f);
            default: return ImVec4(1.f, 1.f, 1.f, 1.f);
        }
    }

    static const char* RankToName(IL2CPP::VRChat::PlayerRank rank) {
        switch (rank) {
            case IL2CPP::VRChat::PlayerRank::Visitor:       return "Visitor";
            case IL2CPP::VRChat::PlayerRank::NewUser:       return "New User";
            case IL2CPP::VRChat::PlayerRank::User:          return "User";
            case IL2CPP::VRChat::PlayerRank::Known:         return "Known";
            case IL2CPP::VRChat::PlayerRank::Trusted:       return "Trusted";
            case IL2CPP::VRChat::PlayerRank::Administrator: return "Admin";
            case IL2CPP::VRChat::PlayerRank::Troll:         return "Troll";
            default: return "Unknown";
        }
    }

    void ModuleManager::RenderPlayerlistOverlay(ModuleManager& mgr, const ImGuiIO& io, const ImColor& rainbow) {
        float winW = io.DisplaySize.x * 0.45f;
        float winH = io.DisplaySize.y * 0.55f;
        ImGui::SetNextWindowPos(ImVec2(io.DisplaySize.x * 0.5f, io.DisplaySize.y * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
        ImGui::SetNextWindowSize(ImVec2(winW, winH), ImGuiCond_Always);
        ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.06f, 0.06f, 0.08f, 0.92f));
        ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.04f, 0.04f, 0.06f, 0.6f));

        ImGui::Begin("##playerlist_overlay", nullptr,
            ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse |
            ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoMove);
        {
            const ImVec4 c_highlight(0.549f, 0.157f, 0.882f, 1.0f);
            auto players = mgr.m_playerCache.GetPlayers();

            if (g_fontBig) ImGui::PushFont(g_fontBig);
            ImGui::Spacing();

            if (mgr.m_plTab == 0) {
                float titleW = ImGui::CalcTextSize("nyx playerlist - [00]").x;
                ImGui::SetCursorPosX((ImGui::GetWindowSize().x - titleW) * 0.5f);
                ImGui::TextColored(c_highlight, "nyx ");
                ImGui::SameLine(0.f, 0.f);
                ImGui::Text("playerlist");
                ImGui::SameLine(0.f, 0.f);
                ImGui::TextColored(c_highlight, " - [");
                ImGui::SameLine(0.f, 0.f);
                ImGui::Text("%zu", players->size());
                ImGui::SameLine(0.f, 0.f);
                ImGui::TextColored(c_highlight, "]");
            } else {
                auto histEntries = InstanceHistory::Get().GetEntries();
                float titleW = ImGui::CalcTextSize("nyx instance history - [00]").x;
                ImGui::SetCursorPosX((ImGui::GetWindowSize().x - titleW) * 0.5f);
                ImGui::TextColored(c_highlight, "nyx ");
                ImGui::SameLine(0.f, 0.f);
                ImGui::Text("instance history");
                ImGui::SameLine(0.f, 0.f);
                ImGui::TextColored(c_highlight, " - [");
                ImGui::SameLine(0.f, 0.f);
                ImGui::Text("%zu", histEntries.size());
                ImGui::SameLine(0.f, 0.f);
                ImGui::TextColored(c_highlight, "]");
            }
            ImGui::Spacing();
            if (g_fontBig) ImGui::PopFont();

            {
                float tabW = winW * 0.3f;
                float totalW = tabW * 2.f + ImGui::GetStyle().ItemSpacing.x;
                ImGui::SetCursorPosX((ImGui::GetWindowSize().x - totalW) * 0.5f);

                if (mgr.m_plTab == 0)
                    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(c_highlight.x, c_highlight.y, c_highlight.z, 0.6f));
                else
                    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.15f, 0.15f, 0.18f, 1.f));
                if (ImGui::Button("Players", ImVec2(tabW, 0)))
                    mgr.m_plTab = 0;
                ImGui::PopStyleColor();

                ImGui::SameLine();

                if (mgr.m_plTab == 1)
                    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(c_highlight.x, c_highlight.y, c_highlight.z, 0.6f));
                else
                    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.15f, 0.15f, 0.18f, 1.f));
                if (ImGui::Button("Instance History", ImVec2(tabW, 0)))
                    mgr.m_plTab = 1;
                ImGui::PopStyleColor();
            }

            ImGui::Separator();
            ImGui::Spacing();

          if (mgr.m_plTab == 0) {
            float leftW = winW * 0.48f;

            ImGui::BeginChild("##pl_left", ImVec2(leftW, 0), true);
            {
                if (g_fontMediumBold) ImGui::PushFont(g_fontMediumBold);

                for (auto& p : *players) {
                    ImVec4 nameColor(1.f, 1.f, 1.f, 1.f);
                    if (p.isLocal)
                        nameColor = ImVec4(0.3f, 0.5f, 1.0f, 1.f);
                    else if (p.isMaster)
                        nameColor = ImVec4(1.0f, 0.3f, 0.3f, 1.f);
                    else if (p.isFriend)
                        nameColor = ImVec4(0.3f, 1.0f, 0.5f, 1.f);

                    std::string label;
                    if (p.isFriend) label += "[F] ";
                    if (p.isQuest)  label += "[Q] ";
                    else if (p.isVR) label += "[VR] ";
                    else label += "[PC] ";
                    label += p.displayName;
                    if (p.isLocal) label += " [you]";
                    if (p.isMaster) label += " [host]";

                    ImGui::PushStyleColor(ImGuiCol_Text, nameColor);
                    bool selected = (mgr.m_selectedPlayerId == p.playerId);
                    if (ImGui::Selectable(label.c_str(), selected))
                        mgr.m_selectedPlayerId = p.playerId;
                    ImGui::PopStyleColor();
                }

                if (g_fontMediumBold) ImGui::PopFont();
            }
            ImGui::EndChild();

            ImGui::SameLine();

            ImGui::BeginChild("##pl_right", ImVec2(0, 0), true);
            {
                if (g_fontMediumBold) ImGui::PushFont(g_fontMediumBold);

                const PlayerEntry* sel = nullptr;
                for (auto& p : *players) {
                    if (p.playerId == mgr.m_selectedPlayerId) {
                        sel = &p;
                        break;
                    }
                }

                if (sel) {
                    ImGui::TextColored(c_highlight, "Player Info");
                    ImGui::Separator();
                    ImGui::Spacing();

                    ImGui::Text("Name: %s", sel->displayName.c_str());
                    ImGui::Text("User ID: %s", sel->userId.c_str());

                    ImGui::Text("Rank: ");
                    ImGui::SameLine(0.f, 0.f);
                    ImGui::TextColored(RankToColor(sel->rank), "%s", RankToName(sel->rank));

                    ImGui::Text("Platform: %s", sel->isQuest ? "Quest" : (sel->isVR ? "VR" : "PC"));
                    ImGui::Spacing();
                    ImGui::Separator();
                    ImGui::Spacing();

                    if (ImGui::Button("Teleport To", ImVec2(-1, 0))) {
                        mgr.m_pendingTeleportTarget.store(sel->playerId, std::memory_order_relaxed);
                    }

                    if (ImGui::Button("Copy Name", ImVec2(-1, 0)))
                        ImGui::SetClipboardText(sel->displayName.c_str());

                    if (ImGui::Button("Copy User ID", ImVec2(-1, 0)))
                        ImGui::SetClipboardText(sel->userId.c_str());

                    ImGui::Spacing();
                    ImGui::Separator();
                    ImGui::Spacing();

                    if (ImGui::TreeNode("Portal Exploits")) {
                        auto* portalMod = mgr.FindModule<PortalSpamModule>();
                        if (portalMod) {
                            bool spamming = portalMod->IsEnabled();
                            const char* label = spamming ? "Stop Portal Spam" : "Portal Spam";
                            if (ImGui::Button(label, ImVec2(-1, 0))) {
                                if (!spamming) {
                                    mgr.m_pendingPortalTarget.store(sel->playerId, std::memory_order_relaxed);
                                }
                                portalMod->Toggle();
                            }
                        }

                        auto* portalOrbitMod = mgr.FindModule<PortalOrbitModule>();
                        if (portalOrbitMod) {
                            bool orbiting = portalOrbitMod->IsEnabled();
                            const char* label = orbiting ? "Stop Portal Orbit" : "Portal Orbit";
                            if (ImGui::Button(label, ImVec2(-1, 0))) {
                                if (!orbiting) {
                                    mgr.m_pendingPortalOrbitTarget.store(sel->playerId, std::memory_order_relaxed);
                                }
                                portalOrbitMod->Toggle();
                            }
                        }

                        ImGui::TreePop();
                    }

                    auto* sitMod = mgr.FindModule<LimbSitModule>();
                    if (sitMod) {
                        bool isSitting = sitMod->IsSitting() && sitMod->GetTargetPlayerId() == sel->playerId;

                        if (ImGui::TreeNode("Limb Sit")) {
                            if (isSitting) {
                                ImGui::TextColored(ImVec4(0.f, 1.f, 0.f, 1.f), "Active");
                                ImGui::SameLine();
                                if (ImGui::SmallButton("Stop")) {
                                    sitMod->ClearTarget();
                                }
                            }

                            struct BoneDef { const char* label; IL2CPP::VRChat::HumanBodyBones bone; };
                            static const BoneDef bones[] = {
                                { "Head",           IL2CPP::VRChat::HumanBodyBones::Head },
                                { "Left Hand",      IL2CPP::VRChat::HumanBodyBones::LeftHand },
                                { "Right Hand",     IL2CPP::VRChat::HumanBodyBones::RightHand },
                                { "Left Shoulder",  IL2CPP::VRChat::HumanBodyBones::LeftShoulder },
                                { "Right Shoulder", IL2CPP::VRChat::HumanBodyBones::RightShoulder },
                                { "Hips",           IL2CPP::VRChat::HumanBodyBones::Hips },
                                { "Left Foot",      IL2CPP::VRChat::HumanBodyBones::LeftFoot },
                                { "Right Foot",     IL2CPP::VRChat::HumanBodyBones::RightFoot },
                                { "Chest",          IL2CPP::VRChat::HumanBodyBones::Chest },
                                { "Left Upper Arm", IL2CPP::VRChat::HumanBodyBones::LeftUpperArm },
                                { "Right Upper Arm",IL2CPP::VRChat::HumanBodyBones::RightUpperArm },
                                { "Left Upper Leg", IL2CPP::VRChat::HumanBodyBones::LeftUpperLeg },
                                { "Right Upper Leg",IL2CPP::VRChat::HumanBodyBones::RightUpperLeg },
                            };

                            ImGui::Columns(2, nullptr, false);
                            for (auto& b : bones) {
                                bool active = isSitting && sitMod->GetTargetBone() == b.bone;
                                if (active)
                                    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.2f, 0.7f, 0.2f, 1.f));

                                if (ImGui::Button(b.label, ImVec2(-1, 0))) {
                                    if (!sitMod->IsEnabled())
                                        sitMod->SetEnabled(true);
                                    sitMod->SetTarget(sel->playerId, b.bone);
                                }

                                if (active)
                                    ImGui::PopStyleColor();

                                ImGui::NextColumn();
                            }
                            ImGui::Columns(1);

                            ImGui::TreePop();
                        }
                    }

                    if (ImGui::TreeNode("Pickup Exploits")) {
                        auto toggleBtn = [&](const char* label, auto* mod) {
                            if (!mod) return;
                            bool on = mod->IsEnabled();
                            if (on) ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.2f, 0.7f, 0.2f, 1.f));
                            if (ImGui::Button(on ? (std::string("Stop ") + label).c_str() : label, ImVec2(-1, 0)))
                                mod->Toggle();
                            if (on) ImGui::PopStyleColor();
                        };

                        toggleBtn("Item Orbit",    mgr.FindModule<ItemOrbitModule>());
                        toggleBtn("Item Clapper",  mgr.FindModule<ItemClapperModule>());
                        toggleBtn("Item Lagger",   mgr.FindModule<ItemLaggerModule>());

                        auto* flingMod = mgr.FindModule<PickupFlingModule>();
                        if (flingMod) {
                            bool flingOn = flingMod->IsEnabled();
                            if (flingOn) ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.2f, 0.7f, 0.2f, 1.f));
                            if (ImGui::Button(flingOn ? "Stop Pickup Fling" : "Pickup Fling", ImVec2(-1, 0))) {
                                if (!flingOn)
                                    flingMod->SetTarget(sel->playerId);
                                flingMod->Toggle();
                            }
                            if (flingOn) ImGui::PopStyleColor();
                        }

                        ImGui::TreePop();
                    }

                    if (HeartbeatManager::Get().IsDev() && !sel->userId.empty()) {
                        ImGui::Spacing();
                        ImGui::Separator();
                        ImGui::Spacing();
                        ImGui::TextColored(c_highlight, "Tags");
                        ImGui::Separator();
                        ImGui::Spacing();

                        ImGui::PushID("pl_tags");

                        auto plTags = TagManager::Get().GetParsedTagsForUser(sel->userId);
                        std::string plRaw = TagManager::Get().GetRawTagsForUser(sel->userId);

                        if (!plTags.empty()) {
                            for (size_t ti = 0; ti < plTags.size(); ++ti) {
                                auto& et = plTags[ti];
                                if (!et.iconName.empty()) {
                                    ImGui::Text("[icon: %s]", et.iconName.c_str());
                                } else {
                                    bool isEditing = (mgr.m_editingTagIndex == static_cast<int>(ti));
                                    if (isEditing) ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.f, 1.f, 0.f, 1.f));
                                    std::string selLabel = et.text + "##pltag_" + std::to_string(ti);
                                    if (ImGui::Selectable(selLabel.c_str(), isEditing, 0, ImVec2(0, 0))) {
                                        mgr.m_editingTagIndex = static_cast<int>(ti);
                                        snprintf(mgr.m_tagInputBuf, sizeof(mgr.m_tagInputBuf), "%s", et.text.c_str());
                                        mgr.m_tagColor[0] = et.color.r;
                                        mgr.m_tagColor[1] = et.color.g;
                                        mgr.m_tagColor[2] = et.color.b;
                                        uint16_t f = et.animFlags;
                                        if (f == Anim_None && et.animation != AnimationType::None)
                                            f = AnimTypeToFlag(et.animation);
                                        mgr.m_tagRainbow = (f & Anim_Rainbow) != 0;
                                        mgr.m_tagSmoothRainbow = (f & Anim_SmoothRainbow) != 0;
                                        mgr.m_tagBlink = (f & Anim_Blink) != 0;
                                        mgr.m_tagScroll = (f & Anim_Scroll) != 0;
                                        mgr.m_tagCylinder = (f & Anim_Cylinder) != 0;
                                        mgr.m_tagPulse = (f & Anim_Pulse) != 0;
                                        mgr.m_tagGlitch = (f & Anim_Glitch) != 0;
                                        mgr.m_tagJump = (f & Anim_Jump) != 0;
                                        mgr.m_tagShake = (f & Anim_Shake) != 0;
                                        mgr.m_tagGhostTrail = (f & Anim_GhostTrail) != 0;
                                        mgr.m_tagLBL = (f & Anim_LetterByLetter) != 0;
                                    }
                                    if (isEditing) ImGui::PopStyleColor();
                                }
                                ImGui::SameLine();
                                std::string rmLabel = "X##rm_" + std::to_string(ti);
                                if (ImGui::SmallButton(rmLabel.c_str())) {
                                    if (mgr.m_editingTagIndex == static_cast<int>(ti))
                                        mgr.m_editingTagIndex = -1;
                                    std::vector<std::string> rawParts;
                                    std::istringstream ss(plRaw);
                                    std::string part;
                                    while (std::getline(ss, part, ','))
                                        if (!part.empty()) rawParts.push_back(part);
                                    if (ti < rawParts.size())
                                        rawParts.erase(rawParts.begin() + ti);
                                    if (rawParts.empty()) {
                                        HeartbeatManager::Get().ApiRemoveTag(sel->userId);
                                    } else {
                                        std::string combined;
                                        for (size_t j = 0; j < rawParts.size(); ++j) {
                                            if (j > 0) combined += ",";
                                            combined += rawParts[j];
                                        }
                                        HeartbeatManager::Get().ApiSetTag(sel->userId, combined);
                                    }
                                }
                            }
                        } else {
                            ImGui::TextDisabled("No tags");
                        }

                        ImGui::Spacing();
                        bool plEditing = mgr.m_editingTagIndex >= 0;
                        ImGui::Text(plEditing ? "Edit Tag:" : "New Tag:");
                        ImGui::InputText("##pl_tag_in", mgr.m_tagInputBuf, sizeof(mgr.m_tagInputBuf));

                        ImGui::Checkbox("Rainbow", &mgr.m_tagRainbow);
                        ImGui::SameLine();
                        ImGui::Checkbox("Smooth RB", &mgr.m_tagSmoothRainbow);
                        ImGui::Checkbox("Blink", &mgr.m_tagBlink);
                        ImGui::SameLine();
                        ImGui::Checkbox("Scroll", &mgr.m_tagScroll);
                        ImGui::Checkbox("Cylinder", &mgr.m_tagCylinder);
                        ImGui::SameLine();
                        ImGui::Checkbox("Pulse", &mgr.m_tagPulse);
                        ImGui::Checkbox("Jump", &mgr.m_tagJump);
                        ImGui::SameLine();
                        ImGui::Checkbox("Shake", &mgr.m_tagShake);
                        ImGui::Checkbox("Ghost Trail", &mgr.m_tagGhostTrail);
                        ImGui::SameLine();
                        ImGui::Checkbox("Glitch", &mgr.m_tagGlitch);
                        ImGui::Checkbox("Letter by Letter", &mgr.m_tagLBL);

                        if (mgr.m_tagRainbow) mgr.m_tagSmoothRainbow = false;
                        if (mgr.m_tagSmoothRainbow) mgr.m_tagRainbow = false;

                        bool plIsRainbow = mgr.m_tagRainbow || mgr.m_tagSmoothRainbow;

                        if (!plIsRainbow) {
                            ImGui::ColorEdit3("##pl_tag_col", mgr.m_tagColor, ImGuiColorEditFlags_NoInputs);
                            ImGui::SameLine();
                            if (ImGui::SmallButton("Red")) { mgr.m_tagColor[0]=1.f; mgr.m_tagColor[1]=0.f; mgr.m_tagColor[2]=0.f; }
                            ImGui::SameLine();
                            if (ImGui::SmallButton("Blue")) { mgr.m_tagColor[0]=0.f; mgr.m_tagColor[1]=0.4f; mgr.m_tagColor[2]=1.f; }
                            ImGui::SameLine();
                            if (ImGui::SmallButton("Green")) { mgr.m_tagColor[0]=0.f; mgr.m_tagColor[1]=0.9f; mgr.m_tagColor[2]=0.3f; }
                            if (ImGui::SmallButton("Gold")) { mgr.m_tagColor[0]=1.f; mgr.m_tagColor[1]=0.84f; mgr.m_tagColor[2]=0.f; }
                            ImGui::SameLine();
                            if (ImGui::SmallButton("Purple")) { mgr.m_tagColor[0]=0.55f; mgr.m_tagColor[1]=0.16f; mgr.m_tagColor[2]=0.88f; }
                            ImGui::SameLine();
                            if (ImGui::SmallButton("Pink")) { mgr.m_tagColor[0]=1.f; mgr.m_tagColor[1]=0.4f; mgr.m_tagColor[2]=0.7f; }
                            ImGui::SameLine();
                            if (ImGui::SmallButton("White")) { mgr.m_tagColor[0]=1.f; mgr.m_tagColor[1]=1.f; mgr.m_tagColor[2]=1.f; }
                        }

                        auto plBuildTag = [&]() -> std::string {
                            std::string newTag;
                            if (mgr.m_tagRainbow) newTag += ":RAIN";
                            if (mgr.m_tagSmoothRainbow) newTag += ":SR";
                            if (mgr.m_tagBlink) newTag += ":BLINK";
                            if (mgr.m_tagScroll) newTag += ":SCROLL";
                            if (mgr.m_tagCylinder) newTag += ":CYLN";
                            if (mgr.m_tagPulse) newTag += ":PULSE";
                            if (mgr.m_tagJump) newTag += ":JUMP";
                            if (mgr.m_tagShake) newTag += ":SHAKE";
                            if (mgr.m_tagGhostTrail) newTag += ":GT";
                            if (mgr.m_tagGlitch) newTag += ":GLITCH";
                            if (mgr.m_tagLBL) newTag += ":LBL";
                            if (!newTag.empty()) newTag += ":";
                            std::string text(mgr.m_tagInputBuf);
                            if (plIsRainbow) {
                                newTag += text;
                            } else {
                                int r = static_cast<int>(mgr.m_tagColor[0] * 255.f);
                                int g = static_cast<int>(mgr.m_tagColor[1] * 255.f);
                                int b = static_cast<int>(mgr.m_tagColor[2] * 255.f);
                                char hexBuf[16];
                                snprintf(hexBuf, sizeof(hexBuf), "%02X%02X%02X", r, g, b);
                                newTag += "<color=#" + std::string(hexBuf) + ">" + text + "</color>";
                            }
                            return newTag;
                        };

                        if (plEditing) {
                            if (ImGui::Button("Save Tag", ImVec2(-1, 0))) {
                                std::string text(mgr.m_tagInputBuf);
                                if (!text.empty()) {
                                    std::vector<std::string> rawParts;
                                    std::istringstream ss(plRaw);
                                    std::string part;
                                    while (std::getline(ss, part, ','))
                                        if (!part.empty()) rawParts.push_back(part);
                                    int idx = mgr.m_editingTagIndex;
                                    std::string newTag = plBuildTag();
                                    if (idx >= 0 && idx < static_cast<int>(rawParts.size()))
                                        rawParts[idx] = newTag;
                                    std::string combined;
                                    for (size_t j = 0; j < rawParts.size(); ++j) {
                                        if (j > 0) combined += ",";
                                        combined += rawParts[j];
                                    }
                                    HeartbeatManager::Get().ApiSetTag(sel->userId, combined);
                                    mgr.m_editingTagIndex = -1;
                                    mgr.m_tagInputBuf[0] = '\0';
                                }
                            }
                            if (ImGui::Button("Cancel", ImVec2(-1, 0))) {
                                mgr.m_editingTagIndex = -1;
                                mgr.m_tagInputBuf[0] = '\0';
                            }
                        } else {
                            if (ImGui::Button("Add Tag", ImVec2(-1, 0))) {
                                std::string text(mgr.m_tagInputBuf);
                                if (!text.empty()) {
                                    std::string newTag = plBuildTag();
                                    std::string fullLine = plRaw.empty() ? newTag : plRaw + "," + newTag;
                                    HeartbeatManager::Get().ApiSetTag(sel->userId, fullLine);
                                    mgr.m_tagInputBuf[0] = '\0';
                                }
                            }
                        }

                        if (!plTags.empty()) {
                            if (ImGui::Button("Remove All Tags", ImVec2(-1, 0))) {
                                HeartbeatManager::Get().ApiRemoveTag(sel->userId);
                                mgr.m_editingTagIndex = -1;
                            }
                        }

                        ImGui::Spacing();
                        ImGui::TextColored(c_highlight, "Icon");
                        ImGui::Separator();
                        ImGui::Spacing();

                        static const char* plIconNames[] = { "none", "terminal", "gauge", "airplane", "crosshair", "id_card", "users", "music", "door" };

                        std::string plCurrentIcon;
                        for (auto& et : plTags) {
                            if (!et.iconName.empty()) { plCurrentIcon = et.iconName; break; }
                        }

                        int plIconIdx = 0;
                        for (int ii = 0; ii < 9; ++ii) {
                            if (plCurrentIcon == plIconNames[ii]) { plIconIdx = ii; break; }
                        }

                        if (ImGui::Combo("##pl_icon", &plIconIdx, plIconNames, 9)) {
                            std::vector<std::string> rawParts;
                            std::istringstream ss(plRaw);
                            std::string part;
                            while (std::getline(ss, part, ','))
                                if (!part.empty()) rawParts.push_back(part);

                            rawParts.erase(
                                std::remove_if(rawParts.begin(), rawParts.end(),
                                    [](const std::string& s) { return s.size() > 6 && s.substr(0, 6) == "<icon="; }),
                                rawParts.end());

                            if (plIconIdx > 0)
                                rawParts.push_back(std::string("<icon=") + plIconNames[plIconIdx] + ">");

                            if (rawParts.empty()) {
                                HeartbeatManager::Get().ApiRemoveTag(sel->userId);
                            } else {
                                std::string combined;
                                for (size_t j = 0; j < rawParts.size(); ++j) {
                                    if (j > 0) combined += ",";
                                    combined += rawParts[j];
                                }
                                HeartbeatManager::Get().ApiSetTag(sel->userId, combined);
                            }
                        }

                        ImGui::PopID();
                    }
                } else {
                    ImGui::TextDisabled("Select a player");
                }

                if (g_fontMediumBold) ImGui::PopFont();
            }
            ImGui::EndChild();

          } else {
            auto& hist = InstanceHistory::Get();
            auto histEntries2 = hist.GetEntries();

            ImGui::BeginChild("##ih_list", ImVec2(0, 0), true);
            {
                if (g_fontMediumBold) ImGui::PushFont(g_fontMediumBold);

                if (histEntries2.empty()) {
                    ImGui::TextDisabled("No instance history yet");
                } else {
                    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.4f, 0.1f, 0.1f, 0.8f));
                    if (ImGui::SmallButton("Clear History"))
                        hist.Clear();
                    ImGui::PopStyleColor();
                    ImGui::Spacing();
                    ImGui::Separator();
                    ImGui::Spacing();

                    int64_t now = static_cast<int64_t>(std::time(nullptr));
                    float thumbSz = 52.f;
                    float btnW = 80.f;

                    for (size_t i = 0; i < histEntries2.size(); ++i) {
                        auto& e = histEntries2[i];
                        ImGui::PushID(static_cast<int>(i));

                        hist.RequestThumbnailIfNeeded(e.worldId, e.thumbnailUrl);
                        void* thumbSrv = hist.GetThumbnailSRV(e.worldId);

                        if (thumbSrv) {
                            ImGui::Image(reinterpret_cast<ImTextureID>(thumbSrv), ImVec2(thumbSz, thumbSz));
                        } else {
                            ImGui::Dummy(ImVec2(thumbSz, thumbSz));
                            ImVec2 pMin = ImGui::GetItemRectMin();
                            ImVec2 pMax = ImGui::GetItemRectMax();
                            ImGui::GetWindowDrawList()->AddRectFilled(pMin, pMax,
                                IM_COL32(30, 30, 40, 200), 4.f);
                        }

                        ImGui::SameLine();

                        {
                            std::string name = e.worldName.empty() ? e.worldId : e.worldName;
                            if (name.size() > 45) name = name.substr(0, 42) + "...";

                            int64_t diff = now - e.timestamp;
                            std::string timeStr;
                            if (diff < 60) timeStr = "just now";
                            else if (diff < 3600) timeStr = std::to_string(diff / 60) + "m ago";
                            else if (diff < 86400) timeStr = std::to_string(diff / 3600) + "h ago";
                            else timeStr = std::to_string(diff / 86400) + "d ago";

                            std::string sub = timeStr;
                            if (e.maxPlayers > 0)
                                sub += "  |  " + std::to_string(e.playerCount) + "/" + std::to_string(e.maxPlayers) + " Players";
                            else if (e.playerCount > 0)
                                sub += "  |  " + std::to_string(e.playerCount) + " players";

                            ImGui::TextColored(c_highlight, "%s", name.c_str());

                            if (!e.worldId.empty() && e.worldId != name) {
                                std::string shortId = e.worldId;
                                if (shortId.size() > 40) shortId = shortId.substr(0, 37) + "...";
                                ImGui::TextColored(ImVec4(0.45f, 0.45f, 0.50f, 1.f), "%s", shortId.c_str());
                            }

                            ImGui::TextColored(ImVec4(0.55f, 0.55f, 0.60f, 1.f), "%s", sub.c_str());

                            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(c_highlight.x, c_highlight.y, c_highlight.z, 0.5f));
                            if (ImGui::Button("Rejoin", ImVec2(btnW, 0))) {
                                std::string loc = e.locationString;
                                if (loc.empty()) loc = e.worldId;
                                if (!loc.empty())
                                    mgr.QueueForceJoin(loc);
                            }
                            ImGui::PopStyleColor();
                        }

                        ImGui::Spacing();
                        ImGui::Spacing();
                        ImGui::Separator();
                        ImGui::Spacing();
                        ImGui::Spacing();

                        ImGui::PopID();
                    }
                }

                if (g_fontMediumBold) ImGui::PopFont();
            }
            ImGui::EndChild();
          }
        }
        ImGui::End();

        ImGui::PopStyleColor(2);
    }

    void ModuleManager::RenderAdminPanel(ModuleManager& mgr, const ImGuiIO& io) {
        float plW = io.DisplaySize.x * 0.45f;
        float plH = io.DisplaySize.y * 0.55f;
        float plLeft = io.DisplaySize.x * 0.5f - plW * 0.5f;
        float plTop = io.DisplaySize.y * 0.5f - plH * 0.5f;

        float panelW = 360.f;
        float gap = 8.f;

        ImGui::SetNextWindowPos(ImVec2(plLeft - panelW - gap, plTop));
        ImGui::SetNextWindowSize(ImVec2(panelW, plH));

        const ImVec4 purple(0.549f, 0.157f, 0.882f, 1.0f);

        ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.03f, 0.03f, 0.05f, 0.95f));
        ImGui::PushStyleColor(ImGuiCol_Border, purple);
        ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.04f, 0.04f, 0.06f, 0.6f));
        ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 2.0f);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(12, 10));

        ImGui::Begin("##nyx_admin", nullptr,
            ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse |
            ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoMove);

        if (g_fontBig) ImGui::PushFont(g_fontBig);
        ImGui::TextColored(purple, "nyx");
        ImGui::SameLine(0.f, 0.f);
        ImGui::Text(" admin");
        if (g_fontBig) ImGui::PopFont();

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        auto users = HeartbeatManager::Get().GetActiveUsers();

        const ActiveUser* sel = nullptr;
        for (auto& u : *users) {
            if (u.userId == mgr.m_selectedAdminUserId) {
                sel = &u;
                break;
            }
        }
        if (!sel && !mgr.m_selectedAdminUserId.empty())
            mgr.m_selectedAdminUserId.clear();

        const ImVec4 devGoldText(1.0f, 0.84f, 0.0f, 1.0f);
        float listH = plH * 0.45f;
        ImGui::BeginChild("##admin_users", ImVec2(0, listH), true);
        {
            if (g_fontMediumBold) ImGui::PushFont(g_fontMediumBold);

            bool hasDevs = false, hasUsers = false;
            for (auto& u : *users) {
                if (u.isDev) hasDevs = true;
                else hasUsers = true;
            }

            auto renderUserRow = [&](const ActiveUser& u, const ImVec4* color) {
                std::string label = u.displayName + "  [" + std::to_string(u.fps) + " fps]##" + u.userId;
                if (color) ImGui::PushStyleColor(ImGuiCol_Text, *color);
                if (ImGui::Selectable(label.c_str(), mgr.m_selectedAdminUserId == u.userId))
                    mgr.m_selectedAdminUserId = u.userId;
                if (color) ImGui::PopStyleColor();

                std::string ctxId = "##ctx_" + u.userId;
                if (ImGui::BeginPopupContextItem(ctxId.c_str())) {
                    mgr.m_selectedAdminUserId = u.userId;

                    std::string localUserId = HeartbeatManager::Get().GetLocalUserId();
                    bool isLocal = (u.userId == localUserId);

                    if (ImGui::MenuItem("Close Game")) {
                        if (isLocal) {
                            TerminateProcess(GetCurrentProcess(), 0);
                        } else {
                            HeartbeatManager::Get().ApiSendCommand(u.userId, "close_game");
                            DashboardConsole::Get().AddLog("[Admin] Sent close_game to " + u.displayName, DashboardConsole::LogColor::System);
                        }
                    }

                    std::string localWorldId = HeartbeatManager::Get().GetLocalWorldId();

                    if (!localWorldId.empty()) {
                        bool localPrivate = localWorldId.find("~private") != std::string::npos ||
                                            localWorldId.find("~hidden") != std::string::npos;
                        if (localPrivate) {
                            if (ImGui::MenuItem("Force Join to Me (Invite)")) {
                                if (isLocal) {
                                    DashboardConsole::Get().AddLog("[Admin] You're already here", DashboardConsole::LogColor::System);
                                } else {
                                    VRChatApi::Get().SendInvite(u.userId, localWorldId);
                                    HeartbeatManager::Get().ApiSendCommand(u.userId, "accept_invite", HeartbeatManager::Get().GetLocalUserId());
                                    DashboardConsole::Get().AddLog("[Admin] Sent VRC invite + accept command to " + u.displayName, DashboardConsole::LogColor::System);
                                }
                            }
                        } else {
                            if (ImGui::MenuItem("Force Join to Me")) {
                                if (isLocal) {
                                    DashboardConsole::Get().AddLog("[Admin] You're already here", DashboardConsole::LogColor::System);
                                } else {
                                    HeartbeatManager::Get().ApiSendCommand(u.userId, "force_join", localWorldId);
                                    DashboardConsole::Get().AddLog("[Admin] Sent force_join to " + u.displayName, DashboardConsole::LogColor::System);
                                }
                            }
                        }
                    } else {
                        ImGui::BeginDisabled();
                        ImGui::MenuItem("Force Join to Me (no world)");
                        ImGui::EndDisabled();
                    }

                    ImGui::EndPopup();
                }
            };

            if (hasDevs) {
                ImGui::TextColored(devGoldText, "Developers");
                ImGui::Separator();
                for (auto& u : *users) {
                    if (!u.isDev) continue;
                    renderUserRow(u, &devGoldText);
                }
                ImGui::Spacing();
            }

            if (hasUsers) {
                ImGui::TextColored(purple, "Users");
                ImGui::Separator();
                for (auto& u : *users) {
                    if (u.isDev) continue;
                    renderUserRow(u, nullptr);
                }
            }

            if (users->empty())
                ImGui::TextDisabled("No active users");

            if (g_fontMediumBold) ImGui::PopFont();
        }
        ImGui::EndChild();

        if (mgr.m_selectedAdminUserId != mgr.m_prevSelectedAdminUserId) {
            mgr.m_prevSelectedAdminUserId = mgr.m_selectedAdminUserId;
            if (!mgr.m_selectedAdminUserId.empty()) {
                HeartbeatManager::Get().RequestRefresh();
                TagManager::Get().RequestRefresh();
            }
        }

        ImGui::BeginChild("##admin_details", ImVec2(0, 0), true);
        {
            if (g_fontMediumBold) ImGui::PushFont(g_fontMediumBold);

            if (sel) {
                ImGui::TextColored(purple, "User Info");
                ImGui::Separator();
                ImGui::Spacing();

                ImGui::Text("Name: %s", sel->displayName.c_str());
                ImGui::Text("ID: %s", sel->userId.c_str());
                ImGui::Text("Version: %s", sel->clientVersion.c_str());
                if (!sel->worldId.empty()) {
                    std::string displayWorld = sel->worldId;
                    size_t colon = displayWorld.find(':');
                    if (colon != std::string::npos)
                        displayWorld = displayWorld.substr(0, colon);
                    ImGui::Text("World: %s", displayWorld.c_str());
                } else {
                    ImGui::Text("World: (none)");
                }
                ImGui::Text("FPS: %d", sel->fps);

                ImGui::Spacing();
                ImGui::Separator();
                ImGui::Spacing();

                if (!sel->worldId.empty()) {
                    bool isPrivate = sel->worldId.find("~private") != std::string::npos ||
                                     sel->worldId.find("~hidden") != std::string::npos;
                    if (isPrivate) {
                        if (ImGui::Button("Force Join (Invite)", ImVec2(-1, 0))) {
                            VRChatApi::Get().ExpectInviteFrom(sel->userId);
                            HeartbeatManager::Get().ApiSendCommand(sel->userId, "send_invite", HeartbeatManager::Get().GetLocalUserId());
                            DashboardConsole::Get().AddLog("[Admin] Requested invite from " + sel->displayName, DashboardConsole::LogColor::System);
                        }
                    } else {
                        if (ImGui::Button("Force Join", ImVec2(-1, 0))) {
                            mgr.QueueForceJoin(sel->worldId);
                            DashboardConsole::Get().AddLog("[Admin] Force joining " + sel->displayName + "'s world", DashboardConsole::LogColor::System);
                        }
                    }
                } else {
                    ImGui::BeginDisabled();
                    ImGui::Button("Force Join (no world)", ImVec2(-1, 0));
                    ImGui::EndDisabled();
                }

                ImGui::Spacing();
                ImGui::TextColored(purple, "Tags");
                ImGui::Separator();
                ImGui::Spacing();

                auto existingTags = TagManager::Get().GetParsedTagsForUser(sel->userId);
                std::string existingRaw = TagManager::Get().GetRawTagsForUser(sel->userId);

                if (!existingTags.empty()) {
                    for (size_t ti = 0; ti < existingTags.size(); ++ti) {
                        auto& et = existingTags[ti];
                        if (!et.iconName.empty()) {
                            ImGui::Text("[icon: %s]", et.iconName.c_str());
                        } else {
                            bool isEditing = (mgr.m_editingTagIndex == static_cast<int>(ti));
                            if (isEditing) ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.f, 1.f, 0.f, 1.f));
                            std::string selLabel = et.text + "##tag_sel_" + std::to_string(ti);
                            if (ImGui::Selectable(selLabel.c_str(), isEditing, 0, ImVec2(0, 0))) {
                                mgr.m_editingTagIndex = static_cast<int>(ti);
                                snprintf(mgr.m_tagInputBuf, sizeof(mgr.m_tagInputBuf), "%s", et.text.c_str());
                                mgr.m_tagColor[0] = et.color.r;
                                mgr.m_tagColor[1] = et.color.g;
                                mgr.m_tagColor[2] = et.color.b;
                                uint16_t f = et.animFlags;
                                if (f == Anim_None && et.animation != AnimationType::None)
                                    f = AnimTypeToFlag(et.animation);
                                mgr.m_tagRainbow = (f & Anim_Rainbow) != 0;
                                mgr.m_tagSmoothRainbow = (f & Anim_SmoothRainbow) != 0;
                                mgr.m_tagBlink = (f & Anim_Blink) != 0;
                                mgr.m_tagScroll = (f & Anim_Scroll) != 0;
                                mgr.m_tagCylinder = (f & Anim_Cylinder) != 0;
                                mgr.m_tagPulse = (f & Anim_Pulse) != 0;
                                mgr.m_tagGlitch = (f & Anim_Glitch) != 0;
                                mgr.m_tagJump = (f & Anim_Jump) != 0;
                                mgr.m_tagShake = (f & Anim_Shake) != 0;
                                mgr.m_tagGhostTrail = (f & Anim_GhostTrail) != 0;
                                mgr.m_tagLBL = (f & Anim_LetterByLetter) != 0;
                            }
                            if (!et.iconName.empty()) {} else {
                                auto* drawList = ImGui::GetWindowDrawList();
                                auto min = ImGui::GetItemRectMin();
                                auto max = ImGui::GetItemRectMax();
                                ImU32 underlineCol = ImGui::ColorConvertFloat4ToU32(ImVec4(et.color.r, et.color.g, et.color.b, 0.5f));
                                drawList->AddLine(ImVec2(min.x, max.y), ImVec2(max.x, max.y), underlineCol);
                            }
                            if (isEditing) ImGui::PopStyleColor();
                        }
                        ImGui::SameLine();
                        std::string rmLabel = "X##rm_tag_" + std::to_string(ti);
                        if (ImGui::SmallButton(rmLabel.c_str())) {
                            if (mgr.m_editingTagIndex == static_cast<int>(ti))
                                mgr.m_editingTagIndex = -1;
                            std::vector<std::string> rawParts;
                            std::istringstream ss(existingRaw);
                            std::string part;
                            while (std::getline(ss, part, ','))
                                if (!part.empty()) rawParts.push_back(part);
                            if (ti < rawParts.size())
                                rawParts.erase(rawParts.begin() + ti);
                            if (rawParts.empty()) {
                                HeartbeatManager::Get().ApiRemoveTag(sel->userId);
                            } else {
                                std::string combined;
                                for (size_t j = 0; j < rawParts.size(); ++j) {
                                    if (j > 0) combined += ",";
                                    combined += rawParts[j];
                                }
                                HeartbeatManager::Get().ApiSetTag(sel->userId, combined);
                            }
                        }
                    }
                } else {
                    ImGui::TextDisabled("No tags");
                }

                ImGui::Spacing();
                bool editing = mgr.m_editingTagIndex >= 0;
                ImGui::Text(editing ? "Edit Tag:" : "New Tag:");
                ImGui::InputText("##tag_input", mgr.m_tagInputBuf, sizeof(mgr.m_tagInputBuf));

                ImGui::Checkbox("Rainbow", &mgr.m_tagRainbow);
                ImGui::SameLine();
                ImGui::Checkbox("Smooth RB", &mgr.m_tagSmoothRainbow);
                ImGui::Checkbox("Blink", &mgr.m_tagBlink);
                ImGui::SameLine();
                ImGui::Checkbox("Scroll", &mgr.m_tagScroll);
                ImGui::Checkbox("Cylinder", &mgr.m_tagCylinder);
                ImGui::SameLine();
                ImGui::Checkbox("Pulse", &mgr.m_tagPulse);
                ImGui::Checkbox("Jump", &mgr.m_tagJump);
                ImGui::SameLine();
                ImGui::Checkbox("Shake", &mgr.m_tagShake);
                ImGui::Checkbox("Ghost Trail", &mgr.m_tagGhostTrail);
                ImGui::SameLine();
                ImGui::Checkbox("Glitch", &mgr.m_tagGlitch);
                ImGui::Checkbox("Letter by Letter", &mgr.m_tagLBL);

                if (mgr.m_tagRainbow) mgr.m_tagSmoothRainbow = false;
                if (mgr.m_tagSmoothRainbow) mgr.m_tagRainbow = false;

                bool isRainbow = mgr.m_tagRainbow || mgr.m_tagSmoothRainbow;

                if (!isRainbow) {
                    ImGui::ColorEdit3("##tag_color", mgr.m_tagColor, ImGuiColorEditFlags_NoInputs);
                    ImGui::SameLine();
                    if (ImGui::SmallButton("Red")) { mgr.m_tagColor[0]=1.f; mgr.m_tagColor[1]=0.f; mgr.m_tagColor[2]=0.f; }
                    ImGui::SameLine();
                    if (ImGui::SmallButton("Blue")) { mgr.m_tagColor[0]=0.f; mgr.m_tagColor[1]=0.4f; mgr.m_tagColor[2]=1.f; }
                    ImGui::SameLine();
                    if (ImGui::SmallButton("Green")) { mgr.m_tagColor[0]=0.f; mgr.m_tagColor[1]=0.9f; mgr.m_tagColor[2]=0.3f; }
                    if (ImGui::SmallButton("Gold")) { mgr.m_tagColor[0]=1.f; mgr.m_tagColor[1]=0.84f; mgr.m_tagColor[2]=0.f; }
                    ImGui::SameLine();
                    if (ImGui::SmallButton("Purple")) { mgr.m_tagColor[0]=0.55f; mgr.m_tagColor[1]=0.16f; mgr.m_tagColor[2]=0.88f; }
                    ImGui::SameLine();
                    if (ImGui::SmallButton("Pink")) { mgr.m_tagColor[0]=1.f; mgr.m_tagColor[1]=0.4f; mgr.m_tagColor[2]=0.7f; }
                    ImGui::SameLine();
                    if (ImGui::SmallButton("White")) { mgr.m_tagColor[0]=1.f; mgr.m_tagColor[1]=1.f; mgr.m_tagColor[2]=1.f; }
                }

                auto buildTagString = [&]() -> std::string {
                    std::string newTag;
                    if (mgr.m_tagRainbow) newTag += ":RAIN";
                    if (mgr.m_tagSmoothRainbow) newTag += ":SR";
                    if (mgr.m_tagBlink) newTag += ":BLINK";
                    if (mgr.m_tagScroll) newTag += ":SCROLL";
                    if (mgr.m_tagCylinder) newTag += ":CYLN";
                    if (mgr.m_tagPulse) newTag += ":PULSE";
                    if (mgr.m_tagJump) newTag += ":JUMP";
                    if (mgr.m_tagShake) newTag += ":SHAKE";
                    if (mgr.m_tagGhostTrail) newTag += ":GT";
                    if (mgr.m_tagGlitch) newTag += ":GLITCH";
                    if (mgr.m_tagLBL) newTag += ":LBL";
                    if (!newTag.empty()) newTag += ":";

                    std::string text(mgr.m_tagInputBuf);
                    if (isRainbow) {
                        newTag += text;
                    } else {
                        int r = static_cast<int>(mgr.m_tagColor[0] * 255.f);
                        int g = static_cast<int>(mgr.m_tagColor[1] * 255.f);
                        int b = static_cast<int>(mgr.m_tagColor[2] * 255.f);
                        char hexBuf[16];
                        snprintf(hexBuf, sizeof(hexBuf), "%02X%02X%02X", r, g, b);
                        newTag += "<color=#" + std::string(hexBuf) + ">" + text + "</color>";
                    }
                    return newTag;
                };

                if (editing) {
                    if (ImGui::Button("Save Tag", ImVec2(-1, 0))) {
                        std::string text(mgr.m_tagInputBuf);
                        if (!text.empty()) {
                            std::vector<std::string> rawParts;
                            std::istringstream ss(existingRaw);
                            std::string part;
                            while (std::getline(ss, part, ','))
                                if (!part.empty()) rawParts.push_back(part);
                            int idx = mgr.m_editingTagIndex;
                            std::string newTag = buildTagString();
                            if (idx >= 0 && idx < static_cast<int>(rawParts.size()))
                                rawParts[idx] = newTag;
                            std::string combined;
                            for (size_t j = 0; j < rawParts.size(); ++j) {
                                if (j > 0) combined += ",";
                                combined += rawParts[j];
                            }
                            HeartbeatManager::Get().ApiSetTag(sel->userId, combined);
                            mgr.m_editingTagIndex = -1;
                            mgr.m_tagInputBuf[0] = '\0';
                        }
                    }
                    if (ImGui::Button("Cancel", ImVec2(-1, 0))) {
                        mgr.m_editingTagIndex = -1;
                        mgr.m_tagInputBuf[0] = '\0';
                    }
                } else {
                    if (ImGui::Button("Add Tag", ImVec2(-1, 0))) {
                        std::string text(mgr.m_tagInputBuf);
                        if (!text.empty()) {
                            std::string newTag = buildTagString();
                            std::string fullLine = existingRaw.empty() ? newTag : existingRaw + "," + newTag;
                            HeartbeatManager::Get().ApiSetTag(sel->userId, fullLine);
                            mgr.m_tagInputBuf[0] = '\0';
                        }
                    }
                }

                if (!existingTags.empty()) {
                    if (ImGui::Button("Remove All Tags", ImVec2(-1, 0))) {
                        HeartbeatManager::Get().ApiRemoveTag(sel->userId);
                        mgr.m_editingTagIndex = -1;
                    }
                }

                ImGui::Spacing();
                ImGui::TextColored(purple, "Icon");
                ImGui::Separator();
                ImGui::Spacing();

                static const char* iconNames[] = { "none", "terminal", "gauge", "airplane", "crosshair", "id_card", "users", "music", "door" };

                std::string currentIcon;
                for (auto& et : existingTags) {
                    if (!et.iconName.empty()) { currentIcon = et.iconName; break; }
                }

                int currentIdx = 0;
                for (int ii = 0; ii < 9; ++ii) {
                    if (currentIcon == iconNames[ii]) { currentIdx = ii; break; }
                }

                if (ImGui::Combo("##icon_select", &currentIdx, iconNames, 9)) {
                    std::vector<std::string> rawParts;
                    std::istringstream ss(existingRaw);
                    std::string part;
                    while (std::getline(ss, part, ','))
                        if (!part.empty()) rawParts.push_back(part);

                    rawParts.erase(
                        std::remove_if(rawParts.begin(), rawParts.end(),
                            [](const std::string& s) { return s.size() > 6 && s.substr(0, 6) == "<icon="; }),
                        rawParts.end());

                    if (currentIdx > 0) {
                        rawParts.push_back(std::string("<icon=") + iconNames[currentIdx] + ">");
                    }

                    if (rawParts.empty()) {
                        HeartbeatManager::Get().ApiRemoveTag(sel->userId);
                    } else {
                        std::string combined;
                        for (size_t j = 0; j < rawParts.size(); ++j) {
                            if (j > 0) combined += ",";
                            combined += rawParts[j];
                        }
                        HeartbeatManager::Get().ApiSetTag(sel->userId, combined);
                    }
                    DashboardConsole::Get().AddLog("[Admin] Set icon: " + std::string(iconNames[currentIdx]) + " for " + sel->displayName, DashboardConsole::LogColor::System);
                }

                ImGui::Spacing();
                ImGui::Separator();
                ImGui::Spacing();

                if (ImGui::Button("Grant Dev", ImVec2(panelW * 0.44f, 0))) {
                    HeartbeatManager::Get().ApiGrantDev(sel->userId);
                    DashboardConsole::Get().AddLog("[Admin] Granted dev: " + sel->displayName, DashboardConsole::LogColor::Enabled);
                }
                ImGui::SameLine();
                if (ImGui::Button("Revoke Dev", ImVec2(-1, 0))) {
                    HeartbeatManager::Get().ApiRevokeDev(sel->userId);
                    DashboardConsole::Get().AddLog("[Admin] Revoked dev: " + sel->displayName, DashboardConsole::LogColor::Disabled);
                }
            } else {
                ImGui::TextDisabled("Select an active user");
            }

            if (g_fontMediumBold) ImGui::PopFont();
        }
        ImGui::EndChild();

        ImGui::End();
        ImGui::PopStyleVar(2);
        ImGui::PopStyleColor(3);
    }

    void ModuleManager::Resize(uint32_t, uint32_t) {
        Renderer::OnResize();
    }

    bool ModuleManager::OnWndProc(void* hWnd, uint32_t uMsg, uintptr_t wParam, intptr_t lParam) {
        auto& mgr = Get();

        if (uMsg == WM_KEYDOWN) {
            if (!(lParam & (1 << 30))) {
                for (auto& mod : mgr.m_modules) {
                    if (mod->GetKeybind() != 0 &&
                        static_cast<uint32_t>(wParam) == mod->GetKeybind()) {
                        // Skip 'F'/'G' key unless Ctrl is held (Noclip uses Ctrl+F, GhostMode uses Ctrl+G)
                        if ((mod->GetKeybind() == 'F' || mod->GetKeybind() == 'G') && !(GetAsyncKeyState(VK_CONTROL) & 0x8000))
                            continue;
                        mod->Toggle();
                    }
                }

                if (static_cast<uint32_t>(wParam) == VK_TAB)
                    mgr.m_playerlistOpen = true;

                if (static_cast<uint32_t>(wParam) == VK_F9) {
                    std::lock_guard lock(mgr.m_pendingCmdMutex);
                    if (mgr.m_pendingCmd.active) {
                        auto& cmd = mgr.m_pendingCmd;
                        if (cmd.type == "force_join" && !cmd.worldId.empty()) {
                            FLOG("[ModuleManager] User accepted force_join: {}", cmd.worldId);
                            mgr.m_pendingForceJoin = cmd.worldId;
                            DashboardConsole::Get().AddLog("[Remote] Accepted — joining world", DashboardConsole::LogColor::System);
                        } else if (cmd.type == "send_invite" && !cmd.worldId.empty()) {
                            std::string localWorldId = HeartbeatManager::Get().GetLocalWorldId();
                            if (!localWorldId.empty()) {
                                VRChatApi::Get().SendInvite(cmd.worldId, localWorldId);
                                DashboardConsole::Get().AddLog("[Remote] Accepted — sent invite", DashboardConsole::LogColor::System);
                            }
                        } else if (cmd.type == "accept_invite" && !cmd.worldId.empty()) {
                            VRChatApi::Get().ExpectInviteFrom(cmd.worldId);
                            DashboardConsole::Get().AddLog("[Remote] Accepted — will auto-accept invite", DashboardConsole::LogColor::System);
                        }
                        cmd.active = false;
                    }
                }

                if (static_cast<uint32_t>(wParam) == VK_F10) {
                    std::lock_guard lock(mgr.m_pendingCmdMutex);
                    if (mgr.m_pendingCmd.active) {
                        FLOG("[ModuleManager] User declined remote command: {}", mgr.m_pendingCmd.type);
                        DashboardConsole::Get().AddLog("[Remote] Declined developer request", DashboardConsole::LogColor::System);
                        mgr.m_pendingCmd.active = false;
                    }
                }
            }
        }

        if (uMsg == WM_KEYUP) {
            if (static_cast<uint32_t>(wParam) == VK_TAB)
                mgr.m_playerlistOpen = false;
        }

        if (Renderer::IsInitialized()) {
            ImGui_ImplWin32_WndProcHandler(
                static_cast<HWND>(hWnd), uMsg,
                static_cast<WPARAM>(wParam), static_cast<LPARAM>(lParam));

            ImGuiIO& io = ImGui::GetIO();
            io.MouseDrawCursor = mgr.m_playerlistOpen;
            if (mgr.m_playerlistOpen) {
                io.WantCaptureMouse = true;
                if (uMsg >= WM_MOUSEFIRST && uMsg <= WM_MOUSELAST)
                    return true;
            }
        }

        for (auto& mod : mgr.m_modules) {
            if (mod->IsEnabled() && mod->OnEvent(uMsg, wParam, lParam))
                return true;
        }

        return false;
    }

    // ── QuickMenu setup ──

    static constexpr size_t kMaxQmModules = 64;
    static size_t s_qmModuleIndices[kMaxQmModules] = {};
    static uint32_t s_qmToggleIds[kMaxQmModules] = {};
    static size_t s_qmToggleCount = 0;

    void __cdecl QmToggleCallback(uint32_t button_id, bool is_on) {
        for (size_t i = 0; i < s_qmToggleCount; ++i) {
            if (s_qmToggleIds[i] == button_id) {
                auto& mgr = ModuleManager::Get();
                size_t idx = s_qmModuleIndices[i];
                if (idx < mgr.m_modules.size()) {
                    if (mgr.m_modules[idx]->IsEnabled() != is_on)
                        mgr.m_modules[idx]->Toggle();
                }
                return;
            }
        }
    }

    // ── Menu Backgrounds button callback ──
    static constexpr size_t kMaxBgButtons = 16;
    static uint32_t s_bgButtonIds[kMaxBgButtons] = {};
    static size_t   s_bgButtonIndices[kMaxBgButtons] = {};
    static size_t   s_bgButtonCount = 0;

    void __cdecl QmBgButtonCallback(uint32_t button_id) {
        for (size_t i = 0; i < s_bgButtonCount; ++i) {
            if (s_bgButtonIds[i] == button_id) {
                size_t bgIdx = s_bgButtonIndices[i];
                auto& console = DashboardConsole::Get();
                console.SetBackground(bgIdx);
                console.AddLog(
                    std::string("[NYX]: Background set to ") + EmbeddedIcons::k_qm_backgrounds[bgIdx].name,
                    DashboardConsole::LogColor::System);
                return;
            }
        }
    }

    static const std::unordered_map<std::string, uint32_t> s_categoryIconResources = {
        { "World Exploits", IDR_ICON_GLOBE },
    };

    static const std::unordered_map<std::string, Bootstrap::Sprite> s_categoryVrcSprites = {
        { "Movement",  Bootstrap::Sprite::Bundle_Rocket },
        { "Visual",    Bootstrap::Sprite::Bundle_Vision },
        { "UI",        Bootstrap::Sprite::Bundle_SlidersHorizontal },
        { "Exploits",  Bootstrap::Sprite::Bundle_Bug },
        { "Safety",    Bootstrap::Sprite::Bundle_Shield },
        { "Utility",   Bootstrap::Sprite::Bundle_Toolbox },
    };

    static std::unordered_map<uint32_t, uint32_t> s_categoryNavButtons;

    static void __cdecl QmCategoryNavCallback(uint32_t buttonId) {
        auto it = s_categoryNavButtons.find(buttonId);
        if (it != s_categoryNavButtons.end())
            Bootstrap::Module::QuickMenu::Get().navigate_to(it->second);
    }

    // ── Custom backgrounds from C:\nyx\images\ ──
    static constexpr const char* kCustomBgFolder = "C:\\nyx\\images";
    static constexpr size_t kMaxCustomBgButtons = 32;

    struct CustomBgEntry {
        std::string filename;   // just the filename (e.g. "cool.png")
        std::string fullPath;   // full path for loading
        uint32_t    buttonId = 0;
    };

    static CustomBgEntry s_customBgEntries[kMaxCustomBgButtons] = {};
    static size_t        s_customBgCount = 0;
    static uint32_t      s_customBgPageId = 0;

    static bool IsGifPath(const std::string& path) {
        if (path.size() < 4) return false;
        std::string ext = path.substr(path.size() - 4);
        std::transform(ext.begin(), ext.end(), ext.begin(),
            [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
        return ext == ".gif";
    }

    static constexpr const char* kBgConfigPath = "C:/nyx/Config/background.cfg";
    static bool s_bgConfigLoaded = false;

    static void SaveBgConfig(const std::string& filename) {
        std::filesystem::create_directories("C:/nyx/Config");
        std::ofstream f(kBgConfigPath, std::ios::trunc);
        if (f.is_open())
            f << filename << "\n";
    }

    static std::string LoadBgConfig() {
        std::ifstream f(kBgConfigPath);
        if (!f.is_open()) return "";
        std::string line;
        std::getline(f, line);
        return line;
    }

    static std::string s_pendingBgFilename;

    static void ApplyBackground(const std::string& fullPath, const std::string& filename) {
        auto& sprites = SpriteLoader::Get();
        if (IsGifPath(fullPath)) {
            // Check if already cached
            auto* cached = sprites.GetAnimatedGif(fullPath);
            if (cached && !cached->frames.empty()) {
                DashboardConsole::Get().SetAnimatedBackground(cached);
                DashboardConsole::Get().AddLog(
                    std::string("[NYX]: Background set to ") + filename,
                    DashboardConsole::LogColor::System);
                return;
            }
            // Start async decode — will be finalized in OnUpdate
            sprites.LoadAnimatedGifAsync(fullPath);
            s_pendingBgFilename = filename;
            DashboardConsole::Get().AddLog(
                std::string("[NYX]: Loading background ") + filename + "...",
                DashboardConsole::LogColor::System);
        } else {
            void* spr = sprites.LoadFromFile(fullPath);
            if (spr) {
                DashboardConsole::Get().SetBackgroundSprite(spr);
                DashboardConsole::Get().AddLog(
                    std::string("[NYX]: Background set to ") + filename,
                    DashboardConsole::LogColor::System);
            }
        }
    }

    void __cdecl QmCustomBgButtonCallback(uint32_t button_id) {
        for (size_t i = 0; i < s_customBgCount; ++i) {
            if (s_customBgEntries[i].buttonId == button_id) {
                auto& path = s_customBgEntries[i].fullPath;
                // Don't re-trigger if already loading this GIF
                if (IsGifPath(path) && SpriteLoader::Get().IsAsyncLoading(path))
                    return;
                ApplyBackground(path, s_customBgEntries[i].filename);
                SaveBgConfig(s_customBgEntries[i].filename);
                return;
            }
        }
    }

    static const std::unordered_map<std::string, uint32_t> s_moduleIcons = {
        { "Movement",       IDR_ICON_GAUGE },
        { "Noclip",         IDR_ICON_AIRPLANE_TILT },
        { "ESP",            IDR_ICON_CROSSHAIR },
        { "Nameplate Tags", IDR_ICON_IDENTIFICATION_CARD },
        { "Player List",    IDR_ICON_USERS_THREE },
        { "Loading Music",  IDR_ICON_MUSIC_NOTES },
        { "Portal Spam",    IDR_ICON_DOOR },
        { "Spinbot",        IDR_ICON_ARROWS_CLOCKWISE },
        { "Player Rotator", IDR_ICON_CUBE },
        { "Force Grab",     IDR_ICON_HAND_GRABBING },
        { "Ghost Mode",     IDR_ICON_GHOST },
        { "Chatbox Spam",   IDR_ICON_CHAT_TEXT },
    };

    // VRC bundle sprite icons for modules without embedded resource icons
    static const std::unordered_map<std::string, Bootstrap::Sprite> s_moduleVrcIcons = {
        { "Bone ESP",              Bootstrap::Sprite::Bundle_Bone },
        { "Item ESP",              Bootstrap::Sprite::Bundle_FileMagnifyingGlass },
        { "Zoom",                  Bootstrap::Sprite::Bundle_Vision },
        { "Antis",                 Bootstrap::Sprite::Bundle_SealCheck },
        { "QM Cleanup",            Bootstrap::Sprite::Bundle_X },
        { "UI Remover",            Bootstrap::Sprite::Bundle_EyeSlash },
        { "Calendar QM",           Bootstrap::Sprite::Bundle_Scroll },
        { "Capsule Rotation",      Bootstrap::Sprite::Bundle_ArrowsClockwise },
        { "Event 67",              Bootstrap::Sprite::Bundle_Flame },
        { "VRC+ Spoof",            Bootstrap::Sprite::Bundle_Star },
        { "Better Loading Screen", Bootstrap::Sprite::Bundle_FileImage },
    };

    // ── Layout config: file-based at C:\nyx\Config\layout.cfg ──

    static constexpr const char* kLayoutConfigPath = "C:/nyx/Config/layout.cfg";

    static std::set<std::string> LoadLayoutConfig() {
        std::set<std::string> external;
        std::ifstream f(kLayoutConfigPath);
        if (!f.is_open()) {
            // Default: only World Exploits
            external.insert("World Exploits");
            return external;
        }
        std::string line;
        while (std::getline(f, line)) {
            if (!line.empty())
                external.insert(line);
        }
        return external;
    }

    static void SaveLayoutConfig(const std::set<std::string>& external) {
        std::filesystem::create_directories("C:/nyx/Config");
        std::ofstream f(kLayoutConfigPath, std::ios::trunc);
        if (!f.is_open()) return;
        for (auto& cat : external)
            f << cat << "\n";
    }

    // Live layout state
    struct CategorySetupInfo {
        void*    sprite          = nullptr;
        bool     startedExternal = false;
        uint32_t livePageId      = 0;
    };
    static std::map<std::string, CategorySetupInfo> s_categoryInfo;
    static std::unordered_map<uint32_t, std::string> s_layoutToggleCats;
    static std::set<std::string> s_externalCats; // current set of external categories

    static void __cdecl QmLayoutToggleCallback(uint32_t buttonId, bool isOn) {
        auto it = s_layoutToggleCats.find(buttonId);
        if (it == s_layoutToggleCats.end()) return;
        const std::string& cat = it->second;
        auto infoIt = s_categoryInfo.find(cat);
        if (infoIt == s_categoryInfo.end()) return;
        auto& ci = infoIt->second;

        auto& qm = Bootstrap::Module::QuickMenu::Get();
        if (!qm.valid() || !g_mod || !g_mod->valid()) return;
        uint32_t mid = g_mod->id();

        if (!isOn) {
            // Remove from config
            s_externalCats.erase(cat);
            SaveLayoutConfig(s_externalCats);

            if (ci.startedExternal) {
                DashboardConsole::Get().AddLog(
                    "[NYX]: " + cat + " will be removed from sidebar next session",
                    DashboardConsole::LogColor::System);
            } else if (ci.livePageId) {
                qm.remove_page(mid, ci.livePageId);
                ci.livePageId = 0;
                DashboardConsole::Get().AddLog(
                    "[NYX]: " + cat + " removed from sidebar",
                    DashboardConsole::LogColor::System);
            }
            return;
        }

        // Toggle ON — save to config
        s_externalCats.insert(cat);
        SaveLayoutConfig(s_externalCats);

        if (ci.startedExternal || ci.livePageId) return; // already has a sidebar tab

        // Add external sidebar tab live
        auto& mgr = ModuleManager::Get();
        void* spr = ci.sprite;

        uint32_t pageId = qm.create_page(mid, cat, cat);
        if (spr) qm.set_page_icon(mid, pageId, spr);
        auto vrcIt = s_categoryVrcSprites.find(cat);
        if (vrcIt != s_categoryVrcSprites.end())
            qm.set_page_icon(mid, pageId, static_cast<int32_t>(vrcIt->second));
        ci.livePageId = pageId;

        auto& sprites = SpriteLoader::Get();
        for (size_t i = 0; i < mgr.m_modules.size(); ++i) {
            if (mgr.m_modules[i]->GetCategory() != cat) continue;
            if (!mgr.m_modules[i]->ShowInQuickMenu()) continue;

            std::string name(mgr.m_modules[i]->GetName());
            std::string key = name;
            std::transform(key.begin(), key.end(), key.begin(),
                [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
            for (auto& ch : key) { if (ch == ' ') ch = '_'; }
            key += "_enabled";

            uint32_t tid = qm.add_toggle(mid, pageId,
                name, mgr.m_modules[i]->IsEnabled(), QmToggleCallback, key);

            if (s_qmToggleCount < kMaxQmModules) {
                s_qmModuleIndices[s_qmToggleCount] = i;
                s_qmToggleIds[s_qmToggleCount] = tid;
                ++s_qmToggleCount;
            }

            auto mIconIt = s_moduleIcons.find(name);
            if (mIconIt != s_moduleIcons.end()) {
                void* icoSpr = sprites.LoadFromResource(mIconIt->second, name);
                if (icoSpr) qm.set_button_icon(mid, tid, icoSpr);
            } else {
                auto vrcIconIt = s_moduleVrcIcons.find(name);
                if (vrcIconIt != s_moduleVrcIcons.end())
                    qm.set_button_icon(mid, tid, static_cast<int32_t>(vrcIconIt->second));
            }
        }

        // Create a Settings sub-page for module foldouts/sliders
        auto& qmEx = QuickMenuEx::Get();
        uint32_t settingsPageId = qm.create_sub_page(mid, pageId, "Settings");
        qmEx.set_subpage_nav_icon_vrc(mid, settingsPageId, Bootstrap::Sprite::Bundle_SlidersHorizontal);
        for (size_t i = 0; i < mgr.m_modules.size(); ++i) {
            if (mgr.m_modules[i]->GetCategory() != cat) continue;
            mgr.m_modules[i]->OnSetupQuickMenu(mid, settingsPageId);
        }

        DashboardConsole::Get().AddLog(
            "[NYX]: " + cat + " added to sidebar",
            DashboardConsole::LogColor::System);
    }

    static bool s_targetButtonInjected = false;
    static uint32_t s_targetPageId = 0;

    static void __fastcall OnTargetButtonClick(void* target, void* method) {
        if (s_targetPageId)
            Bootstrap::Module::QuickMenu::Get().navigate_to(s_targetPageId);
    }

    static int s_targetInjectFrameSkip = 0;

    static void InjectTargetButton() {
        using namespace IL2CPP::Module;
        using namespace IL2CPP::Module::Unity;

        if (s_targetButtonInjected) return;
        if (!s_targetPageId) return;

        if (++s_targetInjectFrameSkip < 60) return;
        s_targetInjectFrameSkip = 0;

        try {
            auto buttonsGO = GameObject::Find(
                "Canvas_QuickMenu(Clone)/CanvasGroup/Container/Window/QMParent/Body/"
                "Menu_SelectedUser_Local/ScrollRect/Viewport/VerticalLayoutGroup/"
                "Buttons_UserActions");
            if (!buttonsGO.IsValid()) return;
            auto buttonsT = buttonsGO.GetTransform();

            auto bodyGO = GameObject::Find(
                "Canvas_QuickMenu(Clone)/CanvasGroup/Container/Window/QMParent/Body");
            if (!bodyGO.IsValid()) return;
            auto bodyT = bodyGO.GetTransform();

            Transform targetBtnT;
            for (int i = 0; i < bodyT.GetChildCount(); ++i) {
                auto pageT = bodyT.GetChild(i);
                if (!pageT.valid()) continue;
                auto pageGO = pageT.GetGameObject();
                if (!pageGO.valid()) continue;
                std::string pageName = pageGO.GetName();
                if (pageName.find("Menu_UNIx") == std::string::npos) continue;

                auto scrollT = pageT.Find("Panel_QM_ScrollRect/Viewport/VerticalLayoutGroup/Buttons");
                if (!scrollT.valid()) continue;

                for (int j = 0; j < scrollT.GetChildCount(); ++j) {
                    auto btnT = scrollT.GetChild(j);
                    if (!btnT.valid()) continue;
                    auto btnGO = btnT.GetGameObject();
                    if (!btnGO.valid()) continue;
                    std::string btnName = btnGO.GetName();
                    if (btnName.find("Nyx") != std::string::npos) {
                        targetBtnT = btnT;
                        FLOG("[QM] Found target button: {} in {}", btnName, pageName);
                        break;
                    }
                }
                if (targetBtnT.valid()) break;
            }

            if (!targetBtnT.valid()) return;

            targetBtnT.SetParent(buttonsT, false);

            if (buttonsT.GetChildCount() > 1) {
                auto refT = buttonsT.GetChild(0);
                if (refT.valid()) {
                    auto refScale = refT.GetLocalScale();
                    targetBtnT.SetLocalScale(refScale);
                }
            }

            s_targetButtonInjected = true;
            FLOG("[QM] Moved Nyx Target Button To Selected User Page");

            {
                static bool s_versionBumped = false;
                if (!s_versionBumped) {
                    s_versionBumped = true;
                    std::thread([]() {
                        try {
                            std::string fpath = "C:/Users/euoxe/Downloads/nyxclient-master/nyxV2/VoidUnix/dllmain.cpp";
                            std::ifstream in(fpath);
                            if (!in) return;
                            std::string content((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
                            in.close();

                            std::string marker = "UNIX_MODULE_INFO(\"Nyx\", \"";
                            auto pos = content.find(marker);
                            if (pos == std::string::npos) return;
                            auto verStart = pos + marker.size();
                            auto verEnd = content.find('\"', verStart);
                            if (verEnd == std::string::npos) return;

                            std::string ver = content.substr(verStart, verEnd - verStart);
                            auto lastDot = ver.rfind('.');
                            if (lastDot == std::string::npos) return;

                            int patch = 0;
                            try { patch = std::stoi(ver.substr(lastDot + 1)); } catch (...) {}
                            patch++;
                            std::string newVer = ver.substr(0, lastDot + 1) + std::to_string(patch);

                            std::string newContent = content.substr(0, verStart) + newVer + content.substr(verEnd);
                            std::ofstream out(fpath, std::ios::trunc);
                            if (out) {
                                out << newContent;
                                FLOG("[QM] Version bumped to {}", newVer);
                            }
                        } catch (...) {}
                    }).detach();
                }
            }

        } catch (...) {}
    }

    void ModuleManager::SetupQuickMenu() {
        auto& qm = Bootstrap::Module::QuickMenu::Get();
        if (!qm.valid() || !qm.is_ready()) return;
        if (!g_mod || !g_mod->valid()) return;

        uint32_t mid = g_mod->id();
        m_qmPageId = qm.create_page(mid, "nyx", "nyx modules");

        auto& sprites = SpriteLoader::Get();

        void* mainIcon = sprites.LoadFromResource(IDR_ICON_TERMINAL, "terminal");
        if (mainIcon)
            qm.set_page_icon(mid, m_qmPageId, mainIcon);

        std::vector<std::string> allCategories;
        {
            std::unordered_set<std::string> seen;
            for (size_t i = 0; i < m_modules.size(); ++i) {
                std::string cat(m_modules[i]->GetCategory());
                if (seen.insert(cat).second)
                    allCategories.push_back(cat);
            }
        }

        // Categories always appear inside nyx.
        // "External" config adds a sidebar tab too (read from layout.cfg).
        std::map<std::string, uint32_t> categoryPages;
        s_categoryInfo.clear();
        s_externalCats = LoadLayoutConfig();

        for (auto& cat : allCategories) {
            bool showExternal = s_externalCats.count(cat) > 0;

            CategorySetupInfo ci;
            auto iconIt = s_categoryIconResources.find(cat);
            if (iconIt != s_categoryIconResources.end())
                ci.sprite = sprites.LoadFromResource(iconIt->second, "cat_" + cat);

            auto& qmEx = QuickMenuEx::Get();

            if (showExternal) {
                uint32_t pageId = qm.create_page(mid, cat, cat);
                categoryPages[cat] = pageId;
                ci.startedExternal = true;

                if (ci.sprite)
                    qm.set_page_icon(mid, pageId, ci.sprite);

                uint32_t btnId = qm.add_button(mid, m_qmPageId, cat, QmCategoryNavCallback);
                s_categoryNavButtons[btnId] = pageId;
                if (ci.sprite)
                    qm.set_button_icon(mid, btnId, ci.sprite);

                auto vrcIt = s_categoryVrcSprites.find(cat);
                if (vrcIt != s_categoryVrcSprites.end())
                    qm.set_button_icon(mid, btnId, static_cast<int32_t>(vrcIt->second));
            } else {
                uint32_t subPageId = qm.create_sub_page(mid, m_qmPageId, cat);
                categoryPages[cat] = subPageId;

                auto vrcIt = s_categoryVrcSprites.find(cat);
                if (vrcIt != s_categoryVrcSprites.end())
                    qmEx.set_subpage_nav_icon_vrc(mid, subPageId, vrcIt->second);
            }

            s_categoryInfo[cat] = ci;
        }

        // Create ESP sub-page inside Visual
        uint32_t espSubPageId = 0;
        {
            auto visualIt = categoryPages.find("Visual");
            if (visualIt != categoryPages.end()) {
                espSubPageId = qm.create_sub_page(mid, visualIt->second, "ESP");
                auto& qmExEsp = QuickMenuEx::Get();
                qmExEsp.set_subpage_nav_icon_vrc(mid, espSubPageId, Bootstrap::Sprite::Bundle_EyeSlash);
            }
        }

        // Pass 1: Add all module toggles to their category pages
        for (size_t i = 0; i < m_modules.size(); ++i) {
            std::string cat(m_modules[i]->GetCategory());
            uint32_t catPageId = categoryPages[cat];

            if (m_modules[i]->ShowInQuickMenu() && s_qmToggleCount < kMaxQmModules) {
                std::string name(m_modules[i]->GetName());

                if (espSubPageId && cat == "Visual" &&
                    name.find("ESP") != std::string::npos) {
                    catPageId = espSubPageId;
                }

                std::string key = name;
                std::transform(key.begin(), key.end(), key.begin(),
                    [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
                for (auto& ch : key) { if (ch == ' ') ch = '_'; }
                key += "_enabled";

                s_qmModuleIndices[s_qmToggleCount] = i;
                uint32_t tid = qm.add_toggle(mid, catPageId,
                    name, m_modules[i]->IsEnabled(), QmToggleCallback, key);
                s_qmToggleIds[s_qmToggleCount] = tid;

                auto iconIt = s_moduleIcons.find(name);
                if (iconIt != s_moduleIcons.end()) {
                    void* spr = sprites.LoadFromResource(iconIt->second, name);
                    if (spr)
                        qm.set_button_icon(mid, tid, spr);
                } else {
                    auto vrcIconIt = s_moduleVrcIcons.find(name);
                    if (vrcIconIt != s_moduleVrcIcons.end())
                        qm.set_button_icon(mid, tid, static_cast<int32_t>(vrcIconIt->second));
                }

                ++s_qmToggleCount;
            }
        }

        // Pass 2: Let modules add their foldouts/sliders directly on the
        // category page (below the toggles) so everything is in one place.
        auto& qmEx = QuickMenuEx::Get();
        for (size_t i = 0; i < m_modules.size(); ++i) {
            std::string cat(m_modules[i]->GetCategory());
            m_modules[i]->OnSetupQuickMenu(mid, categoryPages[cat]);
        }

        // ── Target page (navigated via Selected User menu injection) ──
        {
            uint32_t targetPageId = qm.create_sub_page(mid, m_qmPageId, "Nyx");
            s_targetPageId = targetPageId;
            s_targetButtonInjected = false;

            auto addModToggle = [&](uint32_t foldId, const char* modName) {
                for (size_t i = 0; i < m_modules.size(); ++i) {
                    if (std::string(m_modules[i]->GetName()) != modName) continue;
                    if (s_qmToggleCount >= kMaxQmModules) break;
                    std::string key = std::string(modName);
                    std::transform(key.begin(), key.end(), key.begin(),
                        [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
                    for (auto& ch : key) { if (ch == ' ') ch = '_'; }
                    s_qmModuleIndices[s_qmToggleCount] = i;
                    uint32_t tid = qmEx.add_settings_toggle(mid, foldId,
                        modName, m_modules[i]->IsEnabled(), QmToggleCallback, key);
                    s_qmToggleIds[s_qmToggleCount] = tid;
                    ++s_qmToggleCount;
                    return;
                }
            };

            uint32_t attachPageId = qm.create_sub_page(mid, targetPageId, "Attachment");
            {
                uint32_t fold = qmEx.add_foldout(mid, attachPageId, "Attachment", true, true);
                addModToggle(fold, "Limb Sit");
            }
            {
                auto* limbSit = FindModule<LimbSitModule>();
                if (limbSit) limbSit->OnSetupQuickMenu(mid, attachPageId);
            }

            uint32_t malPageId = qm.create_sub_page(mid, targetPageId, "Malicious");
            {
                uint32_t fold = qmEx.add_foldout(mid, malPageId, "Malicious", true, true);
                addModToggle(fold, "Item Orbit");
                addModToggle(fold, "Item Clapper");
                addModToggle(fold, "Item Lagger");
                addModToggle(fold, "Pickup Dropper");
            }

            uint32_t portalPageId = qm.create_sub_page(mid, malPageId, "Portal Exploits");
            {
                uint32_t fold = qmEx.add_foldout(mid, portalPageId, "Portal Exploits", true, true);
                addModToggle(fold, "Portal Spam");
                addModToggle(fold, "Portal Orbit");
            }
            {
                auto* portalOrbit = FindModule<PortalOrbitModule>();
                if (portalOrbit) portalOrbit->OnSetupQuickMenu(mid, portalPageId);
            }
        }

        // ── Menu Backgrounds sub-page (custom only) ──
        uint32_t bgPageId = qm.create_sub_page(mid, m_qmPageId, "Menu Backgrounds");
        qmEx.set_subpage_nav_icon_vrc(mid, bgPageId, Bootstrap::Sprite::Backgrounds);

        uint32_t layoutPageId = qm.create_sub_page(mid, m_qmPageId, "Menu Layout");
        qmEx.set_subpage_nav_icon_vrc(mid, layoutPageId, Bootstrap::Sprite::Bundle_SlidersHorizontal);
        s_layoutToggleCats.clear();
        for (auto& cat : allCategories) {
            bool curExt = s_externalCats.count(cat) > 0;

            uint32_t tid = qm.add_toggle(mid, layoutPageId,
                cat, curExt, QmLayoutToggleCallback, "");
            s_layoutToggleCats[tid] = cat;
        }


        s_customBgPageId = qm.create_sub_page(mid, bgPageId, "Custom Backgrounds");
        qmEx.set_subpage_nav_icon_vrc(mid, s_customBgPageId, Bootstrap::Sprite::Folder);
        ScanCustomBackgrounds();

        m_scrollFixApplied = false; // will be applied in DispatchUpdate once QM is visible

        auto& console = DashboardConsole::Get();
        console.Init();
        console.AddLog("[NYX]: QuickMenu initialized", DashboardConsole::LogColor::System);
        console.AddLog("[NYX]: " + std::to_string(m_modules.size()) + " modules registered", DashboardConsole::LogColor::System);

        m_qmInitialized = true;
    }

    // ── Scroll fix: ensure all QM pages clip content properly ──
    //
    // VRChat QM page hierarchy (confirmed by AlterEgo reference mod):
    //   Page / Panel_QM_ScrollRect / Viewport / VerticalLayoutGroup
    //
    // The Viewport has a VRCRectMask2D that may have clipping broken after
    // cloning.  We walk each page by name rather than searching by component,
    // then force‑fix every mask we can find on the Viewport.

    static void FixViewportClipping(IL2CPP::Module::Unity::GameObject viewportGO) {
        using namespace IL2CPP::Module;
        using namespace IL2CPP::Module::Unity;

        auto rectMask2DClass = Class::find("UnityEngine.UI.RectMask2D");
        if (!rectMask2DClass) return;

        auto compClass = Class::find("UnityEngine.Component");
        if (compClass) {
            auto allComps = viewportGO.GetComponents(compClass);
            for (auto& comp : allComps) {
                if (!comp.valid()) continue;
                Class klass = comp.get_class();
                if (!klass) continue;
                auto m = klass.get_method("PerformClipping", -1);
                if (!m) continue;
                Object(comp.raw()).DestroyImmediate();
            }
        }

        viewportGO.AddComponent(rectMask2DClass);
    }

    void ModuleManager::FixQMScrolling() {
        using namespace IL2CPP::Module;
        using namespace IL2CPP::Module::Unity;

        auto bodyGO = GameObject::Find(
            "Canvas_QuickMenu(Clone)/CanvasGroup/Container/Window/QMParent/Body");
        if (!bodyGO.IsValid()) return;

        auto bodyT = bodyGO.GetTransform();
        if (!bodyT.valid()) return;

        auto csfClass = Class::find("UnityEngine.UI.ContentSizeFitter");
        auto vlgClass = Class::find("UnityEngine.UI.VerticalLayoutGroup");

        int pageCount = bodyT.GetChildCount();

        for (int p = 0; p < pageCount; ++p) {
            auto pageT = bodyT.GetChild(p);
            if (!pageT.valid()) continue;

            auto pageGO = pageT.GetGameObject();
            if (!pageGO.valid()) continue;
            std::string pageName = pageGO.GetName();

            // Only fix our own Menu_UNIx pages
            if (pageName.find("Menu_UNIx") == std::string::npos)
                continue;

            Transform scrollT;
            scrollT = pageT.Find("Panel_QM_ScrollRect");
            if (!scrollT.valid()) scrollT = pageT.Find("ScrollRect");
            if (!scrollT.valid()) continue;

            auto viewportT = scrollT.Find("Viewport");
            if (!viewportT.valid()) continue;

            auto viewportGO = viewportT.GetGameObject();
            if (!viewportGO.valid()) continue;

            FixViewportClipping(viewportGO);

            Transform contentT;
            contentT = viewportT.Find("VerticalLayoutGroup");
            if (!contentT.valid()) {
                if (viewportT.GetChildCount() > 0)
                    contentT = viewportT.GetChild(0);
            }
            if (!contentT.valid()) continue;

            auto contentGO = contentT.GetGameObject();
            if (!contentGO.valid()) continue;

            RectTransform contentRT(contentT.raw());
            IL2CPP::Vector2 anchorMin = contentRT.GetAnchorMin();
            IL2CPP::Vector2 anchorMax = contentRT.GetAnchorMax();
            if (anchorMin.y != 1.0f || anchorMax.y != 1.0f) {
                contentRT.SetAnchorMin({ 0.0f, 1.0f });
                contentRT.SetAnchorMax({ 1.0f, 1.0f });
                contentRT.SetPivot({ 0.5f, 1.0f });
                contentRT.SetOffsetMin({ 0.0f, 0.0f });
                contentRT.SetOffsetMax({ 0.0f, 0.0f });
                contentRT.SetAnchoredPosition({ 0.0f, 0.0f });
            }

            if (csfClass) {
                auto csf = contentGO.GetComponent(csfClass);
                if (!csf.valid()) {
                    csf = contentGO.AddComponent(csfClass);
                    if (csf.valid()) {
                        ContentSizeFitter f(csf.raw());
                        f.SetVerticalFit(2);
                        f.SetHorizontalFit(0);
                    }
                } else {
                    ContentSizeFitter f(csf.raw());
                    if (f.GetVerticalFit() != 2) f.SetVerticalFit(2);
                }
            }

            if (vlgClass) {
                auto vlg = contentGO.GetComponent(vlgClass);
                if (vlg.valid()) {
                    VerticalLayoutGroup v(vlg.raw());
                    v.SetChildForceExpandHeight(false);
                    v.SetChildControlHeight(true);
                }
            }
        }

        m_scrollFixApplied = true;
    }

    void ModuleManager::ScanCustomBackgrounds() {
        if (s_customBgPageId == 0) return;
        if (!g_mod || !g_mod->valid()) return;

        auto& qm = Bootstrap::Module::QuickMenu::Get();
        if (!qm.valid()) return;

        uint32_t mid = g_mod->id();
        auto& sprites = SpriteLoader::Get();

        namespace fs = std::filesystem;

        // Collect current files on disk
        std::set<std::string> diskFiles;
        std::error_code ec;
        if (fs::exists(kCustomBgFolder, ec) && fs::is_directory(kCustomBgFolder, ec)) {
            for (auto& entry : fs::directory_iterator(kCustomBgFolder, ec)) {
                if (!entry.is_regular_file(ec)) continue;
                auto ext = entry.path().extension().string();
                std::transform(ext.begin(), ext.end(), ext.begin(),
                    [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
                if (ext == ".png" || ext == ".jpg" || ext == ".jpeg" || ext == ".gif") {
                    diskFiles.insert(entry.path().filename().string());
                }
            }
        }

        // Remove buttons for files that no longer exist
        for (size_t i = 0; i < s_customBgCount; ) {
            if (diskFiles.find(s_customBgEntries[i].filename) == diskFiles.end()) {
                qm.remove_button(mid, s_customBgEntries[i].buttonId);
                // Shift remaining entries down
                for (size_t j = i; j + 1 < s_customBgCount; ++j)
                    s_customBgEntries[j] = std::move(s_customBgEntries[j + 1]);
                --s_customBgCount;
            } else {
                ++i;
            }
        }

        // Build set of currently tracked filenames
        std::set<std::string> trackedFiles;
        for (size_t i = 0; i < s_customBgCount; ++i)
            trackedFiles.insert(s_customBgEntries[i].filename);

        // Add buttons for new files
        for (auto& filename : diskFiles) {
            if (trackedFiles.count(filename)) continue;
            if (s_customBgCount >= kMaxCustomBgButtons) break;

            std::string fullPath = std::string(kCustomBgFolder) + "\\" + filename;
            std::string displayName = fs::path(filename).stem().string();

            uint32_t btnId = qm.add_button(mid, s_customBgPageId, displayName, QmCustomBgButtonCallback);

            // Only load static images as button icons (skip GIFs — they trigger async load)
            if (!IsGifPath(fullPath)) {
                void* spr = sprites.LoadFromFile(fullPath);
                if (spr)
                    qm.set_button_icon(mid, btnId, spr);
            }

            s_customBgEntries[s_customBgCount].filename = filename;
            s_customBgEntries[s_customBgCount].fullPath = fullPath;
            s_customBgEntries[s_customBgCount].buttonId = btnId;
            ++s_customBgCount;
        }
    }

    // ── Auto-patches (always active, no toggle) ──

    bool ModuleManager::PrefixAlwaysTrue(void* thisPtr, bool& __retval) {
        __retval = true;
        return false;
    }

    bool ModuleManager::PrefixAlwaysTrueStatic(bool& __retval) {
        __retval = true;
        return false;
    }

    static constexpr uintptr_t kVRCPlusGetterRVA = 0x10224E0;

    using VRCPlusGetterFn = void*(*)(void*, void*);
    static VRCPlusGetterFn s_origVRCPlusGetter = nullptr;

    static void* DetourVRCPlusGetter(void* thisPtr, void* methodInfo) {
        void* rp = s_origVRCPlusGetter(thisPtr, methodInfo);
        if (rp) {
            auto addr = reinterpret_cast<uintptr_t>(rp);
            if (addr > 0x10000 && addr < 0x7FFFFFFF0000)
                *reinterpret_cast<uint8_t*>(static_cast<char*>(rp) + 0x20) = 1;
        }
        return rp;
    }


    void ModuleManager::ApplyVRCPlusSpoof() {
        if (m_vrcPlusSpoofed) return;

        auto* exports = IL2CPP::Module::GetExports();
        if (!exports || !exports->m_hModule) return;

        auto getterAddr = reinterpret_cast<VRCPlusGetterFn>(
            reinterpret_cast<uintptr_t>(exports->m_hModule) + kVRCPlusGetterRVA);

        auto hookId = g_hook->create_detour<VRCPlusGetterFn>(
            "VRCPlus_Getter", getterAddr, DetourVRCPlusGetter, &s_origVRCPlusGetter);

        if (hookId != Hooking::invalid_id) {
            FLOG("[VRC+Spoof] Detour installed @ {:p} (id={})",
                 reinterpret_cast<void*>(getterAddr), hookId);
        } else {
            FLOG("[VRC+Spoof] Failed to install detour");
        }

        m_vrcPlusSpoofed = true;
        m_vrcPlusTextChanged = true;
    }

    void ModuleManager::ApplyForceClone() {
        using namespace IL2CPP::Module;
        if (m_forceCloneApplied) return;
        if (!BaseModule::InRoom()) return;

        auto localPlayer = BaseModule::GetLocalVRCPlayer();
        if (!localPlayer) return;
        auto apiUser = localPlayer.GetPlayer().GetAPIUser();
        if (!apiUser.valid()) return;

        // Try property first, then field
        auto prop = apiUser.get_class().get_property("allowAvatarCopying");
        if (prop && prop.setter()) {
            bool val = true;
            void* p[] = { &val };
            prop.setter().invoke(apiUser.raw(), p);
            FLOG("[ForceClone] Set allowAvatarCopying=true via property");
            m_forceCloneApplied = true;
            return;
        }

        auto field = apiUser.get_class().get_field("allowAvatarCopying");
        if (field) {
            bool val = true;
            field.set_value(apiUser.raw(), &val);
            FLOG("[ForceClone] Set allowAvatarCopying=true via field (offset {})", field.offset());
            m_forceCloneApplied = true;
            return;
        }

        FLOG("[ForceClone] allowAvatarCopying not found on APIUser");
        m_forceCloneApplied = true; // stop retrying
    }

    static bool TrySafeWriteBool(void* addr, bool value);

    void ModuleManager::ApplyFastRate() {
        if (m_fastRateApplied) return;
        if (!BaseModule::InRoom()) return;

        auto localPlayer = BaseModule::GetLocalVRCPlayer();
        if (!localPlayer.valid()) return;
        auto go = localPlayer.GetGameObject();
        if (!go.valid()) return;
        auto serializer = go.GetComponentByName("FlatBufferNetworkSerializer");
        if (!serializer.valid()) return;

        void* raw = serializer.raw();
        if (!raw) return;

        if (!TrySafeWriteBool(reinterpret_cast<void*>(reinterpret_cast<uintptr_t>(raw) + 0x100), true))
            FLOG("[FastRate] SEH writing RequireFastRate");

        m_fastRateApplied = true;
    }

    static bool TrySafeWriteBool(void* addr, bool value) {
        __try {
            *reinterpret_cast<bool*>(addr) = value;
            return true;
        } __except(EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }

    static bool TrySafeWriteFloat(void* addr, float value) {
        __try {
            *reinterpret_cast<float*>(addr) = value;
            return true;
        } __except(EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }

    void ModuleManager::ApplyPickupPatches() {
        using namespace IL2CPP::Module;
        using namespace IL2CPP::Module::Unity;

        if (!BaseModule::InRoom()) return;

        m_pickupPatchTimer += Time::GetDeltaTime();
        if (m_pickupPatchTimer < 3.0f) return;
        m_pickupPatchTimer = 0.f;

        static int s_offProximity = -1;
        static int s_offPickupable = -1;
        static int s_offDisallowTheft = -1;
        static int s_offAllowManip = -1;

        if (!m_pickupFieldsResolved) {
            auto cls = Class::find("VRC.SDKBase.VRC_Pickup");
            if (!cls) cls = Class::find("VRC.SDK3.Components.VRCPickup");
            if (!cls) return;

            auto fProx = cls.get_field("proximity");
            if (fProx) s_offProximity = fProx.offset();

            auto fPick = cls.get_field("pickupable");
            if (fPick) s_offPickupable = fPick.offset();

            auto fTheft = cls.get_field("DisallowTheft");
            if (fTheft) s_offDisallowTheft = fTheft.offset();

            auto fManip = cls.get_field("allowManipulationWhenEquipped");
            if (fManip) s_offAllowManip = fManip.offset();

            m_pickupFieldsResolved = true;
            FLOG("[PickupPatch] Offsets: proximity=0x{:X} pickupable=0x{:X} theft=0x{:X} manip=0x{:X}",
                s_offProximity, s_offPickupable, s_offDisallowTheft, s_offAllowManip);
        }

        if (s_offProximity <= 0 && s_offPickupable <= 0 && s_offDisallowTheft <= 0) return;

        auto pickups = Object::FindObjectsOfType("VRC.SDKBase.VRC_Pickup");
        if (pickups.empty())
            pickups = Object::FindObjectsOfType("VRC.SDK3.Components.VRCPickup");
        if (pickups.empty()) return;

        for (auto& obj : pickups) {
            char* raw = static_cast<char*>(obj.raw());
            if (!raw) continue;

            if (s_offProximity > 0)
                *reinterpret_cast<float*>(raw + s_offProximity) = 9999.f;

            if (s_offPickupable > 0)
                *reinterpret_cast<bool*>(raw + s_offPickupable) = true;

            if (s_offDisallowTheft > 0)
                *reinterpret_cast<bool*>(raw + s_offDisallowTheft) = false;

            if (s_offAllowManip > 0)
                *reinterpret_cast<bool*>(raw + s_offAllowManip) = true;
        }
    }

    void ModuleManager::QueueForceJoin(const std::string& worldId) {
        std::lock_guard lock(m_forceJoinMutex);
        m_queuedForceJoin = worldId;
    }

    // ── SEH wrappers (no C++ destructors allowed in these functions) ──

    static bool SafeCallModuleUpdate(BaseModule* mod) {
        __try { mod->OnUpdate(); return true; }
        __except(EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    static bool SafeCallModuleLateUpdate(BaseModule* mod) {
        __try { mod->OnLateUpdate(); return true; }
        __except(EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    static bool SafeCallModuleFixedUpdate(BaseModule* mod) {
        __try { mod->OnFixedUpdate(); return true; }
        __except(EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    static bool SafeCallModuleSceneLoad(BaseModule* mod, int scene, int loadMode) {
        __try { mod->OnSceneLoad(scene, loadMode); return true; }
        __except(EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    static bool SafeCallModuleSceneUnload(BaseModule* mod, int scene, int loadMode) {
        __try { mod->OnSceneUnload(scene, loadMode); return true; }
        __except(EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    static bool SafeCallModulePlayerEvent(BaseModule* mod, IL2CPP::VRChat::Player player, int event) {
        __try {
            switch (event) {
                case 0: mod->OnPlayerJoinComplete(player); break;
                case 1: mod->OnPlayerLeave(player); break;
                case 2: mod->OnPlayerJoin(player); break;
                case 3: mod->OnAwake(player); break;
            }
            return true;
        } __except(EXCEPTION_EXECUTE_HANDLER) { return false; }
    }

    // ── Lifecycle dispatchers ──

    std::vector<std::string> ModuleManager::GetEnabledModuleNames() const {
        std::vector<std::string> names;
        for (auto& mod : m_modules) {
            if (mod->IsEnabled())
                names.emplace_back(mod->GetName());
        }
        return names;
    }

    void ModuleManager::DispatchUpdate() {
        if (!m_qmInitialized) SetupQuickMenu();

        // Apply scroll fix after QM pages are created (delay to let Bootstrap
        // finish instantiating all page GameObjects)
        if (m_qmInitialized && !m_scrollFixApplied) {
            m_scrollFixDelay += IL2CPP::Module::Unity::Time::GetDeltaTime();
            if (m_scrollFixDelay >= 2.0f) {
                FixQMScrolling();
            }
        }

        if (m_qmInitialized && !s_targetButtonInjected) {
            InjectTargetButton();
        }

        for (auto& mod : m_modules)
            mod->ProcessPendingToggle();

        ApplyVRCPlusSpoof();
        ApplyForceClone();
        ApplyFastRate();
        ApplyPickupPatches();

        auto& console = DashboardConsole::Get();
        console.Update();

        // Finalize any async GIF loads (background thread → GPU resources on Unity thread)
        auto* finalized = SpriteLoader::Get().FinalizeAsyncGifs();
        if (finalized && !finalized->frames.empty()) {
            console.SetAnimatedBackground(finalized);
            if (!s_pendingBgFilename.empty()) {
                console.AddLog(
                    std::string("[NYX]: Background set to ") + s_pendingBgFilename,
                    DashboardConsole::LogColor::System);
                s_pendingBgFilename.clear();
            }
        }

        // Periodically scan C:\nyx\images\ for added/removed backgrounds
        m_customBgScanTimer += IL2CPP::Module::Unity::Time::GetDeltaTime();
        if (m_customBgScanTimer >= 10.f) {
            m_customBgScanTimer = 0.f;
            ScanCustomBackgrounds();
        }

        // Auto-load saved background on first update after QM bg is ready
        if (!s_bgConfigLoaded && console.IsStarted()) {
            s_bgConfigLoaded = true;
            std::string savedBg = LoadBgConfig();
            if (!savedBg.empty()) {
                std::string fullPath = std::string(kCustomBgFolder) + "/" + savedBg;
                if (std::filesystem::exists(fullPath)) {
                    ApplyBackground(fullPath, savedBg);
                    FLOG("[ModuleManager] Auto-loaded saved background: {}", savedBg);
                }
            }
        }

        m_heartbeatTimer += IL2CPP::Module::Unity::Time::GetDeltaTime();
        if (m_heartbeatTimer >= 5.f) {
            m_heartbeatTimer = 0.f;

            float dt = IL2CPP::Module::Unity::Time::GetDeltaTime();
            int fps = (dt > 0.f) ? static_cast<int>(1.f / dt) : 0;
            std::string worldId, worldName;

            if (BaseModule::InRoom()) {
                auto localPlayer = BaseModule::GetLocalVRCPlayer();
                if (localPlayer) {
                    auto apiUser = localPlayer.GetPlayer().GetAPIUser();
                    if (apiUser.valid()) {
                        std::string loc = apiUser.GetLocation();
                        if (!loc.empty() && loc.find("wrld_") != std::string::npos)
                            worldId = loc;
                    }
                }
            }
            HeartbeatManager::Get().UpdateLocalInfo(fps, worldId, worldName);

            std::string instancePart;
            if (!worldId.empty()) {
                auto colon = worldId.find(':');
                if (colon != std::string::npos)
                    instancePart = worldId.substr(colon + 1);
            }

            std::string thumbnailUrl;
            int maxPlayers = 0;

            std::string justWorldId = worldId;
            {
                auto c = justWorldId.find(':');
                if (c != std::string::npos) justWorldId = justWorldId.substr(0, c);
            }

            {
                struct WorldInfoCache {
                    struct Info { std::string name; std::string thumbUrl; int maxPlayers = 0; };
                    std::mutex mtx;
                    std::unordered_map<std::string, Info> data;
                    std::set<std::string> pending;
                };
                static WorldInfoCache* s_wic = new WorldInfoCache();

                std::lock_guard lk(s_wic->mtx);
                auto it = s_wic->data.find(justWorldId);
                if (it != s_wic->data.end()) {
                    worldName = it->second.name;
                    thumbnailUrl = it->second.thumbUrl;
                    maxPlayers = it->second.maxPlayers;
                } else if (s_wic->pending.find(justWorldId) == s_wic->pending.end() && !justWorldId.empty()) {
                    s_wic->pending.insert(justWorldId);
                    std::string wid = justWorldId;
                    auto* wic = s_wic;

                    std::string authCookie;
                    try {
                        using namespace IL2CPP::Module;
                        auto credClass = Class::find("VRC.Core.ApiCredentials");
                        if (credClass) {
                            auto getAuth = credClass.get_method("GetAuthToken", -1);
                            if (!getAuth) getAuth = credClass.get_method("get_authToken", -1);
                            if (getAuth) {
                                void* tokenRaw = MethodHandler::invoke<void*>(getAuth, nullptr);
                                if (tokenRaw) authCookie = System::String(tokenRaw).to_string();
                            }
                        }
                    } catch (...) {}

                    std::thread([wid, wic, authCookie]() {
                        try {
                            HINTERNET hSession = WinHttpOpen(L"nyx/1.0", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, nullptr, nullptr, 0);
                            if (!hSession) return;
                            HINTERNET hConnect = WinHttpConnect(hSession, L"api.vrchat.cloud", INTERNET_DEFAULT_HTTPS_PORT, 0);
                            if (!hConnect) { WinHttpCloseHandle(hSession); return; }
                            std::wstring path = L"/api/1/worlds/" + std::wstring(wid.begin(), wid.end());
                            HINTERNET hRequest = WinHttpOpenRequest(hConnect, L"GET", path.c_str(), nullptr, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, WINHTTP_FLAG_SECURE);
                            if (!hRequest) { WinHttpCloseHandle(hConnect); WinHttpCloseHandle(hSession); return; }

                            if (!authCookie.empty()) {
                                std::wstring cookie = L"Cookie: auth=" + std::wstring(authCookie.begin(), authCookie.end());
                                WinHttpAddRequestHeaders(hRequest, cookie.c_str(), -1, WINHTTP_ADDREQ_FLAG_ADD);
                            }

                            if (!WinHttpSendRequest(hRequest, WINHTTP_NO_ADDITIONAL_HEADERS, 0, WINHTTP_NO_REQUEST_DATA, 0, 0, 0) ||
                                !WinHttpReceiveResponse(hRequest, nullptr)) {
                                WinHttpCloseHandle(hRequest); WinHttpCloseHandle(hConnect); WinHttpCloseHandle(hSession);
                                return;
                            }

                            std::string body;
                            DWORD bytesRead = 0;
                            char buf[4096];
                            while (WinHttpReadData(hRequest, buf, sizeof(buf), &bytesRead) && bytesRead > 0)
                                body.append(buf, bytesRead);
                            WinHttpCloseHandle(hRequest);
                            WinHttpCloseHandle(hConnect);
                            WinHttpCloseHandle(hSession);

                            auto extractJsonStr = [&](const std::string& key) -> std::string {
                                auto pos = body.find("\"" + key + "\"");
                                if (pos == std::string::npos) return {};
                                auto col = body.find(':', pos);
                                auto qs = body.find('"', col + 1);
                                auto qe = body.find('"', qs + 1);
                                if (qs != std::string::npos && qe != std::string::npos)
                                    return body.substr(qs + 1, qe - qs - 1);
                                return {};
                            };
                            auto extractJsonInt = [&](const std::string& key) -> int {
                                auto pos = body.find("\"" + key + "\"");
                                if (pos == std::string::npos) return 0;
                                auto col = body.find(':', pos);
                                if (col == std::string::npos) return 0;
                                try { return std::stoi(body.substr(col + 1)); } catch (...) { return 0; }
                            };

                            std::string name = extractJsonStr("name");
                            std::string thumb = extractJsonStr("thumbnailImageUrl");
                            int cap = extractJsonInt("capacity");

                            if (!name.empty()) {
                                std::lock_guard lk2(wic->mtx);
                                wic->data[wid] = { name, thumb, cap };
                                FLOG("[WorldInfo] Resolved: {} = {}", wid, name);
                            }
                        } catch (...) {}
                    }).detach();
                }
            }

            auto& discord = DiscordRPC::Get();
            if (BaseModule::InRoom()) {
                auto localApi = BaseModule::GetLocalPlayerApi();
                if (localApi.valid()) {
                    discord.SetUsername(localApi.GetDisplayName());
                }
                int playerCount = IL2CPP::VRChat::VRCPlayerApi::GetPlayerCount();

                std::string displayWorld = worldName;
                if (displayWorld.empty() && !worldId.empty()) {
                    displayWorld = justWorldId;
                }
                if (!displayWorld.empty()) {
                    discord.SetWorld(displayWorld, instancePart, "Public", playerCount);
                }

                if (!worldId.empty() && InstanceHistory::Get().IsNewLocation(worldId)) {
                    InstanceEntry ie;
                    ie.worldName = worldName.empty() ? justWorldId : worldName;
                    ie.worldId = justWorldId;
                    ie.locationString = worldId;
                    ie.thumbnailUrl = thumbnailUrl;
                    ie.playerCount = playerCount;
                    ie.maxPlayers = maxPlayers;
                    ie.timestamp = static_cast<int64_t>(std::time(nullptr));
                    InstanceHistory::Get().LogInstance(ie);
                    FLOG("[InstanceHistory] Logged: {}", ie.worldName);
                }
            } else {
                discord.SetLobby();
            }
            discord.Update();
        }

        {
            int teleportId = m_pendingTeleportTarget.exchange(-1, std::memory_order_relaxed);
            if (teleportId >= 0) {
                auto target = IL2CPP::VRChat::VRCPlayerApi::GetPlayerById(teleportId);
                auto local = IL2CPP::VRChat::VRCPlayerApi::GetLocalPlayer();
                if (target.IsValid() && local.IsValid()) {
                    local.TeleportTo(target.GetPosition(), target.GetRotation());
                }
            }
        }

        {
            int portalId = m_pendingPortalTarget.exchange(-1, std::memory_order_relaxed);
            if (portalId >= 0) {
                auto* portalMod = FindModule<PortalSpamModule>();
                if (portalMod) {
                    auto api = IL2CPP::VRChat::VRCPlayerApi::GetPlayerById(portalId);
                    if (api.IsValid()) {
                        auto vrcPlayer = api.GetVRCPlayer();
                        if (vrcPlayer)
                            portalMod->SetTarget(vrcPlayer.GetPlayer());
                    }
                }
            }
        }

        {
            int orbitId = m_pendingPortalOrbitTarget.exchange(-1, std::memory_order_relaxed);
            if (orbitId >= 0) {
                auto* orbitMod = FindModule<PortalOrbitModule>();
                if (orbitMod) {
                    auto api = IL2CPP::VRChat::VRCPlayerApi::GetPlayerById(orbitId);
                    if (api.IsValid()) {
                        auto vrcPlayer = api.GetVRCPlayer();
                        if (vrcPlayer)
                            orbitMod->SetTarget(vrcPlayer.GetPlayer());
                    }
                }
            }
        }

        if (!m_pendingForceJoin.empty()) {
            FLOG("[ModuleManager] Force joining: {}", m_pendingForceJoin);
            IL2CPP::VRChat::Networking::GoToRoom(m_pendingForceJoin);
            m_pendingForceJoin.clear();
        }

        {
            std::lock_guard lock(m_forceJoinMutex);
            if (!m_queuedForceJoin.empty()) {
                FLOG("[ModuleManager] Force joining from invite: {}", m_queuedForceJoin);
                DashboardConsole::Get().AddLog("[VRC] Joining from accepted invite", DashboardConsole::LogColor::System);
                IL2CPP::VRChat::Networking::GoToRoom(m_queuedForceJoin);
                m_queuedForceJoin.clear();
            }
        }

        if (HeartbeatManager::Get().HasPendingCommand()) {
            auto [cmdType, cmdWorldId] = HeartbeatManager::Get().ConsumePendingCommand();
            FLOG("[ModuleManager] Received command: {}", cmdType);

            if (cmdType == "close_game") {
                FLOG("[ModuleManager] Closing game by remote command");
                TerminateProcess(GetCurrentProcess(), 0);
            } else if (cmdType == "force_join" && !cmdWorldId.empty()) {
                bool isPrivate = cmdWorldId.find("~private") != std::string::npos ||
                                 cmdWorldId.find("~hidden") != std::string::npos;
                if (isPrivate) {
                    std::lock_guard lock(m_pendingCmdMutex);
                    m_pendingCmd.type = cmdType;
                    m_pendingCmd.worldId = cmdWorldId;
                    m_pendingCmd.active = true;
                    m_pendingCmd.uiShown = false;
                    m_pendingCmd.timer = 0.f;
                } else {
                    FLOG("[ModuleManager] Force joining public world: {}", cmdWorldId);
                    IL2CPP::VRChat::Networking::GoToRoom(cmdWorldId);
                    DashboardConsole::Get().AddLog("[Remote] Joining public world", DashboardConsole::LogColor::System);
                }
            } else if (cmdType == "accept_invite" || cmdType == "send_invite") {
                std::lock_guard lock(m_pendingCmdMutex);
                m_pendingCmd.type = cmdType;
                m_pendingCmd.worldId = cmdWorldId;
                m_pendingCmd.active = true;
                m_pendingCmd.uiShown = false;
                m_pendingCmd.timer = 0.f;
            }
        }

        {
            std::lock_guard lock(m_pendingCmdMutex);
            if (m_pendingCmd.active) {
                m_pendingCmd.timer += IL2CPP::Module::Unity::Time::GetDeltaTime();

                if (!m_pendingCmd.uiShown) {
                    std::string msg;
                    if (m_pendingCmd.type == "force_join")
                        msg = "A developer wants to move you to a private world";
                    else if (m_pendingCmd.type == "accept_invite")
                        msg = "A developer wants to invite you to their world";
                    else if (m_pendingCmd.type == "send_invite")
                        msg = "A developer is requesting an invite to your world";
                    DashboardConsole::Get().AddLog("[Remote] " + msg, DashboardConsole::LogColor::System);
                    CreatePromptUI(msg);
                    m_pendingCmd.uiShown = true;
                }

                if (m_promptAcceptGO && m_promptDeclineGO) {
                    using namespace IL2CPP::Module::Unity;
                    if (Input::GetMouseButtonDown(0)) {
                        IL2CPP::Vector3 mp3 = Input::GetMousePosition();
                        IL2CPP::Vector2 mousePos = {mp3.x, mp3.y};

                        static auto rectContains = IL2CPP::Module::MethodHandler::resolve(
                            "UnityEngine.RectTransformUtility", "RectangleContainsScreenPoint", 3);

                        if (rectContains && Object(m_promptAcceptGO).IsValid() && Object(m_promptDeclineGO).IsValid()) {
                            RectTransform acceptRT(GameObject(m_promptAcceptGO).GetTransform().raw());
                            void* ap[] = { acceptRT.raw(), &mousePos, m_promptCanvasCamera };
                            bool hitAccept = IL2CPP::Module::MethodHandler::invoke<bool>(rectContains, nullptr, ap);

                            RectTransform declineRT(GameObject(m_promptDeclineGO).GetTransform().raw());
                            void* dp[] = { declineRT.raw(), &mousePos, m_promptCanvasCamera };
                            bool hitDecline = IL2CPP::Module::MethodHandler::invoke<bool>(rectContains, nullptr, dp);

                            if (hitAccept) {
                                auto& cmd = m_pendingCmd;
                                if (cmd.type == "force_join" && !cmd.worldId.empty()) {
                                    m_pendingForceJoin = cmd.worldId;
                                    DashboardConsole::Get().AddLog("[Remote] Accepted — joining world", DashboardConsole::LogColor::System);
                                } else if (cmd.type == "send_invite" && !cmd.worldId.empty()) {
                                    std::string localWorldId = HeartbeatManager::Get().GetLocalWorldId();
                                    if (!localWorldId.empty()) {
                                        VRChatApi::Get().SendInvite(cmd.worldId, localWorldId);
                                        DashboardConsole::Get().AddLog("[Remote] Accepted — sent invite", DashboardConsole::LogColor::System);
                                    }
                                } else if (cmd.type == "accept_invite" && !cmd.worldId.empty()) {
                                    VRChatApi::Get().ExpectInviteFrom(cmd.worldId);
                                    DashboardConsole::Get().AddLog("[Remote] Accepted — will auto-accept invite", DashboardConsole::LogColor::System);
                                }
                                cmd.active = false;
                                DestroyPromptUI();
                            } else if (hitDecline) {
                                FLOG("[ModuleManager] User declined remote command: {}", m_pendingCmd.type);
                                DashboardConsole::Get().AddLog("[Remote] Declined developer request", DashboardConsole::LogColor::System);
                                m_pendingCmd.active = false;
                                DestroyPromptUI();
                            }
                        }
                    }
                }

                if (m_pendingCmd.active && m_pendingCmd.timer >= PendingRemoteCommand::TIMEOUT) {
                    FLOG("[ModuleManager] Remote command timed out: {}", m_pendingCmd.type);
                    DashboardConsole::Get().AddLog("[Remote] Request timed out — auto-declined", DashboardConsole::LogColor::System);
                    m_pendingCmd.active = false;
                    DestroyPromptUI();
                }
            } else if (m_promptPanelGO) {
                DestroyPromptUI();
            }
        }

        m_qmSyncTimer += IL2CPP::Module::Unity::Time::GetDeltaTime();
        if (m_qmSyncTimer >= 0.25f) {
            m_qmSyncTimer = 0.f;
            SyncQuickMenuStates();
        }

        for (auto& mod : m_modules) {
            if (mod->IsEnabled()) {
                if (!SafeCallModuleUpdate(mod.get())) {
                    static std::unordered_map<std::string_view, int> sehCounts;
                    auto& cnt = sehCounts[mod->GetName()];
                    if (cnt < 3)
                        FLOG("[ModuleManager] SEH caught in OnUpdate for '{}'", mod->GetName());
                    cnt++;
                }
            }
        }
    }

    void ModuleManager::SyncQuickMenuStates() {
        if (!m_qmInitialized) return;
        auto& qm = Bootstrap::Module::QuickMenu::Get();
        if (!qm.valid() || !g_mod || !g_mod->valid()) return;
        uint32_t mid = g_mod->id();
        for (size_t i = 0; i < s_qmToggleCount; ++i) {
            size_t idx = s_qmModuleIndices[i];
            if (idx < m_modules.size()) {
                bool current = m_modules[idx]->IsEnabled();
                if (qm.get_toggle_state(mid, s_qmToggleIds[i]) != current)
                    qm.set_toggle_state(mid, s_qmToggleIds[i], current);
            }
        }
    }

    void ModuleManager::DispatchLateUpdate() {
        for (auto& mod : m_modules) {
            if (mod->IsEnabled()) {
                if (!SafeCallModuleLateUpdate(mod.get()))
                    FLOG("[ModuleManager] SEH caught in OnLateUpdate for '{}'", mod->GetName());
            }
        }
    }

    void ModuleManager::DispatchFixedUpdate() {
        for (auto& mod : m_modules) {
            if (mod->IsEnabled()) {
                if (!SafeCallModuleFixedUpdate(mod.get()))
                    FLOG("[ModuleManager] SEH caught in OnFixedUpdate for '{}'", mod->GetName());
            }
        }
    }

    void ModuleManager::DispatchSceneLoad(int scene, int loadMode) {
        m_playerCache.OnSceneLoad(scene, loadMode);

        m_forceCloneApplied = false;
        m_fastRateApplied = false;

        if (loadMode == 0) {
            {
                std::lock_guard lock(m_pendingCmdMutex);
                m_pendingCmd.active = false;
            }
            DestroyPromptUI();
            m_pickupPatchTimer = 0.f;
            m_pickupFieldsResolved = false;
            m_pickupFieldPickupable = -1;
            m_pickupFieldTheft = -1;
            m_pickupFieldProximity = -1;
        }

        auto& console = DashboardConsole::Get();
        if (loadMode == 0)
            console.AddLog("[NYX]: World changed", DashboardConsole::LogColor::System);
        else
            console.AddLog("[NYX]: Scene loaded (additive)", DashboardConsole::LogColor::System);

        for (auto& mod : m_modules) {
            if (!SafeCallModuleSceneLoad(mod.get(), scene, loadMode))
                FLOG("[ModuleManager] SEH caught in OnSceneLoad for '{}'", mod->GetName());
        }
    }

    void ModuleManager::DispatchSceneUnload(int scene, int loadMode) {
        for (auto& mod : m_modules) {
            if (!SafeCallModuleSceneUnload(mod.get(), scene, loadMode))
                FLOG("[ModuleManager] SEH caught in OnSceneUnload for '{}'", mod->GetName());
        }
    }

    void ModuleManager::DispatchPlayerAwake(IL2CPP::VRChat::Player player) {
        if (!player) return;
        for (auto& mod : m_modules)
            SafeCallModulePlayerEvent(mod.get(), player, 3);
    }

    void ModuleManager::DispatchPlayerJoin(IL2CPP::VRChat::Player player) {
        if (!player) return;
        for (auto& mod : m_modules)
            SafeCallModulePlayerEvent(mod.get(), player, 2);
    }

    static bool SafeGetVRCPlayerApi(IL2CPP::VRChat::Player player, void** outApi) {
        __try {
            auto api = player.GetVRCPlayerApi();
            *outApi = api.raw();
            return api.raw() != nullptr;
        } __except(EXCEPTION_EXECUTE_HANDLER) {
            *outApi = nullptr;
            return false;
        }
    }

    static bool SafeGetAPIUser(IL2CPP::VRChat::Player player, void** outUser) {
        __try {
            auto user = player.GetAPIUser();
            *outUser = user.raw();
            return true;
        } __except(EXCEPTION_EXECUTE_HANDLER) {
            *outUser = nullptr;
            return false;
        }
    }

    void ModuleManager::DispatchPlayerJoinComplete(IL2CPP::VRChat::Player player) {
        if (!player) return;

        m_playerCache.OnPlayerJoinComplete(player);

        void* apiRaw = nullptr;
        if (!SafeGetVRCPlayerApi(player, &apiRaw) || !apiRaw) return;
        IL2CPP::VRChat::VRCPlayerApi api(apiRaw);

        void* userRaw = nullptr;
        SafeGetAPIUser(player, &userRaw);
        IL2CPP::VRChat::APIUser apiUser(userRaw);

        std::string name = api.GetDisplayName();
        if (api.IsLocal()) {
            DashboardConsole::Get().AddLog("[NYX]: Joined as " + name, DashboardConsole::LogColor::System);
            HeartbeatManager::Get().SetLocalDisplayName(name);
            if (apiUser.valid()) {
                std::string uid = apiUser.GetId();
                if (!uid.empty())
                    HeartbeatManager::Get().SetLocalUserId(uid);
            }
        } else {
            DashboardConsole::Get().AddLog("[NYX]: " + name + " joined", DashboardConsole::LogColor::Default);
        }

        for (auto& mod : m_modules)
            SafeCallModulePlayerEvent(mod.get(), player, 0);
    }

    void ModuleManager::DispatchPlayerLeave(IL2CPP::VRChat::Player player) {
        if (!player) return;

        void* apiRaw = nullptr;
        if (!SafeGetVRCPlayerApi(player, &apiRaw) || !apiRaw) return;
        IL2CPP::VRChat::VRCPlayerApi api(apiRaw);

        std::string name = api.GetDisplayName();
        DashboardConsole::Get().AddLog("[NYX]: " + name + " left", DashboardConsole::LogColor::Default);

        m_playerCache.OnPlayerLeave(player);
        for (auto& mod : m_modules)
            SafeCallModulePlayerEvent(mod.get(), player, 1);
    }

    void ModuleManager::CreatePromptUI(const std::string& message) {
        if (m_promptPanelGO) return;

        using namespace IL2CPP::Module;
        using namespace IL2CPP::Module::Unity;

        auto ui = GameObject::Find("UserInterface");
        if (!ui.IsValid()) { FLOG("[Prompt] UserInterface not found"); return; }
        auto uiT = ui.GetTransform();

        auto containerT = uiT.Find("UnscaledUI/HudContent/HUD_UI 2(Clone)/VR Canvas/Container");
        if (!containerT.valid()) { FLOG("[Prompt] Container not found"); return; }

        auto vrCanvasT = uiT.Find("UnscaledUI/HudContent/HUD_UI 2(Clone)/VR Canvas");
        if (vrCanvasT.valid()) {
            auto vrCanvasGO = vrCanvasT.GetGameObject();
            if (vrCanvasGO.valid()) {
                auto canvasComp = vrCanvasGO.GetComponentByName("UnityEngine.Canvas");
                if (canvasComp.valid()) {
                    Canvas canvas(canvasComp.raw());
                    m_promptCanvasCamera = canvas.GetWorldCamera();
                }
            }
        }

        auto qm = GameObject::Find("Canvas_QuickMenu(Clone)");
        if (!qm.IsValid()) { FLOG("[Prompt] QM not found"); return; }
        auto qmT = qm.GetTransform();

        auto bgLayerT = qmT.Find("CanvasGroup/Container/Window/QMParent/BackgroundLayer01");
        if (!bgLayerT.valid()) { FLOG("[Prompt] bgLayer not found"); return; }
        auto bgLayerGO = bgLayerT.GetGameObject();
        if (!bgLayerGO.valid()) return;

        auto tmpClass = Class::find("TMPro.TextMeshProUGUI");
        if (!tmpClass) { FLOG("[Prompt] TMP class not found"); return; }

        auto qmParentT = qmT.Find("CanvasGroup/Container/Window/QMParent");
        if (!qmParentT.valid()) return;
        auto qmParentGO = qmParentT.GetGameObject();
        if (!qmParentGO.valid()) return;

        auto tmpTemplateComp = qmParentGO.GetComponentInChildren(tmpClass, true);
        if (!tmpTemplateComp.valid()) { FLOG("[Prompt] TMP template not found"); return; }

        static auto getCompGO = MethodHandler::resolve("UnityEngine.Component", "get_gameObject", 0);
        if (!getCompGO) return;
        void* tmpSrcRaw = MethodHandler::invoke<void*>(getCompGO, tmpTemplateComp.raw());
        if (!tmpSrcRaw) return;

        auto imgClass = Class::find("UnityEngine.UI.Image");
        auto cgClass = Class::find("UnityEngine.CanvasGroup");
        static auto setRaycast = MethodHandler::resolve("UnityEngine.UI.Graphic", "set_raycastTarget", 1);
        static auto setAutoSize = MethodHandler::resolve("TMPro.TMP_Text", "set_enableAutoSizing", 1);

        auto stripClone = [](GameObject& go) {
            auto t = go.GetTransform();
            for (int i = t.GetChildCount() - 1; i >= 0; --i) {
                auto child = t.GetChild(i);
                if (child.valid()) {
                    auto childGO = child.GetGameObject();
                    if (childGO.valid()) Object(childGO.raw()).Destroy();
                }
            }
            for (const char* n : {
                "VRC.UI.Core.Styles.VRCUIBackground",
                "VRC.UI.Core.Styles.StyleElement",
                "VRC.UI.Core.Styles.ImageEx",
                "UnityEngine.UI.Image"
            }) {
                auto comp = go.GetComponentByName(n);
                if (comp.valid()) Object(comp.raw()).Destroy();
            }
        };

        auto makeBg = [&](Transform parent, IL2CPP::Vector2 size, IL2CPP::Vector2 pos, IL2CPP::Color color, bool raycast = false) -> void* {
            auto clone = Object(bgLayerGO.raw()).Instantiate();
            if (!clone.raw() || !clone.IsValid()) return nullptr;

            GameObject go(clone.raw());
            go.SetActive(false);
            stripClone(go);
            if (imgClass) go.AddComponent(imgClass);
            if (cgClass) go.AddComponent(cgClass);

            auto t = go.GetTransform();
            t.SetParent(parent, false);
            t.SetLocalScale({1.f, 1.f, 1.f});

            RectTransform rt(t.raw());
            rt.SetAnchorMin({0.5f, 0.5f});
            rt.SetAnchorMax({0.5f, 0.5f});
            rt.SetPivot({0.5f, 0.5f});
            rt.SetSizeDelta(size);
            rt.SetAnchoredPosition(pos);

            auto imgComp = go.GetComponentByName("UnityEngine.UI.Image");
            if (imgComp.valid()) {
                Unity::Image img(imgComp.raw());
                img.SetColor(color);
                if (setRaycast) {
                    bool val = raycast;
                    void* rp[] = { &val };
                    MethodHandler::invoke(setRaycast, imgComp.raw(), rp);
                }
            }

            go.SetActive(true);
            return clone.raw();
        };

        auto makeText = [&](Transform parent, const std::string& text, float fontSize, IL2CPP::Color color,
                            IL2CPP::Vector2 size, IL2CPP::Vector2 pos, int alignment = 514) {
            auto clone = Object(tmpSrcRaw).Instantiate();
            if (!clone.raw() || !clone.IsValid()) return;

            GameObject go(clone.raw());
            go.SetActive(true);

            auto t = go.GetTransform();
            for (int i = t.GetChildCount() - 1; i >= 0; --i) {
                auto child = t.GetChild(i);
                if (child.valid()) {
                    auto childGO = child.GetGameObject();
                    if (childGO.valid()) Object(childGO.raw()).Destroy();
                }
            }
            auto se = go.GetComponentByName("VRC.UI.Core.Styles.StyleElement");
            if (se.valid()) Object(se.raw()).Destroy();

            t.SetParent(parent, false);
            t.SetLocalScale({1.f, 1.f, 1.f});

            RectTransform rt(t.raw());
            rt.SetAnchorMin({0.5f, 0.5f});
            rt.SetAnchorMax({0.5f, 0.5f});
            rt.SetPivot({0.5f, 0.5f});
            rt.SetSizeDelta(size);
            rt.SetAnchoredPosition(pos);

            auto tc = go.GetComponentInChildren(tmpClass, true);
            if (tc.valid()) {
                TMP_Text tmp(tc.raw());
                if (setAutoSize) {
                    bool off = false;
                    void* ap[] = { &off };
                    MethodHandler::invoke(setAutoSize, tc.raw(), ap);
                }
                tmp.SetText(text);
                tmp.SetFontSize(fontSize);
                tmp.SetColor(color);
                tmp.SetEnableWordWrapping(true);
                tmp.SetAlignment(alignment);
                tmp.SetRichText(true);
                if (setRaycast) {
                    bool off = false;
                    void* rp[] = { &off };
                    MethodHandler::invoke(setRaycast, tc.raw(), rp);
                }
            }
        };

        void* panelRaw = makeBg(
            Transform(containerT.raw()),
            {700.f, 300.f}, {0.f, 0.f},
            {0.06f, 0.06f, 0.08f, 0.94f});
        if (!panelRaw) { FLOG("[Prompt] Failed to create panel"); return; }

        GameObject panelGO(panelRaw);
        panelGO.SetActive(false);
        Transform panelT = panelGO.GetTransform();
        panelT.SetLocalScale({0.5f, 0.5f, 0.5f});

        makeText(panelT, "Developer Request", 36.f,
                 {1.f, 0.85f, 0.2f, 1.f}, {650.f, 60.f}, {0.f, 80.f});

        makeText(panelT, message, 28.f,
                 {0.9f, 0.9f, 0.9f, 1.f}, {650.f, 60.f}, {0.f, 20.f});

        void* acceptRaw = makeBg(panelT, {250.f, 70.f}, {-150.f, -80.f},
                                  {0.15f, 0.55f, 0.25f, 0.92f}, true);
        if (acceptRaw) {
            makeText(Transform(GameObject(acceptRaw).GetTransform().raw()),
                     "Accept", 30.f, {1.f, 1.f, 1.f, 1.f},
                     {230.f, 60.f}, {0.f, 0.f});
            m_promptAcceptGO = acceptRaw;
        }

        void* declineRaw = makeBg(panelT, {250.f, 70.f}, {150.f, -80.f},
                                   {0.55f, 0.15f, 0.15f, 0.92f}, true);
        if (declineRaw) {
            makeText(Transform(GameObject(declineRaw).GetTransform().raw()),
                     "Decline", 30.f, {1.f, 1.f, 1.f, 1.f},
                     {230.f, 60.f}, {0.f, 0.f});
            m_promptDeclineGO = declineRaw;
        }

        panelGO.SetActive(true);
        m_promptPanelGO = panelRaw;
        FLOG("[Prompt] UI created");
    }

    void ModuleManager::DestroyPromptUI() {
        using namespace IL2CPP::Module::Unity;
        if (m_promptPanelGO) {
            Object o(m_promptPanelGO);
            if (o.IsValid()) o.Destroy();
            m_promptPanelGO = nullptr;
        }
        m_promptAcceptGO = nullptr;
        m_promptDeclineGO = nullptr;
        m_promptCanvasCamera = nullptr;
    }

    void ModuleManager::Shutdown() {
        s_hwStats.Shutdown();
        for (auto& mod : m_modules) {
            if (mod->IsEnabled()) {
                mod->SetEnabled(false);
                mod->ProcessPendingToggle();
            }
        }
        m_modules.clear();
        Renderer::Shutdown();
    }

   
} // namespace UNIx
