#pragma once
#include <Core/BaseModule.hpp>
#include <IL2CPP.Module/include/Unity/Object.hpp>
#include <IL2CPP.Module/include/Unity/Transform.hpp>
#include <IL2CPP.Module/include/Reflection.hpp>
#include <Bootstrap.Module/include/VRChat/APIUser.hpp>
#include <unordered_map>

namespace UNIx {

    class CapsuleESPModule : public BaseModule {
    public:
        CapsuleESPModule() : BaseModule("Capsule ESP", "Through-walls capsule highlight on players", 0, "Visual") {}

        void OnUpdate() override;
        void OnDisable() override;
        void OnSceneLoad(int scene, int loadMode) override;

    private:
        static IL2CPP::Color RankToColor(IL2CPP::VRChat::PlayerRank rank);
        void CleanupAll();

        struct ESPEntry {
            void* goRaw = nullptr;
        };

        std::unordered_map<int, ESPEntry> m_entries;
        void* m_highlightComponent = nullptr;
        IL2CPP::Module::Method m_addHighlightMethod{};
        IL2CPP::Module::Method m_removeHighlightMethod{};
        bool m_highlightResolved = false;
    };

} // namespace UNIx
