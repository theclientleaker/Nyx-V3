#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#include <thread>
#include <atomic>
#include <cstdio>

#include <Bootstrap.Module/Include/module_info.hpp>
UNIX_MODULE_INFO("Nyx", "1.0.1");
    

#include <Core/InstanceHistory/InstanceHistory.hpp>
#include <IL2CPP.Module/include/il2cpp_module.hpp>
#include <IL2CPP.Module/include/Unity/UnityCallbacks.hpp>
#include <Bootstrap.Module/include/module_info.hpp>
#include <Core/Globals.hpp>
#include <Core/FileLog/FileLog.hpp>
#include <Core/ModuleManager.hpp>
#include <Core/TagManager/TagManager.hpp>
#include <Core/ApiClient/ApiClient.hpp>
#include <Core/HeartbeatManager/HeartbeatManager.hpp>
#include <Core/VRChatApi/VRChatApi.hpp>
#include <Core/NameplateConfigManager/NameplateConfigManager.hpp>
#include <Modules/Movement/Speed/MovementModule.hpp>
#include <Modules/Movement/Flight/NoclipModule.hpp>
#include <Modules/Visual/ESP/ESPModule.hpp>
#include <Modules/Visual/ESP/BoneESPModule.hpp>
#include <Modules/Visual/ESP/CapsuleESPModule.hpp>
#include <Modules/Visual/Nameplates/NameplateTagModule.hpp>
#include <Modules/UI/Music/LoadingMusic.hpp>
#include <Modules/Exploits/Portal/PortalSpamModule.hpp>
#include <Modules/Exploits/Portal/PortalOrbitModule.hpp>
#include <Modules/Exploits/LimbSit/LimbSitModule.hpp>
#include <Modules/Exploits/Murder4/Murder4Module.hpp>
#include <Modules/Exploits/AmongUs/Among4Module.hpp>
#include <Modules/Exploits/Prison/PrisonModule.hpp>
#include <Modules/Exploits/Fish/FishModule.hpp>
#include <Modules/Visual/ESP/ItemESPModule.hpp>
#include <Modules/Visual/Zoom/ZoomModule.hpp>
#include <Modules/Visual/Nameplates/CustomNameplateModule.hpp>
#include <Modules/UI/CalendarQM/CalendarQMModule.hpp>
#include <Modules/Visual/LoadingScreen/BetterLoadingScreenModule.hpp>
#include <Modules/Movement/CapsuleRotation/CapsuleRotationModule.hpp>
#include <Modules/Movement/BetterRespawn/BetterRespawnModule.hpp>
#include <Modules/Movement/Rotator/PlayerRotatorModule.hpp>
#include <Modules/Exploits/Pickups/PickupsModule.hpp>
#include <Modules/Exploits/GhostMode/GhostModeModule.hpp>
#include <Modules/Exploits/Event67/Event67Module.hpp>
#include <Modules/Exploits/ChatboxSpam/ChatboxSpamModule.hpp>
#include <Modules/Exploits/ItemOrbit/ItemOrbitModule.hpp>
#include <Modules/Exploits/ItemClapper/ItemClapperModule.hpp>
#include <Modules/Exploits/ItemLagger/ItemLaggerModule.hpp>
#include <Modules/Exploits/PickupDropper/PickupDropperModule.hpp>
#include <Modules/Exploits/PickupFling/PickupFlingModule.hpp>
#include <Modules/Exploits/AvatarHeight/AvatarHeightModule.hpp>
#include <Modules/Visual/ThirdPerson/ThirdPersonModule.hpp>
#include <Modules/Visual/HudStats/HudStatsModule.hpp>
#include <Modules/Movement/RaycastTP/RaycastTPModule.hpp>
#include <Modules/Safety/SafetyModule.hpp>
#include <Modules/Utility/UnityExplorer/UnityExplorerModule.hpp>
#include <Modules/Utility/BundleDecrypt/BundleDecryptModule.hpp>
#include <Modules/Utility/Performance/PerformanceModule.hpp>
#include <Modules/Exploits/Blackout/BlackoutModule.hpp>
#include <Modules/Exploits/HideAndShriek/HideAndShriekModule.hpp>
#include <Modules/Exploits/NightShift/NightShiftModule.hpp>
#include <Modules/Exploits/RumbleDisaster/RumbleDisasterModule.hpp>
#include <Modules/Exploits/SlashCo/SlashCoModule.hpp>
#include <Modules/Exploits/ZombieSurvival/ZombieSurvivalModule.hpp>
#include <Modules/Exploits/SuperTowerDefense/SuperTowerDefenseModule.hpp>
#include <Modules/Exploits/GhostPolice/GhostPoliceModule.hpp>
#include <Modules/UI/UIRemover/UIRemoverModule.hpp>
#include <Modules/UI/WingPlayerList/WingPlayerListModule.hpp>

#include <Modules/UI/ScreenConsole/ScreenConsoleModule.hpp>
#include <Modules/UI/Spotify/SpotifyModule.hpp>
#include <Core/DebugBridge/DebugBridge.hpp>
#include <Core/DiscordRPC/DiscordRPC.hpp>
#include <Modules/UI/Notifier/NotifierModule.hpp>
#include <Modules/UI/Toasts/ToastModule.hpp>
#include <Modules/Visual/OrbitCamera/OrbitCameraModule.hpp>
#include <Modules/Visual/CrashDetection/CrashDetection.hpp>
#include <Modules/UI/InstanceHistory/InstanceHistoryModule.hpp>

static LONG WINAPI NyxVEH(EXCEPTION_POINTERS* ep) {
    if (!ep || !ep->ExceptionRecord) return EXCEPTION_CONTINUE_SEARCH;
    if (ep->ExceptionRecord->ExceptionCode != EXCEPTION_ACCESS_VIOLATION)
        return EXCEPTION_CONTINUE_SEARCH;

#ifdef _M_X64
    auto* ctx = ep->ContextRecord;
    uint8_t* rip = reinterpret_cast<uint8_t*>(ctx->Rip);

    __try {
        if (rip[0] == 0x48 && rip[1] == 0x8B) {
            int len = (rip[2] >= 0x80) ? 7 : ((rip[2] >= 0x40) ? 4 : 3);
            if ((rip[2] & 0x07) == 0x04) len++;
            ctx->Rax = 0;
            ctx->Rip += len;
            return EXCEPTION_CONTINUE_EXECUTION;
        }

        if ((rip[0] & 0xF0) == 0x40 && rip[1] == 0x8B) {
            int len = (rip[3] >= 0x80) ? 8 : ((rip[3] >= 0x40) ? 5 : 4);
            ctx->Rax = 0;
            ctx->Rip += len;
            return EXCEPTION_CONTINUE_EXECUTION;
        }

        if (rip[0] == 0x8B) {
            int len = (rip[1] >= 0x80) ? 6 : ((rip[1] >= 0x40) ? 3 : 2);
            ctx->Rax = 0;
            ctx->Rip += len;
            return EXCEPTION_CONTINUE_EXECUTION;
        }
    } __except(EXCEPTION_EXECUTE_HANDLER) {}
#endif

    return EXCEPTION_CONTINUE_SEARCH;
}

static void* s_vehHandle = nullptr;

static Logger::Module::Logger              s_logger;
static Bootstrap::Module::BootstrapModule  s_mod;
static Hooking::Module::HookModule         s_hook;
static std::thread                         s_initThread;
static std::atomic<bool>                   s_initialized{false};


static void SafeDispatchUpdate() {
    __try {
        UNIx::DebugBridge::Get().ProcessCommands();
    } __except(EXCEPTION_EXECUTE_HANDLER) {}
    __try {
        UNIx::ModuleManager::Get().DispatchUpdate();
    } __except(EXCEPTION_EXECUTE_HANDLER) {}
}
static void SafeDispatchLateUpdate() {
    __try {
        UNIx::ModuleManager::Get().DispatchLateUpdate();
    } __except(EXCEPTION_EXECUTE_HANDLER) {}
}
static void SafeDispatchFixedUpdate() {
    __try {
        UNIx::ModuleManager::Get().DispatchFixedUpdate();
    } __except(EXCEPTION_EXECUTE_HANDLER) {}
}
static void SafeDispatchSceneLoad(int scene, int loadMode) {
    __try {
        UNIx::ModuleManager::Get().DispatchSceneLoad(scene, loadMode);
    } __except(EXCEPTION_EXECUTE_HANDLER) {}
}
static void SafeDispatchSceneUnload(int scene, int loadMode) {
    __try {
        UNIx::ModuleManager::Get().DispatchSceneUnload(scene, loadMode);
    } __except(EXCEPTION_EXECUTE_HANDLER) {}
}
static void SafeDispatchPlayerAwake(IL2CPP::VRChat::Player player) {
    __try {
        UNIx::ModuleManager::Get().DispatchPlayerAwake(player);
    } __except(EXCEPTION_EXECUTE_HANDLER) {}
}
static void SafeDispatchPlayerJoin(IL2CPP::VRChat::Player player) {
    __try {
        UNIx::ModuleManager::Get().DispatchPlayerJoin(player);
    } __except(EXCEPTION_EXECUTE_HANDLER) {}
}
static void SafeDispatchPlayerJoinComplete(IL2CPP::VRChat::Player player) {
    __try {
        UNIx::ModuleManager::Get().DispatchPlayerJoinComplete(player);
    } __except(EXCEPTION_EXECUTE_HANDLER) {}
}
static void SafeDispatchPlayerLeave(IL2CPP::VRChat::Player player) {
    __try {
        UNIx::ModuleManager::Get().DispatchPlayerLeave(player);
    } __except(EXCEPTION_EXECUTE_HANDLER) {}
}

static void SafeRender(const Hooking::UiRenderContext* ctx) {
    __try {
        UNIx::ModuleManager::Render(ctx);
    } __except(EXCEPTION_EXECUTE_HANDLER) {}
}

static void SafeResize(uint32_t w, uint32_t h) {
    __try {
        UNIx::ModuleManager::Resize(w, h);
    } __except(EXCEPTION_EXECUTE_HANDLER) {}
}

static bool SafeWndProc(void* hWnd, uint32_t msg, uintptr_t wp, intptr_t lp) {
    __try {
        return UNIx::ModuleManager::OnWndProc(hWnd, msg, wp, lp);
    } __except(EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

static void InitThread() {
    UNIx::FLOG("InitThread started");

    Bootstrap::Module::ClientUsage::Get().register_client(s_mod.id(), "nyx", "");

    IL2CPP::Module::Unity::Callbacks::Initialize();
    UNIx::FLOG("Unity callbacks initialized");

    IL2CPP::Module::Unity::Callbacks::Register<SafeDispatchUpdate>(IL2CPP::UnityEvent::Update);
    IL2CPP::Module::Unity::Callbacks::Register<SafeDispatchLateUpdate>(IL2CPP::UnityEvent::LateUpdate);
    IL2CPP::Module::Unity::Callbacks::Register<SafeDispatchFixedUpdate>(IL2CPP::UnityEvent::FixedUpdate);
    IL2CPP::Module::Unity::Callbacks::Register<SafeDispatchSceneLoad>(IL2CPP::UnityEvent::OnSceneLoaded);
    IL2CPP::Module::Unity::Callbacks::Register<SafeDispatchSceneUnload>(IL2CPP::UnityEvent::OnSceneUnloaded);


    auto& events = IL2CPP::VRChat::VRChatEvents::Get();
    events.register_on_awake(s_mod.id(), SafeDispatchPlayerAwake);
    events.register_on_join(s_mod.id(), SafeDispatchPlayerJoin);
    events.register_on_join_complete(s_mod.id(), SafeDispatchPlayerJoinComplete);
    events.register_on_leave(s_mod.id(), SafeDispatchPlayerLeave);
    UNIx::FLOG("Events registered");

    s_hook.register_render(SafeRender);
    s_hook.register_resize(SafeResize);
    s_hook.register_wndproc(SafeWndProc);
    UNIx::FLOG("Hooks registered");

    UNIx::ApiClient::Get().Start();
    UNIx::FLOG("ApiClient started");

    UNIx::TagManager::Get().Start();
    UNIx::FLOG("TagManager started");

    UNIx::HeartbeatManager::Get().Start();
    UNIx::FLOG("HeartbeatManager started");

    UNIx::NameplateConfigManager::Get().Start();
    UNIx::FLOG("NameplateConfigManager started");

    auto& mgr = UNIx::ModuleManager::Get();
    mgr.Register<UNIx::MovementModule>();
    mgr.Register<UNIx::ESPModule>();
    mgr.Register<UNIx::BoneESPModule>();
    mgr.Register<UNIx::NoclipModule>();
    mgr.Register<UNIx::LoadingMusic>();
    mgr.Register<UNIx::NameplateTagModule>();
    mgr.Register<UNIx::PortalSpamModule>();
    mgr.Register<UNIx::PortalOrbitModule>();
    mgr.Register<UNIx::LimbSitModule>();
    mgr.Register<UNIx::CustomNameplateModule>();
    mgr.Register<UNIx::ZoomModule>();
    mgr.Register<UNIx::ItemESPModule>();
    mgr.Register<UNIx::BetterLoadingScreenModule>();
    mgr.Register<UNIx::CapsuleRotationModule>();
    mgr.Register<UNIx::BetterRespawnModule>();
    mgr.Register<UNIx::Murder4Module>();
    mgr.Register<UNIx::Among4Module>();
    mgr.Register<UNIx::PrisonModule>();
    mgr.Register<UNIx::FishModule>();
    mgr.Register<UNIx::PlayerRotatorModule>();
    mgr.Register<UNIx::PickupsModule>();
    mgr.Register<UNIx::GhostModeModule>();
    mgr.Register<UNIx::Event67Module>();
    mgr.Register<UNIx::ChatboxSpamModule>();
    mgr.Register<UNIx::SafetyModule>();
    mgr.Register<UNIx::UnityExplorerModule>();
    mgr.Register<UNIx::CalendarQMModule>();
    mgr.Register<UNIx::UIRemoverModule>();
    mgr.Register<UNIx::WingPlayerListModule>();
   mgr.Register<UNIx::NotifierModule>();
    mgr.Register<UNIx::BundleDecryptModule>();
    mgr.Register<UNIx::BlackoutModule>();
    mgr.Register<UNIx::HideAndShriekModule>();
  //  mgr.Register<UNIx::NightShiftModule>();
    mgr.Register<UNIx::RumbleDisasterModule>();
   // mgr.Register<UNIx::SlashCoModule>();


    mgr.Register<UNIx::ZombieSurvivalModule>();
    mgr.Register<UNIx::SuperTowerDefenseModule>();
    mgr.Register<UNIx::GhostPoliceModule>();
    // mgr.Register<UNIx::SettingsMenuModule>();
    mgr.Register<UNIx::PerformanceModule>();
    mgr.Register<UNIx::CapsuleESPModule>();
    mgr.Register<UNIx::ScreenConsoleModule>();
    mgr.Register<UNIx::SpotifyModule>();
    mgr.Register<UNIx::ThirdPersonModule>();
    mgr.Register<UNIx::RaycastTPModule>();
    mgr.Register<UNIx::ItemOrbitModule>();
    mgr.Register<UNIx::ItemClapperModule>();
    mgr.Register<UNIx::ItemLaggerModule>();
    mgr.Register<UNIx::PickupDropperModule>();
    mgr.Register<UNIx::PickupFlingModule>();
    mgr.Register<UNIx::AvatarHeightModule>();
    mgr.Register<UNIx::ToastModule>();
    mgr.Register<UNIx::OrbitCameraModule>();
    mgr.Register<UNIx::HudStatsModule>();
    mgr.Register<UNIx::CrashDetectionModule>();
    mgr.Register<UNIx::InstanceHistoryModule>();
    UNIx::InstanceHistory::Get().Load();
    UNIx::FLOG("InstanceHistory loaded");

    UNIx::FLOG("All modules registered");

    UNIx::FileLog::Get().SetCallback([](const std::string& ts, const std::string& msg) {
        if (UNIx::ScreenConsoleModule::s_instance)
            UNIx::ScreenConsoleModule::s_instance->PushLine(ts, msg);
    });


    UNIx::DebugBridge::Get().Start();
    UNIx::FLOG("DebugBridge started");

    UNIx::DiscordRPC::Get().Start();
    UNIx::FLOG("DiscordRPC started");

    UNIx::VRChatApi::Get().SetInviteAcceptedCallback([](const std::string& worldId) {
        UNIx::ModuleManager::Get().QueueForceJoin(worldId);
    });
    UNIx::VRChatApi::Get().StartNotificationPoller();
    UNIx::FLOG("VRChatApi notification poller started");

    s_initialized = true;
    s_logger.info("nyx loaded successfully!");
    UNIx::FLOG("Main() complete");

    Bootstrap::Module::ClientUsage::Get().register_client(s_mod.id(), "nyx", "usage_BsbtYlVTq7znSWeyYhJnZc2Z8JSJLHkI");
}

static void Main() {
    AllocConsole();
    SetConsoleTitleA("nyx :3");

    HANDLE conOut = CreateFileA("CONOUT$", GENERIC_WRITE, FILE_SHARE_WRITE,
                                nullptr, OPEN_EXISTING, 0, nullptr);
    if (conOut != INVALID_HANDLE_VALUE)
        UNIx::FileLog::Get().SetConsoleHandle(conOut);

    HANDLE nulHandle = CreateFileA("NUL", GENERIC_WRITE, FILE_SHARE_WRITE,
                                   nullptr, OPEN_EXISTING, 0, nullptr);
    if (nulHandle != INVALID_HANDLE_VALUE) {
        SetStdHandle(STD_OUTPUT_HANDLE, nulHandle);
        SetStdHandle(STD_ERROR_HANDLE, nulHandle);
    }
    FILE* nulStream = nullptr;
    freopen_s(&nulStream, "NUL", "w", stdout);
    freopen_s(&nulStream, "NUL", "w", stderr);

    SetErrorMode(SEM_FAILCRITICALERRORS | SEM_NOGPFAULTERRORBOX);

    SetUnhandledExceptionFilter([](EXCEPTION_POINTERS* ep) -> LONG {
        if (ep && ep->ExceptionRecord && ep->ContextRecord) {
            HMODULE hMod = nullptr;
            char modName[MAX_PATH] = "unknown";
            auto addr = reinterpret_cast<void*>(ep->ContextRecord->Rip);
            if (GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS,
                                   reinterpret_cast<LPCSTR>(addr), &hMod) && hMod) {
                GetModuleFileNameA(hMod, modName, MAX_PATH);
            }
            uintptr_t offset = reinterpret_cast<uintptr_t>(addr) -
                               reinterpret_cast<uintptr_t>(hMod);
            UNIx::FLOG("[CRASH] Exception 0x{:08X} at {} + 0x{:X} (RIP=0x{:X})",
                ep->ExceptionRecord->ExceptionCode, modName, offset,
                ep->ContextRecord->Rip);
            if (ep->ExceptionRecord->ExceptionCode == EXCEPTION_ACCESS_VIOLATION &&
                ep->ExceptionRecord->NumberParameters >= 2) {
                UNIx::FLOG("[CRASH] Access violation {} at address 0x{:X}",
                    ep->ExceptionRecord->ExceptionInformation[0] ? "write" : "read",
                    ep->ExceptionRecord->ExceptionInformation[1]);
            }
        }
        return EXCEPTION_CONTINUE_SEARCH;
    });

    s_vehHandle = AddVectoredExceptionHandler(1, NyxVEH);

    UNIx::FLOG("Main() enter");

    if (!Logger::Module::Connect()) { UNIx::FLOG("Logger connect FAILED"); return; }
    if (!Hooking::Module::Connect()) { UNIx::FLOG("Hooking connect FAILED"); return; }
    if (!IL2CPP::Module::Connect()) { UNIx::FLOG("IL2CPP connect FAILED"); return; }
    if (!Bootstrap::Module::Connect()) { UNIx::FLOG("Bootstrap connect FAILED"); return; }

    UNIx::FLOG("All modules connected");

    s_logger = Logger::Module::Logger("nyx");
    s_mod = Bootstrap::Module::BootstrapModule("nyx");
    s_hook = Hooking::Module::HookModule("nyx");

    UNIx::g_logger = &s_logger;
    UNIx::g_mod = &s_mod;
    UNIx::g_hook = &s_hook;

    s_initThread = std::thread(InitThread);
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD reason, LPVOID) {
    switch (reason) {
    case DLL_PROCESS_ATTACH:
        UNIx::g_hModule = hModule;
        DisableThreadLibraryCalls(hModule);
        UNIx::FileLog::Get().Init(hModule);
        UNIx::FLOG("DLL_PROCESS_ATTACH");
        Main();
        break;

    case DLL_PROCESS_DETACH:
        UNIx::FLOG("DLL_PROCESS_DETACH");
        if (s_initThread.joinable()) s_initThread.join();
        if (s_initialized) {
            UNIx::DiscordRPC::Get().Stop();
            UNIx::DebugBridge::Get().Stop();
            UNIx::VRChatApi::Get().StopNotificationPoller();
            UNIx::NameplateConfigManager::Get().Stop();
            UNIx::HeartbeatManager::Get().Stop();
            UNIx::TagManager::Get().Stop();
            UNIx::ApiClient::Get().Stop();
            UNIx::ModuleManager::Get().Shutdown();
            IL2CPP::Module::Unity::Callbacks::Uninitialize();
        }
        UNIx::g_logger = nullptr;
        UNIx::g_mod = nullptr;
        UNIx::g_hook = nullptr;
        Bootstrap::Module::Disconnect();
        Hooking::Module::Disconnect();
        IL2CPP::Module::Disconnect();
        Logger::Module::Disconnect();
        UNIx::FileLog::Get().Shutdown();
        FreeConsole();
        break;

    default:
        break;
    }
    return TRUE;
    
}
