#pragma once

#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#include <d3d11.h>
#include <dxgi.h>

#include <Hooking.Common/hook_shared.hpp>

namespace UNIx {

    class Renderer {
    public:
        static void Initialize(const Hooking::UiRenderContext* ctx);
        static void BeginFrame();
        static void EndFrame();
        static void OnResize();
        static void Shutdown();
        static bool IsInitialized();
        static ID3D11Device* GetDevice() { return s_device; }

    private:
        struct D3D11StateBackup {
            ID3D11RenderTargetView*   rtv = nullptr;
            ID3D11DepthStencilView*   dsv = nullptr;
            D3D11_VIEWPORT            viewports[D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE]{};
            UINT                      numViewports = 0;
            ID3D11BlendState*         blendState = nullptr;
            FLOAT                     blendFactor[4]{};
            UINT                      sampleMask = 0;
            ID3D11DepthStencilState*  depthStencilState = nullptr;
            UINT                      stencilRef = 0;
            ID3D11RasterizerState*    rasterizerState = nullptr;

            void Save(ID3D11DeviceContext* ctx);
            void Restore(ID3D11DeviceContext* ctx);
        };

        static inline bool                    s_initialized = false;
        static inline ID3D11Device*           s_device = nullptr;
        static inline ID3D11DeviceContext*    s_context = nullptr;
        static inline ID3D11RenderTargetView* s_renderTarget = nullptr;
        static inline IDXGISwapChain*         s_swapChain = nullptr;
        static inline HWND                    s_window = nullptr;
    };

} // namespace UNIx
