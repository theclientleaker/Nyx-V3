#pragma once

#define WIN32_LEAN_AND_MEAN
#include <Windows.h>

#include <Logging.Module/include/logger_module.hpp>
#include <Hooking.Module/include/hook_module.hpp>
#include <Bootstrap.Module/include/bootstrap_module.hpp>

namespace UNIx {

    inline HMODULE                          g_hModule = nullptr;
    inline Logger::Module::Logger*          g_logger  = nullptr;
    inline Bootstrap::Module::BootstrapModule* g_mod  = nullptr;
    inline Hooking::Module::HookModule*     g_hook    = nullptr;

} // namespace UNIx
