#pragma once
//
//  NyxTagsSDK — standalone tag API client for third-party clients
//
//  Get an API key from the nyx admin (created via POST /api/keys).
//  Permissions: "tags:write" for writing tags, "nameplates:read" for reading nameplates.
//  Tag reads are public — no permission needed.
//
//  Each API key writes to its own isolated tag store. Reads return all tags
//  combined (global + all client stores).
//
//  Usage:
//    NyxTags::Init("your-api-key-here");
//    auto tags = NyxTags::FetchAll();
//    auto userTags = NyxTags::GetTagsForUser(tags, "usr_xxx");
//    NyxTags::SetTag("usr_xxx", "rain.<color=#FF0000>Cool Tag</color>");
//    NyxTags::AddTag("usr_xxx", "pulse.<color=#00FF00>Extra</color>");
//    NyxTags::RemoveTag("usr_xxx");
//    auto nameplates = NyxTags::FetchNameplates();
//
//  Requires: winhttp.lib linked, C++17
//

#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#include <winhttp.h>
#include <string>
#include <vector>
#include <unordered_map>
#include <sstream>
#include <cstdlib>
#include <algorithm>

#pragma comment(lib, "winhttp.lib")

namespace NyxTags {

    struct Color4 {
        float r = 1.f, g = 1.f, b = 1.f, a = 1.f;
    };

    enum AnimFlag : uint16_t {
        Anim_None           = 0,
        Anim_Rainbow        = 1 << 0,
        Anim_SmoothRainbow  = 1 << 1,
        Anim_Blink          = 1 << 2,
        Anim_Scroll         = 1 << 3,
        Anim_Cylinder       = 1 << 4,
        Anim_Pulse          = 1 << 5,
        Anim_Glitch         = 1 << 6,
        Anim_Jump           = 1 << 7,
        Anim_Shake          = 1 << 8,
        Anim_GhostTrail     = 1 << 9,
        Anim_LetterByLetter = 1 << 10,
    };

    struct Tag {
        std::string text;
        std::string iconName;
        Color4 color;
        uint16_t animations = Anim_None;

        bool HasAnim(AnimFlag flag) const { return (animations & flag) != 0; }
    };

    using TagMap = std::unordered_map<std::string, std::vector<Tag>>;

    inline void Init(const std::string& apiKey);
    inline TagMap FetchAll();
    inline std::string FetchVersion();
    inline std::vector<Tag> GetTagsForUser(const TagMap& tags, const std::string& userId);
    inline bool SetTag(const std::string& userId, const std::string& tagData);
    inline bool AddTag(const std::string& userId, const std::string& tagData);
    inline bool RemoveTag(const std::string& userId);
    inline std::string FetchMyRawTags(const std::string& userId);
    inline std::string FetchNameplates();
    inline std::string FetchNameplateVersion();

    // ── Implementation ──

    namespace detail {
        inline std::string g_apiKey;
        inline HINTERNET g_session = nullptr;

        inline void EnsureSession() {
            if (g_session) return;
            g_session = WinHttpOpen(L"NyxTagsSDK/1.0",
                WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
            if (g_session)
                WinHttpSetTimeouts(g_session, 10000, 10000, 10000, 10000);
        }

        inline std::string DoRequest(const wchar_t* method, const std::wstring& path, const std::string& body = "", const wchar_t* contentType = L"application/json") {
            EnsureSession();
            if (!g_session) return "";

            HINTERNET hConnect = WinHttpConnect(g_session, L"api.lexie.lol", INTERNET_DEFAULT_HTTPS_PORT, 0);
            if (!hConnect) return "";

            HINTERNET hRequest = WinHttpOpenRequest(hConnect, method, path.c_str(),
                nullptr, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, WINHTTP_FLAG_SECURE);
            if (!hRequest) { WinHttpCloseHandle(hConnect); return ""; }

            std::wstring authHeader = L"Authorization: Bearer ";
            authHeader += std::wstring(g_apiKey.begin(), g_apiKey.end());
            std::wstring headers = authHeader;
            if (!body.empty()) {
                headers += L"\r\nContent-Type: ";
                headers += contentType;
            }

            LPVOID bodyPtr = body.empty() ? WINHTTP_NO_REQUEST_DATA : const_cast<char*>(body.c_str());
            DWORD bodyLen = static_cast<DWORD>(body.size());

            BOOL sent = WinHttpSendRequest(hRequest, headers.c_str(), static_cast<DWORD>(headers.size()),
                bodyPtr, bodyLen, bodyLen, 0);

            std::string response;
            if (sent && WinHttpReceiveResponse(hRequest, nullptr)) {
                DWORD bytesAvailable = 0;
                while (WinHttpQueryDataAvailable(hRequest, &bytesAvailable) && bytesAvailable > 0) {
                    std::vector<char> buf(bytesAvailable);
                    DWORD bytesRead = 0;
                    WinHttpReadData(hRequest, buf.data(), bytesAvailable, &bytesRead);
                    response.append(buf.data(), bytesRead);
                }
            }

            WinHttpCloseHandle(hRequest);
            WinHttpCloseHandle(hConnect);
            return response;
        }

        inline Color4 ParseColor(const std::string& hex) {
            Color4 c;
            if (hex.size() < 6) return c;
            unsigned long val = std::strtoul(hex.substr(0, 6).c_str(), nullptr, 16);
            c.r = ((val >> 16) & 0xFF) / 255.f;
            c.g = ((val >> 8) & 0xFF) / 255.f;
            c.b = (val & 0xFF) / 255.f;
            if (hex.size() >= 8) {
                unsigned long alpha = std::strtoul(hex.substr(6, 2).c_str(), nullptr, 16);
                c.a = alpha / 255.f;
            }
            return c;
        }

        inline AnimFlag ParseAnimation(const std::string& prefix) {
            std::string p = prefix;
            std::transform(p.begin(), p.end(), p.begin(), [](unsigned char c) { return static_cast<char>(std::toupper(c)); });
            if (p == "RAIN") return Anim_Rainbow;
            if (p == "SR") return Anim_SmoothRainbow;
            if (p == "BLINK") return Anim_Blink;
            if (p == "SCROLL") return Anim_Scroll;
            if (p == "CYLINDER" || p == "CYLN") return Anim_Cylinder;
            if (p == "PULSE") return Anim_Pulse;
            if (p == "GLITCH") return Anim_Glitch;
            if (p == "GT") return Anim_GhostTrail;
            if (p == "JUMP") return Anim_Jump;
            if (p == "SHAKE") return Anim_Shake;
            if (p == "LBL") return Anim_LetterByLetter;
            return Anim_None;
        }

        inline Tag ParseSingleTag(const std::string& raw) {
            Tag tag;
            std::string remaining = raw;

            if (remaining.size() > 6 && remaining.substr(0, 6) == "<icon=") {
                auto closePos = remaining.find('>');
                if (closePos != std::string::npos) {
                    tag.iconName = remaining.substr(6, closePos - 6);
                    return tag;
                }
            }

            while (remaining.size() > 2) {
                std::string animPrefix;
                size_t textStart;

                if (remaining[0] == '.' || remaining[0] == ':') {
                    size_t next = std::string::npos;
                    for (size_t j = 1; j < remaining.size(); ++j) {
                        if (remaining[j] == '.' || remaining[j] == ':') { next = j; break; }
                    }
                    if (next == std::string::npos) break;
                    animPrefix = remaining.substr(1, next - 1);
                    textStart = next + 1;
                } else {
                    if (remaining[0] == '<') break;
                    size_t next = std::string::npos;
                    for (size_t j = 0; j < remaining.size(); ++j) {
                        if (remaining[j] == '.' || remaining[j] == ':') { next = j; break; }
                    }
                    if (next == std::string::npos) break;
                    animPrefix = remaining.substr(0, next);
                    textStart = next + 1;
                }

                AnimFlag at = ParseAnimation(animPrefix);
                if (at == Anim_None) break;
                tag.animations |= at;
                remaining = remaining.substr(textStart);
            }

            auto colorStart = remaining.find("<color=");
            auto colorEnd = remaining.find('>', colorStart != std::string::npos ? colorStart : 0);
            if (colorStart != std::string::npos && colorEnd != std::string::npos && colorEnd > colorStart) {
                std::string colorVal = remaining.substr(colorStart + 7, colorEnd - colorStart - 7);
                if (!colorVal.empty() && colorVal[0] == '#')
                    colorVal = colorVal.substr(1);
                tag.color = ParseColor(colorVal);

                auto closeTag = remaining.find("</color>");
                if (closeTag != std::string::npos)
                    tag.text = remaining.substr(colorEnd + 1, closeTag - colorEnd - 1);
                else
                    tag.text = remaining.substr(colorEnd + 1);
            } else {
                tag.text = remaining;
            }

            return tag;
        }
    }

    inline void Init(const std::string& apiKey) {
        detail::g_apiKey = apiKey;
    }

    inline TagMap FetchAll() {
        std::string body = detail::DoRequest(L"GET", L"/api/tags");
        TagMap result;
        if (body.empty()) return result;

        std::istringstream stream(body);
        std::string line;
        while (std::getline(stream, line)) {
            if (!line.empty() && line.back() == '\r') line.pop_back();
            if (line.empty()) continue;

            auto colonPos = line.rfind(':');
            if (colonPos == std::string::npos || colonPos == 0) continue;

            std::string tagsPart = line.substr(0, colonPos);
            std::string userId = line.substr(colonPos + 1);
            if (userId.empty() || userId.find("usr_") != 0) continue;

            std::vector<Tag> parsed;
            std::istringstream tagStream(tagsPart);
            std::string singleTag;
            while (std::getline(tagStream, singleTag, ',')) {
                if (!singleTag.empty())
                    parsed.push_back(detail::ParseSingleTag(singleTag));
            }
            if (!parsed.empty())
                result[userId] = std::move(parsed);
        }
        return result;
    }

    inline std::string FetchVersion() {
        return detail::DoRequest(L"GET", L"/api/tags/version");
    }

    inline std::vector<Tag> GetTagsForUser(const TagMap& tags, const std::string& userId) {
        auto it = tags.find(userId);
        if (it != tags.end()) return it->second;
        return {};
    }

    inline bool SetTag(const std::string& userId, const std::string& tagData) {
        std::string body = tagData + ":" + userId;
        std::string resp = detail::DoRequest(L"POST", L"/api/tags", body, L"text/plain");
        return !resp.empty();
    }

    inline std::string FetchMyRawTags(const std::string& userId) {
        std::wstring path = L"/api/tags/mine/";
        path += std::wstring(userId.begin(), userId.end());
        std::string resp = detail::DoRequest(L"GET", path);
        if (resp.empty()) return "";
        auto colonPos = resp.rfind(':');
        if (colonPos == std::string::npos || colonPos == 0) return "";
        return resp.substr(0, colonPos);
    }

    inline bool AddTag(const std::string& userId, const std::string& tagData) {
        std::string existing = FetchMyRawTags(userId);
        std::string combined = existing.empty() ? tagData : existing + "," + tagData;
        return SetTag(userId, combined);
    }

    inline bool RemoveTag(const std::string& userId) {
        std::wstring path = L"/api/tags/";
        path += std::wstring(userId.begin(), userId.end());
        std::string resp = detail::DoRequest(L"DELETE", path);
        return !resp.empty();
    }

    inline std::string FetchNameplates() {
        return detail::DoRequest(L"GET", L"/api/nameplates");
    }

    inline std::string FetchNameplateVersion() {
        return detail::DoRequest(L"GET", L"/api/nameplates/version");
    }

}
