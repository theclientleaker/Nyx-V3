#include <Core/InstanceHistory/InstanceHistory.hpp>
#include <Core/FileLog/FileLog.hpp>

#include <winhttp.h>
#include <ThirdParty/stb/stb_image.h>

#include <fstream>
#include <sstream>
#include <thread>
#include <chrono>
#include <filesystem>
#include <algorithm>

namespace UNIx {

    InstanceHistory& InstanceHistory::Get() {
        static InstanceHistory instance;
        return instance;
    }

    bool InstanceHistory::IsNewLocation(const std::string& locationString) const {
        std::lock_guard lock(m_mutex);
        return m_currentLocation != locationString;
    }

    void InstanceHistory::LogInstance(const InstanceEntry& entry) {
        {
            std::lock_guard lock(m_mutex);
            m_currentLocation = entry.locationString;

            m_entries.erase(
                std::remove_if(m_entries.begin(), m_entries.end(),
                    [&](const InstanceEntry& e) { return e.locationString == entry.locationString; }),
                m_entries.end());

            m_entries.insert(m_entries.begin(), entry);

            if (m_entries.size() > kMaxEntries)
                m_entries.resize(kMaxEntries);
        }
        Save();
    }

    std::vector<InstanceEntry> InstanceHistory::GetEntries() const {
        std::lock_guard lock(m_mutex);
        return m_entries;
    }

    void InstanceHistory::Clear() {
        {
            std::lock_guard lock(m_mutex);
            m_entries.clear();
            m_currentLocation.clear();
        }
        Save();
    }

    void InstanceHistory::Save() const {
        std::lock_guard lock(m_mutex);
        try {
            std::filesystem::create_directories("C:\\nyx\\Config");
            std::ofstream file(kSavePath, std::ios::trunc);
            if (!file) return;
            for (auto& e : m_entries) {
                file << e.worldName << '\t'
                     << e.worldId << '\t'
                     << e.locationString << '\t'
                     << e.thumbnailUrl << '\t'
                     << e.playerCount << '\t'
                     << e.maxPlayers << '\t'
                     << e.timestamp << '\n';
            }
        } catch (...) {}
    }

    void InstanceHistory::Load() {
        std::lock_guard lock(m_mutex);
        m_entries.clear();

        try {
            std::ifstream file(kSavePath);
            if (file) {
                std::string line;
                while (std::getline(file, line)) {
                    if (line.empty()) continue;
                    std::istringstream ss(line);
                    InstanceEntry e;
                    std::string tmp;
                    if (!std::getline(ss, e.worldName, '\t')) continue;
                    if (!std::getline(ss, e.worldId, '\t')) continue;
                    if (!std::getline(ss, e.locationString, '\t')) continue;
                    if (!std::getline(ss, e.thumbnailUrl, '\t')) continue;
                    if (!std::getline(ss, tmp, '\t')) continue;
                    try { e.playerCount = std::stoi(tmp); } catch (...) {}
                    if (!std::getline(ss, tmp, '\t')) continue;
                    try { e.maxPlayers = std::stoi(tmp); } catch (...) {}
                    if (std::getline(ss, tmp))
                        try { e.timestamp = std::stoll(tmp); } catch (...) {}
                    m_entries.push_back(std::move(e));
                }
            }
        } catch (...) {}

        if (m_entries.empty()) {
            try {
                std::ifstream oldFile("C:\\nyx\\instance_history.txt");
                if (oldFile) {
                    std::string line;
                    while (std::getline(oldFile, line)) {
                        if (line.empty()) continue;
                        std::istringstream ss(line);
                        InstanceEntry e;
                        std::string tmp;
                        if (!std::getline(ss, tmp, '|')) continue;
                        try { e.timestamp = std::stoll(tmp); } catch (...) { continue; }
                        if (!std::getline(ss, e.worldId, '|')) continue;
                        std::string instanceId;
                        if (!std::getline(ss, instanceId, '|')) continue;
                        if (std::getline(ss, tmp, '|'))
                            try { e.playerCount = std::stoi(tmp); } catch (...) {}
                        e.locationString = e.worldId;
                        if (!instanceId.empty()) e.locationString += ":" + instanceId;
                        e.worldName = e.worldId;
                        m_entries.push_back(std::move(e));
                    }
                    if (!m_entries.empty()) {
                        FLOG("[InstanceHistory] Migrated {} entries from old format", m_entries.size());
                        Save();
                    }
                }
            } catch (...) {}
        }

        FLOG("[InstanceHistory] Loaded {} entries", m_entries.size());
    }

    std::vector<uint8_t> InstanceHistory::DownloadImage(const std::string& url) {
        if (url.size() < 9) return {};

        size_t protoEnd = url.find("://");
        if (protoEnd == std::string::npos) return {};
        size_t hostStart = protoEnd + 3;
        size_t pathStart = url.find('/', hostStart);
        if (pathStart == std::string::npos) return {};

        std::string host = url.substr(hostStart, pathStart - hostStart);
        std::string path = url.substr(pathStart);

        std::wstring whost(host.begin(), host.end());
        std::wstring wpath(path.begin(), path.end());

        HINTERNET hSession = WinHttpOpen(L"Nyx/1.0",
            WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
            WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
        if (!hSession) return {};

        HINTERNET hConnect = WinHttpConnect(hSession, whost.c_str(),
            INTERNET_DEFAULT_HTTPS_PORT, 0);
        if (!hConnect) {
            WinHttpCloseHandle(hSession);
            return {};
        }

        HINTERNET hRequest = WinHttpOpenRequest(hConnect, L"GET", wpath.c_str(),
            nullptr, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES,
            WINHTTP_FLAG_SECURE);
        if (!hRequest) {
            WinHttpCloseHandle(hConnect);
            WinHttpCloseHandle(hSession);
            return {};
        }

        BOOL sent = WinHttpSendRequest(hRequest,
            WINHTTP_NO_ADDITIONAL_HEADERS, 0,
            WINHTTP_NO_REQUEST_DATA, 0, 0, 0);

        std::vector<uint8_t> data;
        if (sent && WinHttpReceiveResponse(hRequest, nullptr)) {
            DWORD bytesAvailable = 0;
            while (WinHttpQueryDataAvailable(hRequest, &bytesAvailable) && bytesAvailable > 0) {
                size_t offset = data.size();
                data.resize(offset + bytesAvailable);
                DWORD bytesRead = 0;
                WinHttpReadData(hRequest, data.data() + offset, bytesAvailable, &bytesRead);
                data.resize(offset + bytesRead);
            }
        }

        WinHttpCloseHandle(hRequest);
        WinHttpCloseHandle(hConnect);
        WinHttpCloseHandle(hSession);
        return data;
    }

    void InstanceHistory::RequestThumbnailIfNeeded(const std::string& worldId, const std::string& url) {
        if (url.empty() || worldId.empty()) return;

        std::lock_guard lock(m_thumbMutex);
        if (m_thumbCache.count(worldId) || m_thumbRequested.count(worldId)) return;
        m_thumbRequested.insert(worldId);

        std::string wid = worldId;
        std::string thumbUrl = url;

        std::thread([this, wid, thumbUrl]() {
            try {
                auto imageBytes = DownloadImage(thumbUrl);
                if (imageBytes.empty()) return;

                int w, h, channels;
                uint8_t* pixels = stbi_load_from_memory(
                    imageBytes.data(), static_cast<int>(imageBytes.size()),
                    &w, &h, &channels, 4);
                if (!pixels) return;

                PendingThumb pt;
                pt.worldId = wid;
                pt.width = w;
                pt.height = h;
                pt.rgba.assign(pixels, pixels + (w * h * 4));
                stbi_image_free(pixels);

                std::lock_guard lock(m_thumbMutex);
                m_pendingThumbs.push_back(std::move(pt));
            } catch (...) {}
        }).detach();
    }

    ID3D11ShaderResourceView* InstanceHistory::CreateTexture(
        ID3D11Device* device, const uint8_t* rgba, int w, int h)
    {
        D3D11_TEXTURE2D_DESC desc = {};
        desc.Width = static_cast<UINT>(w);
        desc.Height = static_cast<UINT>(h);
        desc.MipLevels = 1;
        desc.ArraySize = 1;
        desc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
        desc.SampleDesc.Count = 1;
        desc.Usage = D3D11_USAGE_DEFAULT;
        desc.BindFlags = D3D11_BIND_SHADER_RESOURCE;

        D3D11_SUBRESOURCE_DATA init = {};
        init.pSysMem = rgba;
        init.SysMemPitch = static_cast<UINT>(w) * 4;

        ID3D11Texture2D* texture = nullptr;
        HRESULT hr = device->CreateTexture2D(&desc, &init, &texture);
        if (FAILED(hr) || !texture) return nullptr;

        D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc = {};
        srvDesc.Format = desc.Format;
        srvDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
        srvDesc.Texture2D.MipLevels = 1;

        ID3D11ShaderResourceView* srv = nullptr;
        hr = device->CreateShaderResourceView(texture, &srvDesc, &srv);
        texture->Release();

        return SUCCEEDED(hr) ? srv : nullptr;
    }

    void InstanceHistory::ProcessPendingThumbnails(ID3D11Device* device) {
        std::lock_guard lock(m_thumbMutex);
        for (auto& pt : m_pendingThumbs) {
            auto* srv = CreateTexture(device, pt.rgba.data(), pt.width, pt.height);
            if (srv)
                m_thumbCache[pt.worldId] = srv;
        }
        m_pendingThumbs.clear();
    }

    void* InstanceHistory::GetThumbnailSRV(const std::string& worldId) {
        std::lock_guard lock(m_thumbMutex);
        auto it = m_thumbCache.find(worldId);
        return (it != m_thumbCache.end()) ? it->second : nullptr;
    }

} // namespace UNIx
