#pragma once

#include <Bootstrap.Module/include/VRChat/Player.hpp>
#include <Bootstrap.Module/include/VRChat/APIUser.hpp>
#include <Bootstrap.Module/include/VRChat/VRCPlayerApi.hpp>

#include <string>
#include <vector>
#include <mutex>
#include <memory>
#include <optional>
#include <unordered_map>

namespace UNIx {

    struct PlayerEntry {
        int playerId = 0;
        std::string displayName;
        std::string userId;
        bool isVR = false;
        bool isMaster = false;
        bool isLocal = false;
        bool isFriend = false;
        bool isQuest = false;
        IL2CPP::VRChat::PlayerRank rank = IL2CPP::VRChat::PlayerRank::Visitor;
    };

    using PlayerSnapshot = std::shared_ptr<const std::vector<PlayerEntry>>;

    class PlayerCache {
    public:
        void OnPlayerJoinComplete(IL2CPP::VRChat::Player player);
        void OnPlayerLeave(IL2CPP::VRChat::Player player);
        void OnSceneLoad(int scene, int loadMode);

        PlayerSnapshot GetPlayers() const;
        std::optional<PlayerEntry> FindByPlayerId(int id) const;
        size_t GetPlayerCount() const;

    private:
        void RebuildIndex();

        mutable std::mutex m_mutex;
        std::shared_ptr<std::vector<PlayerEntry>> m_players = std::make_shared<std::vector<PlayerEntry>>();
        std::unordered_map<int, size_t> m_idIndex;
    };

} // namespace UNIx
