#include <Core/FileLog/FileLog.hpp>
#include <chrono>
#include <filesystem>
#include <cstdlib>

namespace UNIx {

    FileLog& FileLog::Get() {
        static FileLog instance;
        return instance;
    }

    void FileLog::Init(HMODULE hModule) {
        std::lock_guard lock(m_mutex);
        if (m_open) return;

        std::filesystem::path logDir("C:\\nyx");
        std::filesystem::create_directories(logDir);
        auto logPath = logDir / "nyx_debug.log";

        m_file.open(logPath, std::ios::out | std::ios::trunc);
        m_open = m_file.is_open();

        if (m_open) {
            m_file << "=== nyx debug log started ===\n";
            m_file.flush();
        }

        m_console = GetStdHandle(STD_OUTPUT_HANDLE);
    }

    void FileLog::Shutdown() {
        std::lock_guard lock(m_mutex);
        if (m_open) {
            m_file << "=== nyx debug log ended ===\n";
            m_file.flush();
            m_file.close();
            m_open = false;
        }
        m_console = INVALID_HANDLE_VALUE;
    }

    void FileLog::Log(const std::string& msg) {
        std::lock_guard lock(m_mutex);

        auto now = std::chrono::system_clock::now();
        auto time = std::chrono::system_clock::to_time_t(now);
        auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch()) % 1000;

        struct tm t;
        localtime_s(&t, &time);

        char timeBuf[32];
        snprintf(timeBuf, sizeof(timeBuf), "%02d:%02d:%02d.%03d",
            t.tm_hour, t.tm_min, t.tm_sec, static_cast<int>(ms.count()));

        if (m_open) {
            m_file << "[" << timeBuf << "] " << msg << '\n';
        }

        if (m_console && m_console != INVALID_HANDLE_VALUE) {
            std::string line = "[" + std::string(timeBuf) + "] " + msg + "\n";
            DWORD written = 0;
            WriteConsoleA(m_console, line.c_str(), static_cast<DWORD>(line.size()), &written, nullptr);
        }

        if (m_callback)
            m_callback(timeBuf, msg);
    }

} // namespace UNIx
