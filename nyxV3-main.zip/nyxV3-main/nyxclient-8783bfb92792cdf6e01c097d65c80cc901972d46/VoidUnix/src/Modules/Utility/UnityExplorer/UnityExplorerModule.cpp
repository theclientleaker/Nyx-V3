#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <Windows.h>

#include <Modules/Utility/UnityExplorer/UnityExplorerModule.hpp>

#include <IL2CPP.Module/include/Unity/GameObject.hpp>
#include <IL2CPP.Module/include/Unity/Transform.hpp>
#include <IL2CPP.Module/include/Unity/Component.hpp>
#include <IL2CPP.Module/include/Unity/Behaviour.hpp>
#include <IL2CPP.Module/include/Unity/Camera.hpp>
#include <IL2CPP.Module/include/Unity/Resources.hpp>
#include <IL2CPP.Module/include/Unity/Physics.hpp>
#include <IL2CPP.Module/include/Unity/Time.hpp>
#include <IL2CPP.Module/include/Unity/Screen.hpp>
#include <IL2CPP.Module/include/Unity/Object.hpp>
#include <IL2CPP.Module/include/Unity/SceneManager.hpp>
#include <IL2CPP.Module/include/MethodHandler.hpp>
#include <IL2CPP.Module/include/System/Array.hpp>
#include <IL2CPP.Module/include/System/String.hpp>

#include <Core/DashboardConsole/DashboardConsole.hpp>
#include <ThirdParty/imgui/imgui.h>
#include <ThirdParty/imgui/imgui_internal.h>

#include <algorithm>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <fstream>
#include <filesystem>

// Write directly to the alloc console, bypasses C stdio buffering
static void ConLog(const char* fmt, ...) {
    char buf[1024];
    va_list args;
    va_start(args, fmt);
    int len = vsnprintf(buf, sizeof(buf) - 1, fmt, args);
    va_end(args);
    if (len <= 0) return;
    buf[len] = '\0';
    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
    if (h && h != INVALID_HANDLE_VALUE) {
        DWORD written = 0;
        WriteConsoleA(h, buf, static_cast<DWORD>(len), &written, nullptr);
    }
}

static constexpr const char* kThemeConfigPath = "C:/nyx/Config/explorer_theme.cfg";

static int LoadThemeConfig() {
    std::ifstream f(kThemeConfigPath);
    if (!f.is_open()) return 0;
    int idx = 0;
    f >> idx;
    if (idx < 0 || idx >= 12) idx = 0;
    return idx;
}

static void SaveThemeConfig(int idx) {
    std::filesystem::create_directories("C:/nyx/Config");
    std::ofstream f(kThemeConfigPath, std::ios::trunc);
    if (f.is_open())
        f << idx << "\n";
}

namespace UNIx {

    // =========================================================================
    //  Constructor & Lifecycle
    // =========================================================================

    UnityExplorerModule::UnityExplorerModule()
        : BaseModule("Unity Explorer", "Runtime scene and object inspector (F7)", 0x76, "Utility")
    {
        m_enabled = false;
        m_showInQuickMenu = true;
        m_themeIndex = LoadThemeConfig();
    }

    void UnityExplorerModule::OnEnable() {
        m_needsSceneRefresh = true;
    }

    void UnityExplorerModule::OnDisable() {
        if (m_freeCamActive) {
            m_freeCamActive = false;
            std::memset(m_freeCamKeys, 0, sizeof(m_freeCamKeys));
            std::memset(m_fovKeys, 0, sizeof(m_fovKeys));
            m_shiftHeld = false;
            m_ctrlHeld = false;
        }
        m_mouseInspectActive = false;

        // Restore timescale on disable to prevent stuck paused state
        if (m_gamePaused || m_timeScale != 1.0f) {
            try {
                IL2CPP::Module::Unity::Time::SetTimeScale(1.0f);
            } catch (...) {}
            m_gamePaused = false;
            m_timeScale = 1.0f;
            m_prevTimeScale = 1.0f;
        }
    }

    void UnityExplorerModule::OnSceneLoad(int, int) {
        m_needsSceneRefresh = true;
        m_needsLightRefresh = true;
        m_autoNavigatedToApp = false;
        m_appSearchTimer = 0.f;
        m_appSearchRetries = 0;
    }

    void UnityExplorerModule::OnSceneUnload(int, int) {
        m_needsSceneRefresh = true;
        m_needsLightRefresh = true;
    }

    // =========================================================================
    //  History
    // =========================================================================

    void UnityExplorerModule::PushHistory(InspectorMode mode, void* target) {
        if (m_historyIdx + 1 < static_cast<int>(m_history.size()))
            m_history.resize(m_historyIdx + 1);
        m_history.push_back({ mode, target });
        if (m_history.size() > 50)
            m_history.erase(m_history.begin());
        m_historyIdx = static_cast<int>(m_history.size()) - 1;
    }

    void UnityExplorerModule::NavigateBack() {
        if (m_historyIdx <= 0) return;
        --m_historyIdx;
        auto& entry = m_history[m_historyIdx];
        if (entry.mode == InspectorMode::GameObject)
            m_pendingSelectGO = entry.target;
        else if (entry.mode == InspectorMode::Component)
            m_pendingSelectComponent = entry.target;
    }

    void UnityExplorerModule::NavigateForward() {
        if (m_historyIdx + 1 >= static_cast<int>(m_history.size())) return;
        ++m_historyIdx;
        auto& entry = m_history[m_historyIdx];
        if (entry.mode == InspectorMode::GameObject)
            m_pendingSelectGO = entry.target;
        else if (entry.mode == InspectorMode::Component)
            m_pendingSelectComponent = entry.target;
    }

    // =========================================================================
    //  Value Helpers
    // =========================================================================

    std::string UnityExplorerModule::ReadFieldValue(void* obj, const IL2CPP::Module::Field& field) {
        try {
            auto tn = std::string(field.type_name());

            if (tn == "System.Boolean") {
                bool v = false;
                if (field.is_static()) field.get_static_value(&v);
                else field.get_value(obj, &v);
                return v ? "true" : "false";
            }
            if (tn == "System.Int32") {
                int v = 0;
                if (field.is_static()) field.get_static_value(&v);
                else field.get_value(obj, &v);
                return std::to_string(v);
            }
            if (tn == "System.Single") {
                float v = 0;
                if (field.is_static()) field.get_static_value(&v);
                else field.get_value(obj, &v);
                char buf[32]; std::snprintf(buf, sizeof(buf), "%.4f", v);
                return buf;
            }
            if (tn == "System.Double") {
                double v = 0;
                if (field.is_static()) field.get_static_value(&v);
                else field.get_value(obj, &v);
                char buf[32]; std::snprintf(buf, sizeof(buf), "%.4f", v);
                return buf;
            }
            if (tn == "System.Byte") {
                uint8_t v = 0;
                if (field.is_static()) field.get_static_value(&v);
                else field.get_value(obj, &v);
                return std::to_string(v);
            }
            if (tn == "System.Int16") {
                int16_t v = 0;
                if (field.is_static()) field.get_static_value(&v);
                else field.get_value(obj, &v);
                return std::to_string(v);
            }
            if (tn == "System.Int64") {
                int64_t v = 0;
                if (field.is_static()) field.get_static_value(&v);
                else field.get_value(obj, &v);
                return std::to_string(v);
            }
            if (tn == "System.UInt32") {
                uint32_t v = 0;
                if (field.is_static()) field.get_static_value(&v);
                else field.get_value(obj, &v);
                return std::to_string(v);
            }
            if (tn == "System.String") {
                void* strPtr = nullptr;
                if (field.is_static()) field.get_static_value(&strPtr);
                else field.get_value(obj, &strPtr);
                if (!strPtr) return "null";
                IL2CPP::Module::System::String str(strPtr);
                return "\"" + str.to_string() + "\"";
            }
            if (tn == "UnityEngine.Vector3") {
                IL2CPP::Vector3 v{};
                if (field.is_static()) field.get_static_value(&v);
                else field.get_value(obj, &v);
                char buf[64]; std::snprintf(buf, sizeof(buf), "(%.2f, %.2f, %.2f)", v.x, v.y, v.z);
                return buf;
            }
            if (tn == "UnityEngine.Vector2") {
                IL2CPP::Vector2 v{};
                if (field.is_static()) field.get_static_value(&v);
                else field.get_value(obj, &v);
                char buf[48]; std::snprintf(buf, sizeof(buf), "(%.2f, %.2f)", v.x, v.y);
                return buf;
            }
            if (tn == "UnityEngine.Color") {
                IL2CPP::Color v{};
                if (field.is_static()) field.get_static_value(&v);
                else field.get_value(obj, &v);
                char buf[64]; std::snprintf(buf, sizeof(buf), "(%.2f, %.2f, %.2f, %.2f)", v.r, v.g, v.b, v.a);
                return buf;
            }

            // Reference type
            void* ptr = nullptr;
            if (field.is_static()) field.get_static_value(&ptr);
            else field.get_value(obj, &ptr);
            if (!ptr) return "null";

            IL2CPP::Module::ManagedObject managed(ptr);
            std::string ts = managed.to_string();
            if (!ts.empty() && ts != tn) return ts;

            char buf[80]; std::snprintf(buf, sizeof(buf), "(%s) 0x%p", tn.c_str(), ptr);
            return buf;
        }
        catch (...) {
            return "<error>";
        }
    }

    // Property names known to cause crashes when their getter is invoked
    static bool IsUnsafeProperty(const std::string& propName, const std::string& typeName) {
        // Properties that access destroyed objects, or return complex types unsafely
        static const char* unsafeProps[] = {
            "mesh", "sharedMesh", "material", "sharedMaterial", "materials", "sharedMaterials",
            "mainTexture", "sprite", "overrideSprite", "font",
            "rigidbody", "rigidbody2D", "collider", "collider2D",
            "animation", "audio", "networkView", "guiText", "guiTexture",
            "renderer", "hingeJoint", "particleEmitter", "particleSystem",
            "light", "camera",
            // Properties that invoke managed code that may throw
            "vertices", "normals", "tangents", "triangles", "uv", "uv2", "colors", "colors32",
            "bounds", "localBounds",
        };
        for (auto& u : unsafeProps) {
            if (propName == u) return true;
        }
        // Skip array/collection types
        if (typeName.find("[]") != std::string::npos) return true;
        if (typeName.find("List`") != std::string::npos) return true;
        if (typeName.find("Dictionary`") != std::string::npos) return true;
        return false;
    }

    std::string UnityExplorerModule::ReadPropertyValue(void* obj, const IL2CPP::Module::Property& prop) {
        try {
            auto getter = prop.getter();
            if (!getter) return "<no getter>";

            auto tn = std::string(prop.type_name());
            auto pn = std::string(prop.name());

            // Skip properties known to crash
            if (IsUnsafeProperty(pn, tn)) return "<skipped>";

            // Skip properties with parameters (indexers)
            if (getter.param_count() > 0) return "<indexer>";

            if (tn == "System.Boolean") {
                bool v = IL2CPP::Module::MethodHandler::invoke<bool>(getter, obj);
                return v ? "true" : "false";
            }
            if (tn == "System.Int32") {
                int v = IL2CPP::Module::MethodHandler::invoke<int>(getter, obj);
                return std::to_string(v);
            }
            if (tn == "System.Single") {
                float v = IL2CPP::Module::MethodHandler::invoke<float>(getter, obj);
                char buf[32]; std::snprintf(buf, sizeof(buf), "%.4f", v);
                return buf;
            }
            if (tn == "System.String") {
                void* strPtr = IL2CPP::Module::MethodHandler::invoke<void*>(getter, obj);
                if (!strPtr) return "null";
                IL2CPP::Module::System::String str(strPtr);
                return "\"" + str.to_string() + "\"";
            }
            if (tn == "UnityEngine.Vector3") {
                auto v = IL2CPP::Module::MethodHandler::invoke<IL2CPP::Vector3>(getter, obj);
                char buf[64]; std::snprintf(buf, sizeof(buf), "(%.2f, %.2f, %.2f)", v.x, v.y, v.z);
                return buf;
            }
            if (tn == "UnityEngine.Vector2") {
                auto v = IL2CPP::Module::MethodHandler::invoke<IL2CPP::Vector2>(getter, obj);
                char buf[48]; std::snprintf(buf, sizeof(buf), "(%.2f, %.2f)", v.x, v.y);
                return buf;
            }
            if (tn == "UnityEngine.Color") {
                auto v = IL2CPP::Module::MethodHandler::invoke<IL2CPP::Color>(getter, obj);
                char buf[64]; std::snprintf(buf, sizeof(buf), "(%.2f, %.2f, %.2f, %.2f)", v.r, v.g, v.b, v.a);
                return buf;
            }
            if (tn == "UnityEngine.Quaternion") {
                auto v = IL2CPP::Module::MethodHandler::invoke<IL2CPP::Quaternion>(getter, obj);
                char buf[80]; std::snprintf(buf, sizeof(buf), "(%.2f, %.2f, %.2f, %.2f)", v.x, v.y, v.z, v.w);
                return buf;
            }

            void* ptr = IL2CPP::Module::MethodHandler::invoke<void*>(getter, obj);
            if (!ptr) return "null";

            IL2CPP::Module::ManagedObject managed(ptr);
            std::string ts = managed.to_string();
            if (!ts.empty() && ts != tn) return ts;

            char buf[80]; std::snprintf(buf, sizeof(buf), "(%s) 0x%p", tn.c_str(), ptr);
            return buf;
        }
        catch (...) {
            return "<error>";
        }
    }

    // =========================================================================
    //  Scene Tree Building (Unity thread)
    // =========================================================================

    void UnityExplorerModule::BuildNode(SceneNode& out, void* transformPtr, int depth) {
        try {
            IL2CPP::Module::Unity::Transform transform(transformPtr);
            out.transform = transformPtr;

            auto go = transform.GetGameObject();
            out.gameObject = go ? go.raw() : nullptr;
            try { out.name = go ? go.GetName() : "???"; } catch (...) { out.name = "???"; }
            try { out.activeSelf = go ? go.GetActiveSelf() : true; } catch (...) { out.activeSelf = true; }
            try { out.activeInHierarchy = go ? go.GetActiveInHierarchy() : true; } catch (...) { out.activeInHierarchy = true; }
            try { out.childCount = transform.GetChildCount(); } catch (...) { out.childCount = 0; }
            ++m_nodeCount;

            if (depth >= kMaxDepth || m_nodeCount >= kMaxNodes) return;

            out.children.reserve(out.childCount);
            for (int i = 0; i < out.childCount; ++i) {
                try {
                    auto child = transform.GetChild(i);
                    if (!child) continue;

                    SceneNode childNode;
                    BuildNode(childNode, child.raw(), depth + 1);
                    out.children.push_back(std::move(childNode));
                } catch (...) { continue; }

                if (m_nodeCount >= kMaxNodes) break;
            }
        } catch (...) {
            out.name = "???";
            out.childCount = 0;
        }
    }

    void UnityExplorerModule::RefreshSceneTree() {
        std::vector<SceneNode> newRoots;
        int nodeCount = 0;

        try {
            auto transformClass = IL2CPP::Module::Class::find("UnityEngine.Transform");
            if (!transformClass) return;

            auto systemType = transformClass.get_type().get_system_type_object();
            if (!systemType) return;

            void* rawArray = IL2CPP::Module::Unity::Resources::FindObjectsOfTypeAll(systemType);
            if (!rawArray) return;

            IL2CPP::Module::System::Array<void*> allTransforms(rawArray);
            size_t count = allTransforms.size();

            for (size_t i = 0; i < count; ++i) {
                void* t = allTransforms[i];
                if (!t) continue;

                try {
                    IL2CPP::Module::Unity::Transform transform(t);
                    auto parent = transform.GetParent();
                    if (parent) continue;

                    m_nodeCount = 0;
                    SceneNode node;
                    BuildNode(node, t, 0);
                    nodeCount += m_nodeCount;
                    newRoots.push_back(std::move(node));
                } catch (...) { continue; }

                if (nodeCount >= kMaxNodes) break;
            }

            // Sort alphabetically, but put _Application root first
            std::sort(newRoots.begin(), newRoots.end(),
                [](const SceneNode& a, const SceneNode& b) {
                    bool aIsApp = a.name.find("_Application") == 0;
                    bool bIsApp = b.name.find("_Application") == 0;
                    if (aIsApp != bIsApp) return aIsApp;
                    return a.name < b.name;
                });
        }
        catch (...) {
            ConLog("[UnityExplorer] Scene refresh failed\n");
        }

        auto newPtr = std::make_shared<std::vector<SceneNode>>(std::move(newRoots));
        std::lock_guard lock(m_mutex);
        m_sceneRoots = std::move(newPtr);
        m_nodeCount = nodeCount;
    }

    // =========================================================================
    //  Inspector Data Collection (Unity thread)
    // =========================================================================

    void UnityExplorerModule::RefreshGameObjectData(void* goPtr) {
        try {
            IL2CPP::Module::Unity::GameObject go(goPtr);
            if (!go) return;

            std::string name = go.GetName();
            bool active = go.GetActiveSelf();
            unsigned int layer = go.GetLayer();
            std::string tag;
            try { tag = go.GetTag(); } catch (...) { tag = "???"; }

            // Scene name
            std::string sceneName;
            try {
                auto scene = go.GetScene();
                IL2CPP::Module::Unity::SceneWrapper sw(scene);
                sceneName = sw.GetName();
            } catch (...) { sceneName = "???"; }

            float pos[3] = {}, rot[3] = {}, scl[3] = {};
            void* parentTransform = nullptr;
            std::string path;
            std::vector<ChildEntry> children;

            auto transform = go.GetTransform();
            if (transform) {
                auto p = transform.GetLocalPosition();
                pos[0] = p.x; pos[1] = p.y; pos[2] = p.z;

                auto q = transform.GetLocalRotation();
                auto e = q.ToEuler();
                rot[0] = e.x; rot[1] = e.y; rot[2] = e.z;

                auto s = transform.GetLocalScale();
                scl[0] = s.x; scl[1] = s.y; scl[2] = s.z;

                // Parent
                try {
                    auto parent = transform.GetParent();
                    if (parent) parentTransform = parent.raw();
                } catch (...) {}

                // Build full path
                try {
                    std::vector<std::string> pathParts;
                    pathParts.push_back(name);
                    auto cur = transform;
                    for (int i = 0; i < 50; ++i) {
                        auto par = cur.GetParent();
                        if (!par) break;
                        IL2CPP::Module::Unity::GameObject parGO(par.GetGameObject());
                        if (parGO) pathParts.push_back(parGO.GetName());
                        cur = par;
                    }
                    for (int i = (int)pathParts.size() - 1; i >= 0; --i) {
                        if (!path.empty()) path += "/";
                        path += pathParts[i];
                    }
                } catch (...) { path = name; }

                // Children
                try {
                    int childCount = transform.GetChildCount();
                    for (int i = 0; i < childCount && i < 500; ++i) {
                        try {
                            auto childTf = transform.GetChild(i);
                            if (!childTf) continue;
                            auto childGO = childTf.GetGameObject();
                            if (!childGO) continue;
                            ChildEntry ce;
                            ce.gameObject = childGO.raw();
                            ce.name = childGO.GetName();
                            ce.active = childGO.GetActiveSelf();
                            children.push_back(std::move(ce));
                        } catch (...) { continue; }
                    }
                } catch (...) {}
            }

            std::vector<ComponentEntry> comps;
            auto compClass = IL2CPP::Module::Class::find("UnityEngine.Component");
            if (compClass) {
                auto allComps = go.GetComponents(compClass);
                static auto behaviourClass = IL2CPP::Module::Class::find("UnityEngine.Behaviour");

                for (auto& comp : allComps) {
                    if (!comp) continue;

                    ComponentEntry entry;
                    entry.raw = comp.raw();
                    entry.typeName = comp.get_class_name();

                    if (behaviourClass && comp.is_instance_of(behaviourClass)) {
                        entry.isBehaviour = true;
                        try {
                            IL2CPP::Module::Unity::Behaviour beh(comp.raw());
                            entry.enabled = beh.GetEnabled();
                        } catch (...) {
                            entry.enabled = true;
                        }
                    }
                    comps.push_back(std::move(entry));
                }
            }

            std::lock_guard lock(m_mutex);
            m_selectedGO = goPtr;
            m_goName = std::move(name);
            m_goActive = active;
            m_goLayer = layer;
            m_goTag = std::move(tag);
            m_goPath = std::move(path);
            m_goScene = std::move(sceneName);
            m_goInstanceId = 0; // no GetInstanceID in SDK
            m_goParentTransform = parentTransform;
            std::memcpy(m_position, pos, sizeof(pos));
            std::memcpy(m_rotation, rot, sizeof(rot));
            std::memcpy(m_scale, scl, sizeof(scl));
            m_components = std::move(comps);
            m_children = std::move(children);
            m_inspectorMode = InspectorMode::GameObject;
        }
        catch (...) {
            ConLog("[UnityExplorer] RefreshGameObjectData failed\n");
        }
    }

    void UnityExplorerModule::RefreshComponentReflection(void* compPtr) {
        try {
            IL2CPP::Module::ManagedObject obj(compPtr);
            if (!obj) return;

            auto klass = obj.get_class();
            if (!klass) return;

            std::string typeName = std::string(klass.full_name());
            std::vector<FieldEntry> fields;
            std::vector<PropertyEntry> props;
            std::vector<MethodEntry> methods;

            // Fields — walk up hierarchy
            try {
                auto currentClass = klass;
                while (currentClass) {
                    try {
                        auto classFields = currentClass.get_fields();
                        for (auto& f : classFields) {
                            try {
                                FieldEntry entry;
                                entry.name = std::string(f.name());
                                entry.typeName = std::string(f.type_name());
                                entry.isStatic = f.is_static();
                                entry.isReadonly = f.is_readonly() || f.is_const();
                                entry.offset = f.offset();
                                entry.value = ReadFieldValue(compPtr, f);
                                fields.push_back(std::move(entry));
                            } catch (...) { continue; }
                        }
                    } catch (...) {}

                    try {
                        currentClass = currentClass.parent();
                        if (currentClass) {
                            auto pname = std::string(currentClass.full_name());
                            if (pname == "UnityEngine.Object" || pname == "System.Object")
                                break;
                        }
                    } catch (...) { break; }
                }
            } catch (...) {}

            // Properties
            try {
                auto classProps = klass.get_properties();
                for (auto& p : classProps) {
                    try {
                        PropertyEntry entry;
                        entry.name = std::string(p.name());
                        entry.typeName = std::string(p.type_name());
                        entry.hasGetter = (bool)p.getter();
                        entry.hasSetter = (bool)p.setter();
                        if (entry.hasGetter) {
                            entry.value = ReadPropertyValue(compPtr, p);
                        }
                        props.push_back(std::move(entry));
                    } catch (...) { continue; }
                }
            } catch (...) {}

            // Methods
            try {
                auto classMethods = klass.get_methods();
                for (auto& m : classMethods) {
                    try {
                        MethodEntry entry;
                        entry.name = std::string(m.name());
                        entry.returnType = std::string(m.return_type_name());
                        entry.paramCount = static_cast<int>(m.param_count());
                        entry.isStatic = m.is_static();

                        std::string sig;
                        for (int i = 0; i < entry.paramCount; ++i) {
                            try {
                                if (i > 0) sig += ", ";
                                auto pt = m.get_param_type(static_cast<uint32_t>(i));
                                auto pn = m.get_param_name(static_cast<uint32_t>(i));
                                sig += std::string(pt.name()) + " " + std::string(pn);
                            } catch (...) {
                                sig += "?";
                            }
                        }
                        entry.paramSig = sig;
                        methods.push_back(std::move(entry));
                    } catch (...) { continue; }
                }
            } catch (...) {}

            std::stable_sort(fields.begin(), fields.end(),
                [](const FieldEntry& a, const FieldEntry& b) { return !a.isStatic && b.isStatic; });

            std::lock_guard lock(m_mutex);
            m_selectedComponent = compPtr;
            m_selectedComponentType = std::move(typeName);
            m_fields = std::move(fields);
            m_properties = std::move(props);
            m_methods = std::move(methods);
            m_inspectorMode = InspectorMode::Component;
        }
        catch (...) {
            ConLog("[UnityExplorer] RefreshComponentReflection failed for 0x%p\n", compPtr);
        }
    }

    // =========================================================================
    //  Search Execution (Unity thread)
    // =========================================================================

    // Safe helper: build transform path with crash protection
    static std::string SafeBuildPath(const std::string& name, void* goRaw) {
        try {
            IL2CPP::Module::Unity::GameObject go(goRaw);
            if (!go) return name;
            auto transform = go.GetTransform();
            if (!transform) return name;

            std::vector<std::string> parts;
            parts.push_back(name);
            auto cur = transform;
            for (int i = 0; i < 15; ++i) {
                try {
                    auto parent = cur.GetParent();
                    if (!parent) break;
                    try {
                        auto pGo = parent.GetGameObject();
                        if (pGo) parts.push_back(pGo.GetName());
                    } catch (...) { break; }
                    cur = parent;
                } catch (...) { break; }
            }
            std::string path;
            for (int i = (int)parts.size() - 1; i >= 0; --i) {
                if (!path.empty()) path += "/";
                path += parts[i];
            }
            return path;
        } catch (...) {
            return name;
        }
    }

    void UnityExplorerModule::SearchSceneTree(const SceneNode& node, const std::string& queryLower,
                                              std::vector<SearchResult>& results, int maxResults) {
        SearchSceneTreeImpl(node, queryLower, "", results, maxResults);
    }

    // Build path from tree structure (no IL2CPP calls — crash-safe)
    void UnityExplorerModule::SearchSceneTreeImpl(const SceneNode& node,
                                                   const std::string& queryLower,
                                                   const std::string& parentPath,
                                                   std::vector<SearchResult>& results,
                                                   int maxResults) {
        if ((int)results.size() >= maxResults) return;

        std::string currentPath = parentPath.empty() ? node.name : parentPath + "/" + node.name;

        std::string nameLower = node.name;
        std::transform(nameLower.begin(), nameLower.end(), nameLower.begin(),
            [](unsigned char c) { return static_cast<char>(std::tolower(c)); });

        if (nameLower.find(queryLower) != std::string::npos && node.gameObject) {
            SearchResult sr;
            sr.gameObject = node.gameObject;
            sr.name = node.name;
            sr.path = currentPath;
            results.push_back(std::move(sr));
        }

        for (auto& child : node.children) {
            if ((int)results.size() >= maxResults) break;
            SearchSceneTreeImpl(child, queryLower, currentPath, results, maxResults);
        }
    }

    // Type search helper — uses C++ try/catch only (SEH can't mix with C++ destructors)
    static bool SafeGetTypeSearchInfo(void* raw, void** outGO, std::string& outName, std::string& outPath) {
        try {
            *outGO = raw;
            IL2CPP::Module::Unity::Object obj(raw);
            outName = obj.GetName();

            IL2CPP::Module::Unity::Component comp(raw);
            auto go = comp.GetGameObject();
            if (go && go.raw()) {
                *outGO = go.raw();
                outPath = go.GetName() + " (" + outName + ")";
            } else {
                outPath = outName;
            }
            return true;
        } catch (...) {
            outName = "???";
            outPath = "???";
            return false;
        }
    }

    void UnityExplorerModule::ExecuteSearch() {
        std::string query;
        int mode = 0;
        {
            std::lock_guard lock(m_mutex);
            query = m_pendingSearchQuery;
            mode = m_pendingSearchMode;
        }
        if (query.empty()) return;

        ConLog("[UnityExplorer] Search started: \"%s\" mode=%d\n", query.c_str(), mode);

        std::vector<SearchResult> results;
        std::string queryLower = query;
        std::transform(queryLower.begin(), queryLower.end(), queryLower.begin(),
            [](unsigned char c) { return static_cast<char>(std::tolower(c)); });

        if (mode == 0) {
            // Name search — walk the cached scene tree only (zero IL2CPP calls = crash-proof)
            std::shared_ptr<std::vector<SceneNode>> treeSnap;
            { std::lock_guard lock(m_mutex); treeSnap = m_sceneRoots; }

            if (!treeSnap || treeSnap->empty()) {
                m_needsSceneRefresh = true;
                ConLog("[UnityExplorer] Scene tree empty, refresh queued\n");
            } else {
                for (auto& root : *treeSnap) {
                    SearchSceneTree(root, queryLower, results, 200);
                    if (results.size() >= 200) break;
                }
            }
        }
        else {
            // Type search — needs IL2CPP, use SEH-safe wrappers
            try {
                auto klass = IL2CPP::Module::Class::find(query);
                if (!klass) {
                    ConLog("[UnityExplorer] Class not found: %s\n", query.c_str());
                    std::lock_guard lock(m_mutex);
                    m_searchResults.clear();
                    return;
                }

                auto allObjs = IL2CPP::Module::Unity::Object::FindObjectsOfType(klass);
                ConLog("[UnityExplorer] Found %zu objects of type\n", allObjs.size());

                for (auto& o : allObjs) {
                    if (results.size() >= 200) break;
                    if (!o || !o.raw()) continue;
                    void* raw = o.raw();

                    SearchResult sr;
                    sr.gameObject = raw;
                    SafeGetTypeSearchInfo(raw, &sr.gameObject, sr.name, sr.path);
                    results.push_back(std::move(sr));
                }
            } catch (...) {
                ConLog("[UnityExplorer] Type search exception\n");
            }
        }

        ConLog("[UnityExplorer] Search complete: %zu results\n", results.size());

        std::lock_guard lock(m_mutex);
        m_searchResults = std::move(results);
    }

    // =========================================================================
    //  FreeCam Update (Unity thread)
    // =========================================================================

    void UnityExplorerModule::UpdateFreeCam() {
        if (!m_freeCamActive) return;

        try {
            auto camera = IL2CPP::Module::Unity::Camera::GetMain();
            if (!camera) return;

            auto transform = camera.GetTransform();
            if (!transform) return;

            float dt = IL2CPP::Module::Unity::Time::GetUnscaledDeltaTime();
            float speedMul = m_shiftHeld ? 5.0f : (m_ctrlHeld ? 0.2f : 1.0f);
            float speed = m_freeCamSpeed * speedMul * dt;

            auto forward = transform.GetForward();
            auto right = transform.GetRight();

            IL2CPP::Vector3 pos = transform.GetPosition();

            if (m_freeCamKeys[0]) { pos.x += forward.x * speed; pos.y += forward.y * speed; pos.z += forward.z * speed; }
            if (m_freeCamKeys[1]) { pos.x -= right.x * speed; pos.y -= right.y * speed; pos.z -= right.z * speed; }
            if (m_freeCamKeys[2]) { pos.x -= forward.x * speed; pos.y -= forward.y * speed; pos.z -= forward.z * speed; }
            if (m_freeCamKeys[3]) { pos.x += right.x * speed; pos.y += right.y * speed; pos.z += right.z * speed; }
            if (m_freeCamKeys[4]) { pos.y += speed; }
            if (m_freeCamKeys[5]) { pos.y -= speed; }

            transform.SetPosition(pos);
            m_camPos[0] = pos.x; m_camPos[1] = pos.y; m_camPos[2] = pos.z;

            // Apply euler rotation
            IL2CPP::Quaternion q;
            q.Euler(m_camEuler[0], m_camEuler[1], m_camEuler[2]);
            transform.SetRotation(q);

            // FOV keys (numpad +/-)
            if (m_fovKeys[0]) m_freeCamFOV = std::min(m_freeCamFOV + 30.0f * dt, 170.0f);
            if (m_fovKeys[1]) m_freeCamFOV = std::max(m_freeCamFOV - 30.0f * dt, 1.0f);

            // Apply camera properties
            camera.SetFieldOfView(m_freeCamFOV);
            camera.SetNearClipPlane(m_nearClip);
            camera.SetFarClipPlane(m_farClip);
        }
        catch (...) {}
    }

    // =========================================================================
    //  Mouse Inspector (Unity thread)
    // =========================================================================

    void UnityExplorerModule::DoMouseInspect() {
        if (m_mouseInspectMode == 0)
            DoMouseInspectWorld();
        else
            DoMouseInspectUI();
    }

    void UnityExplorerModule::DoMouseInspectWorld() {
        std::vector<MouseHitResult> hits;

        try {
            auto camera = IL2CPP::Module::Unity::Camera::GetMain();
            if (!camera) {
                ConLog("[UnityExplorer] Mouse inspect: no main camera\n");
                return;
            }

            float screenH = static_cast<float>(IL2CPP::Module::Unity::Screen::GetHeight());
            IL2CPP::Vector3 screenPos(m_mouseInspectX, screenH - m_mouseInspectY, 0.f);

            ConLog("[UnityExplorer] Mouse click at (%.0f, %.0f) -> screen (%.0f, %.0f, 0)\n",
                m_mouseInspectX, m_mouseInspectY, screenPos.x, screenPos.y);

            // Strategy: Find all active Renderers/Colliders and check which ones
            // are under the mouse cursor using WorldToScreenPoint
            auto goClass = IL2CPP::Module::Class::find("UnityEngine.GameObject");
            if (!goClass) {
                ConLog("[UnityExplorer] GameObject class not found\n");
                return;
            }

            auto allGOs = IL2CPP::Module::Unity::Object::FindObjectsOfType(goClass);
            ConLog("[UnityExplorer] Found %zu GameObjects\n", allGOs.size());

            for (auto& obj : allGOs) {
                if (!obj || hits.size() >= 50) continue;

                try {
                    IL2CPP::Module::Unity::GameObject go(obj.raw());
                    if (!go.GetActiveInHierarchy()) continue;

                    auto transform = go.GetTransform();
                    if (!transform) continue;

                    // Check if this object has a Renderer or Collider (i.e. is visible/physical)
                    static auto rendererClass = IL2CPP::Module::Class::find("UnityEngine.Renderer");
                    static auto colliderClass = IL2CPP::Module::Class::find("UnityEngine.Collider");
                    static auto getComponent = IL2CPP::Module::MethodHandler::resolve(
                        "UnityEngine.GameObject", "GetComponent", 1);

                    if (!getComponent) continue;

                    bool hasVisual = false;
                    if (rendererClass) {
                        auto sysType = rendererClass.get_type().get_system_type_object();
                        if (sysType) {
                            void* params[] = { sysType };
                            void* comp = IL2CPP::Module::MethodHandler::invoke<void*>(
                                getComponent, go.raw(), params);
                            if (comp) hasVisual = true;
                        }
                    }
                    if (!hasVisual && colliderClass) {
                        auto sysType = colliderClass.get_type().get_system_type_object();
                        if (sysType) {
                            void* params[] = { sysType };
                            void* comp = IL2CPP::Module::MethodHandler::invoke<void*>(
                                getComponent, go.raw(), params);
                            if (comp) hasVisual = true;
                        }
                    }
                    if (!hasVisual) continue;

                    // Project world position to screen
                    auto worldPos = transform.GetPosition();
                    auto scrPt = camera.WorldToScreenPoint(worldPos);

                    // Check if within a tolerance of the click point
                    float dx = scrPt.x - screenPos.x;
                    float dy = scrPt.y - screenPos.y;
                    float distSq = dx * dx + dy * dy;

                    // 80px radius tolerance
                    if (distSq > 6400.0f) continue;
                    // Must be in front of camera
                    if (scrPt.z <= 0.0f) continue;

                    // Check for duplicates
                    void* goPtr = go.raw();
                    bool dup = false;
                    for (auto& h : hits) {
                        if (h.goPtr == goPtr) { dup = true; break; }
                    }
                    if (dup) continue;

                    MouseHitResult hr;
                    hr.goPtr = goPtr;
                    hr.name = go.GetName();

                    try {
                        hr.path = hr.name;
                        auto p = transform.GetParent();
                        int d = 0;
                        while (p && d < 8) {
                            auto pg = p.GetGameObject();
                            if (pg) hr.path = pg.GetName() + "/" + hr.path;
                            p = p.GetParent();
                            ++d;
                        }
                    } catch (...) {
                        hr.path = hr.name;
                    }

                    hits.push_back(std::move(hr));
                } catch (...) {
                    continue;
                }
            }

            // Also try a single raycast as a reliable fallback
            try {
                IL2CPP::Ray ray = camera.ScreenPointToRay(screenPos);
                IL2CPP::RaycastHit hit{};
                if (IL2CPP::Module::Unity::Physics::Raycast(ray, hit, 1000.0f)) {
                    // hit.collider is an instance ID — we need to use the raw Raycast out param
                    // The hit struct has the collider reference, get the GO from the transform
                    // Since Physics::Raycast fills the hit struct, the collider field is valid
                    // but it's an internal ID. Let's use an alternative: get transform from hit.
                    static auto hitGetCollider = IL2CPP::Module::MethodHandler::resolve(
                        "UnityEngine.RaycastHit", "get_collider", 0);
                    auto hitClass = IL2CPP::Module::Class::find("UnityEngine.RaycastHit");

                    if (hitGetCollider && hitClass) {
                        auto boxed = IL2CPP::Module::ManagedObject::box_value(hitClass, &hit);
                        if (boxed) {
                            void* collPtr = IL2CPP::Module::MethodHandler::invoke<void*>(
                                hitGetCollider, boxed.raw());
                            if (collPtr) {
                                IL2CPP::Module::Unity::Component coll(collPtr);
                                auto go = coll.GetGameObject();
                                if (go) {
                                    void* goPtr = go.raw();
                                    bool dup = false;
                                    for (auto& h : hits) {
                                        if (h.goPtr == goPtr) { dup = true; break; }
                                    }
                                    if (!dup) {
                                        MouseHitResult hr;
                                        hr.goPtr = goPtr;
                                        hr.name = go.GetName();
                                        hr.path = hr.name;
                                        try {
                                            auto t = go.GetTransform();
                                            if (t) {
                                                auto p = t.GetParent();
                                                int d = 0;
                                                while (p && d < 8) {
                                                    auto pg = p.GetGameObject();
                                                    if (pg) hr.path = pg.GetName() + "/" + hr.path;
                                                    p = p.GetParent();
                                                    ++d;
                                                }
                                            }
                                        } catch (...) {}
                                        hits.push_back(std::move(hr));
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (...) {
                ConLog("[UnityExplorer] Raycast fallback failed\n");
            }

            ConLog("[UnityExplorer] World inspect found %zu objects\n", hits.size());
        }
        catch (...) {
            ConLog("[UnityExplorer] World mouse inspect exception\n");
        }

        // Store results and show panel
        std::lock_guard lock(m_mutex);
        m_mouseHitResults = std::move(hits);
        if (!m_mouseHitResults.empty()) {
            if (m_mouseHitResults.size() == 1) {
                m_pendingSelectGO = m_mouseHitResults[0].goPtr;
                m_switchToInspector = true;
                m_showInspectorPanel = true;
                PushHistory(InspectorMode::GameObject, m_mouseHitResults[0].goPtr);
            } else {
                m_showMouseResults = true;
            }
        } else {
            ConLog("[UnityExplorer] No objects found under click\n");
        }
    }

    void UnityExplorerModule::DoMouseInspectUI() {
        std::vector<MouseHitResult> hits;

        try {
            float screenH = static_cast<float>(IL2CPP::Module::Unity::Screen::GetHeight());
            float mx = m_mouseInspectX;
            float my = screenH - m_mouseInspectY;

            // Try Graphic-based approach first (covers Text, Image, RawImage, etc.)
            auto graphicClass = IL2CPP::Module::Class::find("UnityEngine.UI.Graphic");
            if (graphicClass) {
                auto allGraphics = IL2CPP::Module::Unity::Object::FindObjectsOfType(graphicClass);
                ConLog("[UnityExplorer] Found %zu Graphics\n", allGraphics.size());

                static auto containsPoint = IL2CPP::Module::MethodHandler::resolve(
                    "UnityEngine.RectTransformUtility", "RectangleContainsScreenPoint", 2);

                IL2CPP::Vector2 mousePos(mx, my);

                for (auto& obj : allGraphics) {
                    if (!obj || hits.size() >= 50) continue;
                    try {
                        IL2CPP::Module::Unity::Component comp(obj.raw());
                        auto go = comp.GetGameObject();
                        if (!go || !go.GetActiveInHierarchy()) continue;

                        auto transform = go.GetTransform();
                        if (!transform) continue;

                        bool isUnder = false;

                        if (containsPoint) {
                            void* rectPtr = transform.raw();
                            void* params[] = { rectPtr, &mousePos };
                            try {
                                isUnder = IL2CPP::Module::MethodHandler::invoke<bool>(
                                    containsPoint, nullptr, params);
                            } catch (...) {}
                        }

                        // Fallback: distance check
                        if (!isUnder) {
                            auto camera = IL2CPP::Module::Unity::Camera::GetMain();
                            if (camera) {
                                auto worldPos = transform.GetPosition();
                                auto scrPt = camera.WorldToScreenPoint(worldPos);
                                float dx = scrPt.x - mx;
                                float dy = scrPt.y - my;
                                isUnder = (dx * dx + dy * dy < 2500.0f);
                            }
                        }

                        if (!isUnder) continue;

                        void* goPtr = go.raw();
                        bool dup = false;
                        for (auto& h : hits) {
                            if (h.goPtr == goPtr) { dup = true; break; }
                        }
                        if (dup) continue;

                        MouseHitResult hr;
                        hr.goPtr = goPtr;
                        hr.name = go.GetName();
                        hr.path = hr.name;
                        try {
                            auto p = transform.GetParent();
                            int d = 0;
                            while (p && d < 8) {
                                auto pg = p.GetGameObject();
                                if (pg) hr.path = pg.GetName() + "/" + hr.path;
                                p = p.GetParent();
                                ++d;
                            }
                        } catch (...) {}

                        hits.push_back(std::move(hr));
                    } catch (...) { continue; }
                }

                ConLog("[UnityExplorer] UI inspect found %zu objects\n", hits.size());
            } else {
                // Fallback: RectTransform distance check
                ConLog("[UnityExplorer] Graphic class not found, using RectTransform fallback\n");
                auto rectClass = IL2CPP::Module::Class::find("UnityEngine.RectTransform");
                if (rectClass) {
                    auto allRects = IL2CPP::Module::Unity::Object::FindObjectsOfType(rectClass);
                    for (auto& obj : allRects) {
                        if (!obj || hits.size() >= 50) continue;
                        try {
                            IL2CPP::Module::Unity::Transform t(obj.raw());
                            auto go = t.GetGameObject();
                            if (!go || !go.GetActiveInHierarchy()) continue;

                            auto camera = IL2CPP::Module::Unity::Camera::GetMain();
                            if (!camera) continue;
                            auto worldPos = t.GetPosition();
                            auto scrPt = camera.WorldToScreenPoint(worldPos);
                            float dx = scrPt.x - mx;
                            float dy = scrPt.y - my;
                            if (dx * dx + dy * dy > 2500.0f) continue;

                            void* goPtr = go.raw();
                            bool dup = false;
                            for (auto& h : hits) {
                                if (h.goPtr == goPtr) { dup = true; break; }
                            }
                            if (dup) continue;

                            MouseHitResult hr;
                            hr.goPtr = goPtr;
                            hr.name = go.GetName();
                            hr.path = hr.name;
                            try {
                                auto p = t.GetParent();
                                int d = 0;
                                while (p && d < 8) {
                                    auto pg = p.GetGameObject();
                                    if (pg) hr.path = pg.GetName() + "/" + hr.path;
                                    p = p.GetParent();
                                    ++d;
                                }
                            } catch (...) {}
                            hits.push_back(std::move(hr));
                        } catch (...) { continue; }
                    }
                    ConLog("[UnityExplorer] UI (RectTransform fallback) found %zu objects\n", hits.size());
                }
            }
        }
        catch (...) {
            ConLog("[UnityExplorer] UI mouse inspect exception\n");
        }

        std::lock_guard lock(m_mutex);
        m_mouseHitResults = std::move(hits);
        if (!m_mouseHitResults.empty()) {
            if (m_mouseHitResults.size() == 1) {
                m_pendingSelectGO = m_mouseHitResults[0].goPtr;
                m_switchToInspector = true;
                m_showInspectorPanel = true;
                PushHistory(InspectorMode::GameObject, m_mouseHitResults[0].goPtr);
            } else {
                m_showMouseResults = true;
            }
        } else {
            ConLog("[UnityExplorer] No UI objects found under click\n");
        }
    }

    // =========================================================================
    //  TimeScale (Unity thread)
    // =========================================================================

    void UnityExplorerModule::ApplyTimeScale() {
        // Only apply if user changed the timescale
        float desired = m_gamePaused ? 0.0f : m_timeScale;
        if (desired == 1.0f && !m_gamePaused && m_prevTimeScale == 1.0f) return;
        try {
            IL2CPP::Module::Unity::Time::SetTimeScale(desired);
            m_prevTimeScale = desired;
        }
        catch (...) {}
    }

    // =========================================================================
    //  Lights (Unity thread)
    // =========================================================================

    void UnityExplorerModule::RefreshSceneLights() {
        std::vector<SceneLightEntry> lights;
        try {
            auto lightClass = IL2CPP::Module::Class::find("UnityEngine.Light");
            if (!lightClass) return;

            auto sysType = lightClass.get_type().get_system_type_object();
            if (!sysType) return;

            void* rawArray = IL2CPP::Module::Unity::Resources::FindObjectsOfTypeAll(sysType);
            if (!rawArray) return;

            IL2CPP::Module::System::Array<void*> allLights(rawArray);
            for (size_t i = 0; i < allLights.size() && lights.size() < 200; ++i) {
                void* lPtr = allLights[i];
                if (!lPtr) continue;

                SceneLightEntry entry;
                entry.lightPtr = lPtr;

                IL2CPP::Module::ManagedObject lightObj(lPtr);

                // Get enabled
                try {
                    IL2CPP::Module::Unity::Behaviour beh(lPtr);
                    entry.enabled = beh.GetEnabled();
                } catch (...) {}

                // Get GameObject
                try {
                    IL2CPP::Module::Unity::Component comp(lPtr);
                    auto go = comp.GetGameObject();
                    if (go) {
                        entry.goPtr = go.raw();
                        entry.name = go.GetName();
                    }
                } catch (...) {
                    entry.name = "Light";
                }

                // Get type (int enum: 0=Spot, 1=Directional, 2=Point, 3=Area)
                try {
                    static auto getType = IL2CPP::Module::MethodHandler::resolve("UnityEngine.Light", "get_type", 0);
                    if (getType) entry.type = IL2CPP::Module::MethodHandler::invoke<int>(getType, lPtr);
                } catch (...) {}

                // Get intensity
                try {
                    static auto getIntensity = IL2CPP::Module::MethodHandler::resolve("UnityEngine.Light", "get_intensity", 0);
                    if (getIntensity) entry.intensity = IL2CPP::Module::MethodHandler::invoke<float>(getIntensity, lPtr);
                } catch (...) {}

                // Get range
                try {
                    static auto getRange = IL2CPP::Module::MethodHandler::resolve("UnityEngine.Light", "get_range", 0);
                    if (getRange) entry.range = IL2CPP::Module::MethodHandler::invoke<float>(getRange, lPtr);
                } catch (...) {}

                // Get spotAngle
                try {
                    static auto getSpotAngle = IL2CPP::Module::MethodHandler::resolve("UnityEngine.Light", "get_spotAngle", 0);
                    if (getSpotAngle) entry.spotAngle = IL2CPP::Module::MethodHandler::invoke<float>(getSpotAngle, lPtr);
                } catch (...) {}

                // Get color
                try {
                    static auto getColor = IL2CPP::Module::MethodHandler::resolve("UnityEngine.Light", "get_color", 0);
                    if (getColor) {
                        auto c = IL2CPP::Module::MethodHandler::invoke<IL2CPP::Color>(getColor, lPtr);
                        entry.color[0] = c.r; entry.color[1] = c.g; entry.color[2] = c.b;
                    }
                } catch (...) {}

                lights.push_back(std::move(entry));
            }
        }
        catch (...) {
            ConLog("[UnityExplorer] RefreshSceneLights failed\n");
        }

        std::lock_guard lock(m_mutex);
        m_sceneLights = std::move(lights);
    }

    // =========================================================================
    //  Misc (Unity thread)
    // =========================================================================

    void UnityExplorerModule::TeleportToSelected() {
        try {
            if (!m_selectedGO) return;

            IL2CPP::Module::Unity::GameObject targetGO(m_selectedGO);
            if (!targetGO) return;
            auto targetTf = targetGO.GetTransform();
            if (!targetTf) return;

            auto targetPos = targetTf.GetPosition();

            auto localPlayer = GetLocalVRCPlayer();
            if (!localPlayer) return;

            auto lpGo = localPlayer.GetGameObject();
            if (!lpGo) return;
            auto lpTf = lpGo.GetTransform();
            if (!lpTf) return;

            lpTf.SetPosition(targetPos);
            ConLog("[UnityExplorer] Teleported to (%.1f, %.1f, %.1f)\n", targetPos.x, targetPos.y, targetPos.z);
        }
        catch (...) {
            ConLog("[UnityExplorer] Teleport failed\n");
        }
    }

    void UnityExplorerModule::RenderDumpPopup() {
        if (!m_showDumpPopup) return;

        ImGui::SetNextWindowSize(ImVec2(320, 0), ImGuiCond_Always);
        if (ImGui::BeginPopup("DumpSettings")) {
            ImGui::TextColored(ImVec4(0.4f, 0.8f, 0.4f, 1.0f), "Dump Settings");
            ImGui::Separator();

            ImGui::Checkbox("Components", &m_dumpComponents);
            ImGui::Checkbox("Enabled/Disabled State", &m_dumpEnabledState);
            ImGui::Checkbox("Inactive Objects", &m_dumpInactiveObjects);
            ImGui::Checkbox("Full Paths", &m_dumpFullPaths);
            ImGui::SliderInt("Max Depth", &m_dumpMaxDepth, 1, 100);

            ImGui::Separator();

            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.15f, 0.50f, 0.15f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.20f, 0.60f, 0.20f, 1.0f));
            if (ImGui::Button("Dump", ImVec2(145, 0))) {
                m_pendingDumpHierarchy = true;
                m_showDumpPopup = false;
                ImGui::CloseCurrentPopup();
            }
            ImGui::PopStyleColor(2);

            ImGui::SameLine();
            if (ImGui::Button("Cancel", ImVec2(145, 0))) {
                m_showDumpPopup = false;
                ImGui::CloseCurrentPopup();
            }

            ImGui::EndPopup();
        } else {
            m_showDumpPopup = false;
        }
    }

    void UnityExplorerModule::DumpHierarchyToFile() {
        if (!m_selectedGO) return;

        using namespace IL2CPP::Module;
        using namespace IL2CPP::Module::Unity;

        std::filesystem::path dir("C:\\nyx\\dumps");
        std::filesystem::create_directories(dir);

        std::string safeName = m_goName;
        for (char& c : safeName) {
            if (c == '/' || c == '\\' || c == ':' || c == '*' || c == '?' || c == '"' || c == '<' || c == '>' || c == '|')
                c = '_';
        }

        std::filesystem::path filePath = dir / (safeName + "_dump.txt");
        std::ofstream ofs(filePath);
        if (!ofs.is_open()) {
            ConLog("[Explorer] Failed to open %s for writing", filePath.string().c_str());
            return;
        }

        auto compClass = m_dumpComponents ? Class::find("UnityEngine.Component") : IL2CPP::Module::Class();
        auto behaviourClass = (m_dumpComponents && m_dumpEnabledState) ? Class::find("UnityEngine.Behaviour") : IL2CPP::Module::Class();
        int maxDepth = m_dumpMaxDepth;
        bool includeInactive = m_dumpInactiveObjects;
        bool fullPaths = m_dumpFullPaths;
        bool showComponents = m_dumpComponents;
        bool showEnabled = m_dumpEnabledState;

        int totalObjects = 0;
        int totalComponents = 0;

        std::function<void(void* goRaw, const std::string& parentPath, int depth)> dumpGO;
        dumpGO = [&](void* goRaw, const std::string& parentPath, int depth) {
            if (!goRaw || depth > maxDepth) return;
            try {
                GameObject go(goRaw);
                if (!go) return;

                std::string name;
                try { name = go.GetName(); } catch (...) { name = "???"; }
                bool active = false;
                try { active = go.GetActiveSelf(); } catch (...) {}

                if (!active && !includeInactive) return;

                std::string displayPath = fullPaths
                    ? (parentPath.empty() ? name : (parentPath + "/" + name))
                    : name;
                std::string fullPath = parentPath.empty() ? name : (parentPath + "/" + name);

                std::string indent(depth * 2, ' ');
                ofs << indent << displayPath << (active ? "" : " [INACTIVE]") << "\n";
                ++totalObjects;

                if (showComponents && compClass) {
                    try {
                        auto comps = go.GetComponents(compClass);
                        for (auto& comp : comps) {
                            if (!comp) continue;
                            std::string typeName;
                            try { typeName = comp.get_class_name(); } catch (...) { typeName = "???"; }
                            std::string enabledStr;
                            if (showEnabled && behaviourClass && comp.is_instance_of(behaviourClass)) {
                                try {
                                    Behaviour beh(comp.raw());
                                    enabledStr = beh.GetEnabled() ? " [ON]" : " [OFF]";
                                } catch (...) {}
                            }
                            ofs << indent << "  + " << typeName << enabledStr << "\n";
                            ++totalComponents;
                        }
                    } catch (...) {}
                }

                Transform tf;
                try { tf = go.GetTransform(); } catch (...) { return; }
                if (!tf) return;

                int childCount = 0;
                try { childCount = tf.GetChildCount(); } catch (...) { return; }

                for (int i = 0; i < childCount && i < 500; ++i) {
                    try {
                        auto childTf = tf.GetChild(i);
                        if (!childTf) continue;
                        auto childGO = childTf.GetGameObject();
                        if (!childGO) continue;
                        dumpGO(childGO.raw(), fullPath, depth + 1);
                    } catch (...) { continue; }
                }
            } catch (...) {}
        };

        ofs << "=== Hierarchy Dump: " << m_goPath << " ===\n\n";
        dumpGO(m_selectedGO, "", 0);
        ofs.close();

        ConLog("[Explorer] Dumped %d objects, %d components to %s", totalObjects, totalComponents, filePath.string().c_str());
    }

    void UnityExplorerModule::ToggleHUD() {
        try {
            auto canvasClass = IL2CPP::Module::Class::find("UnityEngine.Canvas");
            if (!canvasClass) return;
            auto sysType = canvasClass.get_type().get_system_type_object();
            if (!sysType) return;

            void* rawArray = IL2CPP::Module::Unity::Resources::FindObjectsOfTypeAll(sysType);
            if (!rawArray) return;

            IL2CPP::Module::System::Array<void*> canvases(rawArray);
            static auto setEnabled = IL2CPP::Module::MethodHandler::resolve("UnityEngine.Canvas", "set_enabled", 1);
            if (!setEnabled) return;

            m_hudHidden = !m_hudHidden;
            bool enable = !m_hudHidden;

            for (size_t i = 0; i < canvases.size(); ++i) {
                void* c = canvases[i];
                if (!c) continue;

                // Don't disable our own UI
                try {
                    IL2CPP::Module::Unity::Component comp(c);
                    auto go = comp.GetGameObject();
                    if (go) {
                        std::string name = go.GetName();
                        if (name.find("UniverseLib") != std::string::npos ||
                            name.find("nyx") != std::string::npos)
                            continue;
                    }
                } catch (...) {}

                void* params[] = { &enable };
                IL2CPP::Module::MethodHandler::invoke<void>(setEnabled, c, params);
            }
        }
        catch (...) {}
    }

    // =========================================================================
    //  OnUpdate — Unity Thread Dispatch
    // =========================================================================

    void UnityExplorerModule::OnUpdate() {
      try {  // Master try/catch — no exception escapes OnUpdate
        if (m_needsSceneRefresh.exchange(false)) {
            try { RefreshSceneTree(); }
            catch (...) { ConLog("[UnityExplorer] Scene refresh crashed\n"); }
        }

        void* pendingGO = nullptr;
        void* pendingComp = nullptr;
        bool doSearch = false;
        {
            std::lock_guard lock(m_mutex);
            pendingGO = m_pendingSelectGO;
            m_pendingSelectGO = nullptr;
            pendingComp = m_pendingSelectComponent;
            m_pendingSelectComponent = nullptr;
            doSearch = m_needsSearch;
            m_needsSearch = false;
        }

        if (pendingGO) {
            try { RefreshGameObjectData(pendingGO); }
            catch (...) { ConLog("[UnityExplorer] RefreshGameObjectData crashed\n"); }
        }
        if (pendingComp) {
            try { RefreshComponentReflection(pendingComp); }
            catch (...) { ConLog("[UnityExplorer] RefreshComponentReflection crashed\n"); }
        }
        if (doSearch) {
            try { ExecuteSearch(); }
            catch (...) { ConLog("[UnityExplorer] ExecuteSearch crashed\n"); }
        }

        // Handle SetActive request
        if (m_pendingSetActive) {
            m_pendingSetActive = false;
            try {
                if (m_selectedGO) {
                    IL2CPP::Module::Unity::GameObject go(m_selectedGO);
                    if (go) {
                        go.SetActive(m_pendingActiveValue);
                        RefreshGameObjectData(m_selectedGO);
                    }
                }
            } catch (...) { ConLog("[UnityExplorer] SetActive failed\n"); }
        }

        // Handle Destroy GO request
        if (m_pendingDestroyGO) {
            m_pendingDestroyGO = false;
            try {
                if (m_selectedGO) {
                    IL2CPP::Module::Unity::Object obj(m_selectedGO);
                    obj.Destroy();
                    std::lock_guard lock(m_mutex);
                    m_selectedGO = nullptr;
                    m_inspectorMode = InspectorMode::None;
                    m_needsSceneRefresh = true;
                }
            } catch (...) { ConLog("[UnityExplorer] Destroy GO failed\n"); }
        }

        // Handle Destroy Component request
        if (m_pendingDestroyComp) {
            m_pendingDestroyComp = false;
            try {
                if (m_pendingDestroyTarget) {
                    IL2CPP::Module::Unity::Object obj(m_pendingDestroyTarget);
                    obj.Destroy();
                    m_pendingDestroyTarget = nullptr;
                    // Refresh the GO to update component list
                    if (m_selectedGO) RefreshGameObjectData(m_selectedGO);
                }
            } catch (...) { ConLog("[UnityExplorer] Destroy Component failed\n"); }
        }

        // Handle component enable/disable request
        if (m_pendingCompToggle) {
            m_pendingCompToggle = false;
            try {
                if (m_pendingCompToggleTarget) {
                    IL2CPP::Module::Unity::Behaviour beh(m_pendingCompToggleTarget);
                    if (beh) {
                        beh.SetEnabled(m_pendingCompToggleValue);
                        ConLog("[UnityExplorer] Component %s\n", m_pendingCompToggleValue ? "enabled" : "disabled");
                    }
                    m_pendingCompToggleTarget = nullptr;
                }
            } catch (...) { ConLog("[UnityExplorer] Component toggle failed\n"); }
        }

        // Handle View Parent request
        if (m_pendingViewParent) {
            m_pendingViewParent = false;
            try {
                if (m_goParentTransform) {
                    IL2CPP::Module::Unity::Transform parentTf(m_goParentTransform);
                    if (parentTf) {
                        auto parentGO = parentTf.GetGameObject();
                        if (parentGO && parentGO.raw()) {
                            void* parentPtr = parentGO.raw();
                            RefreshGameObjectData(parentPtr);
                            // Push history on render thread side is tricky,
                            // but we set m_selectedGO in RefreshGameObjectData already
                        }
                    }
                }
            } catch (...) { ConLog("[UnityExplorer] View Parent failed\n"); }
        }

        // Handle transform edit request
        if (m_pendingTransformEdit) {
            m_pendingTransformEdit = false;
            try {
                if (m_selectedGO) {
                    IL2CPP::Module::Unity::GameObject go(m_selectedGO);
                    if (go) {
                        auto tf = go.GetTransform();
                        if (tf) {
                            tf.SetLocalPosition({ m_pendingPos[0], m_pendingPos[1], m_pendingPos[2] });
                            IL2CPP::Quaternion q;
                            q.Euler(m_pendingRot[0], m_pendingRot[1], m_pendingRot[2]);
                            tf.SetLocalRotation(q);
                            tf.SetLocalScale({ m_pendingScl[0], m_pendingScl[1], m_pendingScl[2] });
                        }
                    }
                }
            } catch (...) { ConLog("[UnityExplorer] Transform edit failed\n"); }
        }

        try { if (m_freeCamActive) UpdateFreeCam(); }
        catch (...) { ConLog("[UnityExplorer] UpdateFreeCam crashed\n"); }

        if (m_mouseInspectPending) {
            m_mouseInspectPending = false;
            try { DoMouseInspect(); }
            catch (...) { ConLog("[UnityExplorer] DoMouseInspect crashed\n"); }
        }

        // Teleport to selected GO
        if (m_pendingTeleport) {
            m_pendingTeleport = false;
            try { TeleportToSelected(); }
            catch (...) { ConLog("[UnityExplorer] TeleportToSelected crashed\n"); }
        }

        if (m_pendingDumpHierarchy) {
            m_pendingDumpHierarchy = false;
            try { DumpHierarchyToFile(); }
            catch (...) { ConLog("[UnityExplorer] DumpHierarchyToFile crashed\n"); }
        }

        // Auto-navigate to _Application on scene load
        try {
            std::shared_ptr<std::vector<SceneNode>> navSnap;
            { std::lock_guard lock(m_mutex); navSnap = m_sceneRoots; }

            if (!m_autoNavigatedToApp && navSnap && !navSnap->empty()) {
                float dt = 0.f;
                try { dt = IL2CPP::Module::Unity::Time::GetDeltaTime(); } catch (...) {}
                m_appSearchTimer += dt;
                if (m_appSearchTimer >= 1.5f) {
                    m_appSearchTimer = 0.f;
                    ++m_appSearchRetries;

                    // Search all nodes recursively (not just roots — _Application may be nested)
                    std::vector<SearchResult> appResults;
                    for (auto& root : *navSnap) {
                        SearchSceneTreeImpl(root, "_application", "", appResults, 1);
                        if (!appResults.empty()) break;
                    }

                    if (!appResults.empty()) {
                        m_pendingSelectGO = appResults[0].gameObject;
                        m_showInspectorPanel = true;
                        m_switchToInspector = true;
                        PushHistory(InspectorMode::GameObject, appResults[0].gameObject);
                        m_autoNavigatedToApp = true;
                    } else {
                        // Trigger a tree refresh for next attempt
                        m_needsSceneRefresh = true;
                        if (m_appSearchRetries >= 10) {
                            m_autoNavigatedToApp = true; // give up silently
                        }
                    }
                }
            }
        } catch (...) { ConLog("[UnityExplorer] Auto-navigate crashed\n"); m_autoNavigatedToApp = true; }

        // Auto-refresh inspector
        try {
            if (m_autoRefreshInspector) {
                float dt = 0.f;
                try { dt = IL2CPP::Module::Unity::Time::GetDeltaTime(); } catch (...) {}
                m_autoRefreshTimer += dt;
                if (m_autoRefreshTimer >= 1.0f) {
                    m_autoRefreshTimer = 0.f;
                    if (m_inspectorMode == InspectorMode::GameObject && m_selectedGO)
                        RefreshGameObjectData(m_selectedGO);
                    else if (m_inspectorMode == InspectorMode::Component && m_selectedComponent)
                        RefreshComponentReflection(m_selectedComponent);
                }
            }
        } catch (...) { ConLog("[UnityExplorer] Auto-refresh crashed\n"); }

        // Apply timescale changes
        try { ApplyTimeScale(); }
        catch (...) { ConLog("[UnityExplorer] ApplyTimeScale crashed\n"); }

        // Lights refresh
        if (m_needsLightRefresh && m_showLightsPanel) {
            m_needsLightRefresh = false;
            try { RefreshSceneLights(); }
            catch (...) { ConLog("[UnityExplorer] RefreshSceneLights crashed\n"); }
        }
      } catch (...) { ConLog("[UnityExplorer] OnUpdate unhandled exception\n"); }
    }

    // =========================================================================
    //  Style Helper
    // =========================================================================

    // Theme color definitions
    struct ThemeColors {
        const char* name;
        ImVec4 accent;        // primary accent (buttons, active tabs, highlights)
        ImVec4 accentHover;   // hovered accent
        ImVec4 accentDim;     // dimmed accent (active button press)
        ImVec4 bg;            // window background
        ImVec4 bgChild;       // child/panel bg
        ImVec4 bgFrame;       // input frame bg
        ImVec4 bgFrameHov;    // input frame hovered
        ImVec4 titleActive;   // active title bar
        ImVec4 text;          // main text
        ImVec4 textDim;       // disabled text
        ImVec4 border;        // borders
        ImVec4 checkmark;     // checkmarks, slider grabs
        ImVec4 navbarBg;      // navbar background
        ImVec4 navbarAccent;  // navbar title color
    };

    static const ThemeColors kThemes[] = {
        // 0: Obsidian (grey/black default)
        { "Obsidian",
          {0.35f,0.35f,0.38f,1}, {0.45f,0.45f,0.48f,1}, {0.28f,0.28f,0.30f,1},
          {0.06f,0.06f,0.06f,1}, {0.08f,0.08f,0.08f,1},
          {0.12f,0.12f,0.12f,1}, {0.18f,0.18f,0.18f,1},
          {0.22f,0.22f,0.25f,1},
          {0.82f,0.82f,0.82f,1}, {0.42f,0.42f,0.42f,1},
          {0.18f,0.18f,0.18f,1}, {0.75f,0.75f,0.78f,1},
          {0.04f,0.04f,0.04f,0.98f}, {0.70f,0.70f,0.75f,1}
        },
        // 1: Nord
        { "Nord",
          {0.34f,0.43f,0.56f,1}, {0.40f,0.50f,0.64f,1}, {0.28f,0.37f,0.48f,1},
          {0.13f,0.16f,0.20f,1}, {0.15f,0.18f,0.22f,1},
          {0.17f,0.20f,0.25f,1}, {0.22f,0.26f,0.32f,1},
          {0.24f,0.34f,0.46f,1},
          {0.85f,0.87f,0.90f,1}, {0.45f,0.48f,0.52f,1},
          {0.22f,0.26f,0.30f,1}, {0.56f,0.74f,0.56f,1},
          {0.11f,0.13f,0.17f,0.98f}, {0.53f,0.75f,0.82f,1}
        },
        // 2: Monokai
        { "Monokai",
          {0.60f,0.22f,0.40f,1}, {0.72f,0.28f,0.48f,1}, {0.48f,0.18f,0.32f,1},
          {0.10f,0.10f,0.08f,1}, {0.12f,0.12f,0.10f,1},
          {0.15f,0.15f,0.12f,1}, {0.20f,0.20f,0.16f,1},
          {0.40f,0.16f,0.30f,1},
          {0.95f,0.95f,0.88f,1}, {0.50f,0.50f,0.42f,1},
          {0.25f,0.25f,0.20f,1}, {0.65f,0.89f,0.18f,1},
          {0.08f,0.08f,0.06f,0.98f}, {0.98f,0.15f,0.45f,1}
        },
        // 3: Solarized Dark
        { "Solarized",
          {0.15f,0.44f,0.52f,1}, {0.20f,0.52f,0.60f,1}, {0.12f,0.36f,0.42f,1},
          {0.00f,0.17f,0.21f,1}, {0.02f,0.20f,0.24f,1},
          {0.04f,0.22f,0.26f,1}, {0.07f,0.26f,0.30f,1},
          {0.10f,0.34f,0.40f,1},
          {0.51f,0.58f,0.51f,1}, {0.40f,0.44f,0.42f,1},
          {0.08f,0.28f,0.32f,1}, {0.52f,0.60f,0.00f,1},
          {0.00f,0.14f,0.18f,0.98f}, {0.42f,0.64f,0.80f,1}
        },
        // 4: Cyberpunk
        { "Cyberpunk",
          {0.80f,0.10f,0.55f,1}, {0.90f,0.20f,0.65f,1}, {0.65f,0.05f,0.42f,1},
          {0.04f,0.02f,0.08f,1}, {0.06f,0.03f,0.10f,1},
          {0.08f,0.04f,0.14f,1}, {0.14f,0.06f,0.20f,1},
          {0.55f,0.05f,0.38f,1},
          {0.90f,0.88f,0.95f,1}, {0.45f,0.40f,0.55f,1},
          {0.18f,0.10f,0.25f,1}, {0.00f,1.00f,0.85f,1},
          {0.03f,0.01f,0.06f,0.98f}, {0.00f,1.00f,0.85f,1}
        },
        // 5: Dracula
        { "Dracula",
          {0.74f,0.58f,0.98f,1}, {0.82f,0.68f,1.00f,1}, {0.60f,0.45f,0.82f,1},
          {0.16f,0.16f,0.21f,1}, {0.18f,0.19f,0.24f,1},
          {0.22f,0.22f,0.28f,1}, {0.28f,0.28f,0.35f,1},
          {0.50f,0.38f,0.70f,1},
          {0.95f,0.97f,0.98f,1}, {0.40f,0.42f,0.53f,1},
          {0.27f,0.28f,0.35f,1}, {0.31f,0.98f,0.48f,1},
          {0.13f,0.14f,0.18f,0.98f}, {0.74f,0.58f,0.98f,1}
        },
        // 6: Gruvbox
        { "Gruvbox",
          {0.82f,0.53f,0.10f,1}, {0.90f,0.60f,0.15f,1}, {0.70f,0.43f,0.05f,1},
          {0.16f,0.15f,0.13f,1}, {0.18f,0.17f,0.15f,1},
          {0.22f,0.20f,0.17f,1}, {0.28f,0.26f,0.22f,1},
          {0.60f,0.38f,0.05f,1},
          {0.92f,0.86f,0.70f,1}, {0.50f,0.47f,0.40f,1},
          {0.24f,0.22f,0.18f,1}, {0.72f,0.73f,0.15f,1},
          {0.13f,0.12f,0.10f,0.98f}, {0.98f,0.74f,0.02f,1}
        },
        // 7: Tokyo Night
        { "Tokyo Night",
          {0.48f,0.51f,0.90f,1}, {0.58f,0.61f,1.00f,1}, {0.38f,0.41f,0.75f,1},
          {0.10f,0.11f,0.18f,1}, {0.12f,0.13f,0.20f,1},
          {0.15f,0.16f,0.24f,1}, {0.20f,0.21f,0.32f,1},
          {0.38f,0.40f,0.72f,1},
          {0.77f,0.80f,0.92f,1}, {0.38f,0.40f,0.55f,1},
          {0.20f,0.21f,0.30f,1}, {0.45f,0.85f,0.70f,1},
          {0.08f,0.09f,0.15f,0.98f}, {0.48f,0.73f,0.98f,1}
        },
        // 8: Catppuccin Mocha
        { "Catppuccin",
          {0.54f,0.55f,0.90f,1}, {0.64f,0.65f,1.00f,1}, {0.44f,0.45f,0.78f,1},
          {0.12f,0.12f,0.18f,1}, {0.14f,0.14f,0.20f,1},
          {0.18f,0.18f,0.25f,1}, {0.24f,0.24f,0.33f,1},
          {0.42f,0.42f,0.68f,1},
          {0.81f,0.84f,0.95f,1}, {0.42f,0.44f,0.57f,1},
          {0.22f,0.22f,0.30f,1}, {0.65f,0.89f,0.63f,1},
          {0.10f,0.10f,0.15f,0.98f}, {0.95f,0.55f,0.66f,1}
        },
        // 9: Synthwave
        { "Synthwave",
          {0.95f,0.30f,0.80f,1}, {1.00f,0.42f,0.90f,1}, {0.78f,0.20f,0.65f,1},
          {0.07f,0.02f,0.12f,1}, {0.09f,0.03f,0.15f,1},
          {0.12f,0.04f,0.20f,1}, {0.18f,0.06f,0.28f,1},
          {0.65f,0.15f,0.55f,1},
          {0.95f,0.90f,1.00f,1}, {0.50f,0.35f,0.60f,1},
          {0.22f,0.08f,0.30f,1}, {0.20f,0.95f,0.95f,1},
          {0.05f,0.01f,0.08f,0.98f}, {0.20f,0.95f,0.95f,1}
        },
        // 10: Rose Pine
        { "Rose Pine",
          {0.92f,0.60f,0.54f,1}, {0.96f,0.70f,0.64f,1}, {0.78f,0.48f,0.42f,1},
          {0.10f,0.09f,0.14f,1}, {0.12f,0.11f,0.16f,1},
          {0.15f,0.14f,0.20f,1}, {0.20f,0.19f,0.26f,1},
          {0.65f,0.40f,0.38f,1},
          {0.88f,0.85f,0.88f,1}, {0.43f,0.40f,0.48f,1},
          {0.20f,0.18f,0.26f,1}, {0.56f,0.76f,0.67f,1},
          {0.08f,0.07f,0.11f,0.98f}, {0.92f,0.60f,0.54f,1}
        },
        // 11: Abyss
        { "Abyss",
          {0.10f,0.50f,0.75f,1}, {0.15f,0.60f,0.88f,1}, {0.06f,0.38f,0.60f,1},
          {0.02f,0.04f,0.08f,1}, {0.03f,0.05f,0.10f,1},
          {0.05f,0.08f,0.14f,1}, {0.08f,0.12f,0.20f,1},
          {0.06f,0.32f,0.52f,1},
          {0.70f,0.80f,0.88f,1}, {0.30f,0.38f,0.48f,1},
          {0.08f,0.12f,0.18f,1}, {0.30f,0.75f,0.95f,1},
          {0.01f,0.02f,0.05f,0.98f}, {0.30f,0.75f,0.95f,1}
        },
    };
    static constexpr int kThemeCount = 12;

    static void PushThemeStyle(int themeIdx) {
        if (themeIdx < 0 || themeIdx >= kThemeCount) themeIdx = 0;
        auto& t = kThemes[themeIdx];

        ImVec4 bgFrameActive = ImVec4(t.bgFrameHov.x + 0.04f, t.bgFrameHov.y + 0.04f, t.bgFrameHov.z + 0.04f, 1);
        ImVec4 headerBg  = ImVec4(t.bgFrame.x + 0.03f, t.bgFrame.y + 0.03f, t.bgFrame.z + 0.03f, 1);
        ImVec4 scrollGrab = ImVec4(t.border.x + 0.05f, t.border.y + 0.05f, t.border.z + 0.05f, 1);

        ImGui::PushStyleColor(ImGuiCol_WindowBg,             t.bg);
        ImGui::PushStyleColor(ImGuiCol_ChildBg,              t.bgChild);
        ImGui::PushStyleColor(ImGuiCol_PopupBg,              ImVec4(t.bg.x + 0.03f, t.bg.y + 0.03f, t.bg.z + 0.03f, 0.96f));
        ImGui::PushStyleColor(ImGuiCol_Border,               t.border);
        ImGui::PushStyleColor(ImGuiCol_FrameBg,              t.bgFrame);
        ImGui::PushStyleColor(ImGuiCol_FrameBgHovered,       t.bgFrameHov);
        ImGui::PushStyleColor(ImGuiCol_FrameBgActive,        bgFrameActive);
        ImGui::PushStyleColor(ImGuiCol_TitleBg,              ImVec4(t.bg.x - 0.02f, t.bg.y - 0.02f, t.bg.z - 0.02f, 1));
        ImGui::PushStyleColor(ImGuiCol_TitleBgActive,        t.titleActive);
        ImGui::PushStyleColor(ImGuiCol_TitleBgCollapsed,     ImVec4(t.bg.x - 0.02f, t.bg.y - 0.02f, t.bg.z - 0.02f, 0.75f));
        ImGui::PushStyleColor(ImGuiCol_Tab,                  t.bgFrame);
        ImGui::PushStyleColor(ImGuiCol_TabHovered,           t.accentHover);
        ImGui::PushStyleColor(ImGuiCol_TabSelected,          t.accent);
        ImGui::PushStyleColor(ImGuiCol_Header,               headerBg);
        ImGui::PushStyleColor(ImGuiCol_HeaderHovered,        ImVec4(t.accent.x, t.accent.y, t.accent.z, 0.65f));
        ImGui::PushStyleColor(ImGuiCol_HeaderActive,         ImVec4(t.accent.x, t.accent.y, t.accent.z, 0.85f));
        ImGui::PushStyleColor(ImGuiCol_Button,               t.accent);
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered,        t.accentHover);
        ImGui::PushStyleColor(ImGuiCol_ButtonActive,         t.accentDim);
        ImGui::PushStyleColor(ImGuiCol_Separator,            t.border);
        ImGui::PushStyleColor(ImGuiCol_Text,                 t.text);
        ImGui::PushStyleColor(ImGuiCol_TextDisabled,         t.textDim);
        ImGui::PushStyleColor(ImGuiCol_ScrollbarBg,          t.bg);
        ImGui::PushStyleColor(ImGuiCol_ScrollbarGrab,        scrollGrab);
        ImGui::PushStyleColor(ImGuiCol_ScrollbarGrabHovered, ImVec4(scrollGrab.x + 0.10f, scrollGrab.y + 0.10f, scrollGrab.z + 0.10f, 1));
        ImGui::PushStyleColor(ImGuiCol_ScrollbarGrabActive,  ImVec4(scrollGrab.x + 0.15f, scrollGrab.y + 0.15f, scrollGrab.z + 0.15f, 1));
        ImGui::PushStyleColor(ImGuiCol_CheckMark,            t.checkmark);
        ImGui::PushStyleColor(ImGuiCol_SliderGrab,           ImVec4(t.accent.x + 0.10f, t.accent.y + 0.10f, t.accent.z + 0.10f, 1));
        ImGui::PushStyleColor(ImGuiCol_SliderGrabActive,     ImVec4(t.accent.x + 0.15f, t.accent.y + 0.15f, t.accent.z + 0.15f, 1));
        ImGui::PushStyleColor(ImGuiCol_TableHeaderBg,        t.bgFrame);
        ImGui::PushStyleColor(ImGuiCol_TableRowBg,           t.bgChild);
        ImGui::PushStyleColor(ImGuiCol_TableRowBgAlt,        ImVec4(t.bgChild.x + 0.02f, t.bgChild.y + 0.02f, t.bgChild.z + 0.02f, 1));
        ImGui::PushStyleColor(ImGuiCol_TableBorderStrong,    ImVec4(t.border.x + 0.02f, t.border.y + 0.02f, t.border.z + 0.02f, 1));
        ImGui::PushStyleColor(ImGuiCol_TableBorderLight,     t.border);
    }
    static constexpr int kCUEStyleColorCount = 34;

    // Draw custom cursor on the foreground drawlist
    static void DrawCustomCursor(int themeIdx) {
        auto& io = ImGui::GetIO();
        auto* dl = ImGui::GetForegroundDrawList();
        float mx = io.MousePos.x;
        float my = io.MousePos.y;

        ImU32 accentCol = IM_COL32(
            (int)(kThemes[themeIdx].navbarAccent.x * 255),
            (int)(kThemes[themeIdx].navbarAccent.y * 255),
            (int)(kThemes[themeIdx].navbarAccent.z * 255), 255);
        ImU32 fillCol = IM_COL32(
            (int)(kThemes[themeIdx].navbarAccent.x * 180),
            (int)(kThemes[themeIdx].navbarAccent.y * 180),
            (int)(kThemes[themeIdx].navbarAccent.z * 180), 120);
        ImU32 shadow = IM_COL32(0, 0, 0, 160);

        // Arrow cursor shape (pointer)
        ImVec2 p0(mx, my);                        // tip
        ImVec2 p1(mx, my + 18.0f);                // bottom-left
        ImVec2 p2(mx + 5.0f, my + 14.0f);         // notch
        ImVec2 p3(mx + 8.0f, my + 20.0f);         // tail bottom
        ImVec2 p4(mx + 11.0f, my + 18.5f);        // tail top
        ImVec2 p5(mx + 7.5f, my + 12.5f);         // notch inner
        ImVec2 p6(mx + 13.0f, my + 12.5f);        // right point

        // Shadow offset
        float s = 1.5f;
        dl->AddTriangleFilled(ImVec2(p0.x+s,p0.y+s), ImVec2(p1.x+s,p1.y+s), ImVec2(p6.x+s,p6.y+s), shadow);

        // Fill
        dl->AddTriangleFilled(p0, p1, p6, fillCol);
        // Outline
        dl->AddLine(p0, p1, accentCol, 1.5f);
        dl->AddLine(p1, p2, accentCol, 1.5f);
        dl->AddLine(p2, p3, accentCol, 1.5f);
        dl->AddLine(p3, p4, accentCol, 1.5f);
        dl->AddLine(p4, p5, accentCol, 1.5f);
        dl->AddLine(p5, p6, accentCol, 1.5f);
        dl->AddLine(p6, p0, accentCol, 1.5f);
    }

    // =========================================================================
    //  Navbar (Render thread) — fixed at top, non-moveable
    // =========================================================================

    void UnityExplorerModule::RenderNavbar() {
        auto* viewport = ImGui::GetMainViewport();
        ImGui::SetNextWindowPos(viewport->Pos);
        ImGui::SetNextWindowSize(ImVec2(viewport->Size.x, kNavbarHeight));

        ImGuiWindowFlags navFlags =
            ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
            ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar |
            ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoCollapse |
            ImGuiWindowFlags_NoSavedSettings;

        auto& theme = kThemes[m_themeIndex];
        ImGui::PushStyleColor(ImGuiCol_WindowBg, theme.navbarBg);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(6, 5));

        ImGui::Begin("##CUENavbar", nullptr, navFlags);

        // Title
        ImGui::TextColored(theme.navbarAccent, "CUE");
        ImGui::SameLine();
        ImGui::SeparatorEx(ImGuiSeparatorFlags_Vertical);
        ImGui::SameLine();

        // Panel toggle buttons
        auto NavBtn = [&](const char* label, bool& visible) {
            if (visible)
                ImGui::PushStyleColor(ImGuiCol_Button, theme.accent);
            else
                ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(theme.bgFrame.x + 0.02f, theme.bgFrame.y + 0.02f, theme.bgFrame.z + 0.02f, 1.0f));
            if (ImGui::SmallButton(label)) visible = !visible;
            ImGui::PopStyleColor();
            ImGui::SameLine();
        };

        NavBtn("Scene",     m_showScenePanel);
        NavBtn("Inspector", m_showInspectorPanel);
        NavBtn("Search",    m_showSearchPanel);
        NavBtn("Pins",      m_showBookmarksPanel);
        NavBtn("FreeCam",   m_showFreeCamPanel);
        NavBtn("Lights",    m_showLightsPanel);
        NavBtn("Misc",      m_showMiscPanel);

        // Mouse inspect
        ImGui::SeparatorEx(ImGuiSeparatorFlags_Vertical);
        ImGui::SameLine();
        if (m_mouseInspectActive) {
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.60f, 0.20f, 0.20f, 1.0f));
            if (ImGui::SmallButton("Cancel")) m_mouseInspectActive = false;
            ImGui::PopStyleColor();
            ImGui::SameLine();
            ImGui::TextColored(theme.navbarAccent, "Click...");
        } else {
            const char* inspLabel = m_mouseInspectMode == 0 ? "Inspect World" : "Inspect UI";
            if (ImGui::SmallButton(inspLabel)) m_mouseInspectActive = true;
            ImGui::SameLine();
            if (ImGui::SmallButton(m_mouseInspectMode == 0 ? "W" : "U")) {
                m_mouseInspectMode = (m_mouseInspectMode + 1) % 2;
            }
            if (ImGui::IsItemHovered() && ImGui::BeginTooltip()) {
                ImGui::Text("Toggle World/UI inspect");
                ImGui::EndTooltip();
            }
        }
        ImGui::SameLine();

        // Push theme to the right
        float rightWidth = 140.0f;
        float available = ImGui::GetContentRegionAvail().x;
        if (available > rightWidth)
            ImGui::Dummy(ImVec2(available - rightWidth, 0));
        ImGui::SameLine();

        // Theme selector (compact)
        ImGui::SeparatorEx(ImGuiSeparatorFlags_Vertical);
        ImGui::SameLine();
        ImGui::SetNextItemWidth(110);
        {
            const char* themeNames[kThemeCount];
            for (int i = 0; i < kThemeCount; ++i) themeNames[i] = kThemes[i].name;
            int prevTheme = m_themeIndex;
            ImGui::Combo("##Theme", &m_themeIndex, themeNames, kThemeCount);
            if (m_themeIndex != prevTheme)
                SaveThemeConfig(m_themeIndex);
        }

        ImGui::End();
        ImGui::PopStyleVar();
        ImGui::PopStyleColor();
    }

    // =========================================================================
    //  Scene Panel (Render thread)
    // =========================================================================

    void UnityExplorerModule::RenderSceneNode(SceneNode& node) {
        if (!m_showInactive && !node.activeSelf) return;

        ImGuiTreeNodeFlags flags = ImGuiTreeNodeFlags_OpenOnArrow | ImGuiTreeNodeFlags_SpanAvailWidth;
        if (node.children.empty() && node.childCount == 0)
            flags |= ImGuiTreeNodeFlags_Leaf;
        if (node.gameObject == m_selectedGO)
            flags |= ImGuiTreeNodeFlags_Selected;

        // Cyan for active, gray for inactive
        if (!node.activeInHierarchy)
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.40f, 0.40f, 0.40f, 1.0f));
        else
            ImGui::PushStyleColor(ImGuiCol_Text, kThemes[m_themeIndex].navbarAccent);

        char label[512];
        if (node.childCount > 0)
            std::snprintf(label, sizeof(label), "%s [%d]", node.name.c_str(), node.childCount);
        else
            std::snprintf(label, sizeof(label), "%s", node.name.c_str());

        bool open = ImGui::TreeNodeEx((void*)(uintptr_t)node.transform, flags, "%s", label);
        ImGui::PopStyleColor();

        if (ImGui::IsItemClicked() && !ImGui::IsItemToggledOpen()) {
            m_pendingSelectGO = node.gameObject;
            m_switchToInspector = true;
            m_showInspectorPanel = true;
            PushHistory(InspectorMode::GameObject, node.gameObject);
        }

        if (ImGui::BeginPopupContextItem()) {
            if (ImGui::MenuItem("Inspect")) {
                m_pendingSelectGO = node.gameObject;
                m_switchToInspector = true;
                m_showInspectorPanel = true;
                PushHistory(InspectorMode::GameObject, node.gameObject);
            }
            if (ImGui::MenuItem(node.activeSelf ? "Deactivate" : "Activate")) {
                try {
                    IL2CPP::Module::Unity::GameObject go(node.gameObject);
                    if (go) go.SetActive(!node.activeSelf);
                } catch (...) {}
                m_needsSceneRefresh = true;
            }
            if (ImGui::MenuItem("Destroy")) {
                try {
                    IL2CPP::Module::Unity::Object obj(node.gameObject);
                    if (obj) obj.Destroy();
                } catch (...) {}
                m_needsSceneRefresh = true;
            }
            ImGui::EndPopup();
        }

        if (open) {
            for (auto& child : node.children)
                RenderSceneNode(child);
            ImGui::TreePop();
        }
    }

    void UnityExplorerModule::RenderScenePanel() {
        ImGui::SetNextWindowSize(ImVec2(400, 500), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowPos(ImVec2(10, kNavbarHeight + 10), ImGuiCond_FirstUseEver);

        if (!ImGui::Begin("Scene Explorer", &m_showScenePanel)) {
            ImGui::End();
            return;
        }

        // Toolbar
        if (ImGui::Button("Refresh")) m_needsSceneRefresh = true;
        ImGui::SameLine();
        ImGui::Checkbox("Show Inactive", &m_showInactive);
        ImGui::SameLine();
        ImGui::Text("(%d objects)", m_nodeCount);

        // Snapshot scene tree — mutex already held by OnOverlay
        auto treeSnap = m_sceneRoots;

        // Go-to-path input
        ImGui::SetNextItemWidth(-60);
        bool goToEnter = ImGui::InputTextWithHint("##GoToPath", "Go to path (e.g. Canvas/Panel/Button)...",
            m_goToPathBuf, sizeof(m_goToPathBuf), ImGuiInputTextFlags_EnterReturnsTrue);
        ImGui::SameLine();
        if (ImGui::Button("Go") || goToEnter) {
            if (m_goToPathBuf[0] != '\0' && treeSnap) {
                // Search for object by path in scene tree
                std::string target = m_goToPathBuf;
                std::string targetLower = target;
                std::transform(targetLower.begin(), targetLower.end(), targetLower.begin(),
                    [](unsigned char c) { return static_cast<char>(std::tolower(c)); });

                // Search scene for matching path
                std::vector<SearchResult> pathResults;
                for (auto& root : *treeSnap) {
                    SearchSceneTree(root, targetLower, pathResults, 1);
                    if (!pathResults.empty()) break;
                }
                if (!pathResults.empty()) {
                    m_pendingSelectGO = pathResults[0].gameObject;
                    m_showInspectorPanel = true;
                    m_switchToInspector = true;
                    PushHistory(InspectorMode::GameObject, pathResults[0].gameObject);
                }
            }
        }

        ImGui::Separator();

        ImGui::BeginChild("SceneTree", ImVec2(0, 0), false, ImGuiWindowFlags_HorizontalScrollbar);
        if (treeSnap) {
            for (auto& root : *treeSnap)
                RenderSceneNode(root);
        }
        if (m_nodeCount >= kMaxNodes)
            ImGui::TextColored(ImVec4(1, 0.5f, 0, 1), "Showing first %d nodes (limit reached)", kMaxNodes);
        ImGui::EndChild();

        ImGui::End();
    }

    // =========================================================================
    //  Inspector Panel (Render thread)
    // =========================================================================

    void UnityExplorerModule::RenderGameObjectView() {
        if (!m_selectedGO) {
            ImGui::TextDisabled("No GameObject selected. Click an object in the Scene panel.");
            return;
        }

        auto& theme = kThemes[m_themeIndex];

        // ---- Header: Name (click to copy) ----
        ImGui::TextColored(theme.navbarAccent, "%s", m_goName.c_str());
        if (ImGui::IsItemClicked(ImGuiMouseButton_Left) || ImGui::IsItemClicked(ImGuiMouseButton_Right)) {
            ImGui::SetClipboardText(m_goName.c_str());
        }
        if (ImGui::IsItemHovered() && ImGui::BeginTooltip()) {
            ImGui::Text("Click to copy name");
            ImGui::EndTooltip();
        }

        // ---- Path (click to copy) ----
        if (!m_goPath.empty()) {
            ImGui::TextColored(ImVec4(0.5f, 0.5f, 0.5f, 1.0f), "Path: %s", m_goPath.c_str());
            if (ImGui::IsItemClicked(ImGuiMouseButton_Left) || ImGui::IsItemClicked(ImGuiMouseButton_Right)) {
                ImGui::SetClipboardText(m_goPath.c_str());
            }
            if (ImGui::IsItemHovered() && ImGui::BeginTooltip()) {
                ImGui::Text("Click to copy path");
                ImGui::EndTooltip();
            }
        }

        // ---- Info line ----
        ImGui::Text("Scene: %s  |  Layer: %u  |  Tag: %s",
                     m_goScene.c_str(), m_goLayer, m_goTag.c_str());

        // ---- View Parent button ----
        if (m_goParentTransform) {
            ImGui::SameLine();
            if (ImGui::SmallButton("View Parent")) {
                // Route through Unity thread — can't call IL2CPP on render thread
                m_pendingViewParent = true;
            }
        }

        // ---- SetActive / Destroy / Teleport / Bookmark buttons ----
        {
            bool active = m_goActive;
            if (ImGui::Checkbox("Active", &active)) {
                m_pendingSetActive = true;
                m_pendingActiveValue = active;
                m_goActive = active;
            }
            ImGui::SameLine();
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.6f, 0.15f, 0.15f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.8f, 0.2f, 0.2f, 1.0f));
            if (ImGui::SmallButton("Destroy")) {
                m_pendingDestroyGO = true;
            }
            ImGui::PopStyleColor(2);

            ImGui::SameLine();
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.15f, 0.35f, 0.55f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.20f, 0.45f, 0.65f, 1.0f));
            if (ImGui::SmallButton("Teleport")) {
                m_pendingTeleport = true;
            }
            ImGui::PopStyleColor(2);

            ImGui::SameLine();
            if (m_selectedGO) {
                ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.15f, 0.45f, 0.15f, 1.0f));
                ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.20f, 0.55f, 0.20f, 1.0f));
                if (ImGui::SmallButton("Dump")) {
                    m_showDumpPopup = true;
                    ImGui::OpenPopup("DumpSettings");
                }
                ImGui::PopStyleColor(2);
                ImGui::SameLine();
            }
            RenderDumpPopup();

            // Check if already bookmarked
            bool alreadyBookmarked = false;
            for (auto& bm : m_bookmarks) {
                if (bm.gameObject == m_selectedGO) { alreadyBookmarked = true; break; }
            }
            if (alreadyBookmarked) {
                ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.50f, 0.45f, 0.10f, 1.0f));
                if (ImGui::SmallButton("Unpin")) {
                    m_bookmarks.erase(
                        std::remove_if(m_bookmarks.begin(), m_bookmarks.end(),
                            [&](const Bookmark& b) { return b.gameObject == m_selectedGO; }),
                        m_bookmarks.end());
                }
                ImGui::PopStyleColor();
            } else {
                ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.45f, 0.40f, 0.10f, 1.0f));
                ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.55f, 0.50f, 0.15f, 1.0f));
                if (ImGui::SmallButton("Pin")) {
                    Bookmark bm;
                    bm.gameObject = m_selectedGO;
                    bm.name = m_goName;
                    bm.path = m_goPath;
                    m_bookmarks.push_back(std::move(bm));
                }
                ImGui::PopStyleColor(2);
            }
        }

        ImGui::Separator();

        // ---- Transform (editable) ----
        ImGui::SeparatorText("Transform");
        float pos[3] = { m_position[0], m_position[1], m_position[2] };
        float rot[3] = { m_rotation[0], m_rotation[1], m_rotation[2] };
        float scl[3] = { m_scale[0], m_scale[1], m_scale[2] };

        bool changed = false;
        changed |= ImGui::DragFloat3("Position", pos, 0.05f, 0, 0, "%.3f");
        changed |= ImGui::DragFloat3("Rotation", rot, 0.5f, 0, 0, "%.2f");
        changed |= ImGui::DragFloat3("Scale", scl, 0.01f, 0, 0, "%.3f");

        if (changed) {
            std::memcpy(m_position, pos, sizeof(pos));
            std::memcpy(m_rotation, rot, sizeof(rot));
            std::memcpy(m_scale, scl, sizeof(scl));
            std::memcpy(m_pendingPos, pos, sizeof(pos));
            std::memcpy(m_pendingRot, rot, sizeof(rot));
            std::memcpy(m_pendingScl, scl, sizeof(scl));
            m_pendingTransformEdit = true;
        }

        ImGui::Separator();

        // ---- Children ----
        if (!m_children.empty()) {
            char childLabel[64];
            snprintf(childLabel, sizeof(childLabel), "Children (%d)", (int)m_children.size());
            ImGui::SeparatorText(childLabel);
            ImGui::BeginChild("##ChildList", ImVec2(0, std::min((int)m_children.size(), 10) * ImGui::GetTextLineHeightWithSpacing() + 4), true);
            for (size_t i = 0; i < m_children.size(); ++i) {
                auto& child = m_children[i];
                ImGui::PushID(static_cast<int>(i + 10000));

                ImVec4 col = child.active ? theme.text : theme.textDim;
                ImGui::PushStyleColor(ImGuiCol_Text, col);
                if (ImGui::Selectable(child.name.c_str())) {
                    if (child.gameObject) {
                        m_pendingSelectGO = child.gameObject;
                        PushHistory(InspectorMode::GameObject, child.gameObject);
                    }
                }
                ImGui::PopStyleColor();

                if (ImGui::IsItemClicked(ImGuiMouseButton_Right)) {
                    ImGui::SetClipboardText(child.name.c_str());
                }
                if (ImGui::IsItemHovered() && ImGui::BeginTooltip()) {
                    ImGui::Text("Left: Navigate  |  Right: Copy name  |  %s", child.active ? "Active" : "Inactive");
                    ImGui::EndTooltip();
                }

                ImGui::PopID();
            }
            ImGui::EndChild();
        }

        ImGui::Separator();

        // ---- Components ----
        char compLabel[64];
        snprintf(compLabel, sizeof(compLabel), "Components (%d)", (int)m_components.size());
        ImGui::SeparatorText(compLabel);
        for (size_t i = 0; i < m_components.size(); ++i) {
            auto& comp = m_components[i];
            ImGui::PushID(static_cast<int>(i));

            if (comp.isBehaviour) {
                bool en = comp.enabled;
                if (ImGui::Checkbox("##en", &en)) {
                    // Route through Unity thread
                    m_pendingCompToggle = true;
                    m_pendingCompToggleTarget = comp.raw;
                    m_pendingCompToggleValue = en;
                    comp.enabled = en; // optimistic UI update
                }
                ImGui::SameLine();
            } else {
                ImGui::Dummy(ImVec2(ImGui::GetFrameHeight(), 0));
                ImGui::SameLine();
            }

            bool selected = (comp.raw == m_selectedComponent && m_inspectorMode == InspectorMode::Component);
            if (ImGui::Selectable(comp.typeName.c_str(), selected)) {
                m_pendingSelectComponent = comp.raw;
                PushHistory(InspectorMode::Component, comp.raw);
            }
            if (ImGui::IsItemClicked(ImGuiMouseButton_Right)) {
                ImGui::SetClipboardText(comp.typeName.c_str());
            }
            if (ImGui::IsItemHovered() && ImGui::BeginTooltip()) {
                ImGui::Text("Left: Inspect  |  Right: Copy name");
                ImGui::EndTooltip();
            }

            ImGui::PopID();
        }
    }

    void UnityExplorerModule::RenderComponentView() {
        if (!m_selectedComponent) {
            ImGui::TextDisabled("No component selected.");
            return;
        }

        if (ImGui::Button("< Back to GameObject") && m_selectedGO) {
            m_pendingSelectGO = m_selectedGO;
        }
        ImGui::SameLine();
        ImGui::TextColored(kThemes[m_themeIndex].navbarAccent, "%s", m_selectedComponentType.c_str());
        if (ImGui::IsItemClicked(ImGuiMouseButton_Left) || ImGui::IsItemClicked(ImGuiMouseButton_Right)) {
            ImGui::SetClipboardText(m_selectedComponentType.c_str());
        }
        if (ImGui::IsItemHovered() && ImGui::BeginTooltip()) {
            ImGui::Text("Click to copy type name");
            ImGui::EndTooltip();
        }

        // Destroy button (not for Transform)
        if (m_selectedComponentType != "Transform" && m_selectedComponentType != "UnityEngine.Transform") {
            ImGui::SameLine();
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.6f, 0.15f, 0.15f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.8f, 0.2f, 0.2f, 1.0f));
            if (ImGui::SmallButton("Destroy")) {
                m_pendingDestroyComp = true;
                m_pendingDestroyTarget = m_selectedComponent;
            }
            ImGui::PopStyleColor(2);
        }

        ImGui::Separator();

        const char* filters[] = { "All", "Fields", "Properties", "Methods" };
        for (int i = 0; i < 4; ++i) {
            if (i > 0) ImGui::SameLine();
            if (ImGui::RadioButton(filters[i], m_inspectorFilter == i))
                m_inspectorFilter = i;
        }
        ImGui::SameLine();
        ImGui::Checkbox("Static", &m_showStaticMembers);

        ImGui::Separator();

        ImGui::BeginChild("ReflectionView", ImVec2(0, 0), false, ImGuiWindowFlags_HorizontalScrollbar);

        // Fields
        if (m_inspectorFilter == 0 || m_inspectorFilter == 1) {
            if (!m_fields.empty()) {
                ImGui::SeparatorText("Fields");
                if (ImGui::BeginTable("Fields", 3, ImGuiTableFlags_Borders | ImGuiTableFlags_Resizable | ImGuiTableFlags_RowBg)) {
                    ImGui::TableSetupColumn("Name", ImGuiTableColumnFlags_WidthStretch, 0.3f);
                    ImGui::TableSetupColumn("Type", ImGuiTableColumnFlags_WidthStretch, 0.25f);
                    ImGui::TableSetupColumn("Value", ImGuiTableColumnFlags_WidthStretch, 0.45f);
                    ImGui::TableHeadersRow();

                    for (auto& f : m_fields) {
                        if (!m_showStaticMembers && f.isStatic) continue;

                        ImGui::TableNextRow();
                        ImGui::TableNextColumn();
                        if (f.isStatic)
                            ImGui::TextColored(ImVec4(0.55f, 0.55f, 0.90f, 1.0f), "[S] %s", f.name.c_str());
                        else
                            ImGui::TextUnformatted(f.name.c_str());

                        ImGui::TableNextColumn();
                        ImGui::TextColored(ImVec4(0.35f, 0.70f, 0.35f, 1.0f), "%s", f.typeName.c_str());

                        ImGui::TableNextColumn();
                        ImGui::TextWrapped("%s", f.value.c_str());
                    }
                    ImGui::EndTable();
                }
            }
        }

        // Properties
        if (m_inspectorFilter == 0 || m_inspectorFilter == 2) {
            if (!m_properties.empty()) {
                ImGui::SeparatorText("Properties");
                if (ImGui::BeginTable("Properties", 3, ImGuiTableFlags_Borders | ImGuiTableFlags_Resizable | ImGuiTableFlags_RowBg)) {
                    ImGui::TableSetupColumn("Name", ImGuiTableColumnFlags_WidthStretch, 0.3f);
                    ImGui::TableSetupColumn("Type", ImGuiTableColumnFlags_WidthStretch, 0.25f);
                    ImGui::TableSetupColumn("Value", ImGuiTableColumnFlags_WidthStretch, 0.45f);
                    ImGui::TableHeadersRow();

                    for (auto& p : m_properties) {
                        ImGui::TableNextRow();
                        ImGui::TableNextColumn();

                        std::string prefix;
                        if (p.hasGetter && p.hasSetter) prefix = "[get/set] ";
                        else if (p.hasGetter) prefix = "[get] ";
                        else if (p.hasSetter) prefix = "[set] ";
                        ImGui::TextUnformatted((prefix + p.name).c_str());

                        ImGui::TableNextColumn();
                        ImGui::TextColored(ImVec4(0.35f, 0.70f, 0.35f, 1.0f), "%s", p.typeName.c_str());

                        ImGui::TableNextColumn();
                        ImGui::TextWrapped("%s", p.value.c_str());
                    }
                    ImGui::EndTable();
                }
            }
        }

        // Methods
        if (m_inspectorFilter == 0 || m_inspectorFilter == 3) {
            if (!m_methods.empty()) {
                ImGui::SeparatorText("Methods");
                if (ImGui::BeginTable("Methods", 3, ImGuiTableFlags_Borders | ImGuiTableFlags_Resizable | ImGuiTableFlags_RowBg)) {
                    ImGui::TableSetupColumn("Name", ImGuiTableColumnFlags_WidthStretch, 0.35f);
                    ImGui::TableSetupColumn("Returns", ImGuiTableColumnFlags_WidthStretch, 0.2f);
                    ImGui::TableSetupColumn("Parameters", ImGuiTableColumnFlags_WidthStretch, 0.45f);
                    ImGui::TableHeadersRow();

                    for (auto& m : m_methods) {
                        if (!m_showStaticMembers && m.isStatic) continue;

                        ImGui::TableNextRow();
                        ImGui::TableNextColumn();
                        if (m.isStatic)
                            ImGui::TextColored(ImVec4(0.55f, 0.55f, 0.90f, 1.0f), "[S] %s", m.name.c_str());
                        else
                            ImGui::TextUnformatted(m.name.c_str());

                        ImGui::TableNextColumn();
                        ImGui::TextColored(ImVec4(0.35f, 0.70f, 0.35f, 1.0f), "%s", m.returnType.c_str());

                        ImGui::TableNextColumn();
                        if (m.paramSig.empty())
                            ImGui::TextDisabled("(none)");
                        else
                            ImGui::TextWrapped("%s", m.paramSig.c_str());
                    }
                    ImGui::EndTable();
                }
            }
        }

        ImGui::EndChild();
    }

    void UnityExplorerModule::RenderInspectorPanel() {
        ImGui::SetNextWindowSize(ImVec2(600, 500), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowPos(ImVec2(420, kNavbarHeight + 10), ImGuiCond_FirstUseEver);

        if (!ImGui::Begin("Inspector", &m_showInspectorPanel)) {
            ImGui::End();
            return;
        }

        // History nav
        bool canBack = m_historyIdx > 0;
        bool canFwd = m_historyIdx + 1 < static_cast<int>(m_history.size());

        if (!canBack) ImGui::BeginDisabled();
        if (ImGui::ArrowButton("##back", ImGuiDir_Left)) NavigateBack();
        if (!canBack) ImGui::EndDisabled();
        ImGui::SameLine();
        if (!canFwd) ImGui::BeginDisabled();
        if (ImGui::ArrowButton("##fwd", ImGuiDir_Right)) NavigateForward();
        if (!canFwd) ImGui::EndDisabled();
        ImGui::SameLine();
        if (ImGui::Button("Refresh")) {
            if (m_inspectorMode == InspectorMode::GameObject && m_selectedGO)
                m_pendingSelectGO = m_selectedGO;
            else if (m_inspectorMode == InspectorMode::Component && m_selectedComponent)
                m_pendingSelectComponent = m_selectedComponent;
        }
        ImGui::SameLine();
        ImGui::Checkbox("Auto", &m_autoRefreshInspector);
        if (ImGui::IsItemHovered() && ImGui::BeginTooltip()) {
            ImGui::Text("Auto-refresh inspector every 1s");
            ImGui::EndTooltip();
        }
        ImGui::Separator();

        if (m_inspectorMode == InspectorMode::Component)
            RenderComponentView();
        else
            RenderGameObjectView();

        ImGui::End();
    }

    // =========================================================================
    //  Search Panel (Render thread)
    // =========================================================================

    void UnityExplorerModule::RenderSearchPanel() {
        ImGui::SetNextWindowSize(ImVec2(500, 400), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowPos(ImVec2(10, kNavbarHeight + 520), ImGuiCond_FirstUseEver);

        if (!ImGui::Begin("Object Search", &m_showSearchPanel)) {
            ImGui::End();
            return;
        }

        ImGui::RadioButton("Name", &m_searchMode, 0);
        ImGui::SameLine();
        ImGui::RadioButton("Type", &m_searchMode, 1);
        ImGui::SameLine();

        ImGui::SetNextItemWidth(-100);
        bool enter = ImGui::InputText("##search", m_searchBuf, sizeof(m_searchBuf),
            ImGuiInputTextFlags_EnterReturnsTrue);
        ImGui::SameLine();
        if (ImGui::Button("Search") || enter) {
            // mutex already held by OnOverlay
            m_pendingSearchQuery = m_searchBuf;
            m_pendingSearchMode = m_searchMode;
            m_needsSearch = true;
        }

        ImGui::Separator();

        ImGui::BeginChild("SearchResults", ImVec2(0, 0), false);
        {
            // mutex already held by OnOverlay — safe to read directly
            if (m_searchResults.empty()) {
                ImGui::TextDisabled("No results. Enter a search query above.");
            } else {
                ImGui::Text("%zu results:", m_searchResults.size());
                for (size_t i = 0; i < m_searchResults.size(); ++i) {
                    auto& sr = m_searchResults[i];
                    ImGui::PushID(static_cast<int>(i));

                    if (ImGui::Selectable(sr.path.c_str())) {
                        m_pendingSelectGO = sr.gameObject;
                        m_switchToInspector = true;
                        m_showInspectorPanel = true;
                        PushHistory(InspectorMode::GameObject, sr.gameObject);
                    }

                    ImGui::PopID();
                }
            }
        }
        ImGui::EndChild();

        ImGui::End();
    }

    // =========================================================================
    //  FreeCam Panel (Render thread)
    // =========================================================================

    void UnityExplorerModule::RenderFreeCamPanel() {
        ImGui::SetNextWindowSize(ImVec2(450, 400), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowPos(ImVec2(420, kNavbarHeight + 520), ImGuiCond_FirstUseEver);

        if (!ImGui::Begin("FreeCam", &m_showFreeCamPanel)) {
            ImGui::End();
            return;
        }

        // Start/Stop button
        if (m_freeCamActive) {
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.55f, 0.15f, 0.15f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.70f, 0.20f, 0.20f, 1.0f));
            if (ImGui::Button("End Freecam", ImVec2(150, 28))) {
                m_freeCamActive = false;
                std::memset(m_freeCamKeys, 0, sizeof(m_freeCamKeys));
                std::memset(m_fovKeys, 0, sizeof(m_fovKeys));
                // Restore FOV
                try {
                    auto cam = IL2CPP::Module::Unity::Camera::GetMain();
                    if (cam) cam.SetFieldOfView(m_origFOV);
                } catch (...) {}
            }
            ImGui::PopStyleColor(2);
        } else {
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.15f, 0.45f, 0.15f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.20f, 0.55f, 0.20f, 1.0f));
            if (ImGui::Button("Begin Freecam", ImVec2(150, 28))) {
                m_freeCamActive = true;
                try {
                    auto cam = IL2CPP::Module::Unity::Camera::GetMain();
                    if (cam) {
                        m_origFOV = cam.GetFieldOfView();
                        m_freeCamFOV = m_origFOV;
                        m_nearClip = cam.GetNearClipPlane();
                        m_farClip = cam.GetFarClipPlane();
                        auto t = cam.GetTransform();
                        if (t) {
                            auto p = t.GetPosition();
                            m_camPos[0] = p.x; m_camPos[1] = p.y; m_camPos[2] = p.z;
                            auto e = t.GetRotation().ToEuler();
                            m_camEuler[0] = e.x; m_camEuler[1] = e.y; m_camEuler[2] = e.z;
                        }
                    }
                } catch (...) {}
            }
            ImGui::PopStyleColor(2);
        }

        ImGui::Separator();

        // Speed
        ImGui::Text("Move Speed:");
        ImGui::SameLine();
        ImGui::SetNextItemWidth(150);
        ImGui::SliderFloat("##Speed", &m_freeCamSpeed, 0.5f, 50.0f, "%.1f");
        ImGui::SameLine();
        if (ImGui::SmallButton("Reset##spd")) m_freeCamSpeed = 5.0f;

        // Sensitivity
        ImGui::Text("Look Sens: ");
        ImGui::SameLine();
        ImGui::SetNextItemWidth(150);
        ImGui::SliderFloat("##Sens", &m_freeCamSensitivity, 0.1f, 10.0f, "%.1f");

        ImGui::Separator();

        // FOV
        ImGui::Text("FOV:       ");
        ImGui::SameLine();
        ImGui::SetNextItemWidth(150);
        ImGui::SliderFloat("##FOV", &m_freeCamFOV, 1.0f, 170.0f, "%.1f");
        ImGui::SameLine();
        if (ImGui::SmallButton("Reset##fov")) m_freeCamFOV = m_origFOV;

        // Near clip
        ImGui::Text("Near Clip: ");
        ImGui::SameLine();
        ImGui::SetNextItemWidth(150);
        ImGui::SliderFloat("##NearClip", &m_nearClip, 0.001f, 100.0f, "%.3f", ImGuiSliderFlags_Logarithmic);

        // Far clip
        ImGui::Text("Far Clip:  ");
        ImGui::SameLine();
        ImGui::SetNextItemWidth(150);
        ImGui::SliderFloat("##FarClip", &m_farClip, 100.0f, 5000.0f, "%.0f");

        ImGui::Separator();

        // Position/rotation display
        if (m_freeCamActive) {
            ImGui::Text("Position: (%.2f, %.2f, %.2f)", m_camPos[0], m_camPos[1], m_camPos[2]);
            ImGui::Text("Rotation: (%.1f, %.1f, %.1f)", m_camEuler[0], m_camEuler[1], m_camEuler[2]);
            ImGui::Separator();
        }

        // Controls help
        ImGui::TextWrapped(
            "Controls:\n"
            "  WASD - Move  |  Q/E - Up/Down\n"
            "  Right-click + drag - Look\n"
            "  Shift - Speed up  |  Ctrl - Slow down\n"
            "  Numpad +/- - FOV  |  Numpad * - Reset FOV\n"
            "  Numpad 1/3 - Tilt  |  Numpad 2 - Reset tilt"
        );

        ImGui::End();
    }

    // =========================================================================
    //  Lights Panel (Render thread)
    // =========================================================================

    void UnityExplorerModule::RenderLightsPanel() {
        ImGui::SetNextWindowSize(ImVec2(500, 400), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowPos(ImVec2(880, kNavbarHeight + 10), ImGuiCond_FirstUseEver);

        if (!ImGui::Begin("Lights Manager", &m_showLightsPanel)) {
            ImGui::End();
            return;
        }

        if (ImGui::Button("Refresh Lights")) {
            m_needsLightRefresh = true;
        }
        ImGui::SameLine();
        ImGui::Text("%zu lights in scene", m_sceneLights.size());

        ImGui::Separator();

        ImGui::BeginChild("LightsList", ImVec2(0, 0), false);

        const char* lightTypes[] = { "Spot", "Directional", "Point", "Area" };

        for (size_t i = 0; i < m_sceneLights.size(); ++i) {
            auto& light = m_sceneLights[i];
            ImGui::PushID(static_cast<int>(i));

            // Enabled toggle
            if (ImGui::Checkbox("##en", &light.enabled)) {
                try {
                    IL2CPP::Module::Unity::Behaviour beh(light.lightPtr);
                    beh.SetEnabled(light.enabled);
                } catch (...) {}
            }
            ImGui::SameLine();

            // Name + type
            const char* typeName = (light.type >= 0 && light.type < 4) ? lightTypes[light.type] : "?";
            bool open = ImGui::TreeNode("##light", "%s (%s)", light.name.c_str(), typeName);

            if (open) {
                // Intensity
                ImGui::Text("Intensity:");
                ImGui::SameLine();
                ImGui::SetNextItemWidth(150);
                if (ImGui::SliderFloat("##int", &light.intensity, 0.0f, 10.0f, "%.2f")) {
                    try {
                        static auto setIntensity = IL2CPP::Module::MethodHandler::resolve("UnityEngine.Light", "set_intensity", 1);
                        if (setIntensity) {
                            void* params[] = { &light.intensity };
                            IL2CPP::Module::MethodHandler::invoke<void>(setIntensity, light.lightPtr, params);
                        }
                    } catch (...) {}
                }

                // Range (for point/spot)
                if (light.type == 0 || light.type == 2) {
                    ImGui::Text("Range:    ");
                    ImGui::SameLine();
                    ImGui::SetNextItemWidth(150);
                    if (ImGui::SliderFloat("##range", &light.range, 0.1f, 100.0f, "%.1f")) {
                        try {
                            static auto setRange = IL2CPP::Module::MethodHandler::resolve("UnityEngine.Light", "set_range", 1);
                            if (setRange) {
                                void* params[] = { &light.range };
                                IL2CPP::Module::MethodHandler::invoke<void>(setRange, light.lightPtr, params);
                            }
                        } catch (...) {}
                    }
                }

                // Spot angle (for spot only)
                if (light.type == 0) {
                    ImGui::Text("Spot Angle:");
                    ImGui::SameLine();
                    ImGui::SetNextItemWidth(150);
                    if (ImGui::SliderFloat("##spot", &light.spotAngle, 1.0f, 179.0f, "%.1f")) {
                        try {
                            static auto setSpotAngle = IL2CPP::Module::MethodHandler::resolve("UnityEngine.Light", "set_spotAngle", 1);
                            if (setSpotAngle) {
                                void* params[] = { &light.spotAngle };
                                IL2CPP::Module::MethodHandler::invoke<void>(setSpotAngle, light.lightPtr, params);
                            }
                        } catch (...) {}
                    }
                }

                // Color
                if (ImGui::ColorEdit3("Color", light.color)) {
                    try {
                        static auto setColor = IL2CPP::Module::MethodHandler::resolve("UnityEngine.Light", "set_color", 1);
                        if (setColor) {
                            IL2CPP::Color c{ light.color[0], light.color[1], light.color[2], 1.0f };
                            void* params[] = { &c };
                            IL2CPP::Module::MethodHandler::invoke<void>(setColor, light.lightPtr, params);
                        }
                    } catch (...) {}
                }

                // Inspect button
                if (light.goPtr) {
                    if (ImGui::SmallButton("Inspect GameObject")) {
                        m_pendingSelectGO = light.goPtr;
                        m_showInspectorPanel = true;
                        m_switchToInspector = true;
                        PushHistory(InspectorMode::GameObject, light.goPtr);
                    }
                }

                ImGui::TreePop();
            }

            ImGui::PopID();
        }

        ImGui::EndChild();
        ImGui::End();
    }

    // =========================================================================
    //  Bookmarks/Pins Panel (Render thread)
    // =========================================================================

    void UnityExplorerModule::RenderBookmarksPanel() {
        ImGui::SetNextWindowSize(ImVec2(400, 300), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowPos(ImVec2(420, kNavbarHeight + 520), ImGuiCond_FirstUseEver);

        if (!ImGui::Begin("Pinned Objects", &m_showBookmarksPanel)) {
            ImGui::End();
            return;
        }

        if (m_bookmarks.empty()) {
            ImGui::TextDisabled("No pinned objects. Use the Pin button in the Inspector to pin objects.");
        } else {
            ImGui::Text("%d pinned object(s)", (int)m_bookmarks.size());
            ImGui::Separator();

            int removeIdx = -1;
            for (size_t i = 0; i < m_bookmarks.size(); ++i) {
                auto& bm = m_bookmarks[i];
                ImGui::PushID((int)i);

                auto& theme = kThemes[m_themeIndex];
                ImGui::TextColored(theme.navbarAccent, "%s", bm.name.c_str());
                ImGui::SameLine();
                if (ImGui::SmallButton("Inspect")) {
                    m_pendingSelectGO = bm.gameObject;
                    m_showInspectorPanel = true;
                    m_switchToInspector = true;
                    PushHistory(InspectorMode::GameObject, bm.gameObject);
                }
                ImGui::SameLine();
                ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.5f, 0.15f, 0.15f, 1.0f));
                if (ImGui::SmallButton("Remove")) {
                    removeIdx = (int)i;
                }
                ImGui::PopStyleColor();

                if (!bm.path.empty()) {
                    ImGui::TextColored(ImVec4(0.45f, 0.45f, 0.45f, 1.0f), "  %s", bm.path.c_str());
                }

                ImGui::PopID();
                ImGui::Separator();
            }
            if (removeIdx >= 0) {
                m_bookmarks.erase(m_bookmarks.begin() + removeIdx);
            }
        }

        ImGui::End();
    }

    // =========================================================================
    //  Misc Panel (Render thread)
    // =========================================================================

    void UnityExplorerModule::RenderMiscPanel() {
        ImGui::SetNextWindowSize(ImVec2(350, 350), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowPos(ImVec2(880, kNavbarHeight + 420), ImGuiCond_FirstUseEver);

        if (!ImGui::Begin("Misc & Tools", &m_showMiscPanel)) {
            ImGui::End();
            return;
        }

        // TimeScale controls (moved from navbar)
        ImGui::SeparatorText("Time Scale");
        if (m_gamePaused) {
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.20f, 0.50f, 0.20f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.25f, 0.60f, 0.25f, 1.0f));
            if (ImGui::Button("Resume", ImVec2(80, 0))) m_gamePaused = false;
            ImGui::PopStyleColor(2);
        } else {
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.50f, 0.20f, 0.20f, 1.0f));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.60f, 0.25f, 0.25f, 1.0f));
            if (ImGui::Button("Pause", ImVec2(80, 0))) m_gamePaused = true;
            ImGui::PopStyleColor(2);
        }
        ImGui::SameLine();
        ImGui::SetNextItemWidth(150);
        ImGui::SliderFloat("##TimeScale", &m_timeScale, 0.0f, 5.0f, "%.2fx");
        ImGui::SameLine();
        if (ImGui::SmallButton("1x")) m_timeScale = 1.0f;

        ImGui::Separator();

        // HUD toggle
        ImGui::SeparatorText("Scene Tools");
        if (ImGui::Button(m_hudHidden ? "Show HUD" : "Hide HUD", ImVec2(120, 0))) {
            ToggleHUD();
        }
        ImGui::SameLine();

        // Force LOD
        if (ImGui::Checkbox("Force High LODs", &m_forceLOD)) {
            try {
                static auto setLodBias = IL2CPP::Module::MethodHandler::resolve(
                    "UnityEngine.QualitySettings", "set_lodBias", 1);
                if (setLodBias) {
                    float bias = m_forceLOD ? 1000.0f : 1.0f;
                    void* params[] = { &bias };
                    IL2CPP::Module::MethodHandler::invoke<void>(setLodBias, nullptr, params);
                }
            } catch (...) {}
        }

        ImGui::Separator();

        // Scene info
        ImGui::SeparatorText("Info");
        try {
            float fps = 1.0f / IL2CPP::Module::Unity::Time::GetUnscaledDeltaTime();
            ImGui::Text("FPS: %.1f", fps);
        } catch (...) {
            ImGui::Text("FPS: ---");
        }
        ImGui::Text("Screen: %d x %d",
            IL2CPP::Module::Unity::Screen::GetWidth(),
            IL2CPP::Module::Unity::Screen::GetHeight());
        ImGui::Text("Scene objects: %d", m_nodeCount);
        ImGui::Text("Pinned: %d  |  History: %d", (int)m_bookmarks.size(), (int)m_history.size());

        ImGui::End();
    }

    // =========================================================================
    //  Mouse Inspect Results Panel
    // =========================================================================

    void UnityExplorerModule::RenderMouseResultsPanel() {
        ImGui::SetNextWindowSize(ImVec2(550, 400), ImGuiCond_FirstUseEver);
        if (!ImGui::Begin("Mouse Inspect Results##CUE_MouseResults", &m_showMouseResults,
            ImGuiWindowFlags_NoCollapse)) {
            ImGui::End();
            return;
        }

        ImGui::TextColored(ImVec4(0.6f, 0.6f, 0.6f, 1.0f),
            "%d object(s) found under click point", (int)m_mouseHitResults.size());
        ImGui::Separator();

        if (m_mouseHitResults.empty()) {
            ImGui::TextColored(ImVec4(1.0f, 0.5f, 0.5f, 1.0f), "No objects detected.");
            ImGui::End();
            return;
        }

        ImGui::BeginChild("##MouseResultsList", ImVec2(0, 0), true);
        for (size_t i = 0; i < m_mouseHitResults.size(); ++i) {
            auto& r = m_mouseHitResults[i];
            ImGui::PushID((int)i);

            // Cyan object name
            ImGui::TextColored(kThemes[m_themeIndex].navbarAccent, "%s", r.name.c_str());

            // Full path on the next line
            if (!r.path.empty()) {
                ImGui::TextColored(ImVec4(0.5f, 0.5f, 0.5f, 1.0f), "  Path: %s", r.path.c_str());
                // Click path to copy
                if (ImGui::IsItemClicked(ImGuiMouseButton_Left) || ImGui::IsItemClicked(ImGuiMouseButton_Right)) {
                    ImGui::SetClipboardText(r.path.c_str());
                }
                if (ImGui::IsItemHovered() && ImGui::BeginTooltip()) {
                    ImGui::Text("Click to copy path");
                    ImGui::EndTooltip();
                }
            }

            // Buttons row
            if (ImGui::SmallButton("Inspect")) {
                if (r.goPtr) {
                    m_pendingSelectGO = r.goPtr;
                    m_showInspectorPanel = true;
                    m_switchToInspector = true;
                    // Keep mouse results panel open
                }
            }
            ImGui::SameLine();
            if (ImGui::SmallButton("Copy Path")) {
                ImGui::SetClipboardText(r.path.c_str());
            }
            ImGui::SameLine();
            if (ImGui::SmallButton("Copy Name")) {
                ImGui::SetClipboardText(r.name.c_str());
            }

            ImGui::PopID();
            ImGui::Separator();
        }
        ImGui::EndChild();

        ImGui::End();
    }

    // =========================================================================
    //  OnOverlay — Main Render Entry Point
    // =========================================================================

    void UnityExplorerModule::OnOverlay() {
        int ti = m_themeIndex;
        if (ti < 0 || ti >= kThemeCount) ti = 0;

        PushThemeStyle(ti);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 6.0f);
        ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 4.0f);
        ImGui::PushStyleVar(ImGuiStyleVar_TabRounding, 4.0f);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(10, 8));
        ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(6, 3));
        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(8, 5));
        ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 1.0f);

        try {
            // 1. Navbar — always at top
            RenderNavbar();

            // 2. Panels — each is an independent window
            {
                std::lock_guard lock(m_mutex);

                if (m_showScenePanel)      RenderScenePanel();
                if (m_showInspectorPanel)  RenderInspectorPanel();
                if (m_showSearchPanel)     RenderSearchPanel();
                if (m_showBookmarksPanel)  RenderBookmarksPanel();
                if (m_showFreeCamPanel)    RenderFreeCamPanel();
                if (m_showLightsPanel)     RenderLightsPanel();
                if (m_showMiscPanel)       RenderMiscPanel();
                if (m_showMouseResults)    RenderMouseResultsPanel();
            }
        } catch (...) {
            ConLog("[UnityExplorer] OnOverlay panel exception\n");
        }

        // Always pop styles, even after exception
        ImGui::PopStyleVar(7);
        ImGui::PopStyleColor(kCUEStyleColorCount);

        try {
            // Mouse inspect crosshair overlay (on foreground, above everything)
            if (m_mouseInspectActive) {
                auto* drawList = ImGui::GetForegroundDrawList();
                auto& io = ImGui::GetIO();
                float mx = io.MousePos.x;
                float my = io.MousePos.y;
                float size = 22.0f;
                float gap = 5.0f;

                auto& accent = kThemes[ti].navbarAccent;
                ImU32 colInner = IM_COL32(
                    (int)(accent.x * 255), (int)(accent.y * 255), (int)(accent.z * 255), 255);
                ImU32 colOuter = IM_COL32(0, 0, 0, 200);
                ImU32 colGlow = IM_COL32(
                    (int)(accent.x * 255), (int)(accent.y * 255), (int)(accent.z * 255), 50);

                drawList->AddCircleFilled(ImVec2(mx, my), 28.0f, colGlow, 32);
                drawList->AddLine(ImVec2(mx - size, my), ImVec2(mx - gap, my), colOuter, 3.0f);
                drawList->AddLine(ImVec2(mx + gap, my), ImVec2(mx + size, my), colOuter, 3.0f);
                drawList->AddLine(ImVec2(mx, my - size), ImVec2(mx, my - gap), colOuter, 3.0f);
                drawList->AddLine(ImVec2(mx, my + gap), ImVec2(mx, my + size), colOuter, 3.0f);
                drawList->AddLine(ImVec2(mx - size, my), ImVec2(mx - gap, my), colInner, 1.8f);
                drawList->AddLine(ImVec2(mx + gap, my), ImVec2(mx + size, my), colInner, 1.8f);
                drawList->AddLine(ImVec2(mx, my - size), ImVec2(mx, my - gap), colInner, 1.8f);
                drawList->AddLine(ImVec2(mx, my + gap), ImVec2(mx, my + size), colInner, 1.8f);
                drawList->AddCircleFilled(ImVec2(mx, my), 2.5f, colInner);

                const char* label = m_mouseInspectMode == 0 ? "Inspect: World" : "Inspect: UI";
                ImVec2 textPos(mx + size + 8, my - 8);
                ImVec2 textSize = ImGui::CalcTextSize(label);
                drawList->AddRectFilled(
                    ImVec2(textPos.x - 4, textPos.y - 2),
                    ImVec2(textPos.x + textSize.x + 4, textPos.y + textSize.y + 2),
                    IM_COL32(0, 0, 0, 180), 3.0f);
                drawList->AddText(textPos, colInner, label);
            }

            ImGui::SetMouseCursor(ImGuiMouseCursor_None);
            DrawCustomCursor(ti);
        } catch (...) {
            ConLog("[UnityExplorer] OnOverlay cursor exception\n");
        }
    }

    // =========================================================================
    //  OnRender — Settings UI in nyx menu
    // =========================================================================

    void UnityExplorerModule::OnRender() {
        ImGui::TextWrapped("Press F7 to toggle the Unity Explorer window.");
        ImGui::TextWrapped("Use the navbar buttons to open panels.");
        ImGui::TextWrapped("Click objects to inspect their components, fields, and properties.");
    }

    // =========================================================================
    //  OnEvent — Win32 Input
    // =========================================================================

    bool UnityExplorerModule::OnEvent(uint32_t msg, uintptr_t wParam, intptr_t lParam) {
        // Mouse inspect: left click
        if (m_mouseInspectActive && msg == 0x0201) { // WM_LBUTTONDOWN
            m_mouseInspectX = static_cast<float>(LOWORD(static_cast<DWORD>(lParam)));
            m_mouseInspectY = static_cast<float>(HIWORD(static_cast<DWORD>(lParam)));
            m_mouseInspectPending = true;
            m_mouseInspectActive = false;
            return true;
        }

        if (!m_freeCamActive) return false;

        // WASD/QE movement
        bool isDown = (msg == 0x0100); // WM_KEYDOWN
        bool isUp   = (msg == 0x0101); // WM_KEYUP
        if (isDown || isUp) {
            bool state = isDown;
            switch (wParam) {
            case 'W': m_freeCamKeys[0] = state; return true;
            case 'A': m_freeCamKeys[1] = state; return true;
            case 'S': m_freeCamKeys[2] = state; return true;
            case 'D': m_freeCamKeys[3] = state; return true;
            case 'Q': m_freeCamKeys[4] = state; return true;
            case 'E': m_freeCamKeys[5] = state; return true;
            // Speed modifier flags
            case VK_SHIFT:   m_shiftHeld = state; return true;
            case VK_CONTROL: m_ctrlHeld  = state; return true;
            // FOV (numpad +/-)
            case VK_ADD:      m_fovKeys[0] = state; return true;
            case VK_SUBTRACT: m_fovKeys[1] = state; return true;
            case VK_MULTIPLY:
                if (state) m_freeCamFOV = m_origFOV;
                return true;
            // Tilt (numpad 1/3/2)
            case VK_NUMPAD1:
                if (state) m_camEuler[2] -= 5.0f;
                return true;
            case VK_NUMPAD3:
                if (state) m_camEuler[2] += 5.0f;
                return true;
            case VK_NUMPAD2:
                if (state) m_camEuler[2] = 0.0f;
                return true;
            }
        }

        // Right mouse button for look
        if (msg == 0x0204) { // WM_RBUTTONDOWN
            m_freeCamMouseHeld = true;
            m_lastMouseX = static_cast<float>(LOWORD(static_cast<DWORD>(lParam)));
            m_lastMouseY = static_cast<float>(HIWORD(static_cast<DWORD>(lParam)));
            return true;
        }
        if (msg == 0x0205) { // WM_RBUTTONUP
            m_freeCamMouseHeld = false;
            return true;
        }
        if (msg == 0x0200 && m_freeCamMouseHeld) { // WM_MOUSEMOVE
            float mx = static_cast<float>(LOWORD(static_cast<DWORD>(lParam)));
            float my = static_cast<float>(HIWORD(static_cast<DWORD>(lParam)));
            float dx = (mx - m_lastMouseX) * m_freeCamSensitivity * 0.1f;
            float dy = (my - m_lastMouseY) * m_freeCamSensitivity * 0.1f;
            m_camEuler[0] -= dy; // pitch
            m_camEuler[1] += dx; // yaw
            if (m_camEuler[0] > 89.f) m_camEuler[0] = 89.f;
            if (m_camEuler[0] < -89.f) m_camEuler[0] = -89.f;
            m_lastMouseX = mx;
            m_lastMouseY = my;
            return true;
        }

        return false;
    }

} // namespace UNIx
