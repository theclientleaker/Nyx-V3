# VoidUnix IL2CPP API Reference

Complete reference of all available VRChat/Unity functions from IL2CPP dumps, cross-referenced against our current SDK wrappers.

**Legend:** Wrapped = already in our codebase | Missing = available in dumps but not wrapped

---

## 1. VRChat Classes (Bootstrap.Module)

### 1.1 VRCPlayerApi (`VRC.SDKBase.VRCPlayerApi`)

**Wrapper:** `Bootstrap.Module/include/VRChat/VRCPlayerApi.hpp`
**IL2CPP Source:** `VRCSDKBase.dll` | Size: 0x38

**Fields (IL2CPP layout):**
| Offset | Type | Name |
|--------|------|------|
| 0x10 | bool | isLocal |
| 0x18 | String | displayName |
| 0x20 | int32 | mPlayerId |
| 0x28 | GameObject | gameObject |
| 0x30 | bool | _isValid |

**Methods - WRAPPED:**
| Method | Signature |
|--------|-----------|
| GetDisplayName | `string ()` |
| SetDisplayName | `void (string)` |
| GetPlayerId | `int ()` |
| IsLocal | `bool ()` |
| IsMaster | `bool ()` |
| IsInstanceOwner | `bool ()` |
| IsModerator | `bool ()` |
| IsSuper | `bool ()` |
| IsSuspended | `bool ()` |
| IsValid | `bool ()` |
| IsUserInVR | `bool ()` |
| IsPlayerGrounded | `bool ()` |
| GetTrackingData | `TrackingData (TrackingDataType)` |
| GetVelocity | `Vector3 ()` |
| GetPosition | `Vector3 ()` |
| GetRotation | `Quaternion ()` |
| GetBonePosition | `Vector3 (HumanBodyBones)` |
| GetBoneRotation | `Quaternion (HumanBodyBones)` |
| SetVelocity | `void (Vector3)` |
| TeleportTo | `void (Vector3, Quaternion)` (3 overloads) |
| Respawn | `void ()` / `void (int)` |
| Get/SetGravityStrength | `float` |
| Get/SetRunSpeed | `float` |
| Get/SetWalkSpeed | `float` |
| Get/SetStrafeSpeed | `float` |
| Get/SetJumpImpulse | `float` |
| UseLegacyLocomotion | `void ()` |
| UseAttachedStation | `void ()` |
| Immobilize | `void (bool)` |
| Get/SetVoiceGain | `float` |
| Get/SetVoiceDistanceNear | `float` |
| Get/SetVoiceDistanceFar | `float` |
| Get/SetVoiceVolumetricRadius | `float` |
| Get/SetVoiceLowpass | `bool` |
| SetAvatarAudio* | 6 methods (Gain, FarRadius, NearRadius, VolumetricRadius, ForceSpatial, CustomCurve) |
| Get/SetAvatarEyeHeight* | 5 methods |
| Get/SetManualAvatarScalingAllowed | `bool` |
| Set/RestoreNamePlateColor | `void (Color)` / `void ()` |
| Set/RestoreNamePlateVisibility | `void (bool)` / `void ()` |
| IsOwner | `bool (GameObject)` |
| TakeOwnership | `void (GameObject)` |
| EnablePickups | `void (bool)` |
| GetGameObject | `GameObject ()` |
| GetVRCPlayer | `VRCPlayer ()` |
| GetPlayerCount | `int ()` [static] |
| GetPlayerId | `int (VRCPlayerApi)` [static] |
| GetPlayerByGameObject | `VRCPlayerApi (GameObject)` [static] |
| GetPlayerById | `VRCPlayerApi (int)` [static] |
| GetLocalPlayer | `VRCPlayerApi ()` [static] |

**Methods - MISSING (available in dumps):**
| Method | Signature | RVA | Notes |
|--------|-----------|-----|-------|
| GetBoneTransform | `Transform (HumanBodyBones)` | 0x9a3b5b0 | Get actual bone Transform |
| GetPickupInHand | `VRC_Pickup (PickupHand)` | 0x9a3b720 | Check what player is holding |
| PlayHapticEventInHand | `void (PickupHand, float, float, float)` | 0x9a3b8a0 | VR haptic feedback |
| SetPlayerTag | `void (string, string)` | 0x9a3bf40 | SDK player tags |
| GetPlayerTag | `string (string)` | 0x9a3bfe0 | SDK player tags |
| GetPlayersWithTag | `List (string, string)` | 0x1014940 | SDK player tags |
| ClearPlayerTags | `void ()` | 0x9a3c070 | |
| SetInvisibleToTagged | `void (bool, string, string)` | 0x9a3c0f0 | Visibility control |
| SetInvisibleToUntagged | `void (bool, string, string)` | 0x9a3c1b0 | |
| SetSilencedToTagged | `void (int, string, string)` | 0x9a3c270 | Audio control |
| SetSilencedToUntagged | `void (int, string, string)` | 0x9a3c320 | |
| ClearInvisible | `void ()` | 0x9a3caa0 | |
| ClearSilence | `void ()` | 0x9a3cb20 | |
| PushAnimations | `void (RuntimeAnimatorController)` | 0x9a3daf0 | Override animations |
| PopAnimations | `void ()` | 0x9a3db80 | Restore animations |
| GetPlayerObjects | `GameObject[] ()` | 0x9a3da40 | Get player-owned objects |
| FindComponentInPlayerObjects | `Component (Component)` | 0x9a3dae0 | |
| GetDrone | `VRCDroneApi ()` | 0x9a3aeb0 | Drone API |
| GetPlayers | `VRCPlayerApi[] ()` [static] | 0x9a3af90 | Get all players |
| GetAvailableLanguages | `string[] ()` [static] | 0x9a3d960 | |
| GetCurrentLanguage | `string ()` [static] | 0x9a3d9d0 | |
| CombatSetup | `void ()` | 0x9a3ccc0 | Combat system |
| CombatSet/GetHitpoints | multiple | | Combat system |
| CombatSetRespawn | `void (bool, float, Transform)` | 0x9a3cee0 | |
| CombatSetDamageGraphic | `void (GameObject)` | 0x9a3cfa0 | |
| CombatGetDestructible | `IVRC_Destructible ()` | 0x9a3d030 | |

### 1.2 Networking (`VRC.SDKBase.Networking`)

**Wrapper:** `Bootstrap.Module/include/VRChat/Networking.hpp`
**IL2CPP Source:** `VRCSDKBase.dll`

**Methods - WRAPPED:**
| Method | Signature |
|--------|-----------|
| IsNetworkSettled | `bool ()` [static] |
| IsMaster | `bool ()` [static] |
| IsClogged | `bool ()` [static] |
| IsInstanceOwner | `bool ()` [static] |
| GetLocalPlayer | `VRCPlayerApi ()` [static] |
| GetMaster | `VRCPlayerApi ()` [static] |
| GetServerTimeInSeconds | `double ()` [static] |
| GetServerTimeInMilliseconds | `int ()` [static] |
| GoToRoom | `bool (string)` [static] |
| IsOwner | `bool (VRCPlayerApi, GameObject)` / `bool (GameObject)` [static] |
| GetOwner | `VRCPlayerApi (GameObject)` [static] |
| SetOwner | `void (VRCPlayerApi, GameObject)` [static] |

**Methods - MISSING:**
| Method | Signature | RVA | Notes |
|--------|-----------|-----|-------|
| GetInstanceOwner | `VRCPlayerApi ()` [static] | 0x9a456f0 | Get instance owner |
| IsObjectReady | `bool (GameObject)` [static] | 0x9a45970 | Check if networked object ready |
| Instantiate | `GameObject (VrcBroadcastType, string, Vector3, Quaternion)` [static] | 0x9a459e0 | Network instantiate |
| RPC | `void (Destination, GameObject, string, Object[])` [static] | 0x9a45aa0 | Remote procedure call |
| RPC (to player) | `void (VRCPlayerApi, GameObject, string, Object[])` [static] | 0x9a45b30 | RPC to specific player |
| EncodeParameters | `byte[] (Object[])` [static] | 0x9a45bd0 | |
| DecodeParameters | `Object[] (byte[])` [static] | 0x9a45c40 | |
| Destroy | `void (GameObject)` [static] | 0x9a45cb0 | Network destroy |
| GetUniqueName | `string (GameObject)` [static] | 0x9a45d20 | |
| GetNetworkDateTime | `DateTime ()` [static] | 0x9a45e00 | |
| CalculateServerDeltaTime | `double (double, double)` [static] | 0x9a46000 | |
| SimulationTime | `float (GameObject)` / `float (VRCPlayerApi)` [static] | 0x9a46160 | |
| GetSceneEventHandler | `VRC_EventHandler ()` [static] | 0x9a45450 | |

### 1.3 Player (`VRC.Player`)

**Wrapper:** `Bootstrap.Module/include/VRChat/Player.hpp`
**IL2CPP Source:** `Assembly-CSharp.dll` | Size: 160 bytes

**Fields (readable):**
| Offset | Type | Name |
|--------|------|------|
| 32 | APIUser | _APIUser |
| 48 | VRCPlayer | _vrcplayer |
| 56 | MonoBehaviour | _laserSelectRegion |
| 120 | USpeaker | _USpeaker |
| 136 | VRCPlayerApi | _VRCPlayerApi |

**Methods - WRAPPED:**
| Method | Notes |
|--------|-------|
| GetVRCPlayerApi | via _VRCPlayerApi field |
| GetVRCPlayer | via _vrcplayer field |
| GetAPIUser | via _APIUser field |
| GetUSpeaker | via _USpeaker field |
| GetLocalPlayer | static |

**Methods - MISSING:**
| Property | Type | Notes |
|----------|------|-------|
| prop_ApiAvatar_0 | ApiAvatar | Current avatar |
| prop_Player_0 | Player | Self reference for network |
| prop_VRCPlayerApi_0 | VRCPlayerApi | Alternative accessor |
| prop_Boolean_0..21 | bool | Various state flags (isMaster, isLocal, isFriend, etc.) |
| prop_Int32_0 | int | Player ID |
| prop_String_0 | string | Display name via property |

### 1.4 VRCPlayer

**Wrapper:** `Bootstrap.Module/include/VRChat/VRCPlayer.hpp`
**IL2CPP Source:** `Assembly-CSharp.dll` | Size: 728 bytes

**Fields (readable):**
| Offset | Type | Name |
|--------|------|------|
| 0 (static) | VRCPlayer | LocalPlayer |
| 88 | Player | _player |
| 96 | FlatBufferNetworkSerializer | _Serializer |
| 104 | MonoBehaviour | _poseRecorder |
| 112 | MonoBehaviour | _syncPhysics |
| 136 | GameObject | GameObject_NameplateContainer |
| 152 | PlayerNameplate | _PlayerNameplate |
| 344 | GameObject | GameObject_Avatar |
| 416 | VRCPlayerApi | _VRCPlayerApi |
| 472 | ApiAvatar | ApiAvatar |
| 480 | ApiAvatar | ApiAvatarFallback |
| 44 (static) | Color | Rank_AdministratorColor |
| 60 (static) | Color | Rank_Friend |
| 76 (static) | Color | Rank_VisitorColor |
| 92 (static) | Color | Rank_NewUserColor |
| 108 (static) | Color | Rank_UserColor |
| 124 (static) | Color | Rank_KnownUserColor |
| 140 (static) | Color | Rank_Trusted |
| 172 (static) | Color | Rank_NuisanceColor |

**Methods - WRAPPED:**
| Method | Notes |
|--------|-------|
| GetVRCPlayerApi | via _VRCPlayerApi field |
| GetPlayer | via _player field |
| GetNameplate | via _PlayerNameplate field |
| GetLocalPlayer | via LocalPlayer static field |

**Methods - MISSING (useful):**
| Property | Type | Notes |
|----------|------|-------|
| prop_Player_0 | Player | Player reference |
| prop_VRCPlayerApi_0 | VRCPlayerApi | API access |
| prop_ApiAvatar_0/1 | ApiAvatar | Current/Fallback avatar |
| prop_Boolean_0..22 | bool | ~23 state flags |
| prop_String_0..10 | string | ~11 string properties (names, IDs, etc.) |
| prop_Single_0..2 | float | Scale/speed values |
| prop_Vector3_0/1 | Vector3 | Position data |
| prop_Quaternion_0 | Quaternion | Rotation data |
| prop_PhotonHashtable_0 | PhotonHashtable | Network properties |
| prop_Int32_0/1 | int | Player IDs |
| PlayEmoteRPC | `void (int, Player)` | Trigger emote |
| ReloadAvatarNetworkedRPC | `void (Player)` | Force avatar reload |

### 1.5 APIUser (`VRC.Core.APIUser`)

**Wrapper:** `Bootstrap.Module/include/VRChat/APIUser.hpp`
**IL2CPP Source:** Not directly in dumps (VRC.Core.dll not dumped - class resolved via IL2CPP deobfuscation)

**Methods - WRAPPED (30 methods):**
- Identity: GetDisplayName, GetUsername, GetPronouns, GetBio, GetBioLinks, GetStatus, GetStatusDescription, GetTags, GetNote, GetUserLanguageCode
- Avatar: GetAvatarId, GetFallbackId, GetCurrentAvatarImageUrl, GetCurrentAvatarThumbnailImageUrl, GetCurrentAvatarTags, GetAllowAvatarCopying
- Images: GetUserIcon, GetProfilePicOverride, GetIconUrl, GetThumbnailUrl
- Social: GetIsFriend, GetLocation, GetBadges
- Platform: GetAgeVerified, GetIsAdult, GetIsOnMobile, GetLast_platform, GetPlatform, GetPlayerRank

**Likely available but NOT wrapped:** (would need VRC.Core.dll dump)
- GetId (inherited from ApiModel - already wrapped)
- GetTwoFactorAuthEnabled
- GetEmailVerified
- GetHasLoggedInFromClient
- GetHomeLocation
- GetFriendKey
- GetOnlineFriends
- GetOfflineFriends
- GetActiveFriends
- Various static methods (FetchUser, GetCurrentUser, etc.)

### 1.6 PlayerNameplate

**Wrapper:** `Bootstrap.Module/include/VRChat/PlayerNameplate.hpp`
**IL2CPP Source:** `Assembly-CSharp.dll` | Size: 1200 bytes

**All 22 readable fields are WRAPPED** as GameObject getters:
Contents, SubText, TextContainer, MainContainer, Icon, QuickStats, Platform, InteractionStatus, Pronouns, PlayerStatusIcons, UserMuted, UserVolume, ListenBlocked, EarmuffsIcon, FocusViewIcon, DevBanner, DevIcon, GroupInfo, AvatarProgress, FriendIcon

**Missing:**
| Field | Type | Offset | Notes |
|-------|------|--------|-------|
| NameplatePositioner | MonoBehaviour | 912 | Controls nameplate position |
| NameplateRectForChatBubble | RectTransform | 920 | Chat bubble anchor |
| prop_VRCPlayer_0 | VRCPlayer | | Get owning VRCPlayer |

### 1.7 UdonBehaviour

**Wrapper:** `Bootstrap.Module/include/VRChat/UdonBehaviour.hpp` - **Fully wrapped**

### 1.8 VRC_Interactable

**Wrapper:** `Bootstrap.Module/include/VRChat/VRC_Interactable.hpp` - **Fully wrapped**

### 1.9 RoomManager

**Wrapper:** None
**IL2CPP Source:** `Assembly-CSharp.dll` | Size: 104 bytes, 282 methods

**Key readable fields:**
| Offset | Type | Name |
|--------|------|------|
| 48 | ApiWorld | _apiWorld |
| 56 | ApiWorldInstance | _apiWorldInstance |

**Notable methods (all obfuscated names):**
- Start, Update, Awake, OnEnable, OnDisable, OnDestroy (lifecycle)
- 282 methods total but all have obfuscated names like `Method_Public_Void_String_0`
- Would need to resolve via field access patterns or deobfuscation layer

### 1.10 NetworkManager

**Wrapper:** None
**IL2CPP Source:** `Assembly-CSharp.dll` | Size: 280 bytes

**Named methods:**
| Method | Signature |
|--------|-----------|
| Awake | `void ()` |
| OnJoinedRoom | `void ()` |
| OnLeftRoom | `void ()` |
| OnMasterClientSwitched | `void (Player)` |
| OnConnectedToMaster | `void ()` |
| OnCreatedRoom | `void ()` |
| OnCustomAuthenticationFailed | `void (string)` |
| OnCustomAuthenticationResponse | `void (Dictionary)` |
| Update | `void ()` |
| OnEnable/OnDisable | `void ()` |

---

## 2. Unity Engine Classes (IL2CPP.Module)

### 2.1 Camera - **Comprehensive** (30+ methods)
Wrapped: GetMain, GetCurrent, WorldToScreenPoint, ScreenToWorldPoint, ScreenPointToRay, ViewportToWorldPoint, WorldToViewportPoint, Get/SetFieldOfView, Get/SetNearClipPlane, Get/SetFarClipPlane, Get/SetOrthographic, Get/SetOrthographicSize, Get/SetDepth, Get/SetCullingMask, GetPixelRect, Get/SetRect, Get/SetProjectionMatrix, ResetProjectionMatrix, GetWorldToCameraMatrix, GetViewProjectionMatrix, GetAllCamerasCount, IsWorldPointVisible

### 2.2 Transform - **Comprehensive** (40+ methods)
Wrapped: Get/SetPosition, Get/SetLocalPosition, Get/SetRotation, Get/SetLocalRotation, Get/SetLocalScale, GetLossyScale, Get/SetForward, Get/SetRight, Get/SetUp, Get/SetParent, GetRoot, GetChildCount, GetChild, GetHierarchyCount, IsChildOf, DetachChildren, Find, SetPositionAndRotation, SetLocalPositionAndRotation, TransformDirection, InverseTransformDirection, TransformPoint, RotateAround, RotateAroundLocal, LookAt, Rotate, Translate, GetWorldToLocalMatrix, GetLocalToWorldMatrix

### 2.3 GameObject - **Comprehensive** (40+ methods)
Wrapped: Find, FindWithTag, FindGameObjectsWithTag, CreatePrimitive, GetTransform, GetComponent (by Type/Class/Name), GetComponentInChildren, GetComponentInParent, AddComponent, GetComponents, GetComponentsInChildren, GetComponentsInParent, TryGetComponent, Get/SetActive, GetActiveSelf, GetActiveInHierarchy, Get/SetLayer, GetScene, Get/SetTag, CompareTag, SendMessage, SendMessageUpwards, BroadcastMessage

### 2.4 Rigidbody - **Comprehensive** (35+ methods)
Wrapped: Get/SetVelocity, Get/SetAngularVelocity, Get/SetMass, Get/SetDrag, Get/SetAngularDrag, SetDensity, Get/SetUseGravity, Get/SetIsKinematic, AddForce, AddTorque, AddForceAtPosition, AddExplosionForce, MovePosition, MoveRotation, Move, Sleep, WakeUp, IsSleeping, Get/SetFreezeRotation, Get/SetDetectCollisions, Get/SetPosition, Get/SetRotation, Get/SetCenterOfMass, Get/SetInterpolation, Get/SetCollisionDetectionMode, GetRelativePointVelocity, GetPointVelocity, ClosestPointOnBounds, Get/SetConstraints

### 2.5 Physics - **Good** (Raycast, SphereCast, LineOfSight)
Wrapped: Raycast (4 overloads), SphereCast (3 overloads), CreateRayToward, LineOfSight

**Missing:**
| Method | Notes |
|--------|-------|
| BoxCast | Box-shaped raycast |
| CapsuleCast | Capsule-shaped raycast |
| OverlapSphere | Find all colliders in sphere |
| OverlapBox | Find all colliders in box |
| RaycastAll | Returns all hits |
| SphereCastAll | Returns all sphere hits |
| CheckSphere | Bool sphere overlap check |
| CheckBox | Bool box overlap check |
| ClosestPoint | Closest point on collider |
| IgnoreCollision | Ignore collision between 2 colliders |
| Get/SetGravity | Global gravity vector |
| Simulate | Step physics |

### 2.6 Time - **Comprehensive** (20+ properties)
Wrapped: GetTime, GetTimeAsDouble, GetDeltaTime, GetFixedDeltaTime, GetUnscaledDeltaTime, GetUnscaledTime, GetFixedTime, Get/SetTimeScale, GetFrameCount, GetRealtimeSinceStartup, GetRealtimeSinceStartupAsDouble, GetSmoothDeltaTime, GetMaximumDeltaTime, GetTimeSinceLevelLoad, GetTimeSinceLevelLoadAsDouble, GetFixedTimeAsDouble, GetUnscaledTimeAsDouble, GetFixedUnscaledTime, GetFixedUnscaledTimeAsDouble, GetFixedUnscaledDeltaTime, GetRenderedFrameCount, GetCaptureDeltaTime, GetCaptureFramerate

### 2.7 Input - **Comprehensive** (20+ methods)
Wrapped: GetAxis, GetAxisRaw, GetKey, GetKeyDown, GetKeyUp, GetMouseButton, GetMouseButtonDown, GetMouseButtonUp, GetAnyKey, GetAnyKeyDown, GetMousePosition, GetMouseScrollDelta, GetMousePresent, GetButton, GetButtonDown, GetButtonUp, GetTouchCount, IsTouchSupported, GetAcceleration

### 2.8 Screen - **Good**
Wrapped: GetWidth, GetHeight, GetDpi, Get/SetFullScreen, Get/SetFullScreenMode, GetCurrentResolution, SetResolution

### 2.9 Animator - **Good** (20+ methods)
Wrapped: Get/SetSpeed, Get/SetPlaybackTime, Get/SetRuntimeAnimatorController, Get/SetAvatar, Get/SetApplyRootMotion, Get/SetUpdateMode, GetHasRootMotion, GetIsHuman, SetFloat/GetFloat, SetInteger/GetInteger, SetBool/GetBool, SetTrigger, ResetTrigger, Play, CrossFade, Rebind, Update, IsInTransition

### 2.10 AudioSource - **Good** (25+ methods)
Wrapped: Get/SetClip, Get/SetVolume, Get/SetPitch, Get/SetLoop, Get/SetMute, GetIsPlaying, Get/SetTime, Get/SetSpatialBlend, Get/SetMinDistance, Get/SetMaxDistance, Get/SetPlayOnAwake, Get/SetPriority, Get/SetSpatialize, Get/SetOutputAudioMixerGroup, Play, Pause, UnPause, Stop, PlayOneShot, PlayClipAtPoint

### 2.11 Other Unity Wrappers (all present)
| Class | Status | Key Methods |
|-------|--------|-------------|
| Object | Good | GetName, SetName, Instantiate, Destroy, DontDestroyOnLoad, FindObjectOfType |
| Component | Good | GetTransform, GetGameObject, GetComponent*, TryGetComponent |
| Behaviour | Good | Get/SetEnabled |
| MonoBehaviour | Good | Base class |
| Renderer | Good | Get/SetMaterial, Get/SetEnabled, GetBounds |
| MeshRenderer | Good | Inherits Renderer |
| SkinnedMeshRenderer | Good | Get/SetBones, GetBlendShapeWeight |
| Material | Good | Get/SetColor, Get/SetFloat, Get/SetTexture, Get/SetShader |
| Light | Good | Get/SetColor, Get/SetIntensity, Get/SetRange |
| Collider | Good | GetBounds, Get/SetEnabled, GetAttachedRigidbody |
| BoxCollider | Good | Get/SetCenter, Get/SetSize |
| SphereCollider | Good | Get/SetCenter, Get/SetRadius |
| MeshCollider | Good | Get/SetSharedMesh, Get/SetConvex |
| ParticleSystem | Good | Play, Stop, Pause, Clear, IsAlive, IsPlaying |
| Canvas | Good | Get/SetRenderMode, Get/SetSortingOrder |
| Image/RawImage | Good | Get/SetColor, Get/SetSprite |
| Button | Good | OnClick handling |
| Toggle | Good | Get/SetIsOn |
| Slider | Good | Get/SetValue, Get/SetMinValue, Get/SetMaxValue |
| InputField | Good | Get/SetText |
| TMP_Text | Good | Get/SetText, Get/SetColor, Get/SetFontSize |
| TMP_InputField | Good | Get/SetText |
| ScrollRect | Good | Get/SetContent, Get/SetNormalizedPosition |
| RectTransform | Good | Get/SetAnchoredPosition, Get/SetSizeDelta |
| Cursor | Good | Get/SetLockState, Get/SetVisible |
| Application | Good | Quit, GetDataPath, GetVersion |
| Resources | Good | Load, FindObjectsOfTypeAll |
| Texture2D | Good | GetWidth, GetHeight |
| Sprite | Good | Create |

### 2.12 System Collections (IL2CPP.Module/System/)
| Class | Status |
|-------|--------|
| String | Wrapped |
| List\<T\> | Wrapped (get_Count, get_Item, Add, Remove, Clear, Contains) |
| Dictionary\<K,V\> | Wrapped (get_Count, TryGetValue, Add, Remove, ContainsKey) |
| Array | Wrapped (get_Length, GetValue) |
| HashSet\<T\> | Wrapped (get_Count, Add, Remove, Contains, Clear) |

---

## 3. Assembly Dump Coverage

### Available dumps:
| Assembly | File | Classes | Key Content |
|----------|------|---------|-------------|
| Assembly-CSharp.dll | 16.8MB JSON | 4,448 | Player, VRCPlayer, RoomManager, NetworkManager, PlayerNameplate, PhotonView |
| VRCSDKBase.dll | .h only | ~100 | VRCPlayerApi, Networking, VRCStation, UdonBehaviour |
| VRC.Core.Networking.dll | 1.1MB JSON | 592 | FlatBuffer serialization, network codecs |
| VRC.Core.Data.dll | 90KB JSON | 37 | All obfuscated |
| UnityEngine.CoreModule.dll | 1.5MB JSON | | Standard Unity types |
| VRC.UI.Core.dll | 384KB JSON | | UI framework |
| UnityEngine.UI.dll | 382KB JSON | | Unity UI |

### Missing assemblies (not dumped):
| Assembly | Contents Needed |
|----------|----------------|
| VRC.Core.dll | APIUser, ApiWorld, ApiWorldInstance, ApiAvatar (full class definitions) |
| VRC.SDKBase.dll | JSON format (we only have .h header) |
| VRC.SDK3.dll | SDK3 specific APIs |
| Photon assemblies | PhotonNetwork, PhotonView details |

---

## 4. Gap Analysis Summary

### High-Priority Missing Wrappers
These would enable new module features:

1. **VRCPlayerApi.GetPlayers()** - Get all players array (useful for ESP, player iteration)
2. **VRCPlayerApi.GetBoneTransform()** - Get bone Transform directly (better than position-only)
3. **VRCPlayerApi.GetPickupInHand()** - Detect held objects
4. **VRCPlayerApi.PushAnimations/PopAnimations** - Animation override
5. **VRCPlayerApi.GetPlayerObjects()** - Get player-owned objects
6. **Networking.Instantiate/Destroy** - Network object management
7. **Networking.RPC** - Remote procedure calls
8. **Networking.GetInstanceOwner** - Get instance owner player
9. **Physics.OverlapSphere/BoxCast** - Spatial queries for ESP/detection
10. **RoomManager wrapper** - Access _apiWorld, _apiWorldInstance for world info

### Medium-Priority
11. **VRCPlayerApi player tag system** - SetPlayerTag, GetPlayerTag, ClearPlayerTags
12. **VRCPlayerApi visibility control** - SetInvisibleToTagged, ClearInvisible
13. **Networking.SimulationTime** - Network timing
14. **Networking.GetNetworkDateTime** - Server time
15. **Physics.RaycastAll** - Multiple hit detection

### Low-Priority
16. **VRCPlayerApi combat system** - CombatSetup, hitpoints, etc.
17. **VRCPlayerApi.GetDrone()** - Drone API
18. **VRCStation** - Station enter/exit
19. **VRCShader** - Global shader variables

### Well-Covered Areas (no gaps)
- Unity Transform, GameObject, Camera, Rigidbody, Physics (core)
- Unity Time, Input, Screen
- Unity UI (Canvas, Image, Button, Toggle, Slider, Text, etc.)
- Unity Renderer, Material, Light
- Unity Colliders
- Unity Audio
- Unity Animator
- VRChat APIUser (extensive)
- VRChat VRC_Interactable, UdonBehaviour
- VRChat PlayerNameplate
- .NET collections (List, Dictionary, Array, HashSet, String)

---

## 5. Obfuscation Notes

VRChat uses IL2CPP obfuscation on most internal classes. The dump shows:
- **Class names**: Obfuscated with pattern like `MonoBehaviourPublicAbstractBoMoSiVRObBoBoMoUnique`
- **Method names**: Obfuscated with pattern like `Method_Public_Void_String_0`
- **Field names**: Mix of readable (prefixed with `_` or named) and obfuscated (`field_Boolean_0`)
- **Properties**: Mostly obfuscated (`prop_Boolean_0`)

The SDK wrappers handle this via the `Deobfuscation` layer in `IL2CPP.Module/include/Deobfuscation.hpp` which maps obfuscated names to readable ones at runtime.

Readable field names in the dumps (like `_APIUser`, `_vrcplayer`, `_VRCPlayerApi`) are the most reliable way to access VRChat internals - they survived obfuscation because they're used by serialization or reflection.

### Known Obfuscated Name Mappings

| Real Name | Obfuscated Name |
|-----------|-----------------|
| VRCPlayer | `MonoBehaviourPublicMoObObObBoObGaObMoStTeBoSiSiHaMoMoMoGaGaObObBoSi120h1FCCUnique` |
| VRCPlayer (parent) | `MonoBehaviourPublicAbstractBoMoSiVRObBoBoMoUnique` |
| RoomManager | `MonoBehaviourPublicObBoStInInInInInInHaDiUISiInStStApApDiDiHaHaHaHa106hD61FUnique` |
| USpeaker | `MonoBehaviourPublicBoSiSiSiBoLiInStAcLiEnEnEnEnEnBoEnBoBoSiObInSiAc141hB216Unique` |
| FlatBufferNetworkSerializer | `MonoBehaviourInternalObVeVeBoBoBoSyAcAcAcObByByBoBySiSiSiObSiSiNuNuBo61hC501Unique` |
| ONSPAudio | `MonoBehaviourPublicBoSiSiSiSiBoSiSiSiSiBoBoObAuAuAuONSiBoUnique` |

These mappings are handled by the `Deobfuscation` layer at runtime.
