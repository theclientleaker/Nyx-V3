#pragma once
#include <string>
#include <deque>
#include <functional>
#include <cstdint>
#include <mutex>

namespace UNIx {

struct AnimatedSprite;

class DashboardConsole {
public:
    enum class LogColor : uint8_t { Default, System, Enabled, Disabled };

    struct LogEntry {
        std::string text;
        LogColor color;
        std::string timestamp;
    };

    using LogCallback = std::function<void(const std::string& msg, LogColor color)>;

    static DashboardConsole& Get();

    void Init();
    void Update();
    void OnRender();
    void AddLog(const std::string& msg, LogColor color = LogColor::Default);
    size_t GetLineCount() const { std::lock_guard lock(m_mutex); return m_lines.size(); }
    bool IsStarted() const { return m_started; }
    const std::deque<LogEntry>& GetLines() const { return m_lines; }
    std::mutex& GetMutex() { return m_mutex; }

    void SetLogCallback(LogCallback cb) { m_logCallback = std::move(cb); }

    void SetBackground(size_t index);
    void SetBackgroundSprite(void* sprite);
    void SetAnimatedBackground(const AnimatedSprite* anim);
    size_t GetActiveBackgroundIndex() const { return m_activeBgIndex; }

private:
    DashboardConsole() = default;

    static constexpr size_t kMaxLines = 50;

    void InjectQMBackground();

    bool m_started = false;
    bool m_carouselRemoved = false;
    bool m_bgInjected = false;
    bool m_bgFailed = false;
    size_t m_activeBgIndex = 0;
    void* m_bgImageComp = nullptr;
    mutable std::mutex m_mutex;
    std::deque<LogEntry> m_lines;
    LogCallback m_logCallback;

    const AnimatedSprite* m_animBg = nullptr;
    float m_animTime = 0.f;
    size_t m_animFrame = 0;
};

} // namespace UNIx
