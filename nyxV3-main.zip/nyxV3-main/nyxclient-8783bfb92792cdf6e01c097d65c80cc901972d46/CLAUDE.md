# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Build

- **Visual Studio 2022** solution (`VoidUnix.slnx`), C++20, x64 only
- Build: `msbuild VoidUnix.slnx /p:Configuration=Debug /p:Platform=x64` (run from VS Developer Command Prompt)
- `msbuild` is NOT available in CLI environments — user must build locally with Visual Studio
- Output: `x64/Release/VoidUnix.dll` (or `x64/Debug/`)
- Win32 configs build as Application (not DLL) — always use x64
- Links: `d3d11.lib`, `dxgi.lib`, `winhttp.lib`; vcpkg static linking; AVX enabled
- No test framework — testing is done by injecting the DLL into the target process

## Project Dependencies

VoidUnix.dll links against: Bootstrap.Common, Bootstrap.Module, Hooking.Module, IL2CPP.Module, Logging.Module, plus d3d11.lib, dxgi.lib, winhttp.lib.

**NEVER edit SDK projects** (Bootstrap.*, Hooking.*, IL2CPP.*, Logging.*). Write wrappers in `VoidUnix/VoidUnix/` instead.

All vtables are versioned. `Connect()` fails on version mismatch.

### Core Module System

- **`BaseModule`** (`VoidUnix/include/Core/BaseModule.hpp`) — Abstract base class. Virtual hooks: player events (`OnPlayerJoin`, `OnPlayerLeave`), Unity ticks (`OnUpdate`, `OnLateUpdate`, `OnFixedUpdate`), scene events, ImGui settings UI (`OnRender`), screen-space overlay (`OnOverlay`), Win32 input (`OnEvent`), QM settings (`OnSetupQuickMenu`), enable/disable lifecycle. Thread-safe toggle via `ProcessPendingToggle`. Static helpers: `GetLocalPlayer()`, `GetLocalVRCPlayer()`, `GetLocalPlayerApi()`, `InRoom()`.
- **`ModuleManager`** (`VoidUnix/include/Core/ModuleManager.hpp`) — Singleton. Owns all modules, dispatches events. Template methods: `Register<T>()`, `FindModule<T>()`. Two-pass QM setup: Pass 1 adds toggles, Pass 2 calls `OnSetupQuickMenu` on a per-category Settings sub-page.
- **`Globals`** (`VoidUnix/include/Core/Globals.hpp`) — Global pointers to hModule, Logger, BootstrapModule, HookModule.
- **`PlayerCache`** (`VoidUnix/include/Core/PlayerCache/PlayerCache.hpp`) — Thread-safe player list. Access via `ModuleManager::Get().GetPlayerCache().GetPlayers()`.
- **`FileLog`** (`VoidUnix/include/Core/FileLog/FileLog.hpp`) — Singleton file logger. Supports a callback (`SetCallback`) that pipes log lines to other systems (e.g., ScreenConsoleModule's on-screen overlay). Callback receives `(timestamp, message)` strings.
- **Other core services** initialized in `dllmain.cpp`: `ApiClient`, `TagManager`, `HeartbeatManager`, `NameplateConfigManager`, `FileLog`, `Renderer`, `Theme`, `DashboardConsole`, `SpriteLoader`, `VRChatApi`.

### Threading Model

Two threads interact with modules — getting this wrong causes silent failures:

- **Unity thread** — `OnUpdate`, `OnLateUpdate`, `OnFixedUpdate`, player events, scene events. All IL2CPP calls (Camera, VRCPlayerApi, Transform, etc.) **must** happen here.
- **Render thread** — `OnOverlay` (called from `ModuleManager::Render` inside D3D11 present hook). Only ImGui draw calls are safe here.

**OnRender vs OnOverlay:** `OnRender()` runs in the ImGui frame (safe for `ImGui::Begin`/`End`/widgets — used for settings UI). `OnOverlay()` runs inside the D3D11 present hook — only `ImGui::GetBackgroundDrawList()` draw calls are safe here.

**Cross-thread data pattern:** Compute data in `OnUpdate`, protect with `std::mutex`, read in `OnOverlay`:
```cpp
// OnUpdate (Unity thread):
std::lock_guard lock(m_mutex);
m_cachedData = computedData;

// OnOverlay (Render thread):
std::lock_guard lock(m_mutex);
auto snapshot = m_cachedData;
// draw with ImGui::GetBackgroundDrawList()
```

### Entry Point

`VoidUnix/dllmain.cpp` — `Main()` runs on `DLL_PROCESS_ATTACH` and spawns `InitThread` on a separate thread. `Main()` connects services and assigns globals; `InitThread` does the rest (order matters — breaking this sequence causes silent failures):
1. `Main()`: Connects to Logger, Hooking, IL2CPP, Bootstrap services (in this order)
2. `Main()`: Assigns global pointers (`g_logger`, `g_mod`, `g_hook`)
3. `InitThread()`: Registers Unity event callbacks (Update, LateUpdate, FixedUpdate, scene load/unload)
4. Registers VRChat player event callbacks
5. Sets up rendering/input/WndProc hooks
6. Starts services (ApiClient, TagManager, HeartbeatManager, NameplateConfigManager)
7. Creates `ModuleManager` and registers all modules via `mgr.Register<T>()`
8. Wires FileLog callback to ScreenConsoleModule for on-screen log display
9. Starts DebugBridge and VRChatApi poller

### Module Lifecycle

Modules that modify game state should override `OnDisable()` to reset to defaults (e.g., restore vanilla movement speeds). Use an `m_wasActive` flag to avoid resetting when the module never applied changes.

Many modules start enabled by default (`m_enabled = true`): SafetyModule, LoadingMusic, BetterLoadingScreenModule, UIRemoverModule, CalendarQMModule, ZoomModule, NameplateTagModule, WingPlayerListModule, SettingsMenuModule, ScreenConsoleModule, SpotifyModule, and game-specific modules (Murder4, Among4, Prison, Fish, Event67, Blackout, HideAndShriek, RumbleDisaster, ZombieSurvival, SuperTowerDefense, GhostPolice). Some modules have code but are commented out in dllmain.cpp registration (NightShiftModule, SlashCoModule). Modules that are OFF by default are movement cheats, ESP, exploits like PortalSpam/ChatboxSpam, etc.

**Auto-patches (not standalone modules):** VRC+ Spoof and Force Clone are applied directly in `ModuleManager::DispatchUpdate()`. Anti-Block is a hook toggle inside SafetyModule.

### Rank Color Scheme

Used consistently across ESP, nameplates, and playerlist UI:

| Rank | Color | Hex |
|---|---|---|
| Visitor | Gray | `#CCCCCC` |
| Basic | Green | `#2BCF5C` |
| Known | Orange | `#FF7A42` |
| Trusted | Purple | `#C73DFF` |
| Veteran | Light Red | `#FF6666` |
| Administrator | Dark Red | `#8B0000` |
| Troll | Dark Gray | `#808080` |

Defined in: `ESPModule.cpp` (ImU32), `BoneESPModule.cpp` (ImU32), `CapsuleESPModule.cpp` (ImU32), `ModuleManager.cpp` (ImVec4), `NameplateTagModule.cpp` (hex string).

### Platform Color Scheme

| Platform | Tag | Color | Hex |
|---|---|---|---|
| Quest/iOS | `[Q]` | Gray | `#AAAAAA` |
| PC Desktop | `[PC]` | Blue | `#6BBAFF` |
| PC VR | `[VR]` | Purple | `#BB66FF` |
| Friend | `[F]` | Yellow | `#FFD000` |

## Conventions

- **Namespace:** All modules live in `namespace UNIx { }`.
- **Header guards:** `#pragma once` everywhere (not `#ifndef` guards).
- **Keybinds:** Use Windows VK_ constants (`VK_F1`–`VK_F12`, `'F'`, `'P'`, etc.) or `0` for no hotkey.
- **Category strings:** `"Movement"`, `"Visual"`, `"UI"`, `"Exploits"`, `"World Exploits"`, `"Safety"`, `"Utility"` (default `"General"`). These become QuickMenu sub-pages automatically.
- **Comments:** Do not add comments to code. Do not add, modify, or "clean up" comments unless explicitly asked. Never change code while editing comments.

## Adding a New Module

1. Create `VoidUnix/include/Modules/<Category>/MyModule.hpp` and `VoidUnix/src/Modules/<Category>/MyModule.cpp`
2. Inherit from `UNIx::BaseModule`, call base constructor with `(name, description, keybind, category)`
3. Override desired virtuals — use `OnUpdate` for game logic/IL2CPP calls, `OnOverlay` for screen drawing
4. Register in `dllmain.cpp`: `mgr.Register<UNIx::MyModule>();` — insert within the matching category group (modules are grouped by category), or add at the end to reduce merge conflicts
5. Add files to **both** `VoidUnix/VoidUnix.vcxproj` (`<ClCompile>` for .cpp, `<ClInclude>` for .hpp) **and** `VoidUnix/VoidUnix.vcxproj.filters` (with proper filter path like `Source Files\Modules\<Category>`)

The module automatically gets a QuickMenu toggle under its category sub-page (set via the `category` constructor param). Set `m_showInQuickMenu = false` in the constructor to hide a module from the QM.

### Adding QuickMenu Settings (Foldouts/Sliders)

Modules can add settings to the per-category "Settings" sub-page via `OnSetupQuickMenu`. The pattern:

1. Add to header: static instance pointer + static `__cdecl` callbacks + `OnSetupQuickMenu` override
2. Implement in cpp using the static callback pattern:

```cpp
// Header:
void OnSetupQuickMenu(uint32_t moduleId, uint32_t categoryPageId) override;
static MyModule* s_instance;
static void __cdecl QmMySliderCb(uint32_t id, float val);

// Source:
MyModule* MyModule::s_instance = nullptr;
void __cdecl MyModule::QmMySliderCb(uint32_t, float val) { if (s_instance) s_instance->m_value = val; }

void MyModule::OnSetupQuickMenu(uint32_t moduleId, uint32_t categoryPageId) {
    s_instance = this;
    auto& qmEx = QuickMenuEx::Get();
    uint32_t fold = qmEx.add_foldout(moduleId, categoryPageId, "My Settings", false, true);
    qmEx.add_slider(moduleId, fold, "Value", 0.0f, 10.0f, m_value,
        QmMySliderCb, "my_config_key", "%.1f");
}
```

**QuickMenuEx v8 API** (`VoidUnix/include/Core/QuickMenuEx.hpp`):
- `add_foldout(mid, page_id, title, default_expanded, show_background)` → foldout_id
- `add_slider(mid, foldout_id, label, min, max, default, callback, config_key, format)` — callback: `void(__cdecl*)(uint32_t, float)`
- `add_settings_toggle(mid, foldout_id, text, default, callback, config_key)` — callback: `void(__cdecl*)(uint32_t, bool)`
- `add_enum_selector(mid, foldout_id, label, options, count, default, callback, config_key)`
- `add_separator(mid, foldout_id)` — visual divider
- `set_subpage_nav_icon_vrc(mid, page_id, Bootstrap::Sprite)` — bundle sprite icon for sub-page nav buttons

Sliders with non-empty `config_key` auto-persist their value. Valid `Bootstrap::Sprite` values are in `Bootstrap.Common/include/bootstrap_shared.hpp`.

## Module Categories

Modules are organized under `VoidUnix/include/Modules/` and `VoidUnix/src/Modules/`:

- **Movement** — MovementModule, NoclipModule, CapsuleRotationModule, SpinbotModule, PlayerRotatorModule, RaycastTPModule
- **Visual** — ESPModule, BoneESPModule, CapsuleESPModule, ItemESPModule, ZoomModule, NameplateTagModule, CustomNameplateModule, BetterLoadingScreenModule, ThirdPersonModule
- **UI** — WingPlayerListModule, LoadingMusic, UIRemoverModule, CalendarQMModule, NotifierModule, SettingsMenuModule, ScreenConsoleModule, SpotifyModule, ToastModule
- **Exploits** — PortalSpamModule, ChatboxSpamModule, GhostModeModule, Event67Module, PickupsModule, ItemOrbitModule, ItemClapperModule, ItemLaggerModule, PickupDropperModule, AvatarHeightModule, ForceGrabModule (unregistered), AntiBlockModule (unregistered — Anti-Block is a hook toggle in SafetyModule)
- **World Exploits** — Murder4Module, Among4Module, PrisonModule, FishModule, BlackoutModule, HideAndShriekModule, NightShiftModule (commented out), RumbleDisasterModule, SlashCoModule (commented out), ZombieSurvivalModule, SuperTowerDefenseModule, GhostPoliceModule
- **Safety** — SafetyModule
- **Utility** — UnityExplorerModule, BundleDecryptModule, PerformanceModule

## Key References

- `docs/bootstrap-sdk.md` — Full Bootstrap.Module API reference (QuickMenu, ModuleConfig, MessageBus, callback signatures, VRChat data types)
- `Bootstrap.Common/include/bootstrap_shared.hpp` — Bootstrap vtable definition, `Bootstrap::Sprite` enum (~200+ bundle icons)
- `Hooking.Common/hook_shared.hpp` — Hook vtable and types (detour, prefix, suffix)
- `IL2CPP.Common/il2cpp_shared.hpp` — IL2CPP exports vtable
- `Logging.Common/include/logger_shared.hpp` — Logger vtable and types
- `IL2CPP.Module/include/Unity/Camera.hpp` — Camera API (WorldToScreenPoint, GetMain, etc.)
- `Bootstrap.Module/include/VRChat/VRCPlayerApi.hpp` — Player API (GetPosition, GetBonePosition, GetDisplayName, etc.). **Namespace is `IL2CPP::VRChat`**, not `Bootstrap::Module::VRChat`
- `Bootstrap.Module/include/VRChat/Enums.hpp` — HumanBodyBones, TrackingDataType, PlayerEvent enums
- `docs/IL2CPP-API-Reference.md` — IL2CPP module API reference
- `docs/sprite-loader.md` — SpriteLoader usage and API

## MCP Debug Bridge

TCP server on port 29150 (localhost) with 4-byte LE length prefix + JSON protocol. Python MCP server at `tools/mcp_bridge/server.py` (FastMCP, stdio transport). Config in `.mcp.json` at repo root.

Commands needing IL2CPP dispatch to Unity thread via `ProcessCommands()` in OnUpdate; `ping`/`read_log`/`send_log` run directly on network thread.

**Scene & GameObjects:** `list_gameobjects`, `inspect_gameobject`, `search_scene`, `set_gameobject_active`, `get_hierarchy`, `find_objects_of_type`, `inspect_component`, `find_by_tag`, `destroy_object`, `instantiate_object`, `set_component_enabled`, `set_layer`, `set_parent`

**Transform & Physics:** `set_transform`, `set_rigidbody`, `add_force`, `overlap_sphere`, `world_to_screen`, `screen_to_ray`, `raycast`

**Materials & Rendering:** `get_materials`, `set_material`, `set_shader`

**IL2CPP Reflection:** `find_class`, `inspect_class`, `call_method`, `read_field`, `set_field`

**Players:** `list_players`, `get_player_info`, `get_avatar_info`, `get_player_by_name`, `get_all_bones`, `teleport_to_player`, `player_action` (25+ sub-actions)

**Movement & Teleport:** `teleport`, `set_movement`

**Udon:** `list_udon_behaviours`, `get_udon_variables`, `send_udon_event`, `send_network_udon_event`, `set_udon_variable`

**Audio:** `get_audio_sources`, `audio_control`

**Camera & Screen:** `get_camera_info`, `set_camera`, `get_screen_info`

**Time & Input:** `get_time_info`, `set_time_scale`, `get_input`

**Modules & Config:** `list_modules`, `toggle_module`, `get_config`, `set_config`

**Utility:** `ping`, `read_log`, `send_log`, `batch`

## Explorer GUI

Tkinter app at `tools/explorer/explorer.py` with 7 tabs: Inspector, Modules, Players, Udon, World, Tools, Console. Uses `Bridge` class for TCP communication.

## Creating Unity UI Elements at Runtime

When creating UI elements (panels, text, etc.) in VRChat's QuickMenu hierarchy:

- **Never use `CreatePrimitive`** for UI — it creates 3D world objects without RectTransform
- **Never use `Class::new_object()` + `.ctor()`** for GameObjects — Unity GOs require native engine initialization
- **Clone existing UI elements** using `Object::InstantiateWithParent(parentTransform)` or `MethodHandler::resolve("UnityEngine.Object", "Instantiate", ...)` — this gives proper RectTransform and Canvas hierarchy
- The `DashboardConsole::InjectQMBackground()` is the canonical example of this pattern
- VRChat uses `ImageEx` (subclass of Image) and `StyleElement` — destroy these on cloned elements to avoid style system interference
- Use `MethodHandler::resolve("UnityEngine.UI.Graphic", "set_color", 1)` for setting colors on UI elements (works for both Image and ImageEx)
- `using namespace IL2CPP::Module` and `using namespace IL2CPP::Module::Unity` together causes ambiguity for `Image` — qualify as `Unity::Image`
- **VRChat TMP clones have `enableAutoSizing=true`** — this overrides `SetFontSize()`. Call `set_enableAutoSizing(false)` via MethodHandler before setting font size

### VRChat Main Menu (Big Menu) Architecture

The main menu lives under `Canvas_MainMenu(Clone)/Container/MMParent/HeaderOffset/`. Key behaviors:

- **MenuStateController (MSC)** on `Canvas_MainMenu(Clone)` manages page visibility. It sets `CanvasGroup.alpha=0` on ALL `HeaderOffset` children it doesn't recognize, every frame in `Update()`. Custom pages must **disable MSC** (`Behaviour.set_enabled=false`) before showing, and re-enable when hiding.
- **PageButton** (`VRC.UI.Elements`) inherits `ButtonPublicTeImImMoStBoStBoObObUnique` which overrides BOTH `OnPointerClick` AND `OnSubmit` to call `MSC.ShowTabContent`. To make a custom tab: **destroy PageButton entirely** and add a plain `UnityEngine.UI.Button` — no MSC interaction on click.
- **Show/Hide pattern for custom pages:** Show: disable MSC → `SetActive(false)` on sibling pages → `SetActive(true)` on custom page → `EnableAllBehaviours` recursively → `CanvasGroup.alpha=1`. Hide: `CanvasGroup.alpha=0` → `SetActive(false)` on custom page → `SetActive(true)` on siblings → re-enable MSC.
- **VRChat's `_localizableString` at offset 0x7a8** on TMP subclass overwrites text every frame. Null this field AND disable `enableAutoSizing` before calling `SetText()`.
- **`ButtonPublicTeImImMoStBoStBoObObUnique`** is the clickable button base class used throughout VRC UI. When cloning these for custom buttons, destroy the VRC button component and add a plain `UnityEngine.UI.Button` to avoid MSC side effects.
- **SoundPlayer** (`UserInterface/MenuContent/SoundPlayer`) has the UI click AudioSource — use `PlayOneShot` on it for click sounds.
- `SettingsMenuModule` is the canonical example of custom main menu page creation.

### Scrollable UI Panels

For scrollable content (e.g. player lists), use the ScrollRect + RectMask2D + ContentSizeFitter pattern:
1. Clone a panel GO, add `ScrollRect` + `RectMask2D` (viewport = self)
2. Create a child TMP GO as content, add `ContentSizeFitter` with verticalFit=PreferredSize on the **same GO** as the TMP (not a parent)
3. Assign content to ScrollRect, set vertical=true, horizontal=false
4. See `WingPlayerListModule::InitializePanel()` for the canonical example

### Embedded PNG Resources

To embed images in the DLL:
1. Add PNG to `VoidUnix/resources/icons/`
2. Define ID in `VoidUnix/resource.h`: `#define IDR_MY_IMAGE 119`
3. Register in `VoidUnix/VoidUnix.rc`: `IDR_MY_IMAGE PNG "resources\\icons\\my_image.png"`
4. Load at runtime: `SpriteLoader::Get().LoadFromResource(IDR_MY_IMAGE, "cache_key")`

### Scene Transition Safety

When modules replace Unity assets (AudioClips, materials, etc.) on VRChat's GameObjects:

- **Save the original asset** before replacing it (e.g., `m_originalClip = source.GetClip()`)
- **Restore the original asset** when the loading screen dismisses or on scene load — VRChat's cleanup code calls `Resources.UnloadAsset()` which fails on runtime-created objects with "UnloadAsset can only be used on assets"
- **Never call IL2CPP methods** (IsValid, Destroy, etc.) on potentially garbage-collected objects during scene transitions — just null out pointers in cleanup
- **Don't gate panel re-initialization on `InRoom()`** — the loading screen appears before InRoom() returns true. Gate only player-data updates on InRoom()
- `WingPlayerListModule::Cleanup()` and `LoadingMusic::OnLateUpdate()` are canonical examples

## Branch Workflow

Never push directly to `master`. Use personal dev branches and open PRs. Register modules at the end of `dllmain.cpp` to reduce merge conflicts. `sync_branch.py` auto-merges master into a dev branch every 60s.
