#include <Modules/UI/LoadingScreen/LoadingPopup.hpp>
#include <Core/Globals.hpp>
#include <IL2CPP.Module/include/Unity/GameObject.hpp>
#include <IL2CPP.Module/include/Unity/Transform.hpp>
#include <IL2CPP.Module/include/Unity/Texture2D.hpp>
#include <IL2CPP.Module/include/Unity/Component.hpp>
#include <IL2CPP.Module/include/Reflection.hpp>
#include <IL2CPP.Module/include/MethodHandler.hpp>
#include <Core/FileLog/FileLog.hpp>
#include <ThirdParty/imgui/imgui.h>
#include <filesystem>
#include <fstream>
#include <cstring>

using namespace IL2CPP::Module;
using namespace IL2CPP::Module::Unity;

namespace UNIx {

    static void* LoadTextureFromFile(const std::string& path) {
        std::ifstream file(path, std::ios::binary | std::ios::ate);
        if (!file.is_open()) return nullptr;
        auto fileSize = file.tellg();
        if (fileSize <= 0) return nullptr;
        std::vector<uint8_t> bytes(static_cast<size_t>(fileSize));
        file.seekg(0);
        file.read(reinterpret_cast<char*>(bytes.data()), fileSize);
        file.close();

        auto* E = IL2CPP::Module::GetExports();
        if (!E || !E->m_arrayNew || !E->m_runtimeInvoke) return nullptr;

        auto byteClass = IL2CPP::Module::Class::find("System.Byte");
        if (!byteClass) return nullptr;

        void* managedArray = reinterpret_cast<void*(IL2CPP_CALLTYPE)(void*, uintptr_t)>(
            E->m_arrayNew)(byteClass.raw(), static_cast<uintptr_t>(bytes.size()));
        if (!managedArray) return nullptr;
        memcpy(static_cast<char*>(managedArray) + 0x20, bytes.data(), bytes.size());

        static auto getWhite = MethodHandler::resolve("UnityEngine.Texture2D", "get_whiteTexture", 0);
        if (!getWhite) return nullptr;
        void* whiteTex = MethodHandler::invoke<void*>(getWhite, nullptr);
        if (!whiteTex) return nullptr;

        static auto instantiate = MethodHandler::resolve("UnityEngine.Object", "Instantiate", 1);
        if (!instantiate) return nullptr;
        void* instParams[] = { whiteTex };
        void* texObj = MethodHandler::invoke<void*>(instantiate, nullptr, instParams);
        if (!texObj) return nullptr;

        static auto loadImage = MethodHandler::resolve("UnityEngine.ImageConversion", "LoadImage", 2);
        if (!loadImage) return nullptr;
        void* lp[] = { texObj, managedArray };
        MethodHandler::invoke<bool>(loadImage, nullptr, lp);

        return texObj;
    }

    // TrackingVolume/VRLoadingOverlay/FlatLoadingOverlay(Clone)/Container/Canvas/Background
    static GameObject FindBackground() {
        auto overlay = GameObject::Find("FlatLoadingOverlay(Clone)");
        if (!overlay) return GameObject{};
        auto t = overlay.GetTransform();
        if (!t) return GameObject{};
        auto container = t.Find("Container");
        if (!container) return GameObject{};
        auto canvas = container.Find("Canvas");
        if (!canvas) return GameObject{};
        auto bg = canvas.Find("Background");
        if (!bg) return GameObject{};
        return bg.GetGameObject();
    }

    void LoadingPopup::ScanFolder() {
        m_imageFiles.clear();
        const std::filesystem::path folder("C:/nyx/loadingscreen/");
        if (!std::filesystem::exists(folder)) {
            std::filesystem::create_directories(folder);
            return;
        }
        for (auto& entry : std::filesystem::directory_iterator(folder)) {
            if (!entry.is_regular_file()) continue;
            auto ext = entry.path().extension().string();
            for (auto& c : ext) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
            if (ext == ".png" || ext == ".jpg" || ext == ".jpeg" || ext == ".bmp")
                m_imageFiles.push_back(entry.path().string());
        }
    }

    void LoadingPopup::OnSceneLoad(int scene, int loadMode) {
        if (m_state != State::Idle) return;

        m_texture = nullptr;
        ScanFolder();
        if (m_imageFiles.empty()) {
            if (!m_warnedNoFiles) {
                FLOG("[LoadingPopup] no image files in C:/nyx/loadingscreen/");
                m_warnedNoFiles = true;
            }
            return;
        }

        m_currentSource = m_imageFiles[m_fileIndex % m_imageFiles.size()];
        m_fileIndex++;
        m_state = State::WaitForBackground;
        FLOG("[LoadingPopup] OnSceneLoad: waiting for Background, image={}", m_currentSource);
    }

    void LoadingPopup::OnUpdate() {
        if (m_state != State::WaitForBackground) return;

        auto bgObj = FindBackground();
        if (!bgObj) return;

        FLOG("[LoadingPopup] Found Background, cloning...");

        // Load texture from file
        m_texture = LoadTextureFromFile(m_currentSource);
        if (!m_texture) {
            FLOG("[LoadingPopup] FAIL: texture load returned null");
            m_state = State::Idle;
            return;
        }

        // Clone the Background GameObject (gets same UI.Image, RectTransform, etc.)
        static auto instantiate = MethodHandler::resolve("UnityEngine.Object", "Instantiate", 1);
        if (!instantiate) {
            FLOG("[LoadingPopup] FAIL: Object.Instantiate not resolved");
            m_state = State::Idle;
            return;
        }

        void* cloneParams[] = { bgObj.raw() };
        void* clonedRaw = MethodHandler::invoke<void*>(instantiate, nullptr, cloneParams);
        if (!clonedRaw) {
            FLOG("[LoadingPopup] FAIL: clone returned null");
            m_state = State::Idle;
            return;
        }

        GameObject clonedBG(clonedRaw);

        // Parent the clone under the same Canvas parent as Background
        auto bgTransform = bgObj.GetTransform();
        if (!bgTransform) { m_state = State::Idle; return; }
        auto parent = bgTransform.GetParent();
        if (!parent) { m_state = State::Idle; return; }

        auto cloneTransform = clonedBG.GetTransform();
        if (!cloneTransform) { m_state = State::Idle; return; }
        cloneTransform.SetParent(parent, false);

        // Copy the same local position/scale/rotation from original
        cloneTransform.SetLocalPosition(bgTransform.GetLocalPosition());
        cloneTransform.SetLocalRotation(bgTransform.GetLocalRotation());
        cloneTransform.SetLocalScale(bgTransform.GetLocalScale());

        FLOG("[LoadingPopup] Clone parented under Canvas");

        // Hide the original Background
        bgObj.SetActive(false);
        FLOG("[LoadingPopup] Original Background hidden");

        // Get the cloned UI.Image and set its material's mainTexture to our loaded texture
        auto imageClass = Class::find("UnityEngine.UI.Image");
        if (!imageClass) {
            FLOG("[LoadingPopup] FAIL: UI.Image class not found");
            m_state = State::Idle;
            return;
        }

        auto imageComp = clonedBG.GetComponent(imageClass);
        if (!imageComp) {
            FLOG("[LoadingPopup] FAIL: clone has no UI.Image");
            m_state = State::Idle;
            return;
        }

        // Get the sprite's texture from the cloned Image, then overwrite its pixels
        static auto getSprite = MethodHandler::resolve("UnityEngine.UI.Image", "get_sprite", 0);
        static auto getSpriteTexture = MethodHandler::resolve("UnityEngine.Sprite", "get_texture", 0);
        static auto loadImageMethod = MethodHandler::resolve("UnityEngine.ImageConversion", "LoadImage", 2);

        if (!getSprite || !getSpriteTexture || !loadImageMethod) {
            FLOG("[LoadingPopup] FAIL: could not resolve sprite/texture methods");
            m_state = State::Idle;
            return;
        }

        void* sprite = MethodHandler::invoke<void*>(getSprite, imageComp.raw());
        if (!sprite) {
            FLOG("[LoadingPopup] FAIL: clone Image has no sprite");
            m_state = State::Idle;
            return;
        }

        void* spriteTex = MethodHandler::invoke<void*>(getSpriteTexture, sprite);
        if (!spriteTex) {
            FLOG("[LoadingPopup] FAIL: sprite has no texture");
            m_state = State::Idle;
            return;
        }

        // Read file bytes into managed byte[]
        std::ifstream imgFile(m_currentSource, std::ios::binary | std::ios::ate);
        if (!imgFile.is_open()) { m_state = State::Idle; return; }
        auto imgSize = imgFile.tellg();
        std::vector<uint8_t> imgBytes(static_cast<size_t>(imgSize));
        imgFile.seekg(0);
        imgFile.read(reinterpret_cast<char*>(imgBytes.data()), imgSize);
        imgFile.close();

        auto* E = IL2CPP::Module::GetExports();
        auto byteClass = Class::find("System.Byte");
        if (!E || !E->m_arrayNew || !byteClass) { m_state = State::Idle; return; }

        void* managedArray = reinterpret_cast<void*(IL2CPP_CALLTYPE)(void*, uintptr_t)>(
            E->m_arrayNew)(byteClass.raw(), static_cast<uintptr_t>(imgBytes.size()));
        if (!managedArray) { m_state = State::Idle; return; }
        memcpy(static_cast<char*>(managedArray) + 0x20, imgBytes.data(), imgBytes.size());

        // Overwrite the sprite's texture pixels with our image
        void* loadParams[] = { spriteTex, managedArray };
        bool loaded = MethodHandler::invoke<bool>(loadImageMethod, nullptr, loadParams);

        if (loaded) {
            FLOG("[LoadingPopup] SUCCESS: overwrote sprite texture with custom image");
        } else {
            FLOG("[LoadingPopup] FAIL: LoadImage returned false");
        }

        clonedBG.SetActive(true);
        m_state = State::Applied;
    }

    void LoadingPopup::OnRender() {
        if (m_currentSource.empty())
            ImGui::TextDisabled("no image selected");
        else
            ImGui::Text("Image: %s", m_currentSource.c_str());
    }

} // namespace UNIx
