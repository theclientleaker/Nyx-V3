#include <Modules/UI/InstanceHistory/InstanceHistoryModule.hpp>

namespace UNIx {

    InstanceHistoryModule::InstanceHistoryModule()
        : BaseModule("Instance History", "Log visited instances", 0, "UI") {
        m_enabled = true;
        m_showInQuickMenu = true;
    }

    void InstanceHistoryModule::OnEnable() {}
    void InstanceHistoryModule::OnDisable() {}
    void InstanceHistoryModule::OnRender() {}

} // namespace UNIx
