# Bootstrap SDK Reference

Bootstrap.Module is the VRChat-specific SDK layer for UNIx mods. It provides access to player events, the QuickMenu, persistent config, inter-mod messaging, Unity console logging, Unity Explorer integration, and ImGui rendering — all over shared-memory IPC.

**Vtable version:** 6
**SDK version:** 1
**Namespace:** `Bootstrap::Module` (C++ API), `Bootstrap` (shared types/callbacks)
**Header:** `<Bootstrap.Module/include/bootstrap_module.hpp>`

---

## Table of Contents

1. [Overview](#overview)
2. [Getting Started](#getting-started)
3. [QuickMenu](#quickmenu)
4. [ModuleConfig](#moduleconfig)
5. [MessageBus](#messagebus)
6. [UnityConsole](#unityconsole)
7. [UnityExplorer](#unityexplorer)
8. [Rendering](#rendering)
9. [Callback Signatures](#callback-signatures)
10. [VRChat Data Types](#vrchat-data-types)

---

## Overview

Bootstrap.Module follows the UNIx shared-memory IPC pattern:

1. The **Bootstrap DLL** (host) writes a `BootstrapVtable` struct of C-function-pointer fields into a named shared-memory region: `Local\UNIx_PID_{pid}_Core`
2. **Bootstrap.Module** (your mod) maps that memory read-only and wraps the raw vtable behind a C++ API
3. All calls go through the vtable — no direct linking to the Bootstrap DLL

The vtable is versioned (`vtable_version = 6`). If the host vtable version doesn't match, `Connect()` fails. The SDK also sends its own `sdk_version` when registering a module so the host can reject incompatible clients.

### Connection Lifecycle

```
Connect() → BootstrapModule("MyMod") → use APIs → ~BootstrapModule() → Disconnect()
```

`Connect()` also triggers `IL2CPP::Module::Connect()` internally, so IL2CPP is available once Bootstrap connects.

### Safety Guards

Every API method checks `is_connected()` (or `valid()`) before touching the vtable. If the connection is down, methods return safe defaults (0, false, empty string, `invalid_id`). Callback registration additionally null-checks the function pointer.

---

## Getting Started

### Connect / Disconnect

```cpp
namespace Bootstrap::Module {
    [[nodiscard]] bool Connect();
    void Disconnect();
    [[nodiscard]] bool is_connected() noexcept;
}
```

| Function | Description |
|---|---|
| `Connect()` | Opens the shared-memory mapping for the current process, validates the vtable version, and connects IL2CPP. Returns `true` on success. Idempotent — calling it twice is safe. |
| `Disconnect()` | Unmaps shared memory and closes the handle. Idempotent. |
| `is_connected()` | Returns `true` if connected and the vtable pointer is valid. |

### BootstrapModule

Represents your mod's registration with the host. Creating one calls `register_module` on the vtable; destroying it calls `unregister_module`.

```cpp
class BootstrapModule {
public:
    BootstrapModule() = default;
    explicit BootstrapModule(std::string_view name);
    ~BootstrapModule();

    // move-only
    BootstrapModule(BootstrapModule&& other) noexcept;
    BootstrapModule& operator=(BootstrapModule&& other) noexcept;

    [[nodiscard]] bool valid() const noexcept;
    [[nodiscard]] uint32_t id() const noexcept;
    [[nodiscard]] std::string_view name() const noexcept;
};
```

- **`id()`** — The `module_id` assigned by the host. Almost every API call requires this. Returns `Bootstrap::invalid_id` (~0u) if registration failed.
- **`valid()`** — Returns `true` if `id() != invalid_id` and the connection is up.
- Move-only: cannot be copied, but can be moved.

### Minimal Example

```cpp
#include <Bootstrap.Module/include/bootstrap_module.hpp>

void Main() {
    if (!Bootstrap::Module::Connect()) return;

    Bootstrap::Module::BootstrapModule mod("MyMod");
    if (!mod.valid()) return;

    // Use mod.id() with all API calls
    Bootstrap::Module::ModuleConfig cfg(mod.id());
    cfg.set_bool("first_run", false);
    cfg.save();

    // ... cleanup happens automatically via destructors
    // Bootstrap::Module::Disconnect();
}
```

---

## QuickMenu

Add pages, buttons, and toggles to VRChat's QuickMenu. Access via `QuickMenu::Get()` (singleton).

```cpp
auto& qm = Bootstrap::Module::QuickMenu::Get();
```

### Readiness

The QuickMenu isn't available immediately — VRChat must finish initializing it first.

```cpp
bool valid() const noexcept;   // connection is up
bool is_ready();               // VRChat QuickMenu is initialized
```

### Pages

```cpp
uint32_t create_page(uint32_t module_id, std::string_view name,
                     std::string_view tooltip = "");

uint32_t create_sub_page(uint32_t module_id, uint32_t parent_page_id,
                         std::string_view name);

void remove_page(uint32_t module_id, uint32_t page_id);
```

All return a `page_id` (`invalid_id` on failure).

### Buttons

```cpp
uint32_t add_button(uint32_t module_id, uint32_t page_id,
                    std::string_view text,
                    Bootstrap::fn_menu_button_callback callback);

void remove_button(uint32_t module_id, uint32_t button_id);
void set_button_text(uint32_t module_id, uint32_t button_id,
                     std::string_view text);
```

### Toggles

```cpp
uint32_t add_toggle(uint32_t module_id, uint32_t page_id,
                    std::string_view text, bool default_state,
                    Bootstrap::fn_menu_toggle_callback callback,
                    std::string_view config_key = "");

void set_toggle_state(uint32_t module_id, uint32_t button_id, bool state);
bool get_toggle_state(uint32_t module_id, uint32_t button_id);
```

If `config_key` is non-empty, the toggle state is automatically persisted to `ModuleConfig` under that key.

### Icons & Colors

```cpp
// Set icon from a raw Unity Sprite pointer
void set_button_icon(uint32_t module_id, uint32_t button_id, void* sprite_ptr);
// Set icon from a VRChat built-in sprite ID
void set_button_icon(uint32_t module_id, uint32_t button_id, int32_t sprite_id);

void set_button_color(uint32_t module_id, uint32_t button_id,
                      float r, float g, float b, float a);
```

These work on both regular buttons and toggles (they share `button_id`).

### Page Customization

```cpp
void set_page_title(uint32_t module_id, uint32_t page_id,
                    std::string_view title);

void set_page_icon(uint32_t module_id, uint32_t page_id, void* sprite_ptr);
void set_page_icon(uint32_t module_id, uint32_t page_id, int32_t sprite_id);

// Show/hide a badge with optional text and background color
void set_page_badge(uint32_t module_id, uint32_t page_id, bool visible,
                    std::string_view text = "",
                    float r = 0, float g = 0, float b = 0, float a = 0);

// Badge with no custom color (uses default)
void set_page_badge(uint32_t module_id, uint32_t page_id, bool visible,
                    std::string_view text, std::nullptr_t no_color);
```

### Navigation

```cpp
void navigate_to(uint32_t page_id);
void navigate_back();
```

### Full Example

```cpp
void setup_menu(uint32_t mod_id) {
    auto& qm = Bootstrap::Module::QuickMenu::Get();
    if (!qm.is_ready()) return;

    uint32_t page = qm.create_page(mod_id, "My Mod", "Cool features");
    qm.set_page_badge(mod_id, page, true, "NEW", 0.2f, 0.8f, 0.2f, 1.0f);

    qm.add_button(mod_id, page, "Say Hello", [](uint32_t btn_id) {
        // button clicked
    });

    qm.add_toggle(mod_id, page, "Enable ESP", false,
        [](uint32_t btn_id, bool is_on) {
            // toggle changed
        },
        "esp_enabled"  // auto-persist to config
    );

    uint32_t sub = qm.create_sub_page(mod_id, page, "Advanced");
    qm.add_button(mod_id, sub, "Reset Settings", [](uint32_t btn_id) {
        // reset
    });
}
```

---

## ModuleConfig

Persistent key-value store scoped per module. Data survives process restarts. Construct with your `module_id`.

```cpp
Bootstrap::Module::ModuleConfig cfg(mod.id());
```

### Methods

```cpp
void     set_int(std::string_view key, int32_t value);
int32_t  get_int(std::string_view key, int32_t default_val = 0);

void     set_float(std::string_view key, float value);
float    get_float(std::string_view key, float default_val = 0.f);

void        set_string(std::string_view key, std::string_view value);
std::string get_string(std::string_view key, std::string_view default_val = "");

void set_bool(std::string_view key, bool value);
bool get_bool(std::string_view key, bool default_val = false);

bool has_key(std::string_view key);
void remove_key(std::string_view key);
void save();
```

- All getters return `default_val` if the key doesn't exist or the connection is down.
- `get_string` uses an internal 4096-byte buffer. Returns `default_val` if the stored length is 0.
- **Call `save()` to flush changes to disk.** Without it, values are only held in memory.

### Example

```cpp
Bootstrap::Module::ModuleConfig cfg(mod.id());

float speed = cfg.get_float("fly_speed", 5.0f);
speed += 1.0f;
cfg.set_float("fly_speed", speed);
cfg.save();
```

---

## MessageBus

Pub/sub messaging between mods. Access via `MessageBus::Get()` (singleton).

```cpp
auto& bus = Bootstrap::Module::MessageBus::Get();
```

### Methods

```cpp
uint32_t subscribe(uint32_t module_id, std::string_view topic,
                   Bootstrap::fn_message_callback cb);

void unsubscribe(uint32_t module_id, uint32_t subscription_id);

// Binary data
void publish(uint32_t module_id, std::string_view topic,
             const void* data, uint32_t data_len);

// String convenience overload
void publish(uint32_t module_id, std::string_view topic,
             std::string_view message);
```

- `subscribe` returns a `subscription_id` for later unsubscription.
- The string overload of `publish` forwards to the binary version using the string's data/size.

### Example

```cpp
auto& bus = Bootstrap::Module::MessageBus::Get();

uint32_t sub = bus.subscribe(mod.id(), "player/teleport",
    [](uint32_t sender_id, char const* topic, uint32_t topic_len,
       uint8_t const* data, uint32_t data_len) {
        // handle message
    });

// Send from another mod
bus.publish(mod.id(), "player/teleport", "lobby");

// Cleanup
bus.unsubscribe(mod.id(), sub);
```

---

## UnityConsole

Intercept Unity's `Debug.Log` output. Access via `UnityConsole::Get()` (singleton).

```cpp
auto& console = Bootstrap::Module::UnityConsole::Get();
```

### Options

```cpp
void set_enable_colors(bool enable);
void set_file_logging(bool enable, std::wstring_view path = L"");
void set_enable_trace(bool enable);
void set_enable_info_trace(bool enable);
void set_deobfuscate_names(bool enable);
```

Each convenience setter reads the current options, modifies the target field, and writes them back. For bulk changes, use the raw options API:

```cpp
void get_options(Bootstrap::UnityConsoleOptions* out);
void set_options(Bootstrap::UnityConsoleOptions const* opts);
```

#### UnityConsoleOptions

```cpp
struct UnityConsoleOptions {
    bool enable_colors;
    bool enable_file_logging;
    bool enable_trace;        // stack trace for error/warn/assert/exception
    bool enable_info_trace;   // stack trace for info logs (default off)
    bool deobfuscate_names;
    wchar_t log_file_path[260];
};
```

### Log Callbacks

```cpp
uint32_t register_callback(uint32_t module_id,
                            Bootstrap::fn_log_callback callback);
void unregister_callback(uint32_t module_id, uint32_t callback_id);
```

### UnityLogType

```cpp
enum class UnityLogType : int {
    Error = 0, Assert, Warning, Log, Exception
};
```

### Example

```cpp
void __cdecl on_log(char const* msg, uint32_t msg_len,
                    char const* stack, uint32_t stack_len,
                    Bootstrap::UnityLogType log_type) {
    if (log_type == Bootstrap::UnityLogType::Error) {
        std::string_view text(msg, msg_len);
        // handle error
    }
}

auto& console = Bootstrap::Module::UnityConsole::Get();
console.set_enable_colors(true);
console.set_deobfuscate_names(true);
uint32_t cb = console.register_callback(mod.id(), on_log);

// Cleanup
console.unregister_callback(mod.id(), cb);
```

---

## UnityExplorer

Inspect GameObjects and components at runtime. Access via `UnityExplorer::Get()` (singleton).

```cpp
auto& explorer = Bootstrap::Module::UnityExplorer::Get();
```

### Methods

```cpp
void show_game_object(void* gameObject);
void show_component(void* component);

uint32_t register_on_navigate(uint32_t module_id,
                               Bootstrap::fn_explorer_navigate_callback callback);
void unregister_on_navigate(uint32_t module_id, uint32_t callback_id);
```

- `show_game_object` / `show_component` — pass IL2CPP object pointers to display them in the explorer UI.
- `register_on_navigate` — get notified when the user navigates to a GameObject/component in the explorer.
- Null pointers are silently ignored.

### Example

```cpp
void __cdecl on_navigate(void* gameObject, void* component) {
    // user navigated to this object in the explorer
}

auto& explorer = Bootstrap::Module::UnityExplorer::Get();
uint32_t cb = explorer.register_on_navigate(mod.id(), on_navigate);

// Show a specific object
void* go = /* IL2CPP GameObject pointer */;
explorer.show_game_object(go);
```

---

## Rendering

Register ImGui render callbacks that execute each frame on the D3D11 present hook. Access via `Rendering::Get()` (singleton).

```cpp
auto& renderer = Bootstrap::Module::Rendering::Get();
```

### Methods

```cpp
uint32_t register_callback(uint32_t module_id,
                            Bootstrap::fn_render_callback callback);
void unregister_callback(uint32_t module_id, uint32_t callback_id);
void* get_imgui_context();
```

- `register_callback` — your `fn_render_callback` is called every frame inside the ImGui render pass.
- `get_imgui_context` — returns the host's `ImGuiContext*`. Set it with `ImGui::SetCurrentContext()` if your DLL has its own ImGui static instance.

### Example

```cpp
void __cdecl my_render() {
    ImGui::Begin("My Window");
    ImGui::Text("Hello from my mod!");
    ImGui::End();
}

auto& renderer = Bootstrap::Module::Rendering::Get();
ImGui::SetCurrentContext(
    static_cast<ImGuiContext*>(renderer.get_imgui_context()));
uint32_t cb = renderer.register_callback(mod.id(), my_render);
```

---

## Callback Signatures

All callbacks use the `__cdecl` calling convention. Defined in `Bootstrap` namespace in `bootstrap_shared.hpp`.

### User-Facing Callbacks

| Typedef | Signature | Used By |
|---|---|---|
| `fn_log_callback` | `void(__cdecl*)(char const* msg, uint32_t msg_len, char const* stack, uint32_t stack_len, UnityLogType log_type)` | UnityConsole |
| `fn_render_callback` | `void(__cdecl*)()` | Rendering |
| `fn_explorer_navigate_callback` | `void(__cdecl*)(void* gameObject, void* component)` | UnityExplorer |
| `fn_message_callback` | `void(__cdecl*)(uint32_t sender_module_id, char const* topic, uint32_t topic_len, uint8_t const* data, uint32_t data_len)` | MessageBus |
| `fn_menu_button_callback` | `void(__cdecl*)(uint32_t button_id)` | QuickMenu buttons |
| `fn_menu_toggle_callback` | `void(__cdecl*)(uint32_t button_id, bool is_on)` | QuickMenu toggles |
| `fn_player_simple_callback` | `void(__cdecl*)(void* player)` | Player events |

### Internal Vtable Function Types

These are the raw C function pointer types that populate `BootstrapVtable`. Mod code doesn't call these directly — use the C++ wrapper classes instead.

| Category | Typedefs |
|---|---|
| Module lifecycle | `fn_register_module`, `fn_unregister_module` |
| Rendering | `fn_register_render_callback`, `fn_unregister_render_callback`, `fn_get_imgui_context` |
| Console | `fn_register_log_callback`, `fn_unregister_log_callback`, `fn_get_console_options`, `fn_set_console_options` |
| Explorer | `fn_show_gameobject_in_explorer`, `fn_show_component_in_explorer`, `fn_register_explorer_callback`, `fn_unregister_explorer_callback` |
| VRChat data | `fn_get_vrc_player_data`, `fn_get_player_data`, `fn_get_nameplate_data`, `fn_get_local_player`, `fn_get_local_player_api`, `fn_get_local_vrc_player` |
| Player events | `fn_register_player_event`, `fn_unregister_player_event`, `fn_invoke_player_event` |
| Config | `fn_config_set_int`, `fn_config_get_int`, `fn_config_set_float`, `fn_config_get_float`, `fn_config_set_string`, `fn_config_get_string`, `fn_config_set_bool`, `fn_config_get_bool`, `fn_config_save`, `fn_config_has_key`, `fn_config_remove_key` |
| Message bus | `fn_subscribe_message`, `fn_unsubscribe_message`, `fn_publish_message` |
| QuickMenu | `fn_qm_create_page`, `fn_qm_create_sub_page`, `fn_qm_remove_page`, `fn_qm_add_button`, `fn_qm_remove_button`, `fn_qm_set_button_text`, `fn_qm_navigate_to`, `fn_qm_navigate_back`, `fn_qm_is_ready`, `fn_qm_add_toggle`, `fn_qm_set_toggle_state`, `fn_qm_get_toggle_state`, `fn_qm_set_button_icon_ptr`, `fn_qm_set_button_icon_vrc`, `fn_qm_set_button_color`, `fn_qm_set_page_title`, `fn_qm_set_page_icon_ptr`, `fn_qm_set_page_icon_vrc`, `fn_qm_set_page_badge` |

### Calling Convention

All function pointers are explicitly `__cdecl`. This matches the default for MSVC x64 (where `__cdecl` is the only convention), but the annotation is present for clarity and forward compatibility.

---

## VRChat Data Types

Defined in `Bootstrap` namespace in `vrc_types.hpp`. These structs contain IL2CPP class pointers and field offsets used by the SDK's VRChat wrappers.

### PlayerEvent

```cpp
enum class PlayerEvent : uint8_t {
    Awake       = 0,
    Join        = 1,
    JoinComplete = 2,
    Leave       = 3,
    Unknown     = 255
};
```

### PlayerData

```cpp
struct PlayerData {
    void* Class;
    void* Singleton;
    int VRCPlayerApi;
    int VRCPlayer;
    int APIUser;
    int USpeaker;
};
```

### VRCPlayerData

```cpp
struct VRCPlayerData {
    void* Class;
    void* Singleton;
    int VRCPlayerApi;
    int Player;
    int PlayerNameplate;
    int PoseRecorder;
    int Serializer;
    int SyncPhysics;
    int ApiAvatar;
    int ApiAvatarFallback;

    void* Color_Administrator;
    void* Color_Friend;
    void* Color_Visitor;
    void* Color_NewUser;
    void* Color_User;
    void* Color_KnownUser;
    void* Color_Trusted;
    void* Color_Nuisance;

    int gameObject_nameplate;
    int gameObject_avatar;
};
```

### PlayerNameplateData

```cpp
struct PlayerNameplateData {
    void* Class;
    int gameObject_contents;
    int gameObject_subText;
    int gameObject_textContainer;
    int gameObject_mainContainer;
    int gameObject_icon;
    int gameObject_quickStats;
    int gameObject_platform;
    int gameObject_interactionStatus;
    int gameObject_pronouns;
    int gameObject_playerStatusIcons;
    int gameObject_userMuted;
    int gameObject_userVolume;
    int gameObject_listenBlocked;
    int gameObject_earmuffsIcon;
    int gameObject_focusViewIcon;
    int gameObject_devBanner;
    int gameObject_devIcon;
    int gameObject_groupInfo;
    int gameObject_avatarProgress;
    int gameObject_friendIcon;
};
```

### Other Data Structs

| Struct | Fields |
|---|---|
| `LoadBalancingClientData` | `Class`, `OnEvent`, `OpRaiseEvent` |
| `FlatBufferNetworkSerializerData` | `Class`, `RequireFastRate` |
| `PhotonViewData` | `Class`, `ViewId` |
| `VRCPlayerStepHeightData` | `Class`, `maxStepHeight`, `stepUpThreshold`, `offsetDistance`, `characterController`, `groundedLayers` |
| `VRCMotionStateData` | `Class`, `characterController` |
| `ONSPAudioData` | `Class`, `audioSource`, `onspLowPassFilter`, `onspAudioSource` |
| `RoomManagerData` | `Class`, `apiWorld`, `apiWorldInstance` |
| `VRCRectMask2DData` | `Class`, `mask`, `clippingEnabled` |
| `VRCDroneData` | `Class`, `vrcPickup`, `trailRenderer`, `worldCollider`, `pickupCollider`, `PlayerOwner` |

The `int` fields in these structs are IL2CPP field offsets resolved at runtime. The `void* Class` field is the IL2CPP `Il2CppClass*` pointer. Use the IL2CPP.Module API to read actual values from game objects using these offsets.

---

## Constants

```cpp
namespace Bootstrap {
    constexpr uint32_t invalid_id     = ~0u;       // 0xFFFFFFFF
    constexpr uint32_t vtable_version = 6;
    constexpr uint32_t sdk_version    = 1;
}
```

- `invalid_id` — sentinel returned by all registration functions on failure. Check against this before using any returned ID.
- `vtable_version` — must match between host and module for `Connect()` to succeed.
- `sdk_version` — sent to the host during `register_module` for compatibility checks.
