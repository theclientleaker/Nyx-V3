#define MINIMP3_IMPLEMENTATION
#define MINIMP3_FLOAT_OUTPUT
#include "minimp3/minimp3.h"
#include "minimp3/minimp3_ex.h"

#include "stb/stb_vorbis.c"
