#include <Core/ApiClient/ApiSecrets.hpp>

namespace UNIx {

    std::wstring ApiSecrets::Host()         { return L"api.lexie.lol"; }
    std::wstring ApiSecrets::ClientAuth()   { return L"Bearer d812a9d2b77ad435dc2677f3e9d118bd"; }
    std::wstring ApiSecrets::AdminAuth()    { return L"Bearer c2d5f4dad7f0cb5a364d604278e3d661e818c547daf5c1833183ad08ca89aa0c"; }
    std::string  ApiSecrets::ClientSecret() { return "d812a9d2b77ad435dc2677f3e9d118bd"; }

} // namespace UNIx
