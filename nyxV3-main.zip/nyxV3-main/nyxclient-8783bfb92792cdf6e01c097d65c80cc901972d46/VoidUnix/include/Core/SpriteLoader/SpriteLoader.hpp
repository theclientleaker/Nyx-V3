#pragma once
#include <string>
#include <cstddef>
#include <cstdint>
#include <vector>
#include <unordered_map>
#include <mutex>
#include <atomic>
#include <memory>
#include <thread>

namespace UNIx {

    struct AnimatedSprite {
        struct Frame {
            std::vector<uint8_t> pixels;
            float delay;
        };
        std::vector<Frame> frames;
        int width = 0;
        int height = 0;
        float totalDuration = 0.f;
        void* texture = nullptr;
        void* sprite = nullptr;
    };

    // Holds decoded GIF frame data before GPU resources are created (thread-safe transfer)
    struct PendingGifData {
        std::string path;
        AnimatedSprite anim;                   // frames filled, texture/sprite null
        std::atomic<bool> ready{ false };
        std::atomic<bool> failed{ false };
    };

    class SpriteLoader {
    public:
        static SpriteLoader& Get();
        ~SpriteLoader();

        SpriteLoader(const SpriteLoader&) = delete;
        SpriteLoader& operator=(const SpriteLoader&) = delete;

        void* LoadFromFile(const std::string& path);
        void* LoadFromMemory(const std::string& key, const unsigned char* data, size_t size);
        void* LoadFromResource(uint32_t resourceId, const std::string& key);
        void* GetCached(const std::string& key) const;

        const AnimatedSprite* LoadAnimatedGif(const std::string& path);
        const AnimatedSprite* GetAnimatedGif(const std::string& path) const;

        void LoadAnimatedGifAsync(const std::string& path);

        const AnimatedSprite* FinalizeAsyncGifs();

        bool IsAsyncLoading(const std::string& path) const;

        void Shutdown();

    private:
        struct AsyncGifTask {
            std::shared_ptr<PendingGifData> pending;
            std::thread thread;
        };

        SpriteLoader() = default;
        void* CreateSpriteFromBytes(const std::string& key, const uint8_t* data, size_t size);
        bool CreateGifGpuResources(AnimatedSprite& anim);
        void JoinFinishedThreads();

        std::unordered_map<std::string, void*> m_cache;
        std::unordered_map<std::string, AnimatedSprite> m_animCache;

        mutable std::mutex m_pendingMutex;
        std::vector<std::unique_ptr<AsyncGifTask>> m_asyncTasks;
        std::atomic<bool> m_shuttingDown{ false };
    };

} // namespace UNIx
