#pragma once

#include <Core/BaseModule.hpp>
#include <Core/TagManager/TagManager.hpp>

#include <IL2CPP.Module/include/Unity/GameObject.hpp>
#include <IL2CPP.Module/include/Unity/Object.hpp>

#include <vector>
#include <string>

namespace UNIx {

    struct NameplateState {
        int playerId = 0;
        std::string userId;
        std::vector<void*> tagObjects;
        void* infoBarObject = nullptr;
        void* trustIconObject = nullptr;
        void* contentsParent = nullptr;
        void* quickStatsTemplate = nullptr;
        void* bgImage = nullptr;
        bool initialized = false;
        float pendingTimer = 0.f;
        float animTime = 0.f;
        int retryCount = 0;
        std::string appliedIcon;
        int lastTagCount = 0;
        int lblIndex = 0;
        bool lblForward = true;
        float lblTimer = 0.f;
        int bounceIndex = 0;
        bool bounceForward = true;
        float bounceTimer = 0.f;
    };

    class NameplateTagModule : public BaseModule {
    public:
        NameplateTagModule();

        void OnPlayerJoinComplete(IL2CPP::VRChat::Player player) override;
        void OnPlayerLeave(IL2CPP::VRChat::Player player) override;
        void OnSceneLoad(int scene, int loadMode) override;
        void OnUpdate() override;
        void OnRender() override;

    private:
        void InitializeNameplate(NameplateState& state);
        void UpdateAnimations(float dt);
        void UpdateInfoBars();
        void UpdateIcons();
        void UpdateNameTextColors();
        void UpdateSpeakingGlows();
        void UpdateChatBubbleColors();
        void CleanupAll();
        void CleanupState(NameplateState& state);

        std::string BuildAnimatedText(const ParsedTag& tag, float time, int charOffset);
        std::string BuildAnimatedRichText(const std::string& text, uint16_t flags, float time);
        std::string ColorToRichText(const Color4& c);
        std::string ApplyRainbow(const std::string& text, float time);
        std::string ApplySmoothRainbow(const std::string& text, float time);
        std::string ApplyGlitch(const std::string& text, float time);

        std::vector<NameplateState> m_states;
        bool m_nameplateEsp = false;
        float m_globalTime = 0.f;
    };

} // namespace UNIx
