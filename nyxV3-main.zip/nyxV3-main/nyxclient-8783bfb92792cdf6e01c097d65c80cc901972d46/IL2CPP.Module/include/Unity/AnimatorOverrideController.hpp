#pragma once
#include "RuntimeAnimatorController.hpp"
#include "../MethodHandler.hpp"

namespace IL2CPP::Module::Unity {

    class AnimatorOverrideController : public RuntimeAnimatorController {
    public:
        using RuntimeAnimatorController::RuntimeAnimatorController;

        // ---- runtimeAnimatorController ----
        [[nodiscard]] RuntimeAnimatorController GetRuntimeAnimatorController() const {
            static auto m = MethodHandler::resolve("UnityEngine.AnimatorOverrideController", "get_runtimeAnimatorController", 0);
            return RuntimeAnimatorController{ MethodHandler::invoke<void*>(m, raw()) };
        }
        void SetRuntimeAnimatorController(RuntimeAnimatorController controller) {
            static auto m = MethodHandler::resolve("UnityEngine.AnimatorOverrideController", "set_runtimeAnimatorController", 1);
            void* r = controller.raw();
            void* params[] = { r };
            MethodHandler::invoke(m, raw(), params);
        }

        // ---- overridesCount ----
        [[nodiscard]] int GetOverridesCount() const {
            static auto m = MethodHandler::resolve("UnityEngine.AnimatorOverrideController", "get_overridesCount", 0);
            return MethodHandler::invoke<int>(m, raw());
        }

        // ---- indexer: get/set clip override by original clip ----
        [[nodiscard]] AnimationClip GetClipOverride(AnimationClip original) const {
            static auto m = MethodHandler::resolve("UnityEngine.AnimatorOverrideController", "get_Item", 1);
            void* r = original.raw();
            void* params[] = { r };
            return AnimationClip{ MethodHandler::invoke<void*>(m, raw(), params) };
        }
        void SetClipOverride(AnimationClip original, AnimationClip overrideClip) {
            static auto m = MethodHandler::resolve("UnityEngine.AnimatorOverrideController", "set_Item", 2);
            void* r1 = original.raw();
            void* r2 = overrideClip.raw();
            void* params[] = { r1, r2 };
            MethodHandler::invoke(m, raw(), params);
        }
    };

} // namespace IL2CPP::Module::Unity
