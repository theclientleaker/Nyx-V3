#pragma once

#include <string>
#include <string_view>
#include <array>
#include <unordered_map>
#include <optional>
#include <mutex>
#include <shared_mutex>
#include <thread>
#include <atomic>

namespace UNIx {

    struct NameplateConfig {
        bool enabled = true;
        std::array<float, 4> tagColor = {1.f, 1.f, 1.f, 1.f};
        std::array<float, 4> bgColor = {1.f, 1.f, 1.f, 1.f};
        std::array<float, 4> borderColor = {1.f, 1.f, 1.f, 1.f};
        float bgScrollX = 0.f;
        float bgScrollY = 0.f;
        bool autoHueShift = false;
        float hueShiftSpeed = 0.25f;
        float hue = 0.f;
        float saturation = 1.f;
        float luminance = 0.f;
        bool useTag = true;
        bool useBackground = true;
        bool borderHueShift = false;
        float borderScrollX = 0.f;
        float borderScrollY = 0.f;
    };

    class NameplateConfigManager {
    public:
        static NameplateConfigManager& Get();

        void Start();
        void Stop();

        std::optional<NameplateConfig> GetConfigForUser(const std::string& userId) const;
        void RequestRefresh();

    private:
        NameplateConfigManager() = default;
        ~NameplateConfigManager();

        void FetchLoop();
        void FetchConfigs();
        std::string FetchVersion();
        void ParseResponse(const std::string& body);
        static NameplateConfig ParseSingleConfig(std::string_view json);

        mutable std::shared_mutex m_mutex;
        std::unordered_map<std::string, NameplateConfig> m_configs;

        std::thread m_thread;
        std::atomic<bool> m_running{false};
        std::atomic<bool> m_refreshRequested{false};
        std::string m_lastVersion;
    };

} // namespace UNIx
