#pragma once

// VRC+ Spoof is now an auto-patch in ModuleManager, not a standalone module.
// This header is kept for vcxproj compatibility but is intentionally empty.
