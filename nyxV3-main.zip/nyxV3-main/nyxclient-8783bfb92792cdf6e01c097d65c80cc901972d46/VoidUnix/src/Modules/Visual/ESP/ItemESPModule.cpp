#include <Modules/Visual/ESP/ItemESPModule.hpp>
#include <Core/FileLog/FileLog.hpp>

#include <IL2CPP.Module/include/Unity/Camera.hpp>
#include <IL2CPP.Module/include/Unity/GameObject.hpp>
#include <IL2CPP.Module/include/Unity/Transform.hpp>
#include <IL2CPP.Module/include/Unity/Component.hpp>
#include <IL2CPP.Module/include/Unity/Object.hpp>
#include <IL2CPP.Module/include/Unity/Renderer.hpp>
#include <IL2CPP.Module/include/Unity/Material.hpp>
#include <IL2CPP.Module/include/Unity/Time.hpp>
#include <IL2CPP.Module/include/Reflection.hpp>
#include <IL2CPP.Module/include/MethodHandler.hpp>

#include <string>

namespace UNIx {

    using namespace IL2CPP::Module;
    using namespace IL2CPP::Module::Unity;

    static float s_hue = 0.f;

    static IL2CPP::Color HSVToRGB(float h) {
        float c = 1.f;
        float x = c * (1.f - std::fabs(std::fmod(h * 6.f, 2.f) - 1.f));
        float r, g, b;
        int hi = static_cast<int>(h * 6.f) % 6;
        switch (hi) {
            case 0: r = c; g = x; b = 0; break;
            case 1: r = x; g = c; b = 0; break;
            case 2: r = 0; g = c; b = x; break;
            case 3: r = 0; g = x; b = c; break;
            case 4: r = x; g = 0; b = c; break;
            default: r = c; g = 0; b = x; break;
        }
        return IL2CPP::Color(r, g, b, 1.f);
    }

    static bool SafeUpdateHighlightRaw(void* hlComp, void* meshFilter, void* renderer, IL2CPP::Color color) {
        if (!meshFilter || !hlComp) return false;

        Object mfChk(meshFilter);
        if (!mfChk.IsValid()) return false;

        Object hlChk(hlComp);
        if (!hlChk.IsValid()) return false;

        static auto addHL = MethodHandler::resolve("MonoBehaviourPublicAbstractDiDiShMaInCoUnique", "Method_Public_Void_MeshFilter_Color_0", -1);
        if (!addHL) return false;

        void* hlParams[] = { meshFilter, &color };
        MethodHandler::invoke_raw(addHL, hlComp, hlParams);

        if (renderer) {
            Object rnChk(renderer);
            if (!rnChk.IsValid()) return false;

            static auto getMat = MethodHandler::resolve("UnityEngine.Renderer", "get_material", 0);
            static auto setCol = MethodHandler::resolve("UnityEngine.Material", "set_color", 1);
            if (getMat && setCol) {
                void* matRaw = MethodHandler::invoke<void*>(getMat, renderer);
                if (matRaw) {
                    void* cp[] = { &color };
                    MethodHandler::invoke<void>(setCol, matRaw, cp);
                }
            }
        }
        return true;
    }

    static void SetNamedColor(void* matRaw, const char* name, IL2CPP::Color color) {
        static auto setColorNamed = MethodHandler::resolve("UnityEngine.Material", "SetColor", 2);
        if (!setColorNamed || !matRaw) return;
        void* str = IL2CPP::Module::StringNew(name);
        if (!str) return;
        void* params[] = { str, &color };
        MethodHandler::invoke(setColorNamed, matRaw, params);
    }

    void ItemESPModule::ResolveHighlight() {
        if (m_resolved) return;
        m_resolved = true;

        auto parentClass = Class::find("MonoBehaviourPublicAbstractDiDiShMaInCoUnique");
        if (!parentClass) return;

        bool foundFirst1Param = false;
        for (auto& m : parentClass.get_methods()) {
            if (!m || !m.is_public() || m.is_static()) continue;

            if (m.param_count() == 2) {
                auto p0 = m.get_param_type(0);
                auto p1 = m.get_param_type(1);
                if (!p0 || !p1) continue;
                std::string p0Name = p0.name() ? p0.name() : "";
                std::string p1Name = p1.name() ? p1.name() : "";
                if (p0Name == "MeshFilter" && p1Name == "Color")
                    m_addMethod = m;
            }

            if (m.param_count() == 1) {
                auto p0 = m.get_param_type(0);
                if (!p0) continue;
                std::string p0Name = p0.name() ? p0.name() : "";
                if (p0Name == "MeshFilter") {
                    if (!foundFirst1Param)
                        foundFirst1Param = true;
                    else
                        m_removeMethod = m;
                }
            }
        }

        auto cam = Camera::GetMain();
        if (!cam.IsValid()) return;
        auto camGo = cam.GetGameObject();
        if (!camGo.valid()) return;

        auto hlClass = Class::find("MonoBehaviourPublicSealedInInInSiInCoInInInInInMaUnique");
        if (!hlClass) return;

        auto comp = camGo.GetComponent(hlClass);
        if (comp.valid())
            m_highlightComponent = comp.raw();
    }

    static void SafeRemoveHighlightRaw(void* hlComp, void* meshFilter, void* renderer) {
        static auto removeHL = MethodHandler::resolve("MonoBehaviourPublicAbstractDiDiShMaInCoUnique", "Method_Public_Void_MeshFilter_1", -1);
        static auto setEn = MethodHandler::resolve("UnityEngine.Renderer", "set_enabled", 1);

        if (meshFilter && removeHL && hlComp) {
            Object mfChk(meshFilter);
            if (mfChk.IsValid()) {
                void* params[] = { meshFilter };
                MethodHandler::invoke_raw(removeHL, hlComp, params);
            }
        }
        if (renderer && setEn) {
            Object rnChk(renderer);
            if (rnChk.IsValid()) {
                bool off = false;
                void* p[] = { &off };
                MethodHandler::invoke<void>(setEn, renderer, p);
            }
        }
    }

    void ItemESPModule::ClearHighlights() {
        if (m_highlightComponent && m_removeMethod) {
            for (auto& item : m_tracked)
                SafeRemoveHighlightRaw(m_highlightComponent, item.meshFilter, item.renderer);
        }
        m_tracked.clear();
        m_trackedGOs.clear();
    }

    void ItemESPModule::ApplyHighlights() {
        if (!m_highlightComponent || !m_addMethod) return;

        auto meshFilterClass = Class::find("UnityEngine.MeshFilter");
        auto meshRendererClass = Class::find("UnityEngine.MeshRenderer");
        if (!meshFilterClass || !meshRendererClass) return;

        auto pickups = Object::FindObjectsOfType("VRC.SDKBase.VRC_Pickup");

        for (auto& obj : pickups) {
            if (!obj.IsValid()) continue;

            Component comp(obj.raw());
            auto go = comp.GetGameObject();
            if (!go.valid() || !go.GetActiveInHierarchy()) continue;

            if (m_trackedGOs.count(go.raw())) continue;

            auto meshFilters = go.GetComponentsInChildren(meshFilterClass, true);
            for (auto& mf : meshFilters) {
                if (!mf.valid()) continue;

                static auto getGO = MethodHandler::resolve("UnityEngine.Component", "get_gameObject", 0);
                if (!getGO) continue;
                void* mfGO = MethodHandler::invoke<void*>(getGO, mf.raw());
                if (!mfGO) continue;

                GameObject mfGoObj(mfGO);
                auto mr = mfGoObj.GetComponent(meshRendererClass);

                IL2CPP::Color color = HSVToRGB(s_hue);
                void* hlParams[] = { mf.raw(), &color };
                m_addMethod.invoke(m_highlightComponent, hlParams);

                if (mr.valid()) {
                    IL2CPP::Module::Unity::Renderer renderer(mr.raw());
                    renderer.SetEnabled(true);

                    Material mat(renderer.GetMaterial());
                    if (mat.valid()) {
                        mat.SetColor(color);
                        SetNamedColor(mat.raw(), "_RimColor", color);
                        SetNamedColor(mat.raw(), "_EmissionColor", color);
                    }
                }

                m_tracked.push_back({ mf.raw(), mr.valid() ? mr.raw() : nullptr });
            }

            m_trackedGOs.insert(go.raw());
        }
    }

    void ItemESPModule::OnEnable() {
        m_refreshTimer = 0.f;
    }

    void ItemESPModule::OnDisable() {
        ClearHighlights();
    }

    void ItemESPModule::OnSceneLoad(int, int) {
        m_tracked.clear();
        m_trackedGOs.clear();
        m_highlightComponent = nullptr;
        m_resolved = false;
    }

    void ItemESPModule::OnUpdate() {
        if (!InRoom()) {
            if (!m_tracked.empty()) {
                m_tracked.clear();
                m_trackedGOs.clear();
            }
            return;
        }

        if (!m_resolved) ResolveHighlight();
        if (!m_highlightComponent || !m_addMethod) return;

        float dt = Time::GetDeltaTime();
        s_hue += dt * 0.3f;
        if (s_hue >= 1.f) s_hue -= 1.f;

        IL2CPP::Color color = HSVToRGB(s_hue);
        for (size_t i = 0; i < m_tracked.size(); ++i) {
            auto mf = m_tracked[i].meshFilter;
            auto rn = m_tracked[i].renderer;
            if (!mf) continue;
            if (!SafeUpdateHighlightRaw(m_highlightComponent, mf, rn, color)) {
                m_tracked[i].meshFilter = nullptr;
                m_tracked[i].renderer = nullptr;
            }
        }

        m_refreshTimer -= dt;
        if (m_refreshTimer <= 0.f) {
            m_refreshTimer = 2.f;
            ApplyHighlights();
        }
    }

} // namespace UNIx
