#pragma once
#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#include <string>
#include <string_view>
#include <cstdint>
#include <atomic>

#include <Bootstrap.Module/include/VRChat/Player.hpp>
#include <Bootstrap.Module/include/VRChat/VRCPlayer.hpp>
#include <Bootstrap.Module/include/VRChat/VRCPlayerApi.hpp>

namespace UNIx {

    /// Abstract base class for all client modules.
    ///
    /// Provides a lifecycle interface driven by the ModuleManager:
    ///   - Player events (awake, join, leave)
    ///   - Unity tick events (update, late-update, fixed-update)
    ///   - Scene events (load, unload)
    ///   - ImGui rendering for per-module settings UI
    ///   - Raw Win32 input events
    ///   - Enable / disable toggle with optional hotkey
    ///
    /// Toggle safety: SetEnabled / Toggle may be called from any thread
    /// (WndProc, render, etc.). The actual OnEnable / OnDisable callbacks
    /// are deferred to the Unity main thread via ProcessPendingToggle(),
    /// which ModuleManager calls at the start of DispatchUpdate().
    class BaseModule {
    public:
        /// Construct a module with a display name, description, and optional
        /// virtual-key-code hotkey (e.g. VK_F1). Pass 0 for no hotkey.
        BaseModule(std::string_view name,
                   std::string_view description,
                   uint32_t keybind = 0,
                   std::string_view category = "General");

        virtual ~BaseModule();

        // ---- Static Local Player Helpers ----

        /// Get the local Player (MonoBehaviour wrapper). Returns null if not in a room.
        [[nodiscard]] static IL2CPP::VRChat::Player GetLocalPlayer();

        /// Get the local VRCPlayer (MonoBehaviour wrapper). Returns null if not in a room.
        [[nodiscard]] static IL2CPP::VRChat::VRCPlayer GetLocalVRCPlayer();

        /// Get the local VRCPlayerApi (SDK API). Returns null if not in a room.
        [[nodiscard]] static IL2CPP::VRChat::VRCPlayerApi GetLocalPlayerApi();

        /// Returns true if we have a valid local player (i.e. in a room).
        [[nodiscard]] static bool InRoom();

        // ---- Player Events (dispatched to ALL modules) ----

        /// Called when VRCPlayer.Awake fires for any player.
        virtual void OnAwake(IL2CPP::VRChat::Player player);

        /// Called when a player begins joining the instance.
        virtual void OnPlayerJoin(IL2CPP::VRChat::Player player);

        /// Called when a player has fully joined (avatar loaded, etc.).
        virtual void OnPlayerJoinComplete(IL2CPP::VRChat::Player player);

        /// Called when a player leaves the instance.
        virtual void OnPlayerLeave(IL2CPP::VRChat::Player player);

        // ---- Unity Tick Events (dispatched to ENABLED modules only) ----

        /// Called every Unity Update frame.
        virtual void OnUpdate();

        /// Called every Unity LateUpdate frame.
        virtual void OnLateUpdate();

        /// Called every Unity FixedUpdate frame.
        virtual void OnFixedUpdate();

        // ---- Scene Events (dispatched to ALL modules) ----

        /// Called when a scene finishes loading.
        /// @param scene   Scene build index.
        /// @param loadMode  0 = Single, 1 = Additive.
        virtual void OnSceneLoad(int scene, int loadMode);

        /// Called when a scene is unloaded.
        /// @param scene   Scene build index.
        /// @param loadMode  0 = Single, 1 = Additive.
        virtual void OnSceneUnload(int scene, int loadMode);

        // ---- Rendering ----

        /// Called inside an ImGui frame when this module's settings
        /// section is expanded in the menu. Draw sliders, checkboxes, etc.
        virtual void OnRender();

        /// Called every render frame for enabled modules.
        /// Use ImGui::GetBackgroundDrawList() to draw screen-space overlays.
        virtual void OnOverlay();

        // ---- Input ----

        /// Called for every Win32 window message.
        /// @return true to consume the message (prevent game from seeing it).
        virtual bool OnEvent(uint32_t msg, uintptr_t wParam, intptr_t lParam);

        // ---- Toggle ----

        /// Called during QuickMenu setup so modules can add custom sub-pages/buttons.
        virtual void OnSetupQuickMenu(uint32_t moduleId, uint32_t categoryPageId);

        /// Called when the module is enabled (always on the Unity main thread).
        virtual void OnEnable();

        /// Called when the module is disabled (always on the Unity main thread).
        virtual void OnDisable();

        /// Request toggle. Safe to call from any thread.
        void Toggle();

        /// Request enabled state change. Safe to call from any thread.
        /// The actual OnEnable/OnDisable fires on the next Unity Update.
        void SetEnabled(bool enabled);

        /// Process any pending enable/disable on the Unity thread.
        /// Called by ModuleManager at the start of DispatchUpdate().
        void ProcessPendingToggle();

        // ---- Accessors ----

        [[nodiscard]] std::string_view GetName()        const { return m_name; }
        [[nodiscard]] std::string_view GetDescription() const { return m_description; }
        [[nodiscard]] std::string_view GetCategory()    const { return m_category; }
        [[nodiscard]] bool             IsEnabled()      const { return m_enabled.load(std::memory_order_relaxed); }
        [[nodiscard]] uint32_t         GetKeybind()     const { return m_keybind; }
        [[nodiscard]] bool             ShowInQuickMenu() const { return m_showInQuickMenu; }

        void SetKeybind(uint32_t vk) { m_keybind = vk; }

    protected:
        std::string m_name;
        std::string m_description;
        std::string m_category;
        std::atomic<bool> m_enabled{false};
        uint32_t    m_keybind  = 0;
        bool        m_showInQuickMenu = true;

    private:
        bool m_committedEnabled = false;
    };

} // namespace UNIx
