#pragma once
#include <Core/BaseModule.hpp>

namespace UNIx {

    class RaycastTPModule : public BaseModule {
    public:
        RaycastTPModule();

        void OnUpdate() override;

    private:
        float m_maxDistance = 500.f;
    };

} // namespace UNIx
