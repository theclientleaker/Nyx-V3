#include <Modules/Utility/BundleDecrypt/BundleDecryptModule.hpp>
#include <Core/Globals.hpp>
#include <Core/FileLog/FileLog.hpp>
#include <Core/DashboardConsole/DashboardConsole.hpp>
#include <IL2CPP.Module/include/Reflection.hpp>
#include <IL2CPP.Module/include/MethodHandler.hpp>

namespace Hooking::Module {
    extern const Hooking::HookVtable* get_connection_vtable() noexcept;
}

using namespace IL2CPP::Module;

namespace UNIx {

    // Prefix hook for UnityWebRequestAssetBundle.GetAssetBundle.
    // The encKey parameter is a pointer to a Nullable<EncryptionKey> struct
    // (value type, passed by pointer on x64 since it's > 8 bytes).
    // Nullable<T> layout: { bool hasValue; T value; }
    // Setting hasValue = false makes the runtime treat the bundle as unencrypted.
    // We return true to let the original method run with the modified parameter.
    // SEH wrapper — no C++ objects allowed in __try blocks
    static int TryStripEncryption(void* encKey) noexcept {
        __try {
            if (encKey) {
                volatile bool hasValue = *reinterpret_cast<bool*>(encKey);
                if (hasValue) {
                    *reinterpret_cast<bool*>(encKey) = false;
                    return 1; // stripped
                }
                return 0; // no encryption
            }
            return -1; // null pointer
        } __except(1) {
            return -2; // access violation
        }
    }

    bool BundleDecryptModule::PrefixStripEncryption(
        void* url, void* cachedBundle, uint32_t crc,
        bool loadType, void* encKey, void*& __retval)
    {
        int result = TryStripEncryption(encKey);

        switch (result) {
        case  1: FLOG("[BundleDecrypt] Stripped encryption from bundle"); break;
        case  0: FLOG("[BundleDecrypt] Bundle loaded (no encryption key set)"); break;
        case -1: FLOG("[BundleDecrypt] Bundle loaded (encKey was null)"); break;
        case -2: FLOG("[BundleDecrypt] Exception accessing encKey={}", encKey); break;
        }

        return true;
    }

    void BundleDecryptModule::InstallHook() {
        if (m_hookActive) return;
        if (!g_hook || !g_hook->valid()) return;

        // Try to find GetAssetBundle with encryption key parameter.
        // The encrypted overload: (string, CachedAssetBundle, uint, bool, Nullable<EncryptionKey>)
        struct Candidate {
            const char* className;
            int paramCount;
        };

        Candidate candidates[] = {
            {"UnityEngine.Networking.UnityWebRequestAssetBundle", 5},
            {"UnityEngine.UnityWebRequestAssetBundle", 5},
            {"UnityEngine.Networking.UnityWebRequestAssetBundle", 4},
            {"UnityEngine.UnityWebRequestAssetBundle", 4},
        };

        Method method;
        for (auto& c : candidates) {
            method = MethodHandler::resolve(c.className, "GetAssetBundle", c.paramCount);
            if (method) {
                FLOG("[BundleDecrypt] Found {}.GetAssetBundle({})", c.className, c.paramCount);
                break;
            }
        }

        if (!method) {
            DashboardConsole::Get().AddLog(
                "[BundleDecrypt] Could not find GetAssetBundle with encryption param",
                DashboardConsole::LogColor::Disabled);
            FLOG("[BundleDecrypt] FAILED: no matching GetAssetBundle method found");
            return;
        }

        void* ptr = method.pointer();
        FLOG("[BundleDecrypt] Method pointer: {}", ptr);

        m_hookId = g_hook->create_prefix(
            "BundleDecrypt_GetAssetBundle",
            ptr,
            PrefixStripEncryption);

        if (m_hookId != Hooking::invalid_id) {
            m_hookActive = true;
            DashboardConsole::Get().AddLog("[BundleDecrypt] Hook installed — encryption stripped");
            FLOG("[BundleDecrypt] Hook installed (id={})", m_hookId);
        } else {
            DashboardConsole::Get().AddLog(
                "[BundleDecrypt] Failed to install hook",
                DashboardConsole::LogColor::Disabled);
            FLOG("[BundleDecrypt] create_prefix failed");
        }
    }

    void BundleDecryptModule::RemoveHook() {
        if (!m_hookActive) return;
        if (!g_hook || !g_hook->valid()) return;

        g_hook->remove_hook(m_hookId);
        m_hookActive = false;
        m_hookId = Hooking::invalid_id;
        DashboardConsole::Get().AddLog("[BundleDecrypt] Hook removed");
        FLOG("[BundleDecrypt] Hook removed");
    }

    void BundleDecryptModule::OnEnable() {
        InstallHook();
    }

    void BundleDecryptModule::OnDisable() {
        RemoveHook();
    }

} // namespace UNIx
