#pragma once

#include <Core/BaseModule.hpp>
#include <Core/Renderer.hpp>
#include <Core/PlayerCache/PlayerCache.hpp>

#include <Hooking.Common/hook_shared.hpp>
#include <Bootstrap.Module/include/VRChat/Player.hpp>

#include <vector>
#include <memory>
#include <utility>
#include <string>
#include <mutex>
#include <atomic>

struct ImGuiIO;
struct ImColor;

namespace UNIx {

    class ModuleManager {
    public:
        static ModuleManager& Get();

        template<typename T, typename... Args>
        void Register(Args&&... args) {
            m_modules.emplace_back(std::make_unique<T>(std::forward<Args>(args)...));
        }

        template<typename T>
        T* FindModule() const {
            for (auto& mod : m_modules) {
                if (auto* p = dynamic_cast<T*>(mod.get()))
                    return p;
            }
            return nullptr;
        }

        static void Render(const Hooking::UiRenderContext* ctx);
        static void Resize(uint32_t width, uint32_t height);
        static bool OnWndProc(void* hWnd, uint32_t uMsg, uintptr_t wParam, intptr_t lParam);

        void DispatchUpdate();
        void DispatchLateUpdate();
        void DispatchFixedUpdate();
        void DispatchSceneLoad(int scene, int loadMode);
        void DispatchSceneUnload(int scene, int loadMode);
        void DispatchPlayerAwake(IL2CPP::VRChat::Player player);
        void DispatchPlayerJoin(IL2CPP::VRChat::Player player);
        void DispatchPlayerJoinComplete(IL2CPP::VRChat::Player player);
        void DispatchPlayerLeave(IL2CPP::VRChat::Player player);

        PlayerCache& GetPlayerCache() { return m_playerCache; }

        const std::vector<std::unique_ptr<BaseModule>>& GetModules() const { return m_modules; }

        BaseModule* FindModuleByName(std::string_view name) const {
            for (auto& mod : m_modules) {
                if (mod->GetName() == name) return mod.get();
            }
            return nullptr;
        }

        std::vector<std::string> GetEnabledModuleNames() const;

        void Shutdown();

    private:
        friend void __cdecl QmToggleCallback(uint32_t, bool);
        friend void __cdecl QmLayoutToggleCallback(uint32_t, bool);
        ModuleManager() = default;

        static void RenderWatermark(ModuleManager& mgr, const ImGuiIO& io, const ImColor& rainbow);
        static void RenderPlayerlistOverlay(ModuleManager& mgr, const ImGuiIO& io, const ImColor& rainbow);
        static void RenderAdminPanel(ModuleManager& mgr, const ImGuiIO& io);

        void SetupQuickMenu();
        void SyncQuickMenuStates();
        void ScanCustomBackgrounds();
        void FixQMScrolling();

        std::vector<std::unique_ptr<BaseModule>> m_modules;
        PlayerCache m_playerCache;
        float m_hue            = 0.0f;
        bool  m_showWatermark  = false;
        bool  m_showStats      = false;
        bool  m_playerlistOpen = false;
        int   m_plTab          = 0;
        bool  m_qmInitialized  = false;
        uint32_t m_qmPageId    = 0;
        int   m_selectedPlayerId = -1;
        float m_heartbeatTimer = 0.f;
        bool  m_vrcPlusSpoofed = false;
        bool  m_vrcPlusTextChanged = false;
        bool  m_forceCloneApplied = false;
        bool  m_fastRateApplied = false;
        static bool PrefixAlwaysTrue(void* thisPtr, bool& __retval);
        static bool PrefixAlwaysTrueStatic(bool& __retval);
        float m_pickupPatchTimer = 0.f;
        int   m_pickupFieldPickupable = -1;
        int   m_pickupFieldTheft = -1;
        int   m_pickupFieldProximity = -1;
        bool  m_pickupFieldsResolved = false;
        void  ApplyVRCPlusSpoof();
        void  ApplyForceClone();
        void  ApplyFastRate();
        void  ApplyPickupPatches();
        float m_customBgScanTimer = 0.f;
        float m_qmSyncTimer = 0.f;
        bool  m_scrollFixApplied = false;
        float m_scrollFixDelay  = 0.f;
        std::string m_selectedAdminUserId;
        std::string m_prevSelectedAdminUserId;
        char  m_tagInputBuf[4096] = {};
        float m_tagColor[3] = {1.f, 1.f, 1.f};
        bool  m_tagRainbow = false;
        bool  m_tagSmoothRainbow = false;
        bool  m_tagBlink = false;
        bool  m_tagScroll = false;
        bool  m_tagCylinder = false;
        bool  m_tagPulse = false;
        bool  m_tagGlitch = false;
        bool  m_tagJump = false;
        bool  m_tagShake = false;
        bool  m_tagGhostTrail = false;
        bool  m_tagLBL = false;
        int   m_editingTagIndex = -1;
        std::string m_pendingForceJoin;
        std::mutex m_forceJoinMutex;
        std::string m_queuedForceJoin;
        std::atomic<int> m_pendingTeleportTarget{-1};
        std::atomic<int> m_pendingPortalTarget{-1};
        std::atomic<int> m_pendingPortalOrbitTarget{-1};

        struct PendingRemoteCommand {
            std::string type;
            std::string worldId;
            bool active = false;
            bool uiShown = false;
            float timer = 0.f;
            static constexpr float TIMEOUT = 30.f;
        };
        PendingRemoteCommand m_pendingCmd;
        std::mutex m_pendingCmdMutex;

        void* m_promptPanelGO = nullptr;
        void* m_promptAcceptGO = nullptr;
        void* m_promptDeclineGO = nullptr;
        void* m_promptCanvasCamera = nullptr;
        void CreatePromptUI(const std::string& message);
        void DestroyPromptUI();

    public:
        void QueueForceJoin(const std::string& worldId);
    };

} // namespace UNIx
