#define WIN32_LEAN_AND_MEAN
#include <Windows.h>

#include <Core/SpriteLoader/SpriteLoader.hpp>
#include <Core/Globals.hpp>
#include <Core/FileLog/FileLog.hpp>
#include <IL2CPP.Module/include/il2cpp_module.hpp>
#include <IL2CPP.Common/il2cpp_shared.hpp>
#include <fstream>
#include <vector>
#include <cstring>
#include <algorithm>
#include <thread>
#include <ThirdParty/stb/stb_image.h>
#include <ThirdParty/stb/stb_image_write.h>

namespace UNIx {

    SpriteLoader& SpriteLoader::Get() {
        static SpriteLoader instance;
        return instance;
    }

    SpriteLoader::~SpriteLoader() {
        Shutdown();
    }

    void SpriteLoader::Shutdown() {
        m_shuttingDown.store(true);

        std::lock_guard lock(m_pendingMutex);
        for (auto& task : m_asyncTasks) {
            if (task->thread.joinable())
                task->thread.join();
        }
        m_asyncTasks.clear();
    }

    void SpriteLoader::JoinFinishedThreads() {
        for (auto it = m_asyncTasks.begin(); it != m_asyncTasks.end(); ) {
            auto& task = *it;
            if (task->pending->ready.load() || task->pending->failed.load()) {
                if (task->thread.joinable())
                    task->thread.join();
                it = m_asyncTasks.erase(it);
            } else {
                ++it;
            }
        }
    }

    void* SpriteLoader::CreateSpriteFromBytes(const std::string& key, const uint8_t* data, size_t size) {
        auto* E = IL2CPP::Module::GetExports();
        if (!E || !E->m_arrayNew || !E->m_runtimeInvoke) return nullptr;

        auto byteClass = IL2CPP::Module::Class::find("System.Byte");
        if (!byteClass) return nullptr;

        void* managedArray = reinterpret_cast<void*(IL2CPP_CALLTYPE)(void*, uintptr_t)>(
            E->m_arrayNew)(byteClass.raw(), static_cast<uintptr_t>(size));
        if (!managedArray) return nullptr;
        memcpy(static_cast<char*>(managedArray) + 0x20, data, size);

        static auto getWhite = IL2CPP::Module::MethodHandler::resolve(
            "UnityEngine.Texture2D", "get_whiteTexture", 0);
        if (!getWhite) return nullptr;

        void* whiteTex = IL2CPP::Module::MethodHandler::invoke<void*>(getWhite, nullptr);
        if (!whiteTex) return nullptr;

        static auto instantiate = IL2CPP::Module::MethodHandler::resolve(
            "UnityEngine.Object", "Instantiate", 1);
        if (!instantiate) return nullptr;

        void* instParams[] = { whiteTex };
        void* texObj = IL2CPP::Module::MethodHandler::invoke<void*>(instantiate, nullptr, instParams);
        if (!texObj) return nullptr;

        static auto loadImage = IL2CPP::Module::MethodHandler::resolve(
            "UnityEngine.ImageConversion", "LoadImage", 2);
        if (!loadImage) return nullptr;

        void* lp[] = { texObj, managedArray };
        IL2CPP::Module::MethodHandler::invoke<bool>(loadImage, nullptr, lp);

        IL2CPP::Module::Unity::Texture2D tex(texObj);
        int tw = tex.GetWidth();
        int th = tex.GetHeight();

        IL2CPP::Rect rect{ 0.f, 0.f, static_cast<float>(tw), static_cast<float>(th) };
        IL2CPP::Vector2 pivot{ 0.5f, 0.5f };

        auto sprite = IL2CPP::Module::Unity::Sprite::Create(texObj, rect, pivot, 100.0f);
        if (!sprite) return nullptr;

        m_cache[key] = sprite.raw();
        return sprite.raw();
    }

    static bool IsGifFile(const std::string& path) {
        if (path.size() < 4) return false;
        std::string ext = path.substr(path.size() - 4);
        std::transform(ext.begin(), ext.end(), ext.begin(),
            [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
        return ext == ".gif";
    }

    static void PngWriteCallback(void* context, void* data, int size) {
        auto* buf = static_cast<std::vector<uint8_t>*>(context);
        auto* bytes = static_cast<const uint8_t*>(data);
        buf->insert(buf->end(), bytes, bytes + size);
    }

    void* SpriteLoader::LoadFromFile(const std::string& path) {
        auto it = m_cache.find(path);
        if (it != m_cache.end())
            return it->second;

        // Don't read GIF files here — they use the async path
        if (IsGifFile(path)) {
            LoadAnimatedGifAsync(path);
            return nullptr;
        }

        std::ifstream file(path, std::ios::binary | std::ios::ate);
        if (!file.is_open()) return nullptr;

        auto fileSize = file.tellg();
        if (fileSize <= 0) return nullptr;

        std::vector<uint8_t> bytes(static_cast<size_t>(fileSize));
        file.seekg(0);
        file.read(reinterpret_cast<char*>(bytes.data()), fileSize);
        file.close();

        return CreateSpriteFromBytes(path, bytes.data(), bytes.size());
    }

    // Decode GIF frames from raw bytes (pure CPU work, no IL2CPP — safe for background thread)
    static bool DecodeGifFrames(const std::vector<uint8_t>& bytes, AnimatedSprite& anim) {
        int* delays = nullptr;
        int w = 0, h = 0, frameCount = 0, comp = 0;
        auto* pixels = stbi_load_gif_from_memory(bytes.data(), static_cast<int>(bytes.size()),
                                                  &delays, &w, &h, &frameCount, &comp, 4);
        if (!pixels || frameCount <= 0) {
            if (pixels) stbi_image_free(pixels);
            return false;
        }

        anim.width = w;
        anim.height = h;
        size_t frameSize = static_cast<size_t>(w) * h * 4;

        // Cap frame count to prevent excessive memory usage
        int maxFrames = (std::min)(frameCount, 500);
        for (int i = 0; i < maxFrames; ++i) {
            const uint8_t* src = pixels + i * frameSize;

            // stb gives top-down RGBA, Unity expects bottom-up — flip vertically
            std::vector<uint8_t> flipped(frameSize);
            for (int row = 0; row < h; ++row) {
                memcpy(flipped.data() + row * w * 4,
                       src + (h - 1 - row) * w * 4,
                       w * 4);
            }

            constexpr float kFrameDelay = 1.f / 30.f;
            anim.frames.push_back({ std::move(flipped), kFrameDelay });
            anim.totalDuration += kFrameDelay;
        }

        stbi_image_free(pixels);
        return !anim.frames.empty();
    }

    // Create GPU texture + sprite from decoded AnimatedSprite (must be called on Unity thread)
    bool SpriteLoader::CreateGifGpuResources(AnimatedSprite& anim) {
        auto* E = IL2CPP::Module::GetExports();
        if (!E) return false;

        static auto getWhite = IL2CPP::Module::MethodHandler::resolve("UnityEngine.Texture2D", "get_whiteTexture", 0);
        if (!getWhite) return false;
        void* whiteTex = IL2CPP::Module::MethodHandler::invoke<void*>(getWhite, nullptr);
        if (!whiteTex) return false;

        static auto instantiate = IL2CPP::Module::MethodHandler::resolve("UnityEngine.Object", "Instantiate", 1);
        if (!instantiate) return false;

        void* instP[] = { whiteTex };
        void* texObj = IL2CPP::Module::MethodHandler::invoke<void*>(instantiate, nullptr, instP);
        if (!texObj) return false;

        IL2CPP::Module::Unity::Texture2D tex(texObj);
        tex.Resize(anim.width, anim.height);

        size_t frameSize = static_cast<size_t>(anim.width) * anim.height * 4;
        auto byteClass = IL2CPP::Module::Class::find("System.Byte");
        if (!byteClass) return false;

        void* managedArray = reinterpret_cast<void*(IL2CPP_CALLTYPE)(void*, uintptr_t)>(
            E->m_arrayNew)(byteClass.raw(), static_cast<uintptr_t>(frameSize));
        if (!managedArray) return false;

        memcpy(static_cast<char*>(managedArray) + 0x20, anim.frames[0].pixels.data(), frameSize);
        static auto loadRaw = IL2CPP::Module::MethodHandler::resolve("UnityEngine.Texture2D", "LoadRawTextureData", 1);
        if (loadRaw) {
            void* loadParams[] = { managedArray };
            IL2CPP::Module::MethodHandler::invoke(loadRaw, texObj, loadParams);
        }
        tex.Apply();

        IL2CPP::Rect rect{ 0.f, 0.f, static_cast<float>(anim.width), static_cast<float>(anim.height) };
        IL2CPP::Vector2 pivot{ 0.5f, 0.5f };
        auto sprite = IL2CPP::Module::Unity::Sprite::Create(texObj, rect, pivot, 100.0f);
        if (!sprite) return false;

        anim.texture = texObj;
        anim.sprite = sprite.raw();
        return true;
    }

    const AnimatedSprite* SpriteLoader::LoadAnimatedGif(const std::string& path) {
        auto it = m_animCache.find(path);
        if (it != m_animCache.end())
            return &it->second;

        // Synchronous fallback (used for already-cached or direct calls)
        std::ifstream file(path, std::ios::binary | std::ios::ate);
        if (!file.is_open()) return nullptr;

        auto fileSize = file.tellg();
        if (fileSize <= 0) return nullptr;

        std::vector<uint8_t> bytes(static_cast<size_t>(fileSize));
        file.seekg(0);
        file.read(reinterpret_cast<char*>(bytes.data()), fileSize);
        file.close();

        AnimatedSprite anim;
        if (!DecodeGifFrames(bytes, anim)) {
            return nullptr;
        }

        if (!CreateGifGpuResources(anim)) return nullptr;


        auto [inserted, _] = m_animCache.emplace(path, std::move(anim));
        return &inserted->second;
    }

    void SpriteLoader::LoadAnimatedGifAsync(const std::string& path) {
        if (m_shuttingDown.load()) return;
        if (m_animCache.count(path)) return;

        std::lock_guard lock(m_pendingMutex);

        for (auto& task : m_asyncTasks) {
            if (task->pending->path == path) return;
        }

        JoinFinishedThreads();

        auto task = std::make_unique<AsyncGifTask>();
        task->pending = std::make_shared<PendingGifData>();
        task->pending->path = path;

        auto pending = task->pending;
        task->thread = std::thread([pending, path]() {
            try {
                std::ifstream file(path, std::ios::binary | std::ios::ate);
                if (!file.is_open()) {
                    pending->failed.store(true);
                    return;
                }

                auto fileSize = file.tellg();
                if (fileSize <= 0 || fileSize > 200 * 1024 * 1024) {
                    pending->failed.store(true);
                    return;
                }

                std::vector<uint8_t> bytes(static_cast<size_t>(fileSize));
                file.seekg(0);
                file.read(reinterpret_cast<char*>(bytes.data()), fileSize);
                file.close();

                if (!DecodeGifFrames(bytes, pending->anim)) {
                    pending->failed.store(true);
                    return;
                }

                pending->ready.store(true);
            } catch (...) {
                pending->failed.store(true);
            }
        });

        m_asyncTasks.push_back(std::move(task));
    }

    const AnimatedSprite* SpriteLoader::FinalizeAsyncGifs() {
        std::lock_guard lock(m_pendingMutex);
        if (m_asyncTasks.empty()) return nullptr;

        const AnimatedSprite* result = nullptr;

        for (auto it = m_asyncTasks.begin(); it != m_asyncTasks.end(); ) {
            auto& task = *it;
            auto& p = task->pending;

            if (p->failed.load()) {
                FLOG("[SpriteLoader] Async GIF failed: {}", p->path);
                if (task->thread.joinable())
                    task->thread.join();
                it = m_asyncTasks.erase(it);
                continue;
            }
            if (p->ready.load()) {
                if (task->thread.joinable())
                    task->thread.join();
                if (CreateGifGpuResources(p->anim)) {
                    auto [inserted, _] = m_animCache.emplace(p->path, std::move(p->anim));
                    result = &inserted->second;
                } else {
                    FLOG("[SpriteLoader] GPU resource creation failed: {}", p->path);
                }
                it = m_asyncTasks.erase(it);
                continue;
            }
            ++it;
        }
        return result;
    }

    bool SpriteLoader::IsAsyncLoading(const std::string& path) const {
        std::lock_guard lock(m_pendingMutex);
        for (auto& task : m_asyncTasks) {
            if (task->pending->path == path) return true;
        }
        return false;
    }

    const AnimatedSprite* SpriteLoader::GetAnimatedGif(const std::string& path) const {
        auto it = m_animCache.find(path);
        return it != m_animCache.end() ? &it->second : nullptr;
    }

    void* SpriteLoader::LoadFromMemory(const std::string& key, const unsigned char* data, size_t size) {
        auto it = m_cache.find(key);
        if (it != m_cache.end())
            return it->second;

        return CreateSpriteFromBytes(key, data, size);
    }

    void* SpriteLoader::LoadFromResource(uint32_t resourceId, const std::string& key) {
        auto it = m_cache.find(key);
        if (it != m_cache.end())
            return it->second;

        HRSRC hRes = FindResourceW(g_hModule, MAKEINTRESOURCEW(resourceId), L"PNG");
        if (!hRes) {
            return nullptr;
        }

        HGLOBAL hData = LoadResource(g_hModule, hRes);
        if (!hData) return nullptr;

        auto* data = static_cast<const uint8_t*>(LockResource(hData));
        DWORD size = SizeofResource(g_hModule, hRes);
        if (!data || size == 0) return nullptr;

        return CreateSpriteFromBytes(key, data, size);
    }

    void* SpriteLoader::GetCached(const std::string& key) const {
        auto it = m_cache.find(key);
        return it != m_cache.end() ? it->second : nullptr;
    }

} // namespace UNIx
