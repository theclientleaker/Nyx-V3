#include <Modules/Visual/ESP/ESPModule.hpp>
#include <Core/ModuleManager.hpp>
#include <Core/QuickMenuEx.hpp>
#include <ThirdParty/imgui/imgui.h>

#include <IL2CPP.Module/include/Unity/Camera.hpp>
#include <IL2CPP.Module/include/Unity/Screen.hpp>
#include <Bootstrap.Module/include/VRChat/VRCPlayerApi.hpp>

#include <cmath>
#include <algorithm>

namespace UNIx {

    ESPModule* ESPModule::s_instance = nullptr;

    void __cdecl ESPModule::QmRenderModeCb(uint32_t, int val) {
        if (s_instance) s_instance->m_renderMode = static_cast<RenderMode>(val);
    }

    void ESPModule::OnSetupQuickMenu(uint32_t moduleId, uint32_t categoryPageId) {
        s_instance = this;
        auto& qmEx = QuickMenuEx::Get();
        uint32_t fold = qmEx.add_foldout(moduleId, categoryPageId, "Box ESP Settings", false, true);
        const char* modes[] = { "3D Box", "2D Box" };
        qmEx.add_enum_selector(moduleId, fold, "Render Mode", modes, 2,
            static_cast<int>(m_renderMode), QmRenderModeCb, "esp_render_mode");
    }

    ImU32 ESPModule::RankToESPColor(IL2CPP::VRChat::PlayerRank rank) {
        using R = IL2CPP::VRChat::PlayerRank;
        switch (rank) {
            case R::Visitor:       return IM_COL32(204, 204, 204, 255);
            case R::NewUser:         return IM_COL32( 43, 207,  92, 255);
            case R::User:         return IM_COL32(255, 122,  66, 255);
            case R::Known:       return IM_COL32(199,  61, 255, 255);
            case R::Trusted:       return IM_COL32(255, 102, 102, 255);
            case R::Administrator: return IM_COL32(139,   0,   0, 255);
            case R::Troll:         return IM_COL32(128, 128, 128, 255);
            default:               return IM_COL32(255, 255, 255, 255);
        }
    }

    void ESPModule::OnRender() {
    }

    void ESPModule::OnUpdate() {
        using Bones = IL2CPP::VRChat::HumanBodyBones;
        std::vector<ESPEntry> newEntries;

        if (!InRoom()) {
            std::lock_guard lock(m_dataMutex);
            m_entries.clear();
            return;
        }

        auto cam = IL2CPP::Module::Unity::Camera::GetMain();
        if (!cam.valid()) {
            std::lock_guard lock(m_dataMutex);
            m_entries.clear();
            return;
        }

        float screenW = static_cast<float>(IL2CPP::Module::Unity::Screen::GetWidth());
        float screenH = static_cast<float>(IL2CPP::Module::Unity::Screen::GetHeight());

        auto localApi = GetLocalPlayerApi();
        IL2CPP::Vector3 localPos = {};
        bool hasLocalPos = false;
        if (localApi.IsValid()) {
            localPos = localApi.GetPosition();
            hasLocalPos = true;
        }

        auto players = ModuleManager::Get().GetPlayerCache().GetPlayers();

        for (auto& entry : *players) {
            if (entry.isLocal) continue;

            auto api = IL2CPP::VRChat::VRCPlayerApi::GetPlayerById(entry.playerId);
            if (!api.IsValid()) continue;

            IL2CPP::Vector3 feetPos = api.GetPosition();
            IL2CPP::Vector3 headPos = api.GetBonePosition(Bones::Head);
            IL2CPP::Vector3 hipsPos = api.GetBonePosition(Bones::Hips);
            IL2CPP::Vector3 lHand   = api.GetBonePosition(Bones::LeftHand);
            IL2CPP::Vector3 rHand   = api.GetBonePosition(Bones::RightHand);
            IL2CPP::Vector3 lFoot   = api.GetBonePosition(Bones::LeftFoot);
            IL2CPP::Vector3 rFoot   = api.GetBonePosition(Bones::RightFoot);

            // Build tight AABB from bone positions
            float minX = feetPos.x, maxX = feetPos.x;
            float minY = feetPos.y, maxY = feetPos.y;
            float minZ = feetPos.z, maxZ = feetPos.z;

            auto expand = [&](const IL2CPP::Vector3& p) {
                minX = std::min(minX, p.x); maxX = std::max(maxX, p.x);
                minY = std::min(minY, p.y); maxY = std::max(maxY, p.y);
                minZ = std::min(minZ, p.z); maxZ = std::max(maxZ, p.z);
            };

            expand(headPos);
            expand(hipsPos);
            expand(lHand);
            expand(rHand);
            expand(lFoot);
            expand(rFoot);

            // Add some padding above head and around body
            float height = maxY - minY;
            if (height < 0.1f) height = 1.6f;
            float pad = height * 0.08f;
            maxY += pad;
            minX -= pad; maxX += pad;
            minZ -= pad; maxZ += pad;

            // Ensure minimum width so the box isn't paper-thin when facing head-on
            float halfW = (maxX - minX) * 0.5f;
            float halfD = (maxZ - minZ) * 0.5f;
            float minHalf = height * 0.15f;
            if (halfW < minHalf) {
                float cx = (minX + maxX) * 0.5f;
                minX = cx - minHalf;
                maxX = cx + minHalf;
            }
            if (halfD < minHalf) {
                float cz = (minZ + maxZ) * 0.5f;
                minZ = cz - minHalf;
                maxZ = cz + minHalf;
            }

            IL2CPP::Vector3 worldCorners[8] = {
                { minX, minY, minZ },
                { maxX, minY, minZ },
                { maxX, minY, maxZ },
                { minX, minY, maxZ },
                { minX, maxY, minZ },
                { maxX, maxY, minZ },
                { maxX, maxY, maxZ },
                { minX, maxY, maxZ },
            };

            ESPEntry e;
            bool anyVisible = false;
            float sMinX = FLT_MAX, sMinY = FLT_MAX;
            float sMaxX = -FLT_MAX, sMaxY = -FLT_MAX;

            for (int i = 0; i < 8; ++i) {
                IL2CPP::Vector3 sp = cam.WorldToScreenPoint(worldCorners[i]);
                e.visible[i] = (sp.z > 0.f);
                if (e.visible[i]) anyVisible = true;
                float sx = sp.x;
                float sy = screenH - sp.y;
                e.corners[i] = ImVec2(sx, sy);

                if (e.visible[i]) {
                    sMinX = std::min(sMinX, sx);
                    sMinY = std::min(sMinY, sy);
                    sMaxX = std::max(sMaxX, sx);
                    sMaxY = std::max(sMaxY, sy);
                }
            }

            if (!anyVisible) continue;

            e.boxMin = ImVec2(std::max(sMinX, 0.f), std::max(sMinY, 0.f));
            e.boxMax = ImVec2(std::min(sMaxX, screenW), std::min(sMaxY, screenH));
            e.color = RankToESPColor(entry.rank);
            e.name = entry.displayName;

            if (hasLocalPos) {
                float dx = feetPos.x - localPos.x;
                float dy = feetPos.y - localPos.y;
                float dz = feetPos.z - localPos.z;
                e.distance = std::sqrtf(dx * dx + dy * dy + dz * dz);
            } else {
                e.distance = -1.f;
            }

            newEntries.push_back(std::move(e));
        }

        std::lock_guard lock(m_dataMutex);
        m_entries = std::move(newEntries);
    }

    static constexpr int kEdges[12][2] = {
        {0,1}, {1,2}, {2,3}, {3,0},   // bottom
        {4,5}, {5,6}, {6,7}, {7,4},   // top
        {0,4}, {1,5}, {2,6}, {3,7},   // verticals
    };

    void ESPModule::OnOverlay() {
        std::vector<ESPEntry> snapshot;
        {
            std::lock_guard lock(m_dataMutex);
            snapshot = m_entries;
        }

        if (snapshot.empty()) return;

        auto* drawList = ImGui::GetBackgroundDrawList();

        for (auto& e : snapshot) {
            // Name + distance label
            char label[128];
            if (e.distance >= 0.f)
                snprintf(label, sizeof(label), "%s [%.0fm]", e.name.c_str(), e.distance);
            else
                snprintf(label, sizeof(label), "%s", e.name.c_str());

            if (m_renderMode == RenderMode::Box3D) {
                // 3D wireframe box
                for (auto& edge : kEdges) {
                    int a = edge[0], b = edge[1];
                    if (!e.visible[a] || !e.visible[b]) continue;
                    drawList->AddLine(e.corners[a], e.corners[b], IM_COL32(0, 0, 0, 200), 3.0f);
                }
                for (auto& edge : kEdges) {
                    int a = edge[0], b = edge[1];
                    if (!e.visible[a] || !e.visible[b]) continue;
                    drawList->AddLine(e.corners[a], e.corners[b], e.color, 1.5f);
                }
            } else {
                // 2D bounding box
                float bw = e.boxMax.x - e.boxMin.x;
                float bh = e.boxMax.y - e.boxMin.y;
                if (bw < 4.f || bh < 4.f) continue;

                drawList->AddRect(e.boxMin, e.boxMax, IM_COL32(0, 0, 0, 200), 0.f, 0, 3.0f);
                drawList->AddRect(e.boxMin, e.boxMax, e.color, 0.f, 0, 1.5f);
            }

            // Name tag centered above box
            ImVec2 textSize = ImGui::CalcTextSize(label);
            float tagX = e.boxMin.x + ((e.boxMax.x - e.boxMin.x) - textSize.x) * 0.5f;
            float tagY = e.boxMin.y - textSize.y - 4.f;

            drawList->AddRectFilled(
                ImVec2(tagX - 3.f, tagY - 1.f),
                ImVec2(tagX + textSize.x + 3.f, tagY + textSize.y + 1.f),
                IM_COL32(0, 0, 0, 160), 2.f);
            drawList->AddText(ImVec2(tagX, tagY), e.color, label);
        }
    }

} // namespace UNIx
