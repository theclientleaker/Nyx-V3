#pragma once
#include <Core/BaseModule.hpp>
#include <string>
#include <vector>

namespace UNIx {

    class LoadingPopup : public BaseModule {
    public:
        LoadingPopup() : BaseModule("Loading Popup", "Replace loading screen image from C:/nyx/loadingscreen", 0, "UI") {
            m_enabled = true;
        }

        void OnSceneLoad(int scene, int loadMode) override;
        void OnUpdate() override;
        void OnRender() override;

    private:
        enum class State { Idle, WaitForBackground, Applied };

        State m_state = State::Idle;
        void* m_texture = nullptr;
        size_t m_fileIndex = 0;
        bool m_warnedNoFiles = false;
        std::vector<std::string> m_imageFiles;
        std::string m_currentSource;

        void ScanFolder();
    };

} // namespace UNIx
