#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#include <bcrypt.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <ctime>
#include <cstdio>

#include <mutex>
#include <condition_variable>

#include <Core/License/LicenseManager.hpp>
#include <Core/ApiClient/ApiClient.hpp>
#include <Core/FileLog/FileLog.hpp>

#pragma comment(lib, "bcrypt.lib")

namespace UNIx {

    static void EnableAnsiColors() {
        HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
        DWORD mode = 0;
        GetConsoleMode(hOut, &mode);
        SetConsoleMode(hOut, mode | ENABLE_VIRTUAL_TERMINAL_PROCESSING);
    }

    static void ConsolePrint(const std::string& msg) {
        HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
        DWORD w;
        WriteConsoleA(hOut, msg.c_str(), static_cast<DWORD>(msg.size()), &w, nullptr);
    }

    static constexpr const char* C_RESET   = "\033[0m";
    static constexpr const char* C_PURPLE  = "\033[35m";
    static constexpr const char* C_GREEN   = "\033[32m";
    static constexpr const char* C_RED     = "\033[31m";
    static constexpr const char* C_CYAN    = "\033[36m";
    static constexpr const char* C_YELLOW  = "\033[33m";
    static constexpr const char* C_DIM     = "\033[2m";

    LicenseManager& LicenseManager::Get() {
        static LicenseManager instance;
        return instance;
    }

    std::string LicenseManager::SHA256(const std::string& input) {
        BCRYPT_ALG_HANDLE hAlg = nullptr;
        BCRYPT_HASH_HANDLE hHash = nullptr;
        BYTE hash[32]{};
        DWORD hashLen = 0, resultLen = 0;

        if (BCryptOpenAlgorithmProvider(&hAlg, BCRYPT_SHA256_ALGORITHM, nullptr, 0) != 0)
            return "";
        BCryptGetProperty(hAlg, BCRYPT_HASH_LENGTH, reinterpret_cast<PUCHAR>(&hashLen), sizeof(hashLen), &resultLen, 0);
        if (BCryptCreateHash(hAlg, &hHash, nullptr, 0, nullptr, 0, 0) != 0) {
            BCryptCloseAlgorithmProvider(hAlg, 0);
            return "";
        }

        BCryptHashData(hHash, reinterpret_cast<PUCHAR>(const_cast<char*>(input.data())),
            static_cast<ULONG>(input.size()), 0);
        BCryptFinishHash(hHash, hash, sizeof(hash), 0);
        BCryptDestroyHash(hHash);
        BCryptCloseAlgorithmProvider(hAlg, 0);

        char hex[65]{};
        for (int i = 0; i < 32; i++)
            snprintf(hex + i * 2, 3, "%02x", hash[i]);
        return std::string(hex, 64);
    }

    std::string LicenseManager::GenerateHWID() {
        std::string raw;

        HKEY hKey;
        if (RegOpenKeyExA(HKEY_LOCAL_MACHINE, "SOFTWARE\\Microsoft\\Cryptography", 0, KEY_READ | KEY_WOW64_64KEY, &hKey) == ERROR_SUCCESS) {
            char buf[256]{};
            DWORD size = sizeof(buf);
            if (RegQueryValueExA(hKey, "MachineGuid", nullptr, nullptr, reinterpret_cast<LPBYTE>(buf), &size) == ERROR_SUCCESS)
                raw += buf;
            RegCloseKey(hKey);
        }

        DWORD serial = 0;
        if (GetVolumeInformationW(L"C:\\", nullptr, 0, &serial, nullptr, nullptr, nullptr, 0))
            raw += std::to_string(serial);

        if (RegOpenKeyExA(HKEY_LOCAL_MACHINE, "HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0", 0, KEY_READ, &hKey) == ERROR_SUCCESS) {
            char buf[256]{};
            DWORD size = sizeof(buf);
            if (RegQueryValueExA(hKey, "ProcessorNameString", nullptr, nullptr, reinterpret_cast<LPBYTE>(buf), &size) == ERROR_SUCCESS)
                raw += buf;
            RegCloseKey(hKey);
        }

        return SHA256(raw);
    }

    std::string LicenseManager::Encrypt(const std::string& data, const std::string& hwid) {
        std::string out = data;
        for (size_t i = 0; i < out.size(); i++)
            out[i] ^= static_cast<char>((hwid[i % 64] + i * 7) & 0xFF);
        return out;
    }

    std::string LicenseManager::Decrypt(const std::string& data, const std::string& hwid) {
        return Encrypt(data, hwid);
    }

    bool LicenseManager::ReadCache(const std::string& hwid, CachedLicense& out) {
        std::ifstream file("C:/nyx/license.dat", std::ios::binary);
        if (!file) return false;

        std::string encrypted((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
        file.close();

        if (encrypted.empty()) return false;

        std::string json = Decrypt(encrypted, hwid);

        auto findStr = [&](const std::string& key) -> std::string {
            auto pos = json.find("\"" + key + "\"");
            if (pos == std::string::npos) return "";
            pos = json.find(':', pos);
            if (pos == std::string::npos) return "";
            pos++;
            while (pos < json.size() && json[pos] == ' ') pos++;
            if (pos >= json.size()) return "";
            if (json[pos] == '"') {
                auto end = json.find('"', pos + 1);
                if (end == std::string::npos) return "";
                return json.substr(pos + 1, end - pos - 1);
            }
            if (json[pos] == 'n') return "";
            auto end = json.find_first_of(",}", pos);
            if (end == std::string::npos) return json.substr(pos);
            return json.substr(pos, end - pos);
        };

        out.key = findStr("key");
        out.type = findStr("type");
        std::string exp = findStr("expiresAt");
        std::string lv = findStr("lastValidated");

        if (out.key.empty() || out.key.substr(0, 4) != "NYX-") return false;

        out.expiresAt = exp.empty() ? 0 : std::stoll(exp);
        out.lastValidated = lv.empty() ? 0 : std::stoll(lv);
        return true;
    }

    void LicenseManager::WriteCache(const std::string& hwid, const CachedLicense& data) {
        CreateDirectoryA("C:\\nyx", nullptr);

        std::string json = "{\"key\":\"" + data.key + "\",\"type\":\"" + data.type + "\",\"expiresAt\":";
        if (data.expiresAt > 0)
            json += std::to_string(data.expiresAt);
        else
            json += "null";
        json += ",\"lastValidated\":" + std::to_string(data.lastValidated) + "}";

        std::string encrypted = Encrypt(json, hwid);

        std::ofstream file("C:/nyx/license.dat", std::ios::binary);
        if (file) {
            file.write(encrypted.data(), encrypted.size());
            file.close();
        }
    }

    void LicenseManager::DeleteCache() {
        DeleteFileA("C:\\nyx\\license.dat");
    }

    bool LicenseManager::ActivateOnline(const std::string& key, const std::string& hwid, CachedLicense& out, std::string& error) {
        std::string body = "{\"key\":\"" + key + "\",\"hwid\":\"" + hwid + "\"}";

        std::string response;
        std::mutex mtx;
        std::condition_variable cv;
        bool done = false;

        ApiClient::Get().PostAsync("/api/license/activate", body, [&](const std::string& resp) {
            std::lock_guard lock(mtx);
            response = resp;
            done = true;
            cv.notify_one();
        }, ApiAuth::Client);

        {
            std::unique_lock lock(mtx);
            cv.wait_for(lock, std::chrono::seconds(15), [&] { return done; });
        }

        if (response.empty()) {
            FLOG("[License] Empty response (timeout or network failure)");
            error = "network_error";
            return false;
        }

        FLOG("[License] Server response: {}", response);

        auto findStr = [&](const std::string& field) -> std::string {
            auto pos = response.find("\"" + field + "\"");
            if (pos == std::string::npos) return "";
            pos = response.find(':', pos);
            if (pos == std::string::npos) return "";
            pos++;
            while (pos < response.size() && response[pos] == ' ') pos++;
            if (pos >= response.size()) return "";
            if (response[pos] == '"') {
                auto end = response.find('"', pos + 1);
                if (end == std::string::npos) return "";
                return response.substr(pos + 1, end - pos - 1);
            }
            if (response[pos] == 'n') return "";
            if (response[pos] == 't') return "true";
            if (response[pos] == 'f') return "false";
            auto end = response.find_first_of(",}", pos);
            if (end == std::string::npos) return response.substr(pos);
            return response.substr(pos, end - pos);
        };

        std::string status = findStr("status");
        if (status != "active") {
            error = findStr("error");
            if (error.empty()) error = status;
            return false;
        }

        out.key = key;
        out.type = findStr("type");
        std::string exp = findStr("expiresAt");
        out.expiresAt = exp.empty() ? 0 : std::stoll(exp);
        out.lastValidated = static_cast<int64_t>(std::time(nullptr));
        return true;
    }

    std::string LicenseManager::PromptKey() {
        std::string prompt = std::string(C_PURPLE) + "[nyx] " + C_CYAN + "Enter your license key: " + C_RESET;
        ConsolePrint(prompt);

        HANDLE hIn = GetStdHandle(STD_INPUT_HANDLE);
        char buf[128]{};
        DWORD read;
        ReadConsoleA(hIn, buf, sizeof(buf) - 1, &read, nullptr);

        std::string key(buf, read);
        while (!key.empty() && (key.back() == '\n' || key.back() == '\r'))
            key.pop_back();

        return key;
    }

    bool LicenseManager::Validate() {
        EnableAnsiColors();

        m_hwid = GenerateHWID();
        if (m_hwid.empty()) {
            FLOG("[License] HWID generation failed");
            return false;
        }
        FLOG("[License] HWID: {}", m_hwid);

        int64_t now = static_cast<int64_t>(std::time(nullptr));
        CachedLicense cached{};

        if (ReadCache(m_hwid, cached)) {
            FLOG("[License] Cache found: key={} type={} lastValidated={}", cached.key, cached.type, cached.lastValidated);

            bool needsOnline = false;
            if (cached.type == "timed" && cached.expiresAt > 0 && now > cached.expiresAt)
                needsOnline = true;
            else if ((now - cached.lastValidated) > 86400)
                needsOnline = true;

            if (!needsOnline) {
                FLOG("[License] Valid from cache (offline)");
                ConsolePrint(std::string(C_PURPLE) + "[nyx] " + C_GREEN + "License valid." + C_RESET + "\n");
                return true;
            }

            std::string error;
            if (ActivateOnline(cached.key, m_hwid, cached, error)) {
                WriteCache(m_hwid, cached);
                FLOG("[License] Re-validated online");
                ConsolePrint(std::string(C_PURPLE) + "[nyx] " + C_GREEN + "License valid." + C_RESET + "\n");
                return true;
            }

            if (error == "network_error" && (now - cached.lastValidated) < 604800) {
                FLOG("[License] Network error but within 7-day grace period");
                ConsolePrint(std::string(C_PURPLE) + "[nyx] " + C_YELLOW + "License valid (offline)." + C_RESET + "\n");
                return true;
            }

            DeleteCache();

            std::string errMsg;
            if (error == "hwid_mismatch")
                errMsg = std::string(C_PURPLE) + "[nyx] " + C_RED + "Key activated on another machine. Contact admin for reset." + C_RESET + "\n";
            else if (error == "expired")
                errMsg = std::string(C_PURPLE) + "[nyx] " + C_RED + "License expired." + C_RESET + "\n";
            else if (error == "revoked")
                errMsg = std::string(C_PURPLE) + "[nyx] " + C_RED + "License revoked." + C_RESET + "\n";
            else if (error == "banned")
                errMsg = std::string(C_PURPLE) + "[nyx] " + C_RED + "You are banned." + C_RESET + "\n";
            else
                errMsg = std::string(C_PURPLE) + "[nyx] " + C_RED + "License validation failed: " + error + C_RESET + "\n";

            ConsolePrint(errMsg);
            return false;
        }

        std::string key = PromptKey();
        if (key.empty()) {
            FLOG("[License] No key entered");
            return false;
        }

        std::string error;
        CachedLicense license{};
        if (ActivateOnline(key, m_hwid, license, error)) {
            WriteCache(m_hwid, license);
            FLOG("[License] Activated successfully");
            ConsolePrint(std::string(C_PURPLE) + "[nyx] " + C_GREEN + "License activated!" + C_RESET + "\n");
            return true;
        }

        std::string errMsg;
        if (error == "invalid_key")
            errMsg = std::string(C_PURPLE) + "[nyx] " + C_RED + "Invalid license key." + C_RESET + "\n";
        else if (error == "hwid_mismatch")
            errMsg = std::string(C_PURPLE) + "[nyx] " + C_RED + "Key activated on another machine. Contact admin for reset." + C_RESET + "\n";
        else if (error == "expired")
            errMsg = std::string(C_PURPLE) + "[nyx] " + C_RED + "License expired." + C_RESET + "\n";
        else if (error == "revoked")
            errMsg = std::string(C_PURPLE) + "[nyx] " + C_RED + "License revoked." + C_RESET + "\n";
        else if (error == "banned")
            errMsg = std::string(C_PURPLE) + "[nyx] " + C_RED + "You are banned." + C_RESET + "\n";
        else
            errMsg = std::string(C_PURPLE) + "[nyx] " + C_RED + "Activation failed: " + error + C_RESET + "\n";

        ConsolePrint(errMsg);
        return false;
    }

} // namespace UNIx
