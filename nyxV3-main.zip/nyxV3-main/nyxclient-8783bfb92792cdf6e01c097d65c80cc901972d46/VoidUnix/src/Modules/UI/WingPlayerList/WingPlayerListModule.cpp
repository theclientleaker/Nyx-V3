#include <Modules/UI/WingPlayerList/WingPlayerListModule.hpp>
#include <Core/ModuleManager.hpp>
#include <Core/QuickMenuEx.hpp>
#include <Core/PlayerCache/PlayerCache.hpp>
#include <Core/Globals.hpp>
#include <Core/FileLog/FileLog.hpp>
#include <Bootstrap.Module/include/bootstrap_module.hpp>

#include <IL2CPP.Module/include/Unity/GameObject.hpp>
#include <IL2CPP.Module/include/Unity/Transform.hpp>
#include <IL2CPP.Module/include/Unity/Component.hpp>
#include <IL2CPP.Module/include/Unity/Object.hpp>
#include <IL2CPP.Module/include/Unity/RectTransform.hpp>
#include <IL2CPP.Module/include/Unity/TMP_Text.hpp>
#include <IL2CPP.Module/include/Unity/Image.hpp>
#include <IL2CPP.Module/include/Unity/CanvasGroup.hpp>
#include <IL2CPP.Module/include/Unity/ScrollRect.hpp>
#include <IL2CPP.Module/include/Unity/ContentSizeFitter.hpp>
#include <IL2CPP.Module/include/Unity/Texture2D.hpp>
#include <IL2CPP.Module/include/Unity/Sprite.hpp>
#include <IL2CPP.Module/include/Unity/Time.hpp>
#include <IL2CPP.Module/include/Reflection.hpp>
#include <IL2CPP.Module/include/MethodHandler.hpp>

#include <Bootstrap.Module/include/VRChat/VRCPlayerApi.hpp>

#include <Core/SpriteLoader/SpriteLoader.hpp>
#include "resource.h"

#include <algorithm>
#include <string>
#include <vector>
#include <cstring>
#include <cmath>

namespace UNIx {

    using namespace IL2CPP::Module;
    using namespace IL2CPP::Module::Unity;

    WingPlayerListModule* WingPlayerListModule::s_instance = nullptr;

    WingPlayerListModule::WingPlayerListModule()
        : BaseModule("Wing Player List", "Player list on right wing menu", 0, "UI") {
        m_enabled = true;
        m_showInQuickMenu = true;
    }

    // ---- QM Callbacks ----

    void __cdecl WingPlayerListModule::QmFontSizeCb(uint32_t, float val) {
        if (!s_instance) return;
        s_instance->m_fontSize = val;
        if (s_instance->m_tmpComponent) {
            TMP_Text tmp(s_instance->m_tmpComponent);
            tmp.SetFontSize(val);
        }
    }
    void __cdecl WingPlayerListModule::QmPanelWidthCb(uint32_t, float val) {
        if (!s_instance) return;
        s_instance->m_panelWidth = val;
        if (s_instance->m_panelObject) {
            GameObject p(s_instance->m_panelObject);
            auto rt = p.GetComponentByName("UnityEngine.RectTransform");
            if (rt.valid()) RectTransform(rt.raw()).SetSizeDelta({val, s_instance->m_panelHeight});
        }
    }
    void __cdecl WingPlayerListModule::QmPanelHeightCb(uint32_t, float val) {
        if (!s_instance) return;
        s_instance->m_panelHeight = val;
        if (s_instance->m_panelObject) {
            GameObject p(s_instance->m_panelObject);
            auto rt = p.GetComponentByName("UnityEngine.RectTransform");
            if (rt.valid()) RectTransform(rt.raw()).SetSizeDelta({s_instance->m_panelWidth, val});
        }
    }
    void __cdecl WingPlayerListModule::QmShowPlatformCb(uint32_t, bool val) {
        if (s_instance) s_instance->m_showPlatform = val;
    }
    void __cdecl WingPlayerListModule::QmShowHostCb(uint32_t, bool val) {
        if (s_instance) s_instance->m_showHost = val;
    }

    void WingPlayerListModule::OnSetupQuickMenu(uint32_t moduleId, uint32_t categoryPageId) {
        s_instance = this;
        auto& qmEx = QuickMenuEx::Get();
        uint32_t fold = qmEx.add_foldout(moduleId, categoryPageId, "Wing Player List", false, true);
        qmEx.add_settings_toggle(moduleId, fold, "Show Platform Tags", m_showPlatform,
            QmShowPlatformCb, "wing_playerlist_platform");
        qmEx.add_settings_toggle(moduleId, fold, "Show Host Tag", m_showHost,
            QmShowHostCb, "wing_playerlist_host");
        qmEx.add_separator(moduleId, fold);
        qmEx.add_slider(moduleId, fold, "Font Size", 5.0f, 20.0f, m_fontSize,
            QmFontSizeCb, "wing_playerlist_fontsize", "%.0f");
        qmEx.add_slider(moduleId, fold, "Panel Width", 300.0f, 1000.0f, m_panelWidth,
            QmPanelWidthCb, "wing_playerlist_width", "%.0f");
        qmEx.add_slider(moduleId, fold, "Panel Height", 100.0f, 800.0f, m_panelHeight,
            QmPanelHeightCb, "wing_playerlist_height", "%.0f");
    }

    // ---- Enable/Disable lifecycle ----

    void WingPlayerListModule::OnEnable() {
        SetPanelVisible(true);
    }

    void WingPlayerListModule::OnDisable() {
        SetPanelVisible(false);
    }

    void WingPlayerListModule::SetPanelVisible(bool visible) {
        if (!m_panelObject) return;
        GameObject panel(m_panelObject);
        if (!panel.IsValid()) { m_panelObject = nullptr; return; }
        if (visible) {
            auto qm = GameObject::Find("Canvas_QuickMenu(Clone)");
            bool qmOpen = qm.IsValid() && qm.GetActive();
            if (qmOpen) {
                panel.SetActive(true);
                auto t = panel.GetTransform();
                auto& tw = Bootstrap::Module::TweenService::Get();
                tw.local_scale(g_mod->id(), t.raw(), 0.95f, 0.95f, 0.95f, 1.f, 1.f, 1.f, 200.f, 2);
            }
        } else {
            panel.SetActive(false);
        }
    }

    // ---- Lifecycle ----

    void WingPlayerListModule::OnSceneLoad(int, int) {
        Cleanup();
    }

    void WingPlayerListModule::OnUpdate() {
        if (!m_initialized) {
            if (m_initFailed) return;
            m_initDelay -= Time::GetDeltaTime();
            if (m_initDelay <= 0.f)
                InitializePanel();
            return;
        }

        if (!m_panelObject) return;

        GameObject panel(m_panelObject);
        if (!panel.IsValid()) {
            m_panelObject = nullptr;
            m_tmpComponent = nullptr;
            m_titleTmpComp = nullptr;
            m_bgImageComp = nullptr;
            m_initialized = false;
            m_initDelay = 2.0f;
            return;
        }

        auto qm = GameObject::Find("Canvas_QuickMenu(Clone)");
        bool shouldShow = qm.IsValid() && qm.GetActive();
        panel.SetActive(shouldShow);

        if (!shouldShow) return;

        if (m_bgImageComp) {
            Object bgObj(m_bgImageComp);
            if (!bgObj.IsValid()) { m_bgImageComp = nullptr; }
            else {
                m_glowTimer += Time::GetDeltaTime();
                float pulse = 0.06f + 0.02f * std::sin(m_glowTimer * 1.5f);
                static auto setColor = MethodHandler::resolve("UnityEngine.UI.Graphic", "set_color", 1);
                if (setColor) {
                    IL2CPP::Color col{pulse, pulse, pulse * 1.1f, 0.75f};
                    void* cp[] = { &col };
                    MethodHandler::invoke(setColor, m_bgImageComp, cp);
                }
            }
        }

        if (!InRoom()) return;

        m_updateTimer += Time::GetDeltaTime();
        if (m_updateTimer >= 0.5f) {
            m_updateTimer = 0.f;
            UpdatePlayerText();
        }
    }

    // ---- Helper: clone a TMP GO from the QM hierarchy ----

    static void NullLocalizableString(void* tmpComp) {
        if (tmpComp)
            *reinterpret_cast<void**>(static_cast<char*>(tmpComp) + 0x7a8) = nullptr;
    }

    static void* CloneTmpFromQM(GameObject& qm, Transform& qmT) {
        auto tmpClass = Class::find("TMPro.TextMeshProUGUI");
        if (!tmpClass) return nullptr;

        auto qmParentT = qmT.Find("CanvasGroup/Container/Window/QMParent");
        if (!qmParentT.valid()) return nullptr;

        auto qmParentGO = qmParentT.GetGameObject();
        if (!qmParentGO.valid()) return nullptr;

        auto templateComp = qmParentGO.GetComponentInChildren(tmpClass, true);
        if (!templateComp.valid()) return nullptr;

        static auto getGO = MethodHandler::resolve("UnityEngine.Component", "get_gameObject", 0);
        if (!getGO) return nullptr;

        void* srcRaw = MethodHandler::invoke<void*>(getGO, templateComp.raw());
        if (!srcRaw) return nullptr;

        GameObject srcGO(srcRaw);
        auto clone = srcGO.Instantiate();
        if (!clone.raw() || !clone.IsValid()) return nullptr;

        GameObject clonedGO(clone.raw());
        clonedGO.SetActive(true);

        // Strip children
        auto t = clonedGO.GetTransform();
        for (int i = t.GetChildCount() - 1; i >= 0; --i) {
            auto child = t.GetChild(i);
            if (child.valid()) {
                auto childGO = child.GetGameObject();
                if (childGO.valid()) childGO.Destroy();
            }
        }

        // Strip VRC style
        auto se = clonedGO.GetComponentByName("VRC.UI.Core.Styles.StyleElement");
        if (se.valid()) Object(se.raw()).Destroy();

        auto tmpComp = clonedGO.GetComponentByName("TMPro.TextMeshProUGUI");
        if (tmpComp.valid())
            NullLocalizableString(tmpComp.raw());

        return clone.raw();
    }

    // ---- Panel creation ----

    void WingPlayerListModule::InitializePanel() {
        m_panelObject = nullptr;
        m_tmpComponent = nullptr;
        m_titleTmpComp = nullptr;
        m_bgImageComp = nullptr;

        auto qm = GameObject::Find("Canvas_QuickMenu(Clone)");
        if (!qm.IsValid()) { m_initDelay = 2.0f; return; }

        auto qmT = qm.GetTransform();

        auto bgLayerT = qmT.Find("CanvasGroup/Container/Window/QMParent/BackgroundLayer01");
        if (!bgLayerT.valid()) { m_initDelay = 2.0f; return; }

        auto wingBtnT = qmT.Find("CanvasGroup/Container/Window/Wing_Right/Button");
        if (!wingBtnT.valid()) { m_initDelay = 2.0f; return; }

        auto bgLayerGO = bgLayerT.GetGameObject();
        if (!bgLayerGO.valid()) { m_initDelay = 2.0f; return; }

        static auto instantiateMethod = MethodHandler::resolve("UnityEngine.Object", "Instantiate", 1);
        if (!instantiateMethod) { m_initFailed = true; return; }

        void* cloneParams[] = { bgLayerGO.raw() };
        void* cloneRaw = MethodHandler::invoke<void*>(instantiateMethod, nullptr, cloneParams);
        if (!cloneRaw) {
            if (++m_initRetries >= 5) m_initFailed = true;
            else m_initDelay = 3.0f;
            return;
        }

        GameObject panel(cloneRaw);
        panel.SetActive(false);
        m_panelObject = cloneRaw;
        auto panelT = panel.GetTransform();
        if (!panelT.valid()) { m_initFailed = true; return; }

        // Destroy children
        for (int i = panelT.GetChildCount() - 1; i >= 0; --i) {
            auto child = panelT.GetChild(i);
            if (child.valid()) {
                auto childGO = child.GetGameObject();
                if (childGO.valid()) Object(childGO.raw()).Destroy();
            }
        }

        // Reparent
        panelT.SetParent(Transform(wingBtnT.raw()), false);
        panelT.SetLocalScale({1.f, 1.f, 1.f});
        panelT.SetLocalPosition({520.f, 0.f, 0.f});

        RectTransform panelRT(panelT.raw());
        panelRT.SetSizeDelta({m_panelWidth, m_panelHeight});

        // Strip VRC components
        auto vrcBg = panel.GetComponentByName("VRC.UI.Core.Styles.VRCUIBackground");
        if (vrcBg.valid()) Object(vrcBg.raw()).Destroy();
        auto styleElem = panel.GetComponentByName("VRC.UI.Core.Styles.StyleElement");
        if (styleElem.valid()) Object(styleElem.raw()).Destroy();

        // ---- Set up Image with custom rounded sprite ----

        auto imageComp = panel.GetComponentByName("VRC.UI.Core.Styles.ImageEx");
        if (!imageComp.valid())
            imageComp = panel.GetComponentByName("UnityEngine.UI.Image");
        if (!imageComp.valid()) {
            auto imgClass = Class::find("UnityEngine.UI.Image");
            if (imgClass) imageComp = panel.AddComponent(imgClass);
        }

        if (imageComp.valid()) {
            m_bgImageComp = imageComp.raw();

            // Dark translucent background
            static auto setColor = MethodHandler::resolve("UnityEngine.UI.Graphic", "set_color", 1);
            if (setColor) {
                IL2CPP::Color col{0.06f, 0.06f, 0.07f, 0.75f};
                void* cp[] = { &col };
                MethodHandler::invoke(setColor, imageComp.raw(), cp);
            }

            void* panelSprite = SpriteLoader::Get().LoadFromResource(IDR_PANEL_BG, "panel_bg");
            if (panelSprite) {
                static auto setSprite = MethodHandler::resolve("UnityEngine.UI.Image", "set_sprite", 1);
                if (setSprite) {
                    void* sp[] = { panelSprite };
                    MethodHandler::invoke(setSprite, imageComp.raw(), sp);
                }
                static auto setOverride = MethodHandler::resolve("UnityEngine.UI.Image", "set_overrideSprite", 1);
                if (setOverride) {
                    void* sp[] = { panelSprite };
                    MethodHandler::invoke(setOverride, imageComp.raw(), sp);
                }
            }

            static auto setRaycast = MethodHandler::resolve("UnityEngine.UI.Graphic", "set_raycastTarget", 1);
            if (setRaycast) {
                bool off = false;
                void* rp[] = { &off };
                MethodHandler::invoke(setRaycast, imageComp.raw(), rp);
            }
        }

        // CanvasGroup
        auto cgClass = Class::find("UnityEngine.CanvasGroup");
        if (cgClass) {
            auto cg = panel.AddComponent(cgClass);
            if (cg.valid()) {
                CanvasGroup(cg.raw()).SetBlocksRaycasts(true);
                CanvasGroup(cg.raw()).SetInteractable(true);
            }
        }

        // ---- Header: "Players (N)" ----

        void* headerRaw = CloneTmpFromQM(qm, qmT);
        if (headerRaw) {
            GameObject headerGO(headerRaw);
            auto headerT = headerGO.GetTransform();
            headerT.SetParent(panelT, false);

            RectTransform hrt(headerT.raw());
            hrt.SetAnchorMin({0.f, 1.f});
            hrt.SetAnchorMax({1.f, 1.f});
            hrt.SetPivot({0.5f, 1.f});
            hrt.SetSizeDelta({0.f, 45.f});
            hrt.SetAnchoredPosition({0.f, 0.f});

            auto hComp = headerGO.GetComponentByName("TMPro.TextMeshProUGUI");
            if (hComp.valid()) {
                m_titleTmpComp = hComp.raw();
                TMP_Text htmp(hComp.raw());
                static auto setAutoSize = MethodHandler::resolve("TMPro.TMP_Text", "set_enableAutoSizing", 1);
                if (setAutoSize) { bool off = false; void* ap[] = { &off }; MethodHandler::invoke(setAutoSize, hComp.raw(), ap); }
                htmp.SetText("<b>Players</b>");
                htmp.SetRichText(true);
                htmp.SetFontSize(m_fontSize + 1.f);
                htmp.SetAlignment(514); // MiddleCenter
                htmp.SetColor(IL2CPP::Color(0.7f, 0.75f, 0.85f, 0.9f));
                htmp.SetEnableWordWrapping(false);

                static auto sr = MethodHandler::resolve("UnityEngine.UI.Graphic", "set_raycastTarget", 1);
                if (sr) { bool off = false; void* rp[] = { &off }; MethodHandler::invoke(sr, hComp.raw(), rp); }
            }
        }

        // ---- Scrollable body area ----

        void* scrollClone = CloneTmpFromQM(qm, qmT);
        if (!scrollClone) { m_initDelay = 3.0f; return; }
        GameObject scrollGO(scrollClone);
        auto scrollTmpComp = scrollGO.GetComponentByName("TMPro.TextMeshProUGUI");
        if (scrollTmpComp.valid()) Object(scrollTmpComp.raw()).Destroy();

        auto scrollT = scrollGO.GetTransform();
        scrollT.SetParent(panelT, false);
        RectTransform scrollRT(scrollT.raw());
        scrollRT.SetAnchorMin({0.f, 0.f});
        scrollRT.SetAnchorMax({1.f, 1.f});
        scrollRT.SetPivot({0.f, 1.f});
        scrollRT.SetSizeDelta({-20.f, -50.f});
        scrollRT.SetAnchoredPosition({10.f, -48.f});

        auto maskClass = Class::find("UnityEngine.UI.RectMask2D");
        if (maskClass) scrollGO.AddComponent(maskClass);

        // ---- Body TMP (scroll content) ----

        void* bodyRaw = CloneTmpFromQM(qm, qmT);
        if (!bodyRaw) {
            m_initDelay = 3.0f;
            return;
        }

        GameObject bodyGO(bodyRaw);
        auto bodyT = bodyGO.GetTransform();
        bodyT.SetParent(scrollT, false);

        RectTransform brt(bodyT.raw());
        brt.SetAnchorMin({0.f, 1.f});
        brt.SetAnchorMax({1.f, 1.f});
        brt.SetPivot({0.f, 1.f});
        brt.SetSizeDelta({0.f, 0.f});
        brt.SetAnchoredPosition({5.f, 0.f});

        auto bodyComp = bodyGO.GetComponentByName("TMPro.TextMeshProUGUI");
        if (!bodyComp.valid()) {
            m_initDelay = 3.0f;
            return;
        }

        m_tmpComponent = bodyComp.raw();

        TMP_Text tmp(m_tmpComponent);
        static auto setAutoSize2 = MethodHandler::resolve("TMPro.TMP_Text", "set_enableAutoSizing", 1);
        if (setAutoSize2) { bool off = false; void* ap[] = { &off }; MethodHandler::invoke(setAutoSize2, bodyComp.raw(), ap); }
        tmp.SetText("");
        tmp.SetRichText(true);
        tmp.SetFontSize(m_fontSize);
        tmp.SetAlignment(1025); // TopLeft
        tmp.SetColor(IL2CPP::Color(0.9f, 0.9f, 0.9f, 0.9f));
        tmp.SetEnableWordWrapping(false);

        static auto setOverflow = MethodHandler::resolve("TMPro.TMP_Text", "set_overflowMode", 1);
        if (setOverflow) {
            int overflow = 0;
            void* op[] = { &overflow };
            MethodHandler::invoke(setOverflow, bodyComp.raw(), op);
        }

        auto csfClass = Class::find("UnityEngine.UI.ContentSizeFitter");
        if (csfClass) {
            auto csf = bodyGO.AddComponent(csfClass);
            if (csf.valid()) {
                ContentSizeFitter f(csf.raw());
                f.SetVerticalFit(2);   // PreferredSize
                f.SetHorizontalFit(0); // Unconstrained
            }
        }

        auto srClass = Class::find("UnityEngine.UI.ScrollRect");
        if (srClass) {
            auto srComp = scrollGO.AddComponent(srClass);
            if (srComp.valid()) {
                ScrollRect sr(srComp.raw());
                sr.SetContent(brt.raw());
                sr.SetViewport(scrollRT.raw());
                sr.SetVertical(true);
                sr.SetHorizontal(false);
                sr.SetMovementType(2);  // Clamped
                sr.SetScrollSensitivity(25.f);
                sr.SetInertia(true);
                sr.SetDecelerationRate(0.1f);
            }
        }

        panel.SetActive(true);
        m_initialized = true;

        auto& tw = Bootstrap::Module::TweenService::Get();
        tw.anchored_position(g_mod->id(), panelT.raw(), 620.f, 0.f, 520.f, 0.f, 300.f, 2);
    }

    // ---- Player text ----

    static std::string BrightenHex(const std::string& hex) {
        unsigned int r = 0, g = 0, b = 0;
        if (hex.size() == 6) {
            r = std::stoul(hex.substr(0, 2), nullptr, 16);
            g = std::stoul(hex.substr(2, 2), nullptr, 16);
            b = std::stoul(hex.substr(4, 2), nullptr, 16);
        }
        r = (std::min)(static_cast<unsigned int>(r * 1.4f), 255u);
        g = (std::min)(static_cast<unsigned int>(g * 1.4f), 255u);
        b = (std::min)(static_cast<unsigned int>(b * 1.4f), 255u);
        char buf[8];
        snprintf(buf, sizeof(buf), "%02X%02X%02X", r, g, b);
        return buf;
    }

    static std::string RankColorHex(IL2CPP::VRChat::PlayerRank rank) {
        switch (rank) {
            case IL2CPP::VRChat::PlayerRank::Visitor:       return BrightenHex("CCCCCC");
            case IL2CPP::VRChat::PlayerRank::NewUser:         return BrightenHex("2BCF5C");
            case IL2CPP::VRChat::PlayerRank::User:         return BrightenHex("FF7A42");
            case IL2CPP::VRChat::PlayerRank::Known:       return BrightenHex("C73DFF");
            case IL2CPP::VRChat::PlayerRank::Trusted:       return BrightenHex("FF6666");
            case IL2CPP::VRChat::PlayerRank::Administrator: return BrightenHex("8B0000");
            case IL2CPP::VRChat::PlayerRank::Troll:         return BrightenHex("808080");
            default: return "FFFFFF";
        }
    }

    void WingPlayerListModule::UpdatePlayerText() {
        if (!m_tmpComponent || !InRoom()) return;

        auto& cache = ModuleManager::Get().GetPlayerCache();
        auto playersSnap = cache.GetPlayers();
        std::vector<PlayerEntry> players = *playersSnap;
        if (players.empty()) {
            TMP_Text tmp(m_tmpComponent);
            tmp.SetText("<color=#666666><i>No players in lobby</i></color>");
            if (m_titleTmpComp) {
                TMP_Text htmp(m_titleTmpComp);
                htmp.SetText("<b>Players (0)</b>");
            }
            return;
        }

        // Get local player position for distance calc
        IL2CPP::Vector3 localPos{0, 0, 0};
        bool hasLocalPos = false;
        auto localApi = IL2CPP::VRChat::VRCPlayerApi::GetLocalPlayer();
        if (localApi.raw() && localApi.IsValid()) {
            localPos = localApi.GetPosition();
            hasLocalPos = true;
        }

        std::sort(players.begin(), players.end(), [](const PlayerEntry& a, const PlayerEntry& b) {
            if (a.isLocal != b.isLocal) return a.isLocal;
            return static_cast<int>(a.rank) > static_cast<int>(b.rank);
        });

        if (m_titleTmpComp) {
            TMP_Text htmp(m_titleTmpComp);
            std::string title = "<b>Players (" + std::to_string(players.size()) + ")</b>";
            htmp.SetText(title);
        }

        std::string text;
        text.reserve(players.size() * 128);
        char buf[32];
        for (size_t i = 0; i < players.size() && i < 80; ++i) {
            auto& p = players[i];
            std::string color = RankColorHex(p.rank);

            if (i > 0) text += "\n";

            if (p.isLocal)
                text += "<color=#" + color + "><b>" + p.displayName + "</b>";
            else
                text += "<color=#" + color + ">" + p.displayName;

            if (m_showPlatform) {
                if (p.isQuest)
                    text += " <size=75%><color=#AAAAAA>[Q]</color></size>";
                else if (p.isVR)
                    text += " <size=75%><color=#BB66FF>[VR]</color></size>";
                else
                    text += " <size=75%><color=#6BBAFF>[PC]</color></size>";
            }

            if (m_showHost && p.isMaster)
                text += " <size=75%><color=#FFD700>[H]</color></size>";

            if (p.isFriend)
                text += " <size=75%><color=#FFD000>[F]</color></size>";

            if (p.playerId > 0) {
                auto api = IL2CPP::VRChat::VRCPlayerApi::GetPlayerById(p.playerId);
                if (api.raw() && api.IsValid()) {
                    auto pos = api.GetPosition();

                    if (!p.isLocal && hasLocalPos) {
                        float dist = IL2CPP::Vector3::Distance(localPos, pos);
                        snprintf(buf, sizeof(buf), "%.1fm", dist);
                        text += " <size=80%><color=#" + color + ">" + buf + "</color></size>";
                    }

                    snprintf(buf, sizeof(buf), "(%.0f, %.0f, %.0f)", pos.x, pos.y, pos.z);
                    text += " <size=75%><color=#" + color + ">" + buf + "</color></size>";

                    if (!api.IsPlayerGrounded())
                        text += " <size=75%><color=#FF9944>[AIR]</color></size>";
                }
            }

            text += "</color>";
        }

        if (!m_tmpComponent) return;
        Object tmpChk(m_tmpComponent);
        if (!tmpChk.IsValid()) { m_tmpComponent = nullptr; return; }
        TMP_Text tmp(m_tmpComponent);
        tmp.SetText(text);
    }

    // ---- Cleanup ----

    void WingPlayerListModule::Cleanup() {
        if (m_panelObject) {
            GameObject panel(m_panelObject);
            if (panel.IsValid())
                Object(m_panelObject).Destroy();
        }
        m_panelObject = nullptr;
        m_tmpComponent = nullptr;
        m_titleTmpComp = nullptr;
        m_bgImageComp = nullptr;
        m_initialized = false;
        m_initFailed = false;
        m_initRetries = 0;
        m_initDelay = 2.0f;
    }

} // namespace UNIx
