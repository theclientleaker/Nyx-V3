#pragma once

#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#include <string>
#include <thread>
#include <mutex>
#include <atomic>
#include <vector>
#include <queue>
#include <deque>
#include <future>

namespace UNIx {

    class DebugBridge {
    public:
        static DebugBridge& Get();

        void Start();
        void Stop();
        void ProcessCommands();

    private:
        DebugBridge() = default;

        void ServerLoop();
        void HandleClient(uintptr_t clientSock);
        std::string ExecuteCommand(const std::string& method, const std::string& json);

        std::string CmdListGameObjects(const std::string& json);
        std::string CmdInspectGameObject(const std::string& json);
        std::string CmdSearchScene(const std::string& json);
        std::string CmdSetGameObjectActive(const std::string& json);
        std::string CmdGetHierarchy(const std::string& json);
        std::string CmdFindObjectsOfType(const std::string& json);
        std::string CmdGetMaterials(const std::string& json);
        std::string CmdInspectComponent(const std::string& json);

        std::string CmdFindClass(const std::string& json);
        std::string CmdFilterClass(const std::string& json);
        std::string CmdInspectClass(const std::string& json);
        std::string CmdCallMethod(const std::string& json);
        std::string CmdReadField(const std::string& json);
        std::string CmdSetField(const std::string& json);

        std::string CmdListPlayers(const std::string& json);
        std::string CmdGetPlayerInfo(const std::string& json);
        std::string CmdGetAvatarInfo(const std::string& json);
        std::string CmdTeleport(const std::string& json);
        std::string CmdSetMovement(const std::string& json);

        std::string CmdGetWorldInfo(const std::string& json);
        std::string CmdGetNetworkInfo(const std::string& json);
        std::string CmdGetPhotonInfo(const std::string& json);

        std::string CmdListUdonBehaviours(const std::string& json);
        std::string CmdGetUdonVariables(const std::string& json);
        std::string CmdSendUdonEvent(const std::string& json);

        std::string CmdRaycast(const std::string& json);

        std::string CmdListAnimations(const std::string& json);

        std::string CmdReadLog(const std::string& json);
        std::string CmdSendLog(const std::string& json);
        std::string CmdGetScreenInfo(const std::string& json);
        std::string CmdGetCameraInfo(const std::string& json);
        std::string CmdSetCamera(const std::string& json);
        std::string CmdGetTimeInfo(const std::string& json);
        std::string CmdGetAudioSources(const std::string& json);

        std::string CmdListModules(const std::string& json);
        std::string CmdToggleModule(const std::string& json);
        std::string CmdGetConfig(const std::string& json);
        std::string CmdSetConfig(const std::string& json);

        std::string CmdPlayerAction(const std::string& json);
        std::string CmdTeleportToPlayer(const std::string& json);
        std::string CmdSetAnimatorParam(const std::string& json);
        std::string CmdTakeOwnership(const std::string& json);
        std::string CmdGetOwnership(const std::string& json);
        std::string CmdSetRigidbody(const std::string& json);
        std::string CmdAddForce(const std::string& json);
        std::string CmdSetTransform(const std::string& json);
        std::string CmdSendNetworkUdonEvent(const std::string& json);
        std::string CmdSetUdonVariable(const std::string& json);
        std::string CmdGoToRoom(const std::string& json);
        std::string CmdBatch(const std::string& json);
        std::string CmdGetInput(const std::string& json);
        std::string CmdSetTimeScale(const std::string& json);
        std::string CmdDestroyObject(const std::string& json);
        std::string CmdInstantiateObject(const std::string& json);
        std::string CmdFindByTag(const std::string& json);
        std::string CmdSetComponentEnabled(const std::string& json);
        std::string CmdSetLayer(const std::string& json);
        std::string CmdSetParent(const std::string& json);
        std::string CmdWorldToScreen(const std::string& json);
        std::string CmdSetMaterial(const std::string& json);
        std::string CmdAudioControl(const std::string& json);
        std::string CmdOverlapSphere(const std::string& json);
        std::string CmdScreenToRay(const std::string& json);
        std::string CmdGetAllBones(const std::string& json);
        std::string CmdSetShader(const std::string& json);
        std::string CmdGetPlayerByName(const std::string& json);

        std::string CmdStartUdonMonitor(const std::string& json);
        std::string CmdStopUdonMonitor(const std::string& json);
        std::string CmdGetUdonEvents(const std::string& json);

        static bool PrefixUdonSendCustomEvent(void* thisPtr, void* eventNameStr);

        struct UdonEventEntry {
            std::string gameObject;
            std::string eventName;
            uint64_t timestamp;
        };

        std::mutex m_udonEventsMutex;
        std::deque<UdonEventEntry> m_udonEvents;
        std::atomic<bool> m_udonMonitorActive{false};
        bool m_udonHookInstalled = false;
        uint32_t m_udonHookId = ~0u;

        struct PendingCommand {
            std::string method;
            std::string json;
            std::promise<std::string> result;
        };

        std::thread m_thread;
        std::atomic<bool> m_running{false};

        std::mutex m_queueMutex;
        std::queue<PendingCommand> m_commandQueue;

        std::mutex m_clientsMutex;
        std::vector<std::thread> m_clientThreads;
    };

}
