#pragma once
#include <Core/BaseModule.hpp>

namespace UNIx {

    class ZoomModule : public BaseModule {
    public:
        ZoomModule() : BaseModule("Zoom", "Optifine-style zoom (hold Left Alt)", 0, "Visual") {
            m_enabled = true;
            m_showInQuickMenu = false;
        }

        bool OnEvent(uint32_t msg, uintptr_t wParam, intptr_t lParam) override;
        void OnUpdate() override;
        void OnSceneLoad(int scene, int loadMode) override;

    private:
        bool  m_active = false;
        float m_originalFov = 0.f;
        float m_zoomFov = 20.f;
        float m_currentFov = 0.f;
        static constexpr float kLerpSpeed = 10.f;
    };

} // namespace UNIx
