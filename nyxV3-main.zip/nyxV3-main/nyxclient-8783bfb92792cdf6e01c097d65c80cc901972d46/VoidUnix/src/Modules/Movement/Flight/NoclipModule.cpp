#include <Modules/Movement/Flight/NoclipModule.hpp>
#include <ThirdParty/imgui/imgui.h>

#include <IL2CPP.Module/include/Unity/Transform.hpp>
#include <IL2CPP.Module/include/Unity/GameObject.hpp>
#include <IL2CPP.Module/include/Unity/Input.hpp>
#include <IL2CPP.Module/include/Unity/Time.hpp>
#include <Bootstrap.Module/include/VRChat/VRCPlayerApi.hpp>
#include <Bootstrap.Module/include/VRChat/VRCPlayer.hpp>
#include <Bootstrap.Module/include/bootstrap_module.hpp>
#include <Core/QuickMenuEx.hpp>
#include <Core/Globals.hpp>

using namespace IL2CPP::Module::Unity;

namespace UNIx {

    NoclipModule* NoclipModule::s_instance = nullptr;

    NoclipModule::NoclipModule()
        : BaseModule("Noclip", "Fly through walls", 'F', "Movement") {
    }

    void __cdecl NoclipModule::QmFlySpeedCb(uint32_t, float val) { if (s_instance) s_instance->m_flySpeed = val; }
    void __cdecl NoclipModule::QmSprintMultCb(uint32_t, float val) { if (s_instance) s_instance->m_flySpeedMultiplier = val; }

    void NoclipModule::OnSetupQuickMenu(uint32_t moduleId, uint32_t categoryPageId) {
        s_instance = this;
        auto& qmEx = QuickMenuEx::Get();

        uint32_t fold = qmEx.add_foldout(moduleId, categoryPageId, "Noclip", false, true);
        qmEx.add_slider(moduleId, fold, "Fly Speed", 1.0f, 50.0f, m_flySpeed,
            QmFlySpeedCb, "noclip_fly_speed", "");
        qmEx.add_slider(moduleId, fold, "Sprint Multiplier", 1.0f, 10.0f, m_flySpeedMultiplier,
            QmSprintMultCb, "noclip_sprint_mult", "");
    }

    void NoclipModule::SetCharacterControllerEnabled(bool enabled) {
        auto vrcPlayer = IL2CPP::VRChat::VRCPlayer::GetLocalPlayer();
        if (!vrcPlayer.valid()) return;

        auto go = vrcPlayer.GetGameObject();
        if (!go.valid()) return;

        auto charController = go.GetComponentByName("CharacterController");
        if (charController.valid())
            charController.set_property<bool>("enabled", enabled);

        auto collider = go.GetComponentByName("Collider");
        if (collider.valid())
            collider.set_property<bool>("enabled", enabled);
    }

    void NoclipModule::OnDisable() {
        if (m_wasActive) {
            auto api = GetLocalPlayerApi();
            if (api.valid()) {
                api.Immobilize(false);
                api.SetGravityStrength(1.0f);
            }
            SetCharacterControllerEnabled(true);
            m_wasActive = false;
        }
    }

    void NoclipModule::OnUpdate() {
        auto api = GetLocalPlayerApi();
        if (!api.valid()) return;

        if (!m_wasActive) {
            api.Immobilize(true);
            m_wasActive = true;
        }

        api.UseLegacyLocomotion();
        api.SetGravityStrength(0.f);
        api.SetVelocity(IL2CPP::Vector3(0.f, 0.f, 0.f));
        SetCharacterControllerEnabled(false);

        IL2CPP::Quaternion headRot = api.GetTrackingData(IL2CPP::VRChat::TrackingDataType::Head).rotation;
        IL2CPP::Vector3 forward = headRot.Forward();
        IL2CPP::Vector3 right = headRot.Right();

        float moveX = Input::GetAxisRaw("Horizontal");
        float moveZ = Input::GetAxisRaw("Vertical");
        float moveY = 0.f;

        if (Input::GetKey(IL2CPP::KeyCode::E))
            moveY += 1.f;
        if (Input::GetKey(IL2CPP::KeyCode::Q))
            moveY -= 1.f;

        IL2CPP::Vector3 moveDir = forward * moveZ + right * moveX + IL2CPP::Vector3(0.f, moveY, 0.f);
        float len = moveDir.Magnitude();
        if (len < 0.001f) return;

        moveDir = moveDir * (1.f / len);

        float speed = m_flySpeed;
        if (Input::GetKey(IL2CPP::KeyCode::LeftShift))
            speed *= m_flySpeedMultiplier;

        float dt = Time::GetDeltaTime();
        IL2CPP::Vector3 delta = moveDir * speed * dt;

        IL2CPP::Vector3 currentPos = api.GetPosition();
        IL2CPP::Quaternion currentRot = api.GetRotation();

        api.TeleportTo(currentPos + delta, currentRot, IL2CPP::VRChat::SpawnOrientation::Default, true);
    }

    void NoclipModule::OnRender() {
        ImGui::SliderFloat("Fly Speed", &m_flySpeed, 1.0f, 50.0f);
        ImGui::SliderFloat("Sprint Multiplier", &m_flySpeedMultiplier, 1.0f, 10.0f);
    }

} // namespace UNIx
