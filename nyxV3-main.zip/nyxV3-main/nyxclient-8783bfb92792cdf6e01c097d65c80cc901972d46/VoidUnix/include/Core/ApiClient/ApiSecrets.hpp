#pragma once
#include <string>

namespace UNIx {

    struct ApiSecrets {
        static std::wstring Host();
        static std::wstring ClientAuth();
        static std::wstring AdminAuth();
        static std::string  ClientSecret();
    };

} // namespace UNIx
