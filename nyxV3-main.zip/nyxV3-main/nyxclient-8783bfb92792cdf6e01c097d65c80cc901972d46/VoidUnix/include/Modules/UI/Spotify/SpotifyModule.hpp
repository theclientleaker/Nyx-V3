#pragma once
#include <Core/BaseModule.hpp>
#include <string>
#include <cstdint>

namespace UNIx {

    class SpotifyModule : public BaseModule {
    public:
        SpotifyModule()
            : BaseModule("Spotify", "Media controls panel", 0, "UI")
        {
            m_enabled = true;
            m_showInQuickMenu = true;
        }

        void OnEnable() override;
        void OnDisable() override;
        void OnUpdate() override;
        void OnSceneLoad(int scene, int loadMode) override;
        void OnSetupQuickMenu(uint32_t moduleId, uint32_t categoryPageId) override;

        static SpotifyModule* s_instance;

    private:
        void CreateSpotifyPanel();
        void CreateMediaControls();
        void UpdatePanel();
        void HandleClicks();
        void DestroyPanel();
        void ResetState();

        static void SendMediaKey(uint8_t vk);
        static void SetTMP(void* tmpComp, const char* text, float fontSize = 0.f);
        static void* CloneTMP(void* templateGO, void* parent, const char* name);

        bool m_panelCreated = false;
        bool m_panelInjected = false;
        bool m_failed = false;
        float m_retryTimer = 0.f;
        int m_initDelay = 0;
        int m_updateSkip = 0;

        void* m_panelGO = nullptr;
        void* m_containerGO = nullptr;
        void* m_albumArtGO = nullptr;
        void* m_albumArtImage = nullptr;
        void* m_titleTMP = nullptr;
        void* m_artistTMP = nullptr;
        void* m_albumTMP = nullptr;
        void* m_timeTMP = nullptr;
        void* m_progressFillGO = nullptr;

        void* m_btnPrev = nullptr;
        void* m_btnPlayPause = nullptr;
        void* m_btnNext = nullptr;
        void* m_btnVolDown = nullptr;
        void* m_btnVolMute = nullptr;
        void* m_btnVolUp = nullptr;
        void* m_playPauseImage = nullptr;
        bool m_lastPlaying = false;

        uint64_t m_thumbHash = 0;
        std::string m_lastTitle;
        std::string m_lastArtist;
        std::string m_lastAlbum;
        std::string m_lastTime;

        float m_scrollX = 0.f;
        float m_scrollResetAt = 0.f;
        static constexpr float kScrollSpeed = 30.f;
        void* m_titleGO = nullptr;
        void* m_titleViewport = nullptr;

        int m_sceneGuard = 120;

        uint32_t m_moduleId = 0;
        uint32_t m_categoryPageId = 0;
    };

} // namespace UNIx
