#pragma once

#include <ThirdParty/imgui/imgui.h>

namespace UNIx {

    extern ImFont* g_fontSmallBold;
    extern ImFont* g_fontMediumBold;
    extern ImFont* g_fontBig;

    void InitializeFonts(ImGuiIO& io);
    void ApplyUNIxTheme();

} // namespace UNIx
