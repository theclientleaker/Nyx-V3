#include <Modules/Visual/HudStats/HudStatsModule.hpp>
#include <Core/FileLog/FileLog.hpp>
#include <Core/QuickMenuEx.hpp>
#include <Core/SpriteLoader/SpriteLoader.hpp>
#include <resource.h>

#include <IL2CPP.Module/include/il2cpp_module.hpp>
#include <IL2CPP.Module/include/Unity/Transform.hpp>
#include <IL2CPP.Module/include/Unity/RectTransform.hpp>
#include <IL2CPP.Module/include/Unity/TMP_Text.hpp>
#include <IL2CPP.Module/include/Unity/Image.hpp>
#include <IL2CPP.Module/include/Unity/Time.hpp>
#include <IL2CPP.Module/include/Unity/Object.hpp>
#include <IL2CPP.Module/include/MethodHandler.hpp>
#include <IL2CPP.Module/include/Reflection.hpp>

#include <cstdio>

using namespace IL2CPP::Module;
using namespace IL2CPP::Module::Unity;

namespace UNIx {

    HudStatsModule* HudStatsModule::s_instance = nullptr;
    static void* s_vrcPingTMP = nullptr;
    static bool s_vrcPingSearched = false;

    void __cdecl HudStatsModule::QmShowFpsCb(uint32_t, bool val) { if (s_instance) s_instance->m_showFps = val; }
    void __cdecl HudStatsModule::QmShowPingCb(uint32_t, bool val) { if (s_instance) s_instance->m_showPing = val; }

    HudStatsModule::HudStatsModule()
        : BaseModule("HUD Stats", "FPS and ping on HUD", 0, "Visual") {
        m_enabled = true;
        m_showInQuickMenu = true;
    }

    void HudStatsModule::Cleanup() {
        if (m_fpsRowGO) {
            try { Object o(m_fpsRowGO); if (o.IsValid()) o.Destroy(); } catch (...) {}
        }
        if (m_pingRowGO) {
            try { Object o(m_pingRowGO); if (o.IsValid()) o.Destroy(); } catch (...) {}
        }
        m_fpsRowGO = nullptr;
        m_pingRowGO = nullptr;
        m_fpsTMP = nullptr;
        m_pingTMP = nullptr;
        m_hudCreated = false;
        m_initDelay = 6.f;
    }

    void HudStatsModule::OnSceneLoad(int, int loadMode) {
        if (loadMode == 0) {
            m_fpsRowGO = nullptr;
            m_pingRowGO = nullptr;
            m_fpsTMP = nullptr;
            m_pingTMP = nullptr;
            m_hudCreated = false;
            m_initDelay = 6.f;
            m_ping = 0;
            s_vrcPingTMP = nullptr;
            s_vrcPingSearched = false;
        }
    }

    void HudStatsModule::OnSceneUnload(int, int) {
        m_fpsRowGO = nullptr;
        m_pingRowGO = nullptr;
        m_fpsTMP = nullptr;
        m_pingTMP = nullptr;
        m_hudCreated = false;
        m_initDelay = 6.f;
        s_vrcPingTMP = nullptr;
        s_vrcPingSearched = false;
    }

    static void SetupRow(void* rowRaw, void* iconSprite, const std::string& text,
                         float xPos, float yPos, float iconSize, float fontSize,
                         void** outTMP) {
        GameObject row(rowRaw);
        auto rowT = row.GetTransform();

        auto iconT = rowT.Find("Icon");
        if (iconT.valid()) {
            auto iconGO = iconT.GetGameObject();
            if (iconGO.valid()) {
                iconGO.SetActive(true);

                for (const char* comp : {
                    "VRC.UI.Core.Styles.StyleElement"
                }) {
                    try {
                        auto c = iconGO.GetComponentByName(comp);
                        if (c.valid()) Object(c.raw()).DestroyImmediate();
                    } catch (...) {}
                }

                auto imgComp = iconGO.GetComponentByName("UnityEngine.UI.Image");
                if (imgComp.valid() && iconSprite) {
                    static auto setSprite = MethodHandler::resolve("UnityEngine.UI.Image", "set_overrideSprite", 1);
                    if (setSprite) {
                        void* sp[] = { iconSprite };
                        MethodHandler::invoke(setSprite, imgComp.raw(), sp);
                    }
                    static auto setType = MethodHandler::resolve("UnityEngine.UI.Image", "set_type", 1);
                    if (setType) {
                        int simple = 0;
                        void* tp[] = { &simple };
                        MethodHandler::invoke(setType, imgComp.raw(), tp);
                    }
                    static auto setPreserve = MethodHandler::resolve("UnityEngine.UI.Image", "set_preserveAspect", 1);
                    if (setPreserve) {
                        bool on = true;
                        void* pp[] = { &on };
                        MethodHandler::invoke(setPreserve, imgComp.raw(), pp);
                    }
                    static auto setColor = MethodHandler::resolve("UnityEngine.UI.Graphic", "set_color", 1);
                    if (setColor) {
                        IL2CPP::Color col{ 0.9f, 0.3f, 0.3f, 1.f };
                        void* cp[] = { &col };
                        MethodHandler::invoke(setColor, imgComp.raw(), cp);
                    }
                }

                RectTransform iconRT(iconT.raw());
                iconRT.SetAnchorMin({ 1.f, 0.f });
                iconRT.SetAnchorMax({ 1.f, 1.f });
                iconRT.SetPivot({ 1.f, 0.5f });
                iconRT.SetSizeDelta({ iconSize, 0.f });
                iconRT.SetAnchoredPosition({ 0.f, 0.f });
            }
        }

        auto textT = rowT.Find("Text");
        if (textT.valid()) {
            auto textGO = textT.GetGameObject();
            if (textGO.valid()) {
                textGO.SetActive(true);

                for (const char* comp : {
                    "VRC.UI.Core.Styles.StyleElement",
                    "VRC.UI.Core.Styles.StyleString",
                    "UnityEngine.Localization.PropertyVariants.GameObjectLocalizer",
                    "UnityEngine.Localization.Components.LocalizeStringEvent"
                }) {
                    try {
                        auto c = textGO.GetComponentByName(comp);
                        if (c.valid()) Object(c.raw()).DestroyImmediate();
                    } catch (...) {}
                }

                auto tmpClass = Class::find("TMPro.TextMeshProUGUI");
                if (tmpClass) {
                    auto tmpComp = textGO.GetComponent(tmpClass);
                    if (tmpComp.valid()) {
                        static auto setAutoSize = MethodHandler::resolve("TMPro.TMP_Text", "set_enableAutoSizing", 1);
                        if (setAutoSize) {
                            bool off = false;
                            void* ap[] = { &off };
                            MethodHandler::invoke(setAutoSize, tmpComp.raw(), ap);
                        }

                        TMP_Text tmp(tmpComp.raw());
                        tmp.SetFontSize(fontSize);
                        tmp.SetAlignment(516);
                        tmp.SetEnableWordWrapping(false);
                        tmp.SetRichText(true);
                        tmp.SetColor({ 0.9f, 0.3f, 0.3f, 1.f });
                        tmp.SetText(text);

                        *outTMP = tmpComp.raw();
                    }
                }

                RectTransform textRT(textT.raw());
                textRT.SetAnchorMin({ 0.f, 0.f });
                textRT.SetAnchorMax({ 0.72f, 1.f });
                textRT.SetSizeDelta({ 0.f, 6.f });
                textRT.SetAnchoredPosition({ 0.f, 3.f });
            }
        }

        RectTransform rt(rowT.raw());
        rt.SetAnchoredPosition({ xPos, yPos });
        rt.SetSizeDelta({ 95.f, 28.f });

        row.SetActive(true);
    }

    void HudStatsModule::CreateHud() {
        auto ui = GameObject::Find("UserInterface");
        if (!ui.IsValid()) { m_initDelay = 2.f; return; }
        auto uiT = ui.GetTransform();

        auto iconsT = uiT.Find("UnscaledUI/HudContent/HUD_UI 2(Clone)/VR Canvas/Container/Left/Icons");
        if (!iconsT.valid()) { m_initDelay = 2.f; return; }

        auto invitesT = iconsT.Find("Dynamic Icons/Generic & Notification Icons/Notification Icons/Invites");
        if (!invitesT.valid()) { m_initDelay = 2.f; return; }
        auto invitesGO = invitesT.GetGameObject();
        if (!invitesGO.valid()) { m_initDelay = 2.f; return; }

        static auto instantiate = MethodHandler::resolve("UnityEngine.Object", "Instantiate", 1);
        if (!instantiate) { m_initDelay = 3.f; return; }

        auto& sl = SpriteLoader::Get();
        void* gaugeSprite = sl.LoadFromResource(IDR_ICON_FILM_STRIP, "hud_film");
        void* wifiSprite = sl.LoadFromResource(IDR_ICON_WIFI, "hud_wifi");

        void* fpsParams[] = { invitesGO.raw() };
        void* fpsRaw = MethodHandler::invoke<void*>(instantiate, nullptr, fpsParams);
        if (!fpsRaw) { m_initDelay = 3.f; return; }
        GameObject fpsGO(fpsRaw);
        fpsGO.SetName("NyxHud_FPS");
        fpsGO.GetTransform().SetParent(iconsT, false);

        void* pingParams[] = { invitesGO.raw() };
        void* pingRaw = MethodHandler::invoke<void*>(instantiate, nullptr, pingParams);
        if (!pingRaw) { Object(fpsRaw).Destroy(); m_initDelay = 3.f; return; }
        GameObject pingGO(pingRaw);
        pingGO.SetName("NyxHud_Ping");
        pingGO.GetTransform().SetParent(iconsT, false);

        static auto setFirst = MethodHandler::resolve("UnityEngine.Transform", "SetAsFirstSibling", 0);
        if (setFirst) {
            MethodHandler::invoke(setFirst, pingGO.GetTransform().raw());
            MethodHandler::invoke(setFirst, fpsGO.GetTransform().raw());
        }

        SetupRow(fpsRaw, gaugeSprite, std::string("--"), -5.f, 14.f, 26.f, 24.f, &m_fpsTMP);
        SetupRow(pingRaw, wifiSprite, std::string("--ms"), -5.f, -14.f, 26.f, 20.f, &m_pingTMP);

        m_fpsRowGO = fpsRaw;
        m_pingRowGO = pingRaw;
        m_hudCreated = true;
        FLOG("[HudStats] Created FPS + Ping rows next to mic");
    }

    static int ReadVRChatPing() {

        if (!s_vrcPingSearched) {
            s_vrcPingSearched = true;
            auto qm = GameObject::Find("Canvas_QuickMenu(Clone)");
            if (!qm.valid()) return -1;
            auto qmT = qm.GetTransform();
            auto pingT = qmT.Find("CanvasGroup/Container/Window/Panel_QM_Widget/Panel_QM_DebugInfo/Panel/Text_Ping");
            if (!pingT.valid()) return -1;
            auto pingGO = pingT.GetGameObject();
            if (!pingGO.valid()) return -1;
            auto tmpClass = Class::find("TMPro.TextMeshProUGUI");
            if (!tmpClass) return -1;
            auto comp = pingGO.GetComponent(tmpClass);
            if (!comp.valid()) return -1;
            s_vrcPingTMP = comp.raw();
            FLOG("[HudStats] Found VRChat Text_Ping TMP");
        }

        if (!s_vrcPingTMP) return -1;

        try {
            TMP_Text tmp(s_vrcPingTMP);
            std::string text = tmp.GetText();
            int val = 0;
            for (char c : text) {
                if (c >= '0' && c <= '9') val = val * 10 + (c - '0');
                else if (val > 0) break;
            }
            return val > 0 ? val : -1;
        } catch (...) {
            s_vrcPingTMP = nullptr;
            s_vrcPingSearched = false;
            return -1;
        }
    }

    void HudStatsModule::OnUpdate() {
        float dt = Time::GetUnscaledDeltaTime();

        m_fpsAccum += dt;
        m_fpsFrames++;
        m_fpsTimer += dt;
        if (m_fpsTimer >= 0.5f) {
            m_fps = static_cast<int>(m_fpsFrames / m_fpsAccum + 0.5f);
            m_fpsAccum = 0.f;
            m_fpsFrames = 0;
            m_fpsTimer = 0.f;

            if (InRoom()) {
                int ping = ReadVRChatPing();
                if (ping > 0) m_ping = ping;
            }
        }

        if (!m_hudCreated) {
            m_initDelay -= dt;
            if (m_initDelay <= 0.f)
                CreateHud();
            return;
        }

        if (m_fpsRowGO) {
            try {
                GameObject go(m_fpsRowGO);
                if (!go.valid() || !go.IsValid()) { Cleanup(); return; }
            } catch (...) { Cleanup(); return; }
        }

        if (m_fpsTMP) {
            try {
                char buf[16];
                std::snprintf(buf, sizeof(buf), "%d", m_fps);
                TMP_Text(m_fpsTMP).SetText(std::string(buf));
            } catch (...) { m_fpsTMP = nullptr; }
        }

        if (m_pingTMP) {
            try {
                char buf[16];
                std::snprintf(buf, sizeof(buf), "%dms", m_ping);
                TMP_Text(m_pingTMP).SetText(std::string(buf));
            } catch (...) { m_pingTMP = nullptr; }
        }
    }

    void HudStatsModule::OnSetupQuickMenu(uint32_t moduleId, uint32_t categoryPageId) {
        s_instance = this;
        auto& qmEx = QuickMenuEx::Get();
        uint32_t fold = qmEx.add_foldout(moduleId, categoryPageId, "HUD Stats", false, true);
        qmEx.add_settings_toggle(moduleId, fold, "Show FPS", m_showFps, QmShowFpsCb, "hud_fps");
        qmEx.add_settings_toggle(moduleId, fold, "Show Ping", m_showPing, QmShowPingCb, "hud_ping");
    }

} // namespace UNIx
