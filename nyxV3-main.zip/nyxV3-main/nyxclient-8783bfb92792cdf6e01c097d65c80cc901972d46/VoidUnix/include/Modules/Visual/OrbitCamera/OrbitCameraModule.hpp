#pragma once
#include <Core/BaseModule.hpp>
#include <IL2CPP.Common/il2cpp_shared.hpp>

namespace UNIx {

    class OrbitCameraModule : public BaseModule {
    public:
        OrbitCameraModule();

        void OnUpdate() override;
        void OnLateUpdate() override;
        void OnDisable() override;
        void OnSceneLoad(int scene, int loadMode) override;

    private:
        void CreateCamera();
        void DestroyCamera();

        void* m_cam = nullptr;
        bool m_camCreated = false;
        bool m_orbiting = false;

        float m_yaw = 0.f;
        float m_pitch = 15.f;
        float m_distance = 3.f;
        float m_sensitivity = 3.f;
        float m_heightOffset = 1.5f;

        IL2CPP::Quaternion m_savedPlayerRot = { 0.f, 0.f, 0.f, 1.f };
        IL2CPP::Vector3 m_savedPlayerPos = { 0.f, 0.f, 0.f };
    };

} // namespace UNIx
