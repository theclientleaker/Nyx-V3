#pragma once
#include <Core/BaseModule.hpp>
#include <string>

namespace UNIx {

    class BetterLoadingScreenModule : public BaseModule {
    public:
        BetterLoadingScreenModule()
            : BaseModule("Better Loading Screen", "Custom AssetBundle loading screen", 0, "Visual")
        {
            m_enabled = true;
        }

        void OnSceneLoad(int scene, int loadMode) override;
        void OnUpdate() override;

    private:
        enum class State { Idle, WaitForPopup, Applied, Failed };

        State m_state = State::Idle;
        void* m_assetBundle   = nullptr;
        void* m_loadPrefab    = nullptr;
        bool  m_bundleLoaded  = false;
        bool  m_bundleFailed  = false;
        bool  m_flatBgHidden  = false;
        int   m_retryCount    = 0;
        float m_retryTimer    = 0.f;
        static constexpr int   kMaxRetries    = 20;
        static constexpr float kRetryInterval = 0.5f;

        static constexpr const char* kBundlePath = "C:/nyx/loadingscreen/loading.assetbundle";

        bool LoadBundle();
        bool TrySpawnScreen();
        void CleanupOriginal(void* popupRaw);
        void HideFlatOverlayBg();
    };

} // namespace UNIx
