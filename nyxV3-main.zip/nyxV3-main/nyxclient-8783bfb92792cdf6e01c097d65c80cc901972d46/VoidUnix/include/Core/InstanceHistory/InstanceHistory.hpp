#pragma once

#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#include <d3d11.h>

#include <string>
#include <vector>
#include <mutex>
#include <unordered_map>
#include <unordered_set>
#include <cstdint>

namespace UNIx {

    struct InstanceEntry {
        std::string worldName;
        std::string worldId;
        std::string locationString;
        std::string thumbnailUrl;
        int playerCount = 0;
        int maxPlayers = 0;
        int64_t timestamp = 0;
    };

    class InstanceHistory {
    public:
        static InstanceHistory& Get();

        void LogInstance(const InstanceEntry& entry);
        std::vector<InstanceEntry> GetEntries() const;
        void Clear();

        bool IsNewLocation(const std::string& locationString) const;

        void* GetThumbnailSRV(const std::string& worldId);
        void RequestThumbnailIfNeeded(const std::string& worldId, const std::string& url);
        void ProcessPendingThumbnails(ID3D11Device* device);

        void Load();
        void Save() const;

    private:
        InstanceHistory() = default;

        static constexpr size_t kMaxEntries = 50;
        static constexpr const char* kSavePath = "C:\\nyx\\Config\\instance_history.txt";

        mutable std::mutex m_mutex;
        std::vector<InstanceEntry> m_entries;
        std::string m_currentLocation;

        struct PendingThumb {
            std::string worldId;
            std::vector<uint8_t> rgba;
            int width = 0, height = 0;
        };

        std::mutex m_thumbMutex;
        std::unordered_map<std::string, ID3D11ShaderResourceView*> m_thumbCache;
        std::vector<PendingThumb> m_pendingThumbs;
        std::unordered_set<std::string> m_thumbRequested;

        static std::vector<uint8_t> DownloadImage(const std::string& url);
        static ID3D11ShaderResourceView* CreateTexture(ID3D11Device* device,
            const uint8_t* rgba, int w, int h);
    };

} // namespace UNIx
