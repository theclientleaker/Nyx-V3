#pragma once
#include <Core/BaseModule.hpp>
#include <cstdint>

namespace UNIx {

class NotifierModule : public BaseModule {
public:
    NotifierModule();

    void OnEnable() override;
    void OnDisable() override;
    void OnUpdate() override;
    void OnPlayerJoinComplete(IL2CPP::VRChat::Player player) override;
    void OnPlayerLeave(IL2CPP::VRChat::Player player) override;
    void OnSceneLoad(int buildIndex, int sceneBuildIndex) override;
    void OnSetupQuickMenu(uint32_t moduleId, uint32_t categoryPageId) override;

    static NotifierModule* s_instance;

private:
    void LoadAssets();
    void* CreateAudioSourceGO(const char* name, void* clip);
    void* LoadOggAsClip(const char* path, const char* clipName);
    void PlayJoinSound();
    void PlayLeaveSound();

    static void __cdecl QmVolumeCb(uint32_t, float);
    static void __cdecl QmPlayJoinSoundCb(uint32_t, bool);
    static void __cdecl QmPlayLeaveSoundCb(uint32_t, bool);
    static void __cdecl QmFriendsOnlyCb(uint32_t, bool);

    enum class AssetState { NotLoaded, Ready, Failed };
    AssetState m_assetState = AssetState::NotLoaded;

    void* m_joinClip = nullptr;
    void* m_leaveClip = nullptr;
    void* m_joinSourceGO = nullptr;
    void* m_leaveSourceGO = nullptr;

    float m_volume = 0.7f;
    bool m_playSoundOnJoin = true;
    bool m_playSoundOnLeave = true;
    bool m_friendsOnly = false;

    int m_sceneLoadTick = 0;
    bool m_observedLocalJoin = false;
};

} // namespace UNIx
