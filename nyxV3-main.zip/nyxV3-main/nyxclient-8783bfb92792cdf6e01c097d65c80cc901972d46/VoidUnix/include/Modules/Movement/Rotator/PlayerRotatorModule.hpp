#pragma once
#include <Core/BaseModule.hpp>

namespace UNIx {

    class PlayerRotatorModule : public BaseModule {
    public:
        PlayerRotatorModule()
            : BaseModule("Player Rotator", "Set custom XYZ rotation", 0, "Movement") {
            m_showInQuickMenu = true;
        }

        void OnUpdate() override;
        void OnSetupQuickMenu(uint32_t moduleId, uint32_t categoryPageId) override;

    private:
        float m_rotX = 0.f;
        float m_rotY = 0.f;
        float m_rotZ = 0.f;

        static PlayerRotatorModule* s_instance;
        static void __cdecl QmRotXCb(uint32_t id, float val);
        static void __cdecl QmRotYCb(uint32_t id, float val);
        static void __cdecl QmRotZCb(uint32_t id, float val);
    };

} // namespace UNIx
