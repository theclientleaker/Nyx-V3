#include <Core/DashboardConsole/DashboardConsole.hpp>
#include <Core/Globals.hpp>
#include <Core/FileLog/FileLog.hpp>
#include <Core/Theme.hpp>
#include <Core/SpriteLoader/SpriteLoader.hpp>
#include <Core/SpriteLoader/EmbeddedQMBackground.hpp>
#include <ThirdParty/imgui/imgui.h>
#include <IL2CPP.Module/include/il2cpp_module.hpp>
#include <IL2CPP.Module/include/Unity/GameObject.hpp>
#include <IL2CPP.Module/include/Unity/Transform.hpp>
#include <IL2CPP.Module/include/Unity/Object.hpp>
#include <IL2CPP.Module/include/Reflection.hpp>
#include <IL2CPP.Module/include/MethodHandler.hpp>
#include <IL2CPP.Module/include/Unity/Time.hpp>
#include <IL2CPP.Module/include/Unity/Texture2D.hpp>
#include <IL2CPP.Common/il2cpp_shared.hpp>
#include <ctime>
#include <algorithm>

namespace UNIx {

using namespace IL2CPP::Module;
using namespace IL2CPP::Module::Unity;

DashboardConsole& DashboardConsole::Get() {
    static DashboardConsole instance;
    return instance;
}

void DashboardConsole::Init() {
    m_started = true;
    AddLog("nyx console ready", LogColor::System);
}

void DashboardConsole::InjectQMBackground() {
    if (m_bgInjected) return;

    auto canvas = GameObject::Find("Canvas_QuickMenu(Clone)");
    if (!canvas.IsValid()) return;

    auto canvasT = canvas.GetTransform();
    auto qmParentT = canvasT.Find("CanvasGroup/Container/Window/QMParent");
    if (!qmParentT.valid()) return;

    // Find an existing UI child to clone (gives us a proper RectTransform)
    if (qmParentT.GetChildCount() <= 0) return;
    auto templateT = qmParentT.GetChild(0);
    if (!templateT.valid()) return;
    auto templateGO = templateT.GetGameObject();
    if (!templateGO.valid()) return;

    // Clone it (same safe pattern as LoadingPopup)
    static auto instantiateMethod = MethodHandler::resolve("UnityEngine.Object", "Instantiate", 1);
    if (!instantiateMethod) return;
    void* cloneParams[] = { templateGO.raw() };
    void* clonedRaw = MethodHandler::invoke<void*>(instantiateMethod, nullptr, cloneParams);
    if (!clonedRaw) return;

    GameObject bgGo(clonedRaw);

    // Destroy all children of the clone
    auto cloneT = bgGo.GetTransform();
    if (!cloneT.valid()) return;
    for (int i = cloneT.GetChildCount() - 1; i >= 0; --i) {
        auto childT = cloneT.GetChild(i);
        if (childT.valid()) {
            auto childGO = childT.GetGameObject();
            if (childGO.valid()) childGO.Destroy();
        }
    }

    // Parent under QMParent
    cloneT.SetParent(qmParentT, false);

    // Get or add UI.Image (no default sprite — custom backgrounds set it later)
    auto imageClass = Class::find("UnityEngine.UI.Image");
    if (!imageClass) return;
    auto imageComp = bgGo.GetComponent(imageClass);
    if (!imageComp.valid())
        imageComp = bgGo.AddComponent(imageClass);
    if (!imageComp.valid()) return;

    // Cache the image component for later sprite swaps (custom backgrounds)
    m_bgImageComp = imageComp.raw();

    // Start transparent — custom backgrounds will set the sprite and make it visible
    static auto setColor = MethodHandler::resolve("UnityEngine.UI.Graphic", "set_color", 1);
    if (setColor) {
        IL2CPP::Color col{ 1.f, 1.f, 1.f, 0.f };
        void* colP[] = { &col };
        MethodHandler::invoke(setColor, imageComp.raw(), colP);
    }

    // Stretch RectTransform to fill QMParent
    static auto setAnchorMin = MethodHandler::resolve("UnityEngine.RectTransform", "set_anchorMin", 1);
    static auto setAnchorMax = MethodHandler::resolve("UnityEngine.RectTransform", "set_anchorMax", 1);
    static auto setSizeDelta = MethodHandler::resolve("UnityEngine.RectTransform", "set_sizeDelta", 1);
    static auto setAnchoredPos = MethodHandler::resolve("UnityEngine.RectTransform", "set_anchoredPosition", 1);

    if (setAnchorMin && setAnchorMax && setSizeDelta && setAnchoredPos) {
        IL2CPP::Vector2 zero{ 0.f, 0.f };
        IL2CPP::Vector2 one{ 1.f, 1.f };
        void* pMin[] = { &zero };
        void* pMax[] = { &one };
        void* pSize[] = { &zero };
        void* pPos[] = { &zero };
        MethodHandler::invoke(setAnchorMin, cloneT.raw(), pMin);
        MethodHandler::invoke(setAnchorMax, cloneT.raw(), pMax);
        MethodHandler::invoke(setSizeDelta, cloneT.raw(), pSize);
        MethodHandler::invoke(setAnchoredPos, cloneT.raw(), pPos);
    }

    // Sibling index 1 = over QM background, behind Body content
    static auto setSiblingIndex = MethodHandler::resolve("UnityEngine.Transform", "SetSiblingIndex", 1);
    if (setSiblingIndex) {
        int idx = 1;
        void* sibP[] = { &idx };
        MethodHandler::invoke(setSiblingIndex, cloneT.raw(), sibP);
    }

    // Disable raycast so it doesn't block clicks
    static auto setRaycastTarget = MethodHandler::resolve("UnityEngine.UI.Graphic", "set_raycastTarget", 1);
    if (setRaycastTarget) {
        bool val = false;
        void* rtP[] = { &val };
        MethodHandler::invoke(setRaycastTarget, imageComp.raw(), rtP);
    }

    bgGo.SetActive(true);
    m_bgInjected = true;
    FLOG("[DashboardConsole] QM background injected");
}

void DashboardConsole::SetBackground(size_t index) {
    // No embedded backgrounds — use SetBackgroundSprite() or SetAnimatedBackground() instead
    (void)index;
}

void DashboardConsole::SetBackgroundSprite(void* sprite) {
    if (!m_bgImageComp || !sprite) return;

    // Verify the image component is still alive
    Object imgObj(m_bgImageComp);
    if (!imgObj.IsValid()) {
        m_bgImageComp = nullptr;
        m_bgInjected = false;
        m_animBg = nullptr;
        return;
    }

    m_animBg = nullptr;

    static auto setSprite = MethodHandler::resolve("UnityEngine.UI.Image", "set_sprite", 1);
    if (!setSprite) return;
    void* sprP[] = { sprite };
    MethodHandler::invoke(setSprite, m_bgImageComp, sprP);

    // Make visible (was transparent until first bg set)
    static auto setColor = MethodHandler::resolve("UnityEngine.UI.Graphic", "set_color", 1);
    if (setColor) {
        IL2CPP::Color col{ 1.f, 1.f, 1.f, 1.f };
        void* colP[] = { &col };
        MethodHandler::invoke(setColor, m_bgImageComp, colP);
    }
}

void DashboardConsole::SetAnimatedBackground(const AnimatedSprite* anim) {
    if (!anim || anim->frames.empty() || !anim->sprite) return;
    m_animBg = anim;
    m_animTime = 0.f;
    m_animFrame = 0;
    SetBackgroundSprite(anim->sprite);  // also sets color to visible
    m_animBg = anim;
}

void DashboardConsole::Update() {
    if (!m_started) return;

    // One-time setup: carousel removal and background injection
    if (!m_carouselRemoved || !m_bgInjected) {
        auto canvas = GameObject::Find("Canvas_QuickMenu(Clone)");
        if (!canvas.IsValid()) return;

        if (!m_carouselRemoved) {
            auto canvasT = canvas.GetTransform();
            auto vlgT = canvasT.Find(
                "CanvasGroup/Container/Window/QMParent/Body/Menu_QM_Launchpad/ScrollRect/Viewport/VerticalLayoutGroup");
            if (vlgT.valid()) {
                auto carouselT = vlgT.Find("Carousel_Banners");
                if (carouselT.valid()) {
                    auto carouselGO = carouselT.GetGameObject();
                    if (carouselGO.valid()) carouselGO.Destroy();
                }
                m_carouselRemoved = true;
            }
        }

        if (!m_bgInjected) InjectQMBackground();
    }

    if (m_animBg && m_animBg->texture && m_animBg->frames.size() > 1) {
        m_animTime += Time::GetDeltaTime();
        constexpr float kMinFrameDelay = 1.f / 15.f;
        float frameDelay = (std::max)(m_animBg->frames[m_animFrame].delay, kMinFrameDelay);
        if (m_animTime >= frameDelay) {
            m_animTime -= frameDelay;
            m_animFrame = (m_animFrame + 1) % m_animBg->frames.size();

            auto& frame = m_animBg->frames[m_animFrame];
            size_t dataSize = frame.pixels.size();

            if (dataSize > 0) {
                static auto loadRawNative = MethodHandler::resolve(
                    "UnityEngine.Texture2D", "LoadRawTextureData", 2);
                if (loadRawNative) {
                    void* dataPtr = const_cast<uint8_t*>(frame.pixels.data());
                    int dataLen = static_cast<int>(dataSize);
                    void* params[] = { &dataPtr, &dataLen };
                    MethodHandler::invoke<void>(loadRawNative, m_animBg->texture, params);
                    Texture2D tex(m_animBg->texture);
                    tex.Apply();
                }
            }
        }
    }
}

void DashboardConsole::OnRender() {
    if (!m_started) return;

    ImGuiIO& io = ImGui::GetIO();

    float plW = io.DisplaySize.x * 0.45f;
    float plH = io.DisplaySize.y * 0.55f;
    float plRight = io.DisplaySize.x * 0.5f + plW * 0.5f;
    float plTop = io.DisplaySize.y * 0.5f - plH * 0.5f;

    float consoleW = 340.f;
    float gap = 8.f;

    ImGui::SetNextWindowPos(ImVec2(plRight + gap, plTop));
    ImGui::SetNextWindowSize(ImVec2(consoleW, plH));

    const ImVec4 purple(0.549f, 0.157f, 0.882f, 1.0f);
    const ImVec4 dimWhite(0.50f, 0.50f, 0.55f, 1.0f);

    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.03f, 0.03f, 0.05f, 0.95f));
    ImGui::PushStyleColor(ImGuiCol_Border, purple);
    ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.0f, 0.0f, 0.0f, 0.0f));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 2.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(12, 10));

    ImGui::Begin("##nyx_console", nullptr,
        ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse |
        ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoMove);

    if (g_fontBig) ImGui::PushFont(g_fontBig);
    ImGui::TextColored(purple, "nyx");
    ImGui::SameLine(0.f, 0.f);
    ImGui::Text(" console");
    if (g_fontBig) ImGui::PopFont();

    ImGui::Spacing();
    ImGui::Separator();
    ImGui::Spacing();

    ImGui::BeginChild("##console_scroll", ImVec2(0, 0), false);

    if (g_fontSmallBold) ImGui::PushFont(g_fontSmallBold);

    std::lock_guard lock(m_mutex);
    for (auto& entry : m_lines) {
        ImVec4 msgColor;
        switch (entry.color) {
            case LogColor::System:   msgColor = purple; break;
            case LogColor::Enabled:  msgColor = ImVec4(0.29f, 0.87f, 0.50f, 1.f); break;
            case LogColor::Disabled: msgColor = ImVec4(0.97f, 0.44f, 0.44f, 1.f); break;
            default:                 msgColor = ImVec4(0.85f, 0.85f, 0.90f, 1.f); break;
        }

        ImGui::TextColored(dimWhite, "%s", entry.timestamp.c_str());
        ImGui::SameLine(0.f, 6.f);
        ImGui::TextColored(msgColor, "%s", entry.text.c_str());
    }

    if (ImGui::GetScrollY() >= ImGui::GetScrollMaxY() - 5.f)
        ImGui::SetScrollHereY(1.0f);

    if (g_fontSmallBold) ImGui::PopFont();

    ImGui::EndChild();

    ImGui::End();
    ImGui::PopStyleVar(2);
    ImGui::PopStyleColor(3);
}

static std::string GetTimestamp() {
    time_t now = time(nullptr);
    struct tm t;
    localtime_s(&t, &now);
    char buf[16];
    strftime(buf, sizeof(buf), "%H:%M:%S", &t);
    return buf;
}

void DashboardConsole::AddLog(const std::string& msg, LogColor color) {
    std::lock_guard lock(m_mutex);
    m_lines.push_back({msg, color, GetTimestamp()});
    while (m_lines.size() > kMaxLines)
        m_lines.pop_front();
    if (m_logCallback)
        m_logCallback(msg, color);
}

} // namespace UNIx
