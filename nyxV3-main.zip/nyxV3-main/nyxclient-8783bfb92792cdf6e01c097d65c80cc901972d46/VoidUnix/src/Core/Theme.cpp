#include <Core/Theme.hpp>
#include <ThirdParty/imgui/imgui.h>

namespace UNIx {

    ImFont* g_fontSmallBold  = nullptr;
    ImFont* g_fontMediumBold = nullptr;
    ImFont* g_fontBig        = nullptr;

    void InitializeFonts(ImGuiIO& io) {
        const char* verdana    = "C:\\Windows\\Fonts\\Verdana.ttf";
        const char* verdanaBold = "C:\\Windows\\Fonts\\Verdanab.ttf";

        g_fontBig        = io.Fonts->AddFontFromFileTTF(verdana, 20.0f);
        g_fontSmallBold  = io.Fonts->AddFontFromFileTTF(verdanaBold, 14.0f);
        g_fontMediumBold = io.Fonts->AddFontFromFileTTF(verdanaBold, 16.0f);

        if (!g_fontBig)        g_fontBig        = io.Fonts->AddFontDefault();
        if (!g_fontSmallBold)  g_fontSmallBold  = io.Fonts->AddFontDefault();
        if (!g_fontMediumBold) g_fontMediumBold = io.Fonts->AddFontDefault();
    }

    void ApplyUNIxTheme() {
        ImGuiStyle& style = ImGui::GetStyle();

        style.Alpha              = 1.0f;
        style.WindowPadding      = ImVec2(8, 8);
        style.WindowRounding     = 4.0f;
        style.WindowBorderSize   = 1.0f;
        style.WindowMinSize      = ImVec2(32, 32);
        style.WindowTitleAlign   = ImVec2(0.5f, 0.5f);
        style.ChildRounding      = 4.0f;
        style.ChildBorderSize    = 1.0f;
        style.PopupRounding      = 4.0f;
        style.PopupBorderSize    = 1.0f;
        style.FramePadding       = ImVec2(4, 2);
        style.FrameRounding      = 2.0f;
        style.FrameBorderSize    = 1.0f;
        style.ItemSpacing        = ImVec2(8, 4);
        style.ItemInnerSpacing   = ImVec2(4, 4);
        style.IndentSpacing      = 6.0f;
        style.ColumnsMinSpacing  = 6.0f;
        style.ScrollbarSize      = 6.0f;
        style.ScrollbarRounding  = 9.0f;
        style.GrabMinSize        = 0.0f;
        style.GrabRounding       = 4.0f;
        style.TabRounding        = 4.0f;
        style.TabBorderSize      = 1.0f;
        style.ButtonTextAlign    = ImVec2(0.5f, 0.5f);
        style.SelectableTextAlign = ImVec2(0.0f, 0.5f);
        style.MouseCursorScale   = 0.75f;

        // void's exact color palette:
        // p3 (control bg):  sdk::color(0.101, 0.121, 0.156)
        // p5 (hover):       sdk::color(0.302, 0.255, 0.318)
        // a0 (main accent): blueviolet 140,40,225 = (0.549, 0.157, 0.882)
        // a1 (dark accent):  indigo 55,0,100     = (0.216, 0.000, 0.392)
        // a2 (darker accent): darkviolet 75,50,105 = (0.294, 0.196, 0.412)
        // p6 = a0 (used for checkmark/button/tab active)

        const float a0r = 0.549f, a0g = 0.157f, a0b = 0.882f;
        const float a1r = 0.216f, a1g = 0.000f, a1b = 0.392f;
        const float a2r = 0.294f, a2g = 0.196f, a2b = 0.412f;
        const float p3r = 0.101f, p3g = 0.121f, p3b = 0.156f;
        const float p5r = 0.302f, p5g = 0.255f, p5b = 0.318f;

        ImVec4* c = style.Colors;

        c[ImGuiCol_Text]                 = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);
        c[ImGuiCol_TextDisabled]         = ImVec4(0.75f, 0.75f, 0.75f, 0.85f);
        c[ImGuiCol_TextSelectedBg]       = ImVec4(a1r, a1g, a1b, 0.85f);
        c[ImGuiCol_WindowBg]             = ImVec4(p3r, p3g, p3b, 1.00f);
        c[ImGuiCol_ChildBg]              = ImVec4(0.08f, 0.08f, 0.12f, 0.60f);
        c[ImGuiCol_PopupBg]              = ImVec4(0.08f, 0.08f, 0.12f, 0.85f);
        c[ImGuiCol_Border]               = ImVec4(0.00f, 0.00f, 0.00f, 0.10f);
        c[ImGuiCol_BorderShadow]         = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
        c[ImGuiCol_FrameBg]              = ImVec4(p3r, p3g, p3b, 1.00f);
        c[ImGuiCol_FrameBgHovered]       = ImVec4(a1r, a1g, a1b, 1.00f);
        c[ImGuiCol_FrameBgActive]        = ImVec4(a0r, a0g, a0b, 1.00f);
        c[ImGuiCol_TitleBg]              = ImVec4(a0r, a0g, a0b, 0.70f);
        c[ImGuiCol_TitleBgActive]        = ImVec4(a0r, a0g, a0b, 0.85f);
        c[ImGuiCol_TitleBgCollapsed]     = ImVec4(a0r, a0g, a0b, 0.70f);
        c[ImGuiCol_MenuBarBg]            = ImVec4(0.08f, 0.08f, 0.12f, 0.70f);
        c[ImGuiCol_ScrollbarBg]          = ImVec4(p3r, p3g, p3b, 1.00f);
        c[ImGuiCol_ScrollbarGrab]        = ImVec4(a2r, a2g, a2b, 1.00f);
        c[ImGuiCol_ScrollbarGrabHovered] = ImVec4(p5r, p5g, p5b, 0.90f);
        c[ImGuiCol_ScrollbarGrabActive]  = ImVec4(0.75f, 0.75f, 0.75f, 0.10f);
        c[ImGuiCol_CheckMark]            = ImVec4(a0r, a0g, a0b, 0.70f);
        c[ImGuiCol_SliderGrab]           = ImVec4(a0r, a0g, a0b, 1.00f);
        c[ImGuiCol_SliderGrabActive]     = ImVec4(a1r, a1g, a1b, 1.00f);
        c[ImGuiCol_Button]               = ImVec4(a0r, a0g, a0b, 0.70f);
        c[ImGuiCol_ButtonHovered]        = ImVec4(p5r, p5g, p5b, 1.00f);
        c[ImGuiCol_ButtonActive]         = ImVec4(a0r, a0g, a0b, 1.00f);
        c[ImGuiCol_Header]               = ImVec4(a0r, a0g, a0b, 1.00f);
        c[ImGuiCol_HeaderHovered]        = ImVec4(p5r, p5g, p5b, 1.00f);
        c[ImGuiCol_HeaderActive]         = ImVec4(p3r, p3g, p3b, 1.00f);
        c[ImGuiCol_Separator]            = ImVec4(p3r, p3g, p3b, 1.00f);
        c[ImGuiCol_SeparatorHovered]     = ImVec4(p5r, p5g, p5b, 1.00f);
        c[ImGuiCol_SeparatorActive]      = ImVec4(a0r, a0g, a0b, 1.00f);
        c[ImGuiCol_ResizeGrip]           = ImVec4(a0r, a0g, a0b, 1.00f);
        c[ImGuiCol_ResizeGripHovered]    = ImVec4(p5r, p5g, p5b, 0.70f);
        c[ImGuiCol_ResizeGripActive]     = ImVec4(a1r, a1g, a1b, 1.00f);
        c[ImGuiCol_Tab]                  = ImVec4(0.1f, 0.07f, 0.18f, 0.80f);
        c[ImGuiCol_TabHovered]           = ImVec4(p5r, p5g, p5b, 0.80f);
        c[ImGuiCol_TabActive]            = ImVec4(a0r, a0g, a0b, 0.70f);
        c[ImGuiCol_TabUnfocused]         = ImVec4(p5r, p5g, p5b, 0.70f);
        c[ImGuiCol_TabUnfocusedActive]   = ImVec4(a0r, a0g, a0b, 0.60f);
        c[ImGuiCol_PlotLines]            = ImVec4(a0r, a0g, a0b, 1.00f);
        c[ImGuiCol_PlotLinesHovered]     = ImVec4(a0r, a0g, a0b, 0.50f);
        c[ImGuiCol_PlotHistogram]        = ImVec4(a0r, a0g, a0b, 1.00f);
        c[ImGuiCol_PlotHistogramHovered] = ImVec4(a0r, a0g, a0b, 0.50f);
        c[ImGuiCol_DragDropTarget]       = ImVec4(a2r, a2g, a2b, 0.80f);
        c[ImGuiCol_ModalWindowDimBg]     = ImVec4(0.00f, 0.00f, 0.00f, 0.25f);
    }

} // namespace UNIx
