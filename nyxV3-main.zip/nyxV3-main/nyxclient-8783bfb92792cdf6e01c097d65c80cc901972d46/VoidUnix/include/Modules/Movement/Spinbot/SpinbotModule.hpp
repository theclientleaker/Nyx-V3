#pragma once
#include <Core/BaseModule.hpp>
#include <IL2CPP.Module/include/MethodHandler.hpp>
#include <IL2CPP.Common/il2cpp_shared.hpp>
#include <vector>

namespace UNIx {

    class SpinbotModule : public BaseModule {
    public:
        SpinbotModule()
            : BaseModule("Spinbot", "Spinning rainbow ghost - others see you spin", 0, "Movement") {
            m_showInQuickMenu = true;
        }

        void OnEnable() override;
        void OnDisable() override;
        void OnUpdate() override;
        void OnLateUpdate() override;
        void OnSceneLoad(int scene, int loadMode) override;
        void OnSetupQuickMenu(uint32_t moduleId, uint32_t categoryPageId) override;

    private:
        float m_spinSpeed = 180.0f;
        float m_hue = 0.f;
        float m_time = 0.f;
        bool m_antiAim = true;

        float m_aaYawOffset = 0.f;
        float m_aaTimer = 0.f;
        float m_aaSpeedMult = 1.f;
        int m_aaDirection = 1;

        float m_currentYaw = 0.f;
        IL2CPP::Vector3 m_clonePos = { 0.f, 0.f, 0.f };

        bool m_active = false;
        bool m_hookInstalled = false;
        uint32_t m_prefixHookId = 0;
        uint32_t m_suffixHookId = 0;

        void* m_clone = nullptr;
        std::vector<void*> m_cloneRenderers;

        void SpawnClone();
        void DestroyClone();
        void UpdateCloneColor();
        void SetGOTreeLayer(void* goRaw, int layer);
        void SyncBones();
        void InstallPoseHook();
        void RemovePoseHook();

        static SpinbotModule* s_instance;
        static bool __cdecl PosePrefix(void* thisPtr);
        static void __cdecl PoseSuffix(void* thisPtr);
        static void __cdecl QmSpinSpeedCb(uint32_t id, float val);
        static void __cdecl QmAntiAimCb(uint32_t id, bool val);
    };

} // namespace UNIx
