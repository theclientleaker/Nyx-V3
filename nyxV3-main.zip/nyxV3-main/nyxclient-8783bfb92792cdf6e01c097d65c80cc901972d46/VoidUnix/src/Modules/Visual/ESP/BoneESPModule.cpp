#include <Modules/Visual/ESP/BoneESPModule.hpp>
#include <Core/ModuleManager.hpp>
#include <ThirdParty/imgui/imgui.h>

#include <IL2CPP.Module/include/Unity/Camera.hpp>
#include <IL2CPP.Module/include/Unity/Screen.hpp>
#include <Bootstrap.Module/include/VRChat/VRCPlayerApi.hpp>

namespace UNIx {

    // HumanBodyBones enum indices we care about:
    //  0 = Hips
    //  1 = LeftUpLeg      2 = RightUpLeg
    //  3 = LeftLeg         4 = RightLeg
    //  5 = LeftFoot        6 = RightFoot
    //  7 = Spine           8 = Chest          9 = Neck          10 = Head
    // 11 = LeftShoulder   13 = LeftUpperArm  15 = LeftLowerArm  17 = LeftHand
    // 12 = RightShoulder  14 = RightUpperArm 16 = RightLowerArm 18 = RightHand

    const int BoneESPModule::kBoneIds[kBoneCount] = {
         0,                         // 0  Hips
         1,  2,                     // 1  LeftUpLeg, 2 RightUpLeg
         3,  4,                     // 3  LeftLeg,   4 RightLeg
         5,  6,                     // 5  LeftFoot,  6 RightFoot
         7,  8,  9, 10,            // 7  Spine, 8 Chest, 9 Neck, 10 Head
        11, 12,                     // 11 LeftShoulder, 12 RightShoulder
        13, 14,                     // 13 LeftUpperArm, 14 RightUpperArm
        15, 16,                     // 15 LeftLowerArm, 16 RightLowerArm
        17, 18,                     // 17 LeftHand, 18 RightHand
        19, 20,                     // 19 LeftToes, 20 RightToes
    };

    // Connections using indices into kBoneIds (NOT HumanBodyBones directly)
    // idx: 0=Hips 1=LUpLeg 2=RUpLeg 3=LLeg 4=RLeg 5=LFoot 6=RFoot
    //      7=Spine 8=Chest 9=Neck 10=Head
    //      11=LShoulder 12=RShoulder 13=LUpperArm 14=RUpperArm
    //      15=LLowerArm 16=RLowerArm 17=LHand 18=RHand
    //      19=LToes 20=RToes
    const int BoneESPModule::kConnections[kConnectionCount][2] = {
        // Spine
        { 0,  7}, { 7,  8}, { 8,  9}, { 9, 10},
        // Left leg
        { 0,  1}, { 1,  3}, { 3,  5}, { 5, 19},
        // Right leg
        { 0,  2}, { 2,  4}, { 4,  6}, { 6, 20},
        // Left arm
        { 8, 11}, {11, 13}, {13, 15}, {15, 17},
        // Right arm
        { 8, 12}, {12, 14}, {14, 16}, {16, 18},
    };

    ImU32 BoneESPModule::RankToESPColor(IL2CPP::VRChat::PlayerRank rank) {
        using R = IL2CPP::VRChat::PlayerRank;
        switch (rank) {
            case R::Visitor:       return IM_COL32(204, 204, 204, 255);
            case R::NewUser:         return IM_COL32( 43, 207,  92, 255);
            case R::User:         return IM_COL32(255, 122,  66, 255);
            case R::Known:       return IM_COL32(199,  61, 255, 255);
            case R::Trusted:       return IM_COL32(255, 102, 102, 255);
            case R::Administrator: return IM_COL32(139,   0,   0, 255);
            case R::Troll:         return IM_COL32(128, 128, 128, 255);
            default:               return IM_COL32(255, 255, 255, 255);
        }
    }

    void BoneESPModule::OnUpdate() {
        std::vector<BoneESPEntry> newEntries;

        if (!InRoom()) {
            std::lock_guard lock(m_dataMutex);
            m_entries.clear();
            return;
        }

        auto cam = IL2CPP::Module::Unity::Camera::GetMain();
        if (!cam.valid()) {
            std::lock_guard lock(m_dataMutex);
            m_entries.clear();
            return;
        }

        float screenH = static_cast<float>(IL2CPP::Module::Unity::Screen::GetHeight());
        auto players = ModuleManager::Get().GetPlayerCache().GetPlayers();

        for (auto& entry : *players) {
            if (entry.isLocal) continue;

            auto api = IL2CPP::VRChat::VRCPlayerApi::GetPlayerById(entry.playerId);
            if (!api.IsValid()) continue;

            BoneESPEntry e;
            bool anyVisible = false;

            for (int i = 0; i < kBoneCount; ++i) {
                IL2CPP::Vector3 bonePos = api.GetBonePosition(
                    static_cast<IL2CPP::VRChat::HumanBodyBones>(kBoneIds[i]));
                IL2CPP::Vector3 sp = cam.WorldToScreenPoint(bonePos);
                e.visible[i] = (sp.z > 0.f);
                if (e.visible[i]) anyVisible = true;
                e.bones[i] = ImVec2(sp.x, screenH - sp.y);
            }

            if (!anyVisible) continue;

            e.color = RankToESPColor(entry.rank);
            newEntries.push_back(std::move(e));
        }

        std::lock_guard lock(m_dataMutex);
        m_entries = std::move(newEntries);
    }

    void BoneESPModule::OnOverlay() {
        std::vector<BoneESPEntry> snapshot;
        {
            std::lock_guard lock(m_dataMutex);
            snapshot = m_entries;
        }

        if (snapshot.empty()) return;

        auto* drawList = ImGui::GetBackgroundDrawList();

        for (auto& e : snapshot) {
            for (auto& conn : kConnections) {
                int a = conn[0], b = conn[1];
                if (!e.visible[a] || !e.visible[b]) continue;
                drawList->AddLine(e.bones[a], e.bones[b], e.color, 2.0f);
            }

            for (int i = 0; i < kBoneCount; ++i) {
                if (!e.visible[i]) continue;
                drawList->AddCircleFilled(e.bones[i], 3.f, e.color);
            }
        }
    }

} // namespace UNIx
