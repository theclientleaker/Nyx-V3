#include <Modules/Visual/LoadingScreen/BetterLoadingScreenModule.hpp>
#include <Core/FileLog/FileLog.hpp>

#include <IL2CPP.Module/include/Unity/GameObject.hpp>
#include <IL2CPP.Module/include/Unity/Transform.hpp>
#include <IL2CPP.Module/include/Unity/Component.hpp>
#include <IL2CPP.Module/include/Unity/Time.hpp>
#include <IL2CPP.Module/include/Reflection.hpp>
#include <IL2CPP.Module/include/MethodHandler.hpp>
#include <filesystem>

using namespace IL2CPP::Module;
using namespace IL2CPP::Module::Unity;

namespace UNIx {

    bool BetterLoadingScreenModule::LoadBundle() {
        if (m_bundleLoaded) return true;
        if (m_bundleFailed) return false;

        if (!std::filesystem::exists(kBundlePath)) {
            FLOG("[BetterLoadingScreen] Bundle not found: {}", kBundlePath);
            m_bundleFailed = true;
            return false;
        }

        static auto loadFromFile = MethodHandler::resolve("UnityEngine.AssetBundle", "LoadFromFile", 1);
        if (!loadFromFile) {
            FLOG("[BetterLoadingScreen] Cannot resolve AssetBundle.LoadFromFile");
            m_bundleFailed = true;
            return false;
        }

        void* pathStr = IL2CPP::Module::StringNew(kBundlePath);
        if (!pathStr) { m_bundleFailed = true; return false; }

        void* params[] = { pathStr };
        m_assetBundle = MethodHandler::invoke<void*>(loadFromFile, nullptr, params);
        if (!m_assetBundle) {
            FLOG("[BetterLoadingScreen] LoadFromFile returned null");
            m_bundleFailed = true;
            return false;
        }

        static auto loadAsset = MethodHandler::resolve("UnityEngine.AssetBundle", "LoadAsset", 1);
        if (!loadAsset) {
            FLOG("[BetterLoadingScreen] Cannot resolve AssetBundle.LoadAsset");
            m_bundleFailed = true;
            return false;
        }

        static auto getNames = MethodHandler::resolve("UnityEngine.AssetBundle", "GetAllAssetNames", 0);
        if (!getNames) {
            FLOG("[BetterLoadingScreen] Cannot resolve GetAllAssetNames");
            m_bundleFailed = true;
            return false;
        }

        void* namesArray = MethodHandler::invoke<void*>(getNames, m_assetBundle);
        if (!namesArray) {
            FLOG("[BetterLoadingScreen] GetAllAssetNames returned null");
            m_bundleFailed = true;
            return false;
        }

        int32_t nameCount = *reinterpret_cast<int32_t*>(static_cast<char*>(namesArray) + 0x18);
        void** nameElements = reinterpret_cast<void**>(static_cast<char*>(namesArray) + 0x20);

        for (int32_t i = 0; i < nameCount; ++i) {
            void* nameObj = nameElements[i];
            if (!nameObj) continue;

            int32_t len = *reinterpret_cast<int32_t*>(static_cast<char*>(nameObj) + 0x10);
            wchar_t* wchars = reinterpret_cast<wchar_t*>(static_cast<char*>(nameObj) + 0x14);

            bool isPrefab = false, hasLoading = false;
            std::string assetName;
            assetName.reserve(len);
            for (int32_t c = 0; c < len; ++c) {
                assetName.push_back(static_cast<char>(wchars[c]));
            }

            if (assetName.find(".prefab") != std::string::npos &&
                assetName.find("loading") != std::string::npos)
            {
                void* loadParams[] = { nameObj };
                m_loadPrefab = MethodHandler::invoke<void*>(loadAsset, m_assetBundle, loadParams);
                if (m_loadPrefab) break;
            }
        }

        if (!m_loadPrefab) {
            FLOG("[BetterLoadingScreen] No loading prefab found in bundle");
            m_bundleFailed = true;
            return false;
        }

        m_bundleLoaded = true;
        return true;
    }

    void BetterLoadingScreenModule::CleanupOriginal(void* popupRaw) {
        Transform popupT = GameObject{ popupRaw }.GetTransform();
        if (!popupT) return;

        const char* disablePaths[] = {
            "3DElements/LoadingBackground_TealGradient",
            "3DElements/LoadingBackground_TealGradient/SkyCube_Baked",
            "3DElements/LoadingBackground_TealGradient/_FX_ParticleBubbles",
            "ProgressPanel/Parent_Loading_Progress/Decoration_Right",
            "ProgressPanel/Parent_Loading_Progress/Decoration_Left",
            "ProgressPanel/Parent_Loading_Progress/Panel_Backdrop",
        };

        for (auto* path : disablePaths) {
            auto t = popupT.Find(path);
            if (t.valid()) {
                auto go = t.GetGameObject();
                if (go.valid()) go.SetActive(false);
            }
        }

        IL2CPP::Color pink = { 1.0f, 0.55f, 0.7f, 0.35f };

        const char* buttonPaths[] = {
            "ProgressPanel/Parent_Loading_Progress/GoButton",
            "ButtonMiddle",
        };

        static auto setGraphicColor = MethodHandler::resolve("UnityEngine.UI.Graphic", "set_color", 1);
        static auto setTransition = MethodHandler::resolve("UnityEngine.UI.Selectable", "set_transition", 1);

        for (auto* btnPath : buttonPaths) {
            auto btnT = popupT.Find(btnPath);
            if (!btnT.valid()) continue;
            auto btnGO = btnT.GetGameObject();
            if (!btnGO.valid()) continue;

            auto btnComp = btnGO.GetComponentByName("UnityEngine.UI.Button");
            if (btnComp.valid() && setTransition) {
                int none = 0;
                void* tp[] = { &none };
                MethodHandler::invoke(setTransition, btnComp.raw(), tp);
            }

            auto imgComp = btnGO.GetComponentByName("UnityEngine.UI.Image");
            if (imgComp.valid() && setGraphicColor) {
                void* cp[] = { &pink };
                MethodHandler::invoke(setGraphicColor, imgComp.raw(), cp);
            }

            btnT.SetLocalScale({ 0.92f, 0.92f, 0.92f });
        }

        auto infoPanel = popupT.Find("3DElements/LoadingInfoPanel/InfoPanel_Template_ANIM");
        if (!infoPanel.valid()) return;

        auto infoPanelGO = infoPanel.GetGameObject();
        if (!infoPanelGO.valid()) return;

        auto animatorClass = Class::find("UnityEngine.Animator");
        if (animatorClass) {
            auto animComp = infoPanelGO.GetComponent(animatorClass);
            if (animComp.valid()) {
                static auto setEnabled = MethodHandler::resolve("UnityEngine.Behaviour", "set_enabled", 1);
                if (setEnabled) {
                    bool off = false;
                    void* p[] = { &off };
                    MethodHandler::invoke<void>(setEnabled, animComp.raw(), p);
                }
            }
        }

        infoPanelGO.SetActive(false);
    }

    bool BetterLoadingScreenModule::TrySpawnScreen() {
        if (!m_loadPrefab) return false;

        auto popup = GameObject::Find("UserInterface/MenuContent/Popups/LoadingPopup");
        if (!popup.valid()) popup = GameObject::Find("LoadingPopup");
        if (!popup.valid()) return false;

        auto popupT = popup.GetTransform();
        if (!popupT.valid()) return false;

        auto existing = popupT.Find("BetterLoadingScreen_Loading");
        if (existing.valid()) return true;

        static auto instantiate1 = MethodHandler::resolve("UnityEngine.Object", "Instantiate", 1);
        if (!instantiate1) {
            FLOG("[BetterLoadingScreen] Cannot resolve Object.Instantiate");
            return false;
        }

        void* instParams[] = { m_loadPrefab };
        void* instanceRaw = MethodHandler::invoke<void*>(instantiate1, nullptr, instParams);
        if (!instanceRaw) {
            FLOG("[BetterLoadingScreen] Instantiate returned null, disabling");
            m_state = State::Failed;
            return false;
        }

        GameObject instance(instanceRaw);
        if (!instance.valid()) return false;

        auto instT = instance.GetTransform();
        if (!instT.valid()) {
            Object(instanceRaw).Destroy();
            return false;
        }

        instT.SetParent(popupT, false);

        static auto setName = MethodHandler::resolve("UnityEngine.Object", "set_name", 1);
        if (setName) {
            void* nameStr = IL2CPP::Module::StringNew("BetterLoadingScreen_Loading");
            if (nameStr) {
                void* np[] = { nameStr };
                MethodHandler::invoke<void>(setName, instanceRaw, np);
            }
        }

        instT.SetLocalScale({400.f, 400.f, 400.f});

        CleanupOriginal(popup.raw());

        return true;
    }

    void BetterLoadingScreenModule::OnSceneLoad(int, int) {
        m_flatBgHidden = false;
        if (m_state == State::Failed) return;
        if (!LoadBundle()) return;
        m_state = State::WaitForPopup;
        m_retryCount = 0;
        m_retryTimer = 0.f;
    }

    void BetterLoadingScreenModule::HideFlatOverlayBg() {
        if (m_flatBgHidden) return;

        auto bgGo = GameObject::Find("FlatLoadingOverlay(Clone)/Container/Canvas/Background");
        if (!bgGo.valid()) return;

        auto imgComp = bgGo.GetComponentByName("UnityEngine.UI.Image");
        if (!imgComp.valid()) return;

        static auto setEnabled = MethodHandler::resolve("UnityEngine.Behaviour", "set_enabled", 1);
        if (setEnabled) {
            bool off = false;
            void* p[] = { &off };
            MethodHandler::invoke<void>(setEnabled, imgComp.raw(), p);
        }

        m_flatBgHidden = true;
    }

    void BetterLoadingScreenModule::OnUpdate() {
        if (m_state != State::Failed)
            HideFlatOverlayBg();

        if (m_state != State::WaitForPopup) return;

        m_retryTimer -= Time::GetDeltaTime();
        if (m_retryTimer > 0.f) return;
        m_retryTimer = kRetryInterval;

        if (TrySpawnScreen()) {
            m_state = State::Applied;
            return;
        }

        if (++m_retryCount >= kMaxRetries) {
            FLOG("[BetterLoadingScreen] Max retries reached, giving up");
            m_state = State::Failed;
        }
    }

} // namespace UNIx