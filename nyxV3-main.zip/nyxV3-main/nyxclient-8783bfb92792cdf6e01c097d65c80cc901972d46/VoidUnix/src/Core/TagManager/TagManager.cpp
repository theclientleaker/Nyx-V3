#define WIN32_LEAN_AND_MEAN
#include <Windows.h>

#include <Core/TagManager/TagManager.hpp>
#include <Core/ApiClient/ApiClient.hpp>
#include <Core/FileLog/FileLog.hpp>
#include <algorithm>
#include <cctype>
#include <cstdlib>
#include <string_view>

namespace UNIx {

    TagManager& TagManager::Get() {
        static TagManager instance;
        return instance;
    }

    TagManager::~TagManager() {
        Stop();
    }

    void TagManager::Start() {
        if (m_running.exchange(true)) return;
        FLOG("[TagManager] Starting fetch thread");
        m_thread = std::thread(&TagManager::FetchLoop, this);
    }

    void TagManager::Stop() {
        FLOG("[TagManager] Stopping fetch thread");
        m_running = false;
        if (m_thread.joinable())
            m_thread.join();
    }

    std::vector<ParsedTag> TagManager::GetParsedTagsForUser(const std::string& userId) const {
        std::shared_lock lock(m_mutex);
        auto it = m_tags.find(userId);
        if (it != m_tags.end())
            return it->second;
        return {};
    }

    std::string TagManager::GetRawTagsForUser(const std::string& userId) const {
        std::shared_lock lock(m_mutex);
        auto it = m_rawTags.find(userId);
        if (it != m_rawTags.end())
            return it->second;
        return "";
    }

    void TagManager::RequestRefresh() {
        m_refreshRequested = true;
    }

    void TagManager::FetchLoop() {
        for (int i = 0; i < 100 && m_running && !m_refreshRequested; ++i)
            Sleep(100);
        if (m_running) FetchTags();
        while (m_running) {
            if (m_refreshRequested.exchange(false)) {
                FetchTags();
            } else {
                std::string ver = FetchVersion();
                if (!ver.empty() && ver != m_lastVersion) {
                    FLOG("[TagManager] Version changed: {} -> {}", m_lastVersion, ver);
                    m_lastVersion = ver;
                    FetchTags();
                }
            }
            for (int i = 0; i < 50 && m_running; ++i) {
                if (m_refreshRequested) break;
                Sleep(100);
            }
        }
    }

    std::string TagManager::FetchVersion() {
        return ApiClient::Get().Get("/api/tags/version");
    }

    void TagManager::FetchTags() {
        FLOG("[TagManager] Fetching tags...");

        std::string body = ApiClient::Get().Get("/api/tags");

        if (!body.empty()) {
            FLOG("[TagManager] Got {} bytes, parsing", body.size());
            ParseResponse(body);
        } else {
            FLOG("[TagManager] Empty response body");
        }
    }

    void TagManager::ParseResponse(const std::string& body) {
        std::unordered_map<std::string, std::vector<ParsedTag>> newTags;
        std::unordered_map<std::string, std::string> newRawTags;

        std::string_view remaining(body);
        while (!remaining.empty()) {
            size_t nlPos = remaining.find('\n');
            std::string_view line = (nlPos != std::string_view::npos) ? remaining.substr(0, nlPos) : remaining;
            remaining = (nlPos != std::string_view::npos) ? remaining.substr(nlPos + 1) : std::string_view{};

            if (!line.empty() && line.back() == '\r')
                line.remove_suffix(1);
            if (line.empty()) continue;

            auto colonPos = line.rfind(':');
            if (colonPos == std::string_view::npos || colonPos == 0) continue;

            std::string_view tagsPart = line.substr(0, colonPos);
            std::string_view userIdView = line.substr(colonPos + 1);

            if (userIdView.empty() || userIdView.substr(0, 4) != "usr_") continue;

            std::string userId(userIdView);
            newRawTags[userId] = std::string(tagsPart);

            std::vector<ParsedTag> parsed;
            std::string_view tagsRemaining = tagsPart;
            while (!tagsRemaining.empty()) {
                size_t commaPos = tagsRemaining.find(',');
                std::string_view singleTag = (commaPos != std::string_view::npos) ? tagsRemaining.substr(0, commaPos) : tagsRemaining;
                tagsRemaining = (commaPos != std::string_view::npos) ? tagsRemaining.substr(commaPos + 1) : std::string_view{};

                if (!singleTag.empty())
                    parsed.push_back(ParseSingleTag(singleTag));
            }

            if (!parsed.empty())
                newTags[userId] = std::move(parsed);
        }

        std::unique_lock lock(m_mutex);
        m_tags = std::move(newTags);
        m_rawTags = std::move(newRawTags);
    }

    ParsedTag TagManager::ParseSingleTag(std::string_view raw) {
        ParsedTag tag;
        std::string_view remaining = raw;

        if (remaining.size() > 6 && remaining.substr(0, 6) == "<icon=") {
            auto closePos = remaining.find('>');
            if (closePos != std::string_view::npos) {
                tag.iconName = std::string(remaining.substr(6, closePos - 6));
                return tag;
            }
        }

        while (remaining.size() > 2) {
            std::string_view animPrefix;
            size_t textStart;
            char delim = '\0';

            if (remaining[0] == '.' || remaining[0] == ':') {
                delim = remaining[0];
                size_t next = std::string_view::npos;
                for (size_t j = 1; j < remaining.size(); ++j) {
                    if (remaining[j] == '.' || remaining[j] == ':') { next = j; break; }
                }
                if (next == std::string_view::npos) break;
                animPrefix = remaining.substr(1, next - 1);
                textStart = next + 1;
            } else {
                if (remaining[0] == '<') break;
                size_t next = std::string_view::npos;
                for (size_t j = 0; j < remaining.size(); ++j) {
                    if (remaining[j] == '.' || remaining[j] == ':') { next = j; break; }
                }
                if (next == std::string_view::npos) break;
                animPrefix = remaining.substr(0, next);
                textStart = next + 1;
            }

            AnimationType at = ParseAnimation(animPrefix);
            if (at == AnimationType::None) break;
            if (tag.animation == AnimationType::None)
                tag.animation = at;
            tag.animFlags |= AnimTypeToFlag(at);
            remaining = remaining.substr(textStart);
        }

        auto colorStart = remaining.find("<color=");
        if (colorStart != std::string_view::npos) {
            size_t colorCount = 0;
            size_t searchPos = 0;
            while (searchPos < remaining.size()) {
                auto pos = remaining.find("<color=", searchPos);
                if (pos == std::string_view::npos) break;
                colorCount++;
                searchPos = pos + 7;
            }

            if (colorCount > 1) {
                tag.text = std::string(remaining);
                tag.isRichText = true;
            } else {
                auto colorEnd = remaining.find('>', colorStart);
                if (colorEnd != std::string_view::npos && colorEnd > colorStart) {
                    std::string_view colorVal = remaining.substr(colorStart + 7, colorEnd - colorStart - 7);
                    if (!colorVal.empty() && colorVal[0] == '#')
                        colorVal.remove_prefix(1);
                    tag.color = ParseColor(colorVal);

                    auto closeTag = remaining.find("</color>");
                    if (closeTag != std::string_view::npos) {
                        tag.text = std::string(remaining.substr(colorEnd + 1, closeTag - colorEnd - 1));
                    } else {
                        tag.text = std::string(remaining.substr(colorEnd + 1));
                    }
                } else {
                    tag.text = std::string(remaining);
                }
            }
        } else {
            tag.text = std::string(remaining);
        }

        return tag;
    }

    AnimationType TagManager::ParseAnimation(std::string_view prefix) {
        static const std::unordered_map<std::string, AnimationType> lookup = {
            {"RAIN", AnimationType::Rainbow},
            {"SR", AnimationType::SmoothRainbow},
            {"BLINK", AnimationType::Blink},
            {"SCROLL", AnimationType::Scroll},
            {"CYLINDER", AnimationType::Cylinder},
            {"CYLN", AnimationType::Cylinder},
            {"PULSE", AnimationType::Pulse},
            {"GLITCH", AnimationType::Glitch},
            {"GT", AnimationType::GhostTrail},
            {"JUMP", AnimationType::Jump},
            {"SHAKE", AnimationType::Shake},
            {"LBL", AnimationType::LetterByLetter},
        };

        char buf[16];
        if (prefix.size() >= sizeof(buf)) return AnimationType::None;
        for (size_t i = 0; i < prefix.size(); ++i)
            buf[i] = static_cast<char>(std::toupper(static_cast<unsigned char>(prefix[i])));
        buf[prefix.size()] = '\0';

        auto it = lookup.find(buf);
        return (it != lookup.end()) ? it->second : AnimationType::None;
    }

    Color4 TagManager::ParseColor(std::string_view hex) {
        Color4 c;
        if (hex.size() < 6) return c;

        char buf[7];
        std::memcpy(buf, hex.data(), 6);
        buf[6] = '\0';

        unsigned long val = std::strtoul(buf, nullptr, 16);
        c.r = ((val >> 16) & 0xFF) / 255.f;
        c.g = ((val >> 8) & 0xFF) / 255.f;
        c.b = (val & 0xFF) / 255.f;

        if (hex.size() >= 8) {
            char alphaBuf[3] = { static_cast<char>(hex[6]), static_cast<char>(hex[7]), '\0' };
            unsigned long alpha = std::strtoul(alphaBuf, nullptr, 16);
            c.a = alpha / 255.f;
        }

        return c;
    }

} // namespace UNIx
