#pragma once
#include <Core/BaseModule.hpp>

namespace UNIx {

    class MovementModule : public BaseModule {
    public:
        MovementModule();

        void OnUpdate() override;
        void OnRender() override;
        void OnDisable() override;
        void OnSetupQuickMenu(uint32_t moduleId, uint32_t categoryPageId) override;

    private:
        float m_runSpeed = 4.0f;
        float m_walkSpeed = 2.0f;
        float m_strafeSpeed = 2.0f;
        float m_jumpImpulse = 3.0f;
        float m_gravity = 1.0f;
        bool m_wasActive = false;

        static MovementModule* s_instance;
        static void __cdecl QmRunSpeedCb(uint32_t id, float val);
        static void __cdecl QmWalkSpeedCb(uint32_t id, float val);
        static void __cdecl QmStrafeSpeedCb(uint32_t id, float val);
        static void __cdecl QmJumpCb(uint32_t id, float val);
        static void __cdecl QmGravityCb(uint32_t id, float val);
    };

} // namespace UNIx
