#pragma once
#include <Core/BaseModule.hpp>
#include <string>
#include <cstdint>

namespace UNIx {

    class CalendarQMModule : public BaseModule {
    public:
        enum class ConsoleTab : uint8_t { PlayerEvents = 0, Udon = 1, Functions = 2 };

        CalendarQMModule()
            : BaseModule("Calendar QM", "Replaces Calendar page with nyx console", 0, "UI") {
            m_showInQuickMenu = false;
            m_enabled = true;
        }

        void OnUpdate() override;
        void OnSceneLoad(int scene, int loadMode) override;

    private:
        void StripCalendarPage();
        void SwapCalendarIcons();
        void CreateTabs();
        void CreateConsoleTexts();
        void UpdateConsoleTexts();
        std::string BuildRichText(ConsoleTab filter);
        static ConsoleTab CategorizeEntry(const std::string& text);

        bool  m_stripped = false;
        bool  m_tabsCreated = false;
        bool  m_textsCreated = false;
        bool  m_qmIconSwapped = false;
        bool  m_mmIconSwapped = false;

        // Tab labels
        void* m_tabBtnObjects[3] = {};
        void* m_tabTmpRaws[3] = {};

        // 3 console text columns (one per tab)
        void* m_textObjects[3] = {};
        void* m_tmpRaws[3] = {};
        size_t m_lastLineCount = 0;
    };

} // namespace UNIx
