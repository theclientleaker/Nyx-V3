#pragma once
#include <Core/BaseModule.hpp>
#include <IL2CPP.Common/il2cpp_shared.hpp>

namespace UNIx {

    class ThirdPersonModule : public BaseModule {
    public:
        ThirdPersonModule();

        void OnUpdate() override;
        void OnDisable() override;
        void OnSceneLoad(int scene, int loadMode) override;

    private:
        enum class CameraMode { Normal, Behind, InFront };

        void CreateCameras();
        void DestroyCameras();
        void ShowHead(bool show);

        CameraMode m_mode = CameraMode::Normal;
        float m_distance = 3.0f;
        void* m_camBack = nullptr;
        void* m_camFront = nullptr;
        void* m_headBone = nullptr;
        IL2CPP::Vector3 m_savedHeadScale{1.f, 1.f, 1.f};
        bool m_headShown = false;
        bool m_camerasCreated = false;
    };

} // namespace UNIx
