#include <Modules/UI/Toasts/ToastModule.hpp>
#include <Core/ModuleManager.hpp>
#include <Core/PlayerCache/PlayerCache.hpp>
#include <Core/Globals.hpp>
#include <Core/FileLog/FileLog.hpp>
#include <Core/QuickMenuEx.hpp>

#include <IL2CPP.Module/include/il2cpp_module.hpp>
#include <IL2CPP.Module/include/Unity/Transform.hpp>
#include <IL2CPP.Module/include/Unity/TMP_Text.hpp>
#include <IL2CPP.Module/include/Unity/Time.hpp>
#include <IL2CPP.Module/include/Unity/Object.hpp>
#include <IL2CPP.Module/include/MethodHandler.hpp>
#include <IL2CPP.Module/include/Reflection.hpp>
#include <IL2CPP.Module/include/ManagedObject.hpp>

#include <Core/VRChatApi/VRChatApi.hpp>
#include <Core/SpriteLoader/SpriteLoader.hpp>
#include <resource.h>

using namespace IL2CPP::Module;
using namespace IL2CPP::Module::Unity;

namespace UNIx {

    ToastModule* ToastModule::s_instance = nullptr;

    void __cdecl ToastModule::QmShowJoinsCb(uint32_t, bool val) { if (s_instance) s_instance->m_showJoins = val; }
    void __cdecl ToastModule::QmShowLeavesCb(uint32_t, bool val) { if (s_instance) s_instance->m_showLeaves = val; }
    void __cdecl ToastModule::QmShowFriendsCb(uint32_t, bool val) { if (s_instance) s_instance->m_showFriends = val; }
    void __cdecl ToastModule::QmShowFriendOnlineCb(uint32_t, bool val) { if (s_instance) s_instance->m_showFriendOnline = val; }

    ToastModule::ToastModule()
        : BaseModule("Notifications", "Push notifications into VRChat's HUD carousel", 0, "UI") {
        m_enabled = true;
        m_showInQuickMenu = true;
        m_joinGrace = kJoinGracePeriod;

        VRChatApi::Get().SetFriendStatusCallback([this](const std::string& name, bool online) {
            if (!m_showFriendOnline) return;
            if (online)
                AddToast(name + " is now online", ToastType::FriendOnline);
            else
                AddToast(name + " went offline", ToastType::FriendOffline);
        });
    }

    void ToastModule::AddToast(const std::string& message, ToastType type) {
        std::lock_guard lock(m_pendingMutex);
        m_queue.push_back({ message, type });
    }

    void ToastModule::OnPlayerJoinComplete(IL2CPP::VRChat::Player player) {
        if (!player) return;
        if (m_joinGrace > 0.f) return;
        auto api = player.GetVRCPlayerApi();
        if (!api) return;
        if (api.IsLocal()) return;
        std::string name = api.GetDisplayName();
        if (name.empty()) return;
        auto user = player.GetAPIUser();
        bool isFriend = user.valid() && user.GetIsFriend();
        if (isFriend && m_showFriends)
            AddToast(name + " joined", ToastType::FriendJoin);
        else if (m_showJoins)
            AddToast(name + " joined", ToastType::Join);
    }

    void ToastModule::OnPlayerLeave(IL2CPP::VRChat::Player player) {
        if (!player) return;
        if (m_joinGrace > 0.f) return;
        auto api = player.GetVRCPlayerApi();
        if (!api) return;
        if (api.IsLocal()) return;
        std::string name = api.GetDisplayName();
        if (name.empty()) return;
        auto& cache = ModuleManager::Get().GetPlayerCache();
        auto entry = cache.FindByPlayerId(api.GetPlayerId());
        bool isFriend = entry.has_value() && entry->isFriend;
        if (isFriend && m_showFriends)
            AddToast(name + " left", ToastType::FriendLeave);
        else if (m_showLeaves)
            AddToast(name + " left", ToastType::Leave);
    }

    void ToastModule::OnSceneLoad(int, int loadMode) {
        if (loadMode == 0) {
            m_carouselComponent = nullptr;
            m_initialized = false;
            m_initDelay = 5.f;
            m_joinGrace = kJoinGracePeriod;
            m_showing = false;
            m_showTimer = 0.f;
            {
                std::lock_guard lock(m_pendingMutex);
                m_queue.clear();
            }
        }
    }

    void ToastModule::OnSceneUnload(int, int) {
        m_carouselComponent = nullptr;
        m_initialized = false;
        m_initDelay = 6.f;
        m_showing = false;
        m_showTimer = 0.f;
    }

    void ToastModule::FindCarousel() {
        auto ui = GameObject::Find("UserInterface");
        if (!ui.IsValid()) { m_initDelay = 2.f; return; }
        auto uiT = ui.GetTransform();
        auto carouselT = uiT.Find("UnscaledUI/HudContent/HUD_UI 2(Clone)/VR Canvas/Container/Center/F2_DesktopMenuOpen/User Event Carousel");
        if (!carouselT.valid())
            carouselT = uiT.Find("UnscaledUI/HudContent/HUD_UI 2(Clone)/VR Canvas/Container/Center/F2/User Event Carousel");
        if (!carouselT.valid()) { m_initDelay = 3.f; return; }
        auto carouselGO = carouselT.GetGameObject();
        if (!carouselGO.valid()) { m_initDelay = 3.f; return; }
        auto comp = carouselGO.GetComponentByName("MonoBehaviourPublicMoQuQuLiLiSiEnSpSpSpSpSpUnique");
        if (!comp.valid()) { m_initDelay = 3.f; return; }
        m_carouselComponent = comp.raw();
        m_initialized = true;
        FLOG("[Notif] Got carousel component");
    }

    static void* GetToastSprite(ToastType type) {
        auto& sl = SpriteLoader::Get();
        switch (type) {
            case ToastType::Join:          return sl.LoadFromResource(IDR_ICON_DOOR, "notif_door");
            case ToastType::Leave:         return sl.LoadFromResource(IDR_ICON_DOOR, "notif_door");
            case ToastType::FriendJoin:    return sl.LoadFromResource(IDR_ICON_USERS_THREE, "notif_users");
            case ToastType::FriendLeave:   return sl.LoadFromResource(IDR_ICON_USERS_THREE, "notif_users");
            case ToastType::FriendOnline:  return sl.LoadFromResource(IDR_ICON_GLOBE, "notif_globe");
            case ToastType::FriendOffline: return sl.LoadFromResource(IDR_ICON_GLOBE, "notif_globe");
            case ToastType::Info:          return sl.LoadFromResource(IDR_ICON_LOGO, "notif_logo");
            default:                       return nullptr;
        }
    }

    void ToastModule::ShowNativeNotification(const std::string& message, ToastType type) {
        if (!m_carouselComponent) return;

        static Method s_noTranslation;
        static Method s_showMethod;
        static bool s_resolved = false;

        if (!s_resolved) {
            s_resolved = true;
            auto extClass = Class::find("VRC.Localization.LocalizableStringExtensions");
            if (extClass)
                s_noTranslation = extClass.get_method("NoTranslation", 4);
            auto carouselClass = Class::find("MonoBehaviourPublicMoQuQuLiLiSiEnSpSpSpSpSpUnique");
            if (carouselClass) {
                auto methods = carouselClass.get_methods();
                for (auto& m : methods) {
                    if (m.param_count() == 3 && m.is_public() && !m.is_static()) {
                        std::string n = m.name() ? m.name() : "";
                        if (n.find("LocalizableString") != std::string::npos &&
                            n.find("Sprite") != std::string::npos &&
                            n.find("Single") != std::string::npos) {
                            s_showMethod = m;
                            break;
                        }
                    }
                }
            }
        }

        if (!s_noTranslation || !s_showMethod) return;

        void* il2cppStr = IL2CPP::Module::StringNew(message.c_str());
        if (!il2cppStr) return;

        void* ntParams[] = { il2cppStr, nullptr, nullptr, nullptr };
        void* boxedStruct = nullptr;
        try { boxedStruct = s_noTranslation.invoke(nullptr, ntParams); } catch (...) {}
        if (!boxedStruct) return;

        void* structData = static_cast<char*>(static_cast<void*>(boxedStruct)) + 0x10;
        void* sprite = GetToastSprite(type);
        float duration = kDisplayTime;
        void* showParams[] = { structData, sprite, &duration };
        try { s_showMethod.invoke(m_carouselComponent, showParams); } catch (...) { return; }

        FLOG("[Notif] Showed: {}", message);
    }

    void ToastModule::OnUpdate() {
        float dt = Time::GetDeltaTime();

        if (m_joinGrace > 0.f) {
            m_joinGrace -= dt;
            if (m_joinGrace <= 0.f) {
                m_joinGrace = 0.f;
                std::lock_guard lock(m_pendingMutex);
                m_queue.clear();
            }
        }

        if (!m_initialized) {
            m_initDelay -= dt;
            if (m_initDelay <= 0.f)
                FindCarousel();
            return;
        }

        if (m_showing) {
            m_showTimer += dt;
            if (m_showTimer >= kDisplayTime)
                m_showing = false;
            else
                return;
        }

        PendingToast next;
        bool hasNext = false;
        {
            std::lock_guard lock(m_pendingMutex);
            if (!m_queue.empty()) {
                next = m_queue.front();
                m_queue.pop_front();
                hasNext = true;
            }
        }

        if (hasNext) {
            try {
                ShowNativeNotification(next.message, next.type);
                m_showing = true;
                m_showTimer = 0.f;
            }
            catch (...) { FLOG("[Notif] ShowNativeNotification exception"); }
        }
    }

    void ToastModule::OnSetupQuickMenu(uint32_t moduleId, uint32_t categoryPageId) {
        s_instance = this;
        auto& qmEx = QuickMenuEx::Get();
        uint32_t fold = qmEx.add_foldout(moduleId, categoryPageId, "Notification Settings", false, true);
        qmEx.add_settings_toggle(moduleId, fold, "Show Joins", m_showJoins, QmShowJoinsCb, "notif_joins");
        qmEx.add_settings_toggle(moduleId, fold, "Show Leaves", m_showLeaves, QmShowLeavesCb, "notif_leaves");
        qmEx.add_settings_toggle(moduleId, fold, "Show Friends", m_showFriends, QmShowFriendsCb, "notif_friends");
        qmEx.add_settings_toggle(moduleId, fold, "Friend Online/Offline", m_showFriendOnline, QmShowFriendOnlineCb, "notif_friend_online");
    }

} // namespace UNIx
