#pragma once
#include <Core/BaseModule.hpp>

namespace UNIx {

    class QMCleanupModule : public BaseModule {
    public:
        QMCleanupModule()
            : BaseModule("QM Cleanup", "Destroys the report button from the Quick Menu", 0, "UI") {
            m_showInQuickMenu = true;
            m_enabled = true;
        }

        void OnUpdate() override;
        void OnEnable() override;
        void OnDisable() override;
        void OnSceneLoad(int scene, int loadMode) override;

    private:
        void RunCleanup();

        static constexpr int kCleanupCount = 3;
        bool m_destroyed[kCleanupCount] = {};
        bool m_titleRenamed = false;
        bool m_chinStripped = false;
    };

} // namespace UNIx
