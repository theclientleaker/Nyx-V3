#pragma once
#include <Core/BaseModule.hpp>
#include <vector>
#include <string>

namespace UNIx {

class SettingsMenuModule : public BaseModule {
public:
    SettingsMenuModule();

    void OnEnable() override;
    void OnDisable() override;
    void OnUpdate() override;
    void OnLateUpdate() override;
    void OnSceneLoad(int scene, int loadMode) override;
    bool OnEvent(UINT msg, WPARAM wParam, LPARAM lParam) override;

    static SettingsMenuModule* s_instance;
    static void __cdecl QmSettingsButtonCb(uint32_t buttonId);

    bool  m_pendingShow         = false;

private:
    void InitMenu();
    void InitTabButton();
    void InitPageContent();
    void InitContentButtons();
    void CleanupMenu();
    void ShowNyxPage();
    void HideNyxPage();
    void PlayClickSound();

    static void SetTMPText(void* tmpComp, const char* text);
    static void StripVRCLogicComponents(void* goRaw);
    static void EnableAllBehaviours(void* goRaw);
    static void EnableAllBehavioursRecursive(void* transformRaw);

    void* m_menuGO              = nullptr;
    void* m_tabButtonGO         = nullptr;
    void* m_headerOffsetT       = nullptr;
    void* m_navVLG              = nullptr;
    void* m_contentViewport     = nullptr;
    void* m_menuCanvasGroup     = nullptr;
    void* m_menuCanvas          = nullptr;
    void* m_tabBarParent        = nullptr;
    void* m_mscComponent        = nullptr;
    void* m_clickAudioClip      = nullptr;

    struct NavButton {
        void* goRaw = nullptr;
        std::string label;
    };
    std::vector<NavButton> m_navButtons;

    struct ContentButton {
        void* goRaw = nullptr;
        std::string label;
    };
    std::vector<ContentButton> m_contentButtons;

    bool  m_initialized         = false;
    int   m_initDelay           = 0;
    bool  m_visible             = false;
    int   m_showCooldown        = 0;
    bool  m_tabWasSelected      = false;
};

} // namespace UNIx
