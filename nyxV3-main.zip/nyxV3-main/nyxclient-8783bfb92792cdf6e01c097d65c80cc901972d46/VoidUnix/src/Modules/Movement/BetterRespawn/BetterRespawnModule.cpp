#include <Modules/Movement/BetterRespawn/BetterRespawnModule.hpp>
#include <Core/ModuleManager.hpp>
#include <Core/FileLog/FileLog.hpp>

#include <Bootstrap.Module/include/VRChat/VRCPlayerApi.hpp>
#include <Bootstrap.Module/include/VRChat/VRCPlayer.hpp>
#include <Bootstrap.Module/include/VRChat/Player.hpp>
#include <Bootstrap.Module/include/VRChat/APIUser.hpp>

#include <IL2CPP.Module/include/Unity/Time.hpp>

#include <ThirdParty/imgui/imgui.h>

#include <fstream>
#include <sstream>
#include <filesystem>

using namespace IL2CPP::Module::Unity;

namespace UNIx {

    BetterRespawnModule::BetterRespawnModule()
        : BaseModule("Better Respawn", "Saves position per world and restores on rejoin", 0, "Movement") {
        m_showInQuickMenu = true;
    }

    void BetterRespawnModule::OnEnable() {
        if (!m_loaded) LoadPositions();
    }

    void BetterRespawnModule::OnDisable() {
        if (!m_currentWorldId.empty()) {
            auto local = GetLocalPlayerApi();
            if (local.valid() && local.IsValid()) {
                m_saved[m_currentWorldId] = { local.GetPosition(), local.GetRotation() };
                SavePositions();
            }
        }
    }

    std::string BetterRespawnModule::GetCurrentWorldId() {
        try {
            auto vrcPlayer = GetLocalVRCPlayer();
            if (!vrcPlayer.valid()) return {};
            auto player = vrcPlayer.GetPlayer();
            if (!player.valid()) return {};
            auto apiUser = player.GetAPIUser();
            if (!apiUser.valid()) return {};
            std::string loc = apiUser.GetLocation();
            if (loc.empty() || loc.find("wrld_") == std::string::npos) return {};
            auto colon = loc.find(':');
            if (colon != std::string::npos)
                return loc.substr(0, colon);
            return loc;
        } catch (...) {}
        return {};
    }

    void BetterRespawnModule::OnSceneLoad(int, int) {
        if (!m_currentWorldId.empty()) {
            auto local = GetLocalPlayerApi();
            if (local.valid() && local.IsValid()) {
                m_saved[m_currentWorldId] = { local.GetPosition(), local.GetRotation() };
                SavePositions();
                FLOG("[BetterRespawn] Saved position for {}", m_currentWorldId);
            }
        }
        m_currentWorldId.clear();
        m_pendingRestore = true;
        m_restoreDelay = kRestoreDelay;
    }

    void BetterRespawnModule::OnUpdate() {
        if (!InRoom()) return;

        if (m_pendingRestore) {
            m_restoreDelay -= Time::GetDeltaTime();
            if (m_restoreDelay > 0.f) return;
            m_pendingRestore = false;

            std::string wid = GetCurrentWorldId();
            if (wid.empty()) return;
            m_currentWorldId = wid;

            auto it = m_saved.find(wid);
            if (it != m_saved.end()) {
                auto local = GetLocalPlayerApi();
                if (local.valid() && local.IsValid()) {
                    local.TeleportTo(it->second.position, it->second.rotation);
                    FLOG("[BetterRespawn] Restored position for {}", wid);
                }
            }
            return;
        }

        if (m_currentWorldId.empty()) {
            m_currentWorldId = GetCurrentWorldId();
        }

        m_saveTimer += Time::GetDeltaTime();
        if (m_saveTimer >= kSaveInterval) {
            m_saveTimer = 0.f;
            if (!m_currentWorldId.empty()) {
                auto local = GetLocalPlayerApi();
                if (local.valid() && local.IsValid()) {
                    m_saved[m_currentWorldId] = { local.GetPosition(), local.GetRotation() };
                }
            }
        }
    }

    void BetterRespawnModule::SavePositions() {
        try {
            std::filesystem::create_directories("C:\\nyx\\Config");
            std::ofstream f(kSavePath, std::ios::trunc);
            if (!f) return;
            for (auto& [wid, t] : m_saved) {
                f << wid << '\t'
                  << t.position.x << '\t' << t.position.y << '\t' << t.position.z << '\t'
                  << t.rotation.x << '\t' << t.rotation.y << '\t' << t.rotation.z << '\t' << t.rotation.w << '\n';
            }
        } catch (...) {}
    }

    void BetterRespawnModule::LoadPositions() {
        m_loaded = true;
        m_saved.clear();
        try {
            std::ifstream f(kSavePath);
            if (!f) return;
            std::string line;
            while (std::getline(f, line)) {
                if (line.empty()) continue;
                std::istringstream ss(line);
                std::string wid;
                SavedTransform t;
                if (!(ss >> wid >> t.position.x >> t.position.y >> t.position.z
                         >> t.rotation.x >> t.rotation.y >> t.rotation.z >> t.rotation.w))
                    continue;
                m_saved[wid] = t;
            }
            FLOG("[BetterRespawn] Loaded {} saved positions", m_saved.size());
        } catch (...) {}
    }

    void BetterRespawnModule::OnRender() {
        ImGui::Text("Current world: %s", m_currentWorldId.empty() ? "none" : m_currentWorldId.c_str());
        ImGui::Text("Saved worlds: %d", static_cast<int>(m_saved.size()));

        auto it = m_saved.find(m_currentWorldId);
        if (it != m_saved.end()) {
            ImGui::Text("Saved pos: %.1f, %.1f, %.1f",
                it->second.position.x, it->second.position.y, it->second.position.z);
        }

        if (ImGui::Button("Save Now")) {
            if (!m_currentWorldId.empty()) {
                auto local = GetLocalPlayerApi();
                if (local.valid() && local.IsValid()) {
                    m_saved[m_currentWorldId] = { local.GetPosition(), local.GetRotation() };
                    SavePositions();
                }
            }
        }

        ImGui::SameLine();
        if (ImGui::Button("Clear All")) {
            m_saved.clear();
            SavePositions();
        }
    }

} // namespace UNIx
