#include <Modules/UI/Music/LoadingMusic.hpp>
#include <Core/Globals.hpp>
#include <Core/FileLog/FileLog.hpp>
#include <IL2CPP.Module/include/Unity/GameObject.hpp>
#include <IL2CPP.Module/include/Unity/AudioSource.hpp>
#include <IL2CPP.Module/include/Unity/Behaviour.hpp>
#include <IL2CPP.Module/include/Unity/Object.hpp>
#include <IL2CPP.Module/include/MethodHandler.hpp>
#include <IL2CPP.Module/include/Unity/Resources.hpp>
#include <IL2CPP.Module/include/Reflection.hpp>
#include <ThirdParty/imgui/imgui.h>
#include <filesystem>
#include <fstream>
#include <cstring>
#include <algorithm>

#define MINIMP3_FLOAT_OUTPUT
#include <ThirdParty/minimp3/minimp3.h>
#include <ThirdParty/minimp3/minimp3_ex.h>

#define STB_VORBIS_HEADER_ONLY
#include <ThirdParty/stb/stb_vorbis.c>

using namespace IL2CPP::Module;
using namespace IL2CPP::Module::Unity;

namespace UNIx {

    static constexpr float kVolume = 0.15f;

    struct WavHeader {
        char     riff[4];
        uint32_t fileSize;
        char     wave[4];
        char     fmt[4];
        uint32_t fmtSize;
        uint16_t audioFormat;
        uint16_t channels;
        uint32_t sampleRate;
        uint32_t byteRate;
        uint16_t blockAlign;
        uint16_t bitsPerSample;
    };

    static void ApplyClipToSource(AudioSource& source, void* clip) {
        source.Stop();
        source.SetClip(clip);
        source.SetLoop(true);
        source.SetVolume(kVolume);
        source.SetMute(false);
        source.Play();
    }

    void* LoadingMusic::CreateClipFromFloats(float* samples, int totalSamples, int channels, int sampleRate) {
        auto* exports = GetExports();
        if (!exports || !exports->m_stringNew || !exports->m_arrayNew) return nullptr;

        static auto clipCreate = MethodHandler::resolve("UnityEngine.AudioClip", "Create", 5);
        if (!clipCreate) clipCreate = MethodHandler::resolve("UnityEngine.AudioClip", "Create", 4);
        if (!clipCreate) clipCreate = MethodHandler::resolve("UnityEngine.AudioClip", "Create");
        if (!clipCreate) return nullptr;

        void* clipName = reinterpret_cast<void*(IL2CPP_CALLTYPE)(const char*)>(exports->m_stringNew)("nyx_music");
        bool stream = false;
        void* createParams[] = { clipName, &totalSamples, &channels, &sampleRate, &stream };
        void* clip = MethodHandler::invoke<void*>(clipCreate, nullptr, createParams);
        if (!clip) return nullptr;

        auto arrayClass = Class::find("System.Single");
        if (!arrayClass) return nullptr;

        size_t sampleCount = static_cast<size_t>(totalSamples) * channels;
        void* il2cppArray = reinterpret_cast<void*(IL2CPP_CALLTYPE)(void*, uintptr_t)>(exports->m_arrayNew)(
            arrayClass.raw(), static_cast<uintptr_t>(sampleCount));
        if (!il2cppArray) return nullptr;

        float* arrayData = reinterpret_cast<float*>(reinterpret_cast<uint8_t*>(il2cppArray) + 0x20);
        std::memcpy(arrayData, samples, sampleCount * sizeof(float));

        static auto setData = MethodHandler::resolve("UnityEngine.AudioClip", "SetData", 2);
        if (!setData) setData = MethodHandler::resolve("UnityEngine.AudioClip", "SetData");
        if (!setData) return nullptr;

        int offsetSamples = 0;
        void* setDataParams[] = { il2cppArray, &offsetSamples };
        MethodHandler::invoke<bool>(setData, clip, setDataParams);
        return clip;
    }

    void* LoadingMusic::CreateClipFromShorts(short* samples, int totalSamples, int channels, int sampleRate) {
        size_t sampleCount = static_cast<size_t>(totalSamples) * channels;
        std::vector<float> floatData(sampleCount);
        for (size_t i = 0; i < sampleCount; i++)
            floatData[i] = static_cast<float>(samples[i]) / 32768.0f;
        return CreateClipFromFloats(floatData.data(), totalSamples, channels, sampleRate);
    }

    void* LoadingMusic::LoadAudioAsClip(const std::string& path) {
        auto ext = std::filesystem::path(path).extension().string();
        for (auto& c : ext) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));

        if (ext == ".mp3") {
            mp3dec_t dec;
            mp3dec_file_info_t info{};
            mp3dec_init(&dec);
            int ret = mp3dec_load(&dec, path.c_str(), &info, nullptr, nullptr);
            if (ret || !info.buffer || info.samples == 0) {
                if (info.buffer) free(info.buffer);
                return nullptr;
            }
            int totalSamples = static_cast<int>(info.samples / info.channels);
            void* clip = CreateClipFromFloats(info.buffer, totalSamples, info.channels, info.hz);
            free(info.buffer);
            return clip;
        }

        if (ext == ".ogg") {
            int channels = 0, sampleRate = 0;
            short* output = nullptr;
            int totalSamples = stb_vorbis_decode_filename(path.c_str(), &channels, &sampleRate, &output);
            if (totalSamples < 0 || !output) {
                if (output) free(output);
                return nullptr;
            }
            void* clip = CreateClipFromShorts(output, totalSamples, channels, sampleRate);
            free(output);
            return clip;
        }

        if (ext == ".wav") {
            std::ifstream file(path, std::ios::binary);
            if (!file.is_open()) return nullptr;

            WavHeader header{};
            file.read(reinterpret_cast<char*>(&header), sizeof(header));
            if (std::memcmp(header.riff, "RIFF", 4) != 0 || std::memcmp(header.wave, "WAVE", 4) != 0)
                return nullptr;
            if (header.audioFormat != 1) return nullptr;

            if (header.fmtSize > 16)
                file.seekg(header.fmtSize - 16, std::ios::cur);

            char chunkId[4];
            uint32_t chunkSize;
            while (file.read(chunkId, 4) && file.read(reinterpret_cast<char*>(&chunkSize), 4)) {
                if (std::memcmp(chunkId, "data", 4) == 0) break;
                file.seekg(chunkSize, std::ios::cur);
            }
            if (file.eof()) return nullptr;

            std::vector<char> rawData(chunkSize);
            file.read(rawData.data(), chunkSize);

            int bytesPerSample = header.bitsPerSample / 8;
            int totalSamples = static_cast<int>(chunkSize / bytesPerSample / header.channels);
            size_t sampleCount = static_cast<size_t>(totalSamples) * header.channels;
            std::vector<float> floatData(sampleCount);

            if (header.bitsPerSample == 16) {
                auto* s = reinterpret_cast<int16_t*>(rawData.data());
                for (size_t i = 0; i < sampleCount; i++)
                    floatData[i] = static_cast<float>(s[i]) / 32768.0f;
            } else if (header.bitsPerSample == 24) {
                for (size_t i = 0; i < sampleCount; i++) {
                    int32_t val = static_cast<int32_t>(static_cast<uint8_t>(rawData[i * 3]))
                                | (static_cast<int32_t>(static_cast<uint8_t>(rawData[i * 3 + 1])) << 8)
                                | (static_cast<int32_t>(static_cast<int8_t>(rawData[i * 3 + 2])) << 16);
                    floatData[i] = static_cast<float>(val) / 8388608.0f;
                }
            } else if (header.bitsPerSample == 8) {
                auto* s = reinterpret_cast<uint8_t*>(rawData.data());
                for (size_t i = 0; i < sampleCount; i++)
                    floatData[i] = (static_cast<float>(s[i]) - 128.0f) / 128.0f;
            } else {
                return nullptr;
            }

            return CreateClipFromFloats(floatData.data(), totalSamples, static_cast<int>(header.channels), static_cast<int>(header.sampleRate));
        }

        return nullptr;
    }

    void LoadingMusic::ScanFolder() {
        const std::filesystem::path folder("C:/nyx/music/");
        if (!std::filesystem::exists(folder)) {
            std::filesystem::create_directories(folder);
            return;
        }

        for (auto& entry : std::filesystem::directory_iterator(folder)) {
            if (!entry.is_regular_file()) continue;
            auto ext = entry.path().extension().string();
            for (auto& c : ext) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
            if (ext == ".mp3" || ext == ".wav" || ext == ".ogg")
                m_playlist.push_back({ entry.path().string(), false });
        }
    }

    void LoadingMusic::LoadPlaylist() {
        m_playlist.clear();
        const std::filesystem::path playlistPath("C:/nyx/music/playlist.txt");

        if (std::filesystem::exists(playlistPath)) {
            std::ifstream pf(playlistPath);
            std::string line;
            while (std::getline(pf, line)) {
                if (line.empty() || line[0] == '#') continue;

                while (!line.empty() && (line.back() == '\r' || line.back() == '\n' || line.back() == ' '))
                    line.pop_back();
                if (line.empty()) continue;

                if (line.rfind("http://", 0) == 0 || line.rfind("https://", 0) == 0) {
                    m_playlist.push_back({ line, true });
                } else {
                    std::string fullPath = line;
                    if (!std::filesystem::path(line).is_absolute())
                        fullPath = "C:/nyx/music/" + line;

                    if (std::filesystem::exists(fullPath))
                        m_playlist.push_back({ fullPath, false });
                }
            }
        } else {
            ScanFolder();
        }
    }

    void LoadingMusic::CleanupWebRequest() {
        if (!m_webRequest) return;

        static auto dispose = MethodHandler::resolve("UnityEngine.Networking.UnityWebRequest", "Dispose", 0);
        if (dispose)
            MethodHandler::invoke<void>(dispose, m_webRequest, nullptr);
        m_webRequest = nullptr;
    }

    void LoadingMusic::OnSceneLoad(int scene, int loadMode) {
        if (m_originalClip && m_audioSourceRaw) {
            AudioSource source{ m_audioSourceRaw };
            source.Stop();
            source.SetClip(m_originalClip);
        }

        m_clip = nullptr;
        m_goneFrames = 0;
        m_audioSourceRaw = nullptr;
        CleanupWebRequest();

        // Only scan filesystem once — playlist doesn't change at runtime
        if (!m_playlistLoaded) {
            LoadPlaylist();
            m_playlistLoaded = true;
        }

        if (m_playlist.empty()) {
            m_state = State::Idle;
            return;
        }

        auto& entry = m_playlist[m_fileIndex % m_playlist.size()];
        m_currentSource = entry.source;
        m_currentIsUrl = entry.isUrl;
        m_state = State::WaitForSource;
    }

    void LoadingMusic::OnUpdate() {
        if (m_state == State::WaitForSource) {
            auto obj = GameObject::Find("LoadingSound");
            if (!obj) return;

            auto comp = obj.GetComponentByName("UnityEngine.AudioSource");
            if (!comp) return;

            AudioSource srcForSave{ comp.raw() };
            m_audioSourceRaw = comp.raw();

            // Save original clip so we can restore it when loading screen dismisses
            if (!m_originalClip)
                m_originalClip = srcForSave.GetClip();

            // Destroy VRChat's MonoBehaviours on LoadingSound — their OnDisable calls
            // Resources.UnloadAsset() which fails on our runtime-created clip
            auto allComps = obj.GetComponents("UnityEngine.MonoBehaviour");
            for (auto& c : allComps) {
                Object(c.raw()).DestroyImmediate();
            }

            if (!m_currentIsUrl) {
                // Reuse cached clip if same track — avoids blocking Unity thread with decode
                if (m_cachedClipSource == m_currentSource && m_cachedClip) {
                    m_clip = m_cachedClip;
                } else {
                    m_clip = LoadAudioAsClip(m_currentSource);
                    if (m_clip) {
                        m_cachedClipSource = m_currentSource;
                        m_cachedClip = m_clip;
                    }
                }
                if (!m_clip) {
                    m_state = State::Idle;
                    return;
                }

                AudioSource source{ comp.raw() };
                ApplyClipToSource(source, m_clip);

                m_fileIndex++;
                m_state = State::Applied;
                m_applyFrame = 0;
            } else {
                auto* exports = GetExports();
                if (!exports || !exports->m_stringNew) {
                    m_state = State::Idle;
                    return;
                }

                static auto getAudioClip = MethodHandler::resolve("UnityEngine.Networking.UnityWebRequestMultimedia", "GetAudioClip", 2);
                if (!getAudioClip) getAudioClip = MethodHandler::resolve("UnityEngine.Networking.UnityWebRequestMultimedia", "GetAudioClip");

                static auto sendWebRequest = MethodHandler::resolve("UnityEngine.Networking.UnityWebRequest", "SendWebRequest", 0);
                if (!sendWebRequest) sendWebRequest = MethodHandler::resolve("UnityEngine.Networking.UnityWebRequest", "SendWebRequest");

                void* urlStr = reinterpret_cast<void*(IL2CPP_CALLTYPE)(const char*)>(exports->m_stringNew)(m_currentSource.c_str());

                if (getAudioClip) {
                    int audioType = 0;
                    void* getClipParams[] = { urlStr, &audioType };
                    m_webRequest = MethodHandler::invoke<void*>(getAudioClip, nullptr, getClipParams);
                } else {
                    static auto webRequestGet = MethodHandler::resolve("UnityEngine.Networking.UnityWebRequest", "Get", 1);
                    if (!webRequestGet) webRequestGet = MethodHandler::resolve("UnityEngine.Networking.UnityWebRequest", "Get");
                    if (!webRequestGet) {
                        m_state = State::Idle;
                        return;
                    }
                    void* getParams[] = { urlStr };
                    m_webRequest = MethodHandler::invoke<void*>(webRequestGet, nullptr, getParams);
                    if (m_webRequest) {
                        static auto dhacCtor = MethodHandler::resolve("UnityEngine.Networking.DownloadHandlerAudioClip", ".ctor", 2);
                        if (!dhacCtor) dhacCtor = MethodHandler::resolve("UnityEngine.Networking.DownloadHandlerAudioClip", ".ctor");
                        if (dhacCtor) {
                            auto dhacClass = Class::find("UnityEngine.Networking.DownloadHandlerAudioClip");
                            if (dhacClass) {
                                void* handler = reinterpret_cast<void*(IL2CPP_CALLTYPE)(void*)>(exports->m_objectNew)(dhacClass.raw());
                                if (handler) {
                                    int audioType = 0;
                                    void* ctorParams[] = { urlStr, &audioType };
                                    MethodHandler::invoke<void>(dhacCtor, handler, ctorParams);
                                    static auto setDH = MethodHandler::resolve("UnityEngine.Networking.UnityWebRequest", "set_downloadHandler", 1);
                                    if (!setDH) setDH = MethodHandler::resolve("UnityEngine.Networking.UnityWebRequest", "set_downloadHandler");
                                    if (setDH) {
                                        void* setDHParams[] = { handler };
                                        MethodHandler::invoke<void>(setDH, m_webRequest, setDHParams);
                                    }
                                }
                            }
                        }
                    }
                }

                if (!m_webRequest || !sendWebRequest) {
                    m_state = State::Idle;
                    return;
                }

                MethodHandler::invoke<void*>(sendWebRequest, m_webRequest, nullptr);
                m_state = State::StreamingUrl;
            }
        }

        else if (m_state == State::StreamingUrl) {
            if (!m_webRequest) {
                m_state = State::Idle;
                return;
            }

            static auto isDone = MethodHandler::resolve("UnityEngine.Networking.UnityWebRequest", "get_isDone", 0);
            if (!isDone) {
                CleanupWebRequest();
                m_state = State::Idle;
                return;
            }

            bool done = MethodHandler::invoke<bool>(isDone, m_webRequest, nullptr);
            if (!done) return;

            static auto getResult = MethodHandler::resolve("UnityEngine.Networking.UnityWebRequest", "get_result", 0);
            if (getResult) {
                int result = MethodHandler::invoke<int>(getResult, m_webRequest, nullptr);
                if (result != 1) {
                    CleanupWebRequest();
                    m_state = State::Idle;
                    return;
                }
            }

            static auto getContent = MethodHandler::resolve("UnityEngine.Networking.DownloadHandlerAudioClip", "GetContent", 1);
            if (!getContent) {
                CleanupWebRequest();
                m_state = State::Idle;
                return;
            }

            void* getContentParams[] = { m_webRequest };
            m_clip = MethodHandler::invoke<void*>(getContent, nullptr, getContentParams);
            CleanupWebRequest();

            if (!m_clip) {
                m_state = State::Idle;
                return;
            }

            auto obj = GameObject::Find("LoadingSound");
            if (!obj) {
                m_state = State::Idle;
                return;
            }

            auto comp = obj.GetComponentByName("UnityEngine.AudioSource");
            if (!comp) {
                m_state = State::Idle;
                return;
            }

            AudioSource source{ comp.raw() };
            ApplyClipToSource(source, m_clip);

            m_fileIndex++;
            m_state = State::Applied;
            m_applyFrame = 0;
        }
    }

    void LoadingMusic::OnLateUpdate() {
        if (m_state != State::Applied) return;

        m_applyFrame++;

        auto obj = GameObject::Find("LoadingSound");
        if (!obj) {
            m_goneFrames++;
            if (m_goneFrames >= 60) {
                CleanupWebRequest();
                m_state = State::Idle;
                m_clip = nullptr;
                m_audioSourceRaw = nullptr;
                m_goneFrames = 0;
            }
            return;
        }
        m_goneFrames = 0;

        auto comp = obj.GetComponentByName("UnityEngine.AudioSource");
        if (!comp) return;

        AudioSource source{ comp.raw() };
        m_audioSourceRaw = comp.raw();

        if (m_applyFrame <= 5) {
            auto allComps = obj.GetComponents("UnityEngine.MonoBehaviour");
            for (auto& c : allComps) {
                Object(c.raw()).DestroyImmediate();
            }
        }

        if (!obj.GetActive()) return;

        static auto isEnabled = MethodHandler::resolve("UnityEngine.Behaviour", "get_enabled", 0);
        if (isEnabled) {
            bool enabled = MethodHandler::invoke<bool>(isEnabled, comp.raw(), nullptr);
            if (!enabled) return;
        }

        void* currentClip = source.GetClip();
        bool playing = source.GetIsPlaying();

        if (currentClip != m_clip || !playing)
            ApplyClipToSource(source, m_clip);
    }

    void LoadingMusic::OnRender() {
        if (m_state == State::StreamingUrl)
            ImGui::Text("Streaming: %s", m_currentSource.c_str());
        else if (m_currentSource.empty())
            ImGui::TextDisabled("no track selected");
        else
            ImGui::Text("%s: %s", m_currentIsUrl ? "URL" : "File", m_currentSource.c_str());
    }

} // namespace UNIx
