#include <Modules/Visual/Nameplates/NameplateTagModule.hpp>
#include <Core/ModuleManager.hpp>
#include <Core/PlayerCache/PlayerCache.hpp>
#include <Core/Globals.hpp>
#include <Core/FileLog/FileLog.hpp>

#include <IL2CPP.Module/include/Unity/Transform.hpp>
#include <IL2CPP.Module/include/Unity/Component.hpp>
#include <IL2CPP.Module/include/Unity/TMP_Text.hpp>
#include <IL2CPP.Module/include/Unity/RectTransform.hpp>

#include <Bootstrap.Module/include/VRChat/VRCPlayer.hpp>
#include <Bootstrap.Module/include/VRChat/PlayerNameplate.hpp>
#include <Bootstrap.Module/include/VRChat/VRCPlayerApi.hpp>

#include <ThirdParty/imgui/imgui.h>
#include <IL2CPP.Module/include/Unity/Image.hpp>
#include <IL2CPP.Module/include/ManagedObject.hpp>
#include <Core/SpriteLoader/SpriteLoader.hpp>
#include "resource.h"

#include <Core/HeartbeatManager/HeartbeatManager.hpp>

#include <cmath>
#include <algorithm>

namespace UNIx {

    static bool SafeIsValid(void* ptr) {
        if (!ptr) return false;
        __try {
            void* cachedPtr = *reinterpret_cast<void**>(reinterpret_cast<uintptr_t>(ptr) + 0x10);
            if (!cachedPtr) return false;
            uintptr_t addr = reinterpret_cast<uintptr_t>(cachedPtr);
            return addr >= 0x10000 && addr <= 0x7FFFFFFF0000;
        } __except(EXCEPTION_EXECUTE_HANDLER) {
            return false;
        }
    }

    static constexpr float kInitDelay = 3.0f;
    static constexpr float kRetryDelay = 2.0f;
    static constexpr int kMaxRetries = 5;
    static constexpr int kNormalLayer = 12;
    static constexpr int kOverlayLayer = 19;

    static std::string GradientText(const std::string& text,
                                     float r1, float g1, float b1,
                                     float r2, float g2, float b2) {
        int len = static_cast<int>(text.size());
        if (len == 0) return "";
        if (len == 1) {
            char buf[16];
            snprintf(buf, sizeof(buf), "%02X%02X%02X",
                static_cast<int>(r1 * 255.f), static_cast<int>(g1 * 255.f), static_cast<int>(b1 * 255.f));
            return std::string("<color=#") + buf + ">" + text + "</color>";
        }
        std::string result;
        result.reserve(text.size() * 30);
        for (int i = 0; i < len; ++i) {
            float t = static_cast<float>(i) / static_cast<float>(len - 1);
            int r = static_cast<int>((r1 + (r2 - r1) * t) * 255.f);
            int g = static_cast<int>((g1 + (g2 - g1) * t) * 255.f);
            int b = static_cast<int>((b1 + (b2 - b1) * t) * 255.f);
            char buf[16];
            snprintf(buf, sizeof(buf), "%02X%02X%02X",
                std::clamp(r, 0, 255), std::clamp(g, 0, 255), std::clamp(b, 0, 255));
            result += "<color=#";
            result += buf;
            result += ">";
            result += text[i];
            result += "</color>";
        }
        return result;
    }

    static IL2CPP::Color ReadNameplateRankColor(void* quickStatsPtr) {
        IL2CPP::Color fallback = { 1.f, 1.f, 1.f, 1.f };
        if (!quickStatsPtr || !SafeIsValid(quickStatsPtr)) return fallback;
        IL2CPP::Module::Unity::GameObject qsGo(quickStatsPtr);
        auto qsT = qsGo.GetTransform();
        auto trustT = qsT.Find("Trust Text");
        if (!trustT.valid()) return fallback;
        auto trustGO = trustT.GetGameObject();
        if (!trustGO.valid()) return fallback;
        auto tmpComp = trustGO.GetComponentByName("TMPro.TextMeshProUGUI");
        if (!tmpComp.valid())
            tmpComp = trustGO.GetComponentByName("TextMeshProUGUI");
        if (!tmpComp.valid()) return fallback;
        IL2CPP::Module::Unity::TMP_Text tmp(tmpComp.raw());
        return tmp.GetColor();
    }

    static std::string ReadNameplateRankText(void* quickStatsPtr) {
        if (!quickStatsPtr || !SafeIsValid(quickStatsPtr)) return "";
        IL2CPP::Module::Unity::GameObject qsGo(quickStatsPtr);
        auto qsT = qsGo.GetTransform();
        auto trustT = qsT.Find("Trust Text");
        if (!trustT.valid()) return "";
        auto trustGO = trustT.GetGameObject();
        if (!trustGO.valid()) return "";
        auto tmpComp = trustGO.GetComponentByName("TMPro.TextMeshProUGUI");
        if (!tmpComp.valid())
            tmpComp = trustGO.GetComponentByName("TextMeshProUGUI");
        if (!tmpComp.valid()) return "";
        IL2CPP::Module::Unity::TMP_Text tmp(tmpComp.raw());
        return tmp.GetText();
    }

    static std::string ColorToHex(const IL2CPP::Color& c) {
        char buf[16];
        snprintf(buf, sizeof(buf), "%02X%02X%02X",
            std::clamp(static_cast<int>(c.r * 255.f), 0, 255),
            std::clamp(static_cast<int>(c.g * 255.f), 0, 255),
            std::clamp(static_cast<int>(c.b * 255.f), 0, 255));
        return buf;
    }

    static const std::unordered_map<std::string, uint32_t> s_iconMap = {
        { "terminal",     IDR_ICON_TERMINAL },
        { "gauge",        IDR_ICON_GAUGE },
        { "airplane",     IDR_ICON_AIRPLANE_TILT },
        { "crosshair",    IDR_ICON_CROSSHAIR },
        { "id_card",      IDR_ICON_IDENTIFICATION_CARD },
        { "users",        IDR_ICON_USERS_THREE },
        { "music",        IDR_ICON_MUSIC_NOTES },
        { "door",         IDR_ICON_DOOR },
    };

    NameplateTagModule::NameplateTagModule()
        : BaseModule("Nameplate Tags", "Cloud tags on player nameplates", VK_F6, "Visual") {
        m_enabled = true;
    }

    void NameplateTagModule::OnPlayerJoinComplete(IL2CPP::VRChat::Player player) {
        if (!player) return;
        auto api = player.GetVRCPlayerApi();
        if (!api) return;
        auto user = player.GetAPIUser();

        NameplateState state;
        state.playerId = api.GetPlayerId();
        state.pendingTimer = kInitDelay;
        if (user.valid())
            state.userId = user.GetId();

        m_states.push_back(std::move(state));
    }

    void NameplateTagModule::OnPlayerLeave(IL2CPP::VRChat::Player player) {
        if (!player) return;
        auto api = player.GetVRCPlayerApi();
        if (!api) return;
        int id = api.GetPlayerId();

        for (auto it = m_states.begin(); it != m_states.end(); ++it) {
            if (it->playerId == id) {
                CleanupState(*it);
                m_states.erase(it);
                return;
            }
        }
    }

    void NameplateTagModule::OnSceneLoad(int, int) {
        for (auto& s : m_states) {
            s.tagObjects.clear();
            s.infoBarObject = nullptr;
            s.trustIconObject = nullptr;
            s.contentsParent = nullptr;
            s.quickStatsTemplate = nullptr;
            s.bgImage = nullptr;
            s.initialized = false;
        }
        m_states.clear();
    }

    void NameplateTagModule::OnUpdate() {
        if (!InRoom()) return;

        float dt = 1.f / 90.f;
        m_globalTime += dt;

        UpdateChatBubbleColors();

        if (m_states.empty()) return;

        for (auto& state : m_states) {
            if (!state.initialized && state.retryCount < kMaxRetries && state.pendingTimer > 0.f) {
                state.pendingTimer -= dt;
                if (state.pendingTimer <= 0.f) {
                    InitializeNameplate(state);
                }
            }
        }

        bool anyLoaded = false;
        for (auto& s : m_states) { if (s.initialized) { anyLoaded = true; break; } }
        if (!anyLoaded) return;

        UpdateAnimations(dt);
        UpdateInfoBars();
        UpdateIcons();
        UpdateNameTextColors();
        UpdateSpeakingGlows();

        int targetLayer = m_nameplateEsp ? kOverlayLayer : kNormalLayer;
        for (auto& state : m_states) {
            if (!state.initialized) continue;
            for (auto* obj : state.tagObjects) {
                if (obj && SafeIsValid(obj)) {
                    IL2CPP::Module::Unity::GameObject go(obj);
                    if (static_cast<int>(go.GetLayer()) != targetLayer)
                        go.SetLayer(targetLayer);
                }
            }
            if (state.infoBarObject && SafeIsValid(state.infoBarObject)) {
                IL2CPP::Module::Unity::GameObject go(state.infoBarObject);
                if (static_cast<int>(go.GetLayer()) != targetLayer)
                    go.SetLayer(targetLayer);
            }
        }
    }

    void NameplateTagModule::OnRender() {
        ImGui::Checkbox("Nameplate ESP", &m_nameplateEsp);
    }

    static void RetryState(NameplateState& state) {
        state.pendingTimer = kRetryDelay;
        state.retryCount++;
    }

    static const std::string s_objectsToHide[] = {
        "Trust Icon", "Performance Icon", "Performance Text",
        "Friend Anchor Stats", "Reason", "Shared Connections Icon",
        "Shared Connections Text"
    };

    static void SetupTagClone(IL2CPP::Module::Unity::GameObject& go, IL2CPP::Module::Unity::Transform& parent, float yPos) {
        go.SetActive(true);
        auto t = go.GetTransform();
        t.SetParent(parent, false);
        t.SetLocalPosition({0.f, yPos, 0.f});
        t.SetLocalScale({1.f, 1.f, 1.f});

        for (const auto& objName : s_objectsToHide) {
            auto childT = t.Find(objName);
            if (childT.valid()) {
                auto childGO = childT.GetGameObject();
                if (childGO.valid()) childGO.SetActive(false);
            }
        }

        auto bgComponent = go.GetComponentByName("UnityEngine.UI.Image");
        if (bgComponent.valid()) {
            IL2CPP::Module::Unity::Image bgImg(bgComponent.raw());
            bgImg.SetColor(IL2CPP::Color(0.f, 0.f, 0.f, 0.f));
        }

        auto trustTextT = t.Find("Trust Text");
        if (trustTextT.valid()) {
            auto trustTextGO = trustTextT.GetGameObject();
            if (trustTextGO.valid()) {
                trustTextGO.SetActive(true);
                auto tmpComponent = trustTextGO.GetComponentByName("TMPro.TextMeshProUGUI");
                if (!tmpComponent.valid())
                    tmpComponent = trustTextGO.GetComponentByName("TextMeshProUGUI");
                if (tmpComponent.valid()) {
                    IL2CPP::Module::Unity::TMP_Text tmp(tmpComponent.raw());
                    tmp.SetRichText(true);
                }
            }
        }
    }

    void NameplateTagModule::InitializeNameplate(NameplateState& state) {
        auto playerApi = IL2CPP::VRChat::VRCPlayerApi::GetPlayerById(state.playerId);
        if (!playerApi.raw()) { RetryState(state); return; }

        auto vrcPlayer = playerApi.GetVRCPlayer();
        if (!vrcPlayer.raw()) { RetryState(state); return; }

        auto nameplate = vrcPlayer.GetNameplate();
        if (!nameplate.raw()) { RetryState(state); return; }

        auto contentsGO = nameplate.GetContents();
        if (!contentsGO.valid()) { RetryState(state); return; }

        auto quickStats = nameplate.GetQuickStats();
        if (!quickStats.valid()) { RetryState(state); return; }

        auto contentsTransform = contentsGO.GetTransform();
        if (!contentsTransform.valid()) { RetryState(state); return; }

        state.initialized = true;
        state.contentsParent = contentsTransform.raw();
        state.quickStatsTemplate = quickStats.raw();

        state.bgImage = nullptr;

        auto qsTransform = quickStats.GetTransform();
        if (qsTransform.valid()) {
            auto origTrustIconT = qsTransform.Find("Trust Icon");
            if (origTrustIconT.valid()) {
                auto origTrustIconGO = origTrustIconT.GetGameObject();
                if (origTrustIconGO.valid()) {
                    origTrustIconGO.SetActive(false);
                    state.trustIconObject = origTrustIconGO.raw();
                }
            }
        }

        auto infoClone = quickStats.Instantiate();
        if (infoClone.raw() && infoClone.IsValid()) {
            IL2CPP::Module::Unity::GameObject infoGo(infoClone.raw());
            infoGo.SetActive(true);

            auto infoTransform = infoGo.GetTransform();
            infoTransform.SetParent(contentsTransform, false);
            infoTransform.SetLocalPosition({0.f, 60.f, 0.f});
            infoTransform.SetLocalScale({1.f, 1.f, 1.f});

            state.infoBarObject = infoClone.raw();

            for (const auto& objName : s_objectsToHide) {
                auto childT = infoTransform.Find(objName);
                if (childT.valid()) {
                    auto childGO = childT.GetGameObject();
                    if (childGO.valid()) childGO.SetActive(false);
                }
            }

            auto infoTrustT = infoTransform.Find("Trust Text");
            if (infoTrustT.valid()) {
                auto infoTrustGO = infoTrustT.GetGameObject();
                if (infoTrustGO.valid()) {
                    infoTrustGO.SetActive(true);
                    auto infoTmpComponent = infoTrustGO.GetComponentByName("TMPro.TextMeshProUGUI");
                    if (!infoTmpComponent.valid())
                        infoTmpComponent = infoTrustGO.GetComponentByName("TextMeshProUGUI");
                    if (infoTmpComponent.valid()) {
                        IL2CPP::Module::Unity::TMP_Text infoTmp(infoTmpComponent.raw());
                        infoTmp.SetRichText(true);
                    }
                }
            }
        }
    }

    void NameplateTagModule::UpdateAnimations(float dt) {
        for (auto& state : m_states) {
            if (!state.initialized) continue;

            state.animTime += dt;

            auto tags = TagManager::Get().GetParsedTagsForUser(state.userId);

            std::vector<ParsedTag> textTags;
            for (auto& t : tags) {
                if (!t.text.empty())
                    textTags.push_back(t);
            }

            int needed = static_cast<int>(textTags.size());

            if (needed != state.lastTagCount) {
                for (auto* obj : state.tagObjects) {
                    if (obj && SafeIsValid(obj)) {
                        IL2CPP::Module::Unity::Object o(obj);
                        try { o.Destroy(); } catch (...) {}
                    }
                }
                state.tagObjects.clear();

                if (!state.contentsParent || !state.quickStatsTemplate) {
                    state.lastTagCount = 0;
                    continue;
                }

                if (!SafeIsValid(state.contentsParent) || !SafeIsValid(state.quickStatsTemplate)) {
                    state.contentsParent = nullptr;
                    state.quickStatsTemplate = nullptr;
                    state.lastTagCount = 0;
                    continue;
                }

                IL2CPP::Module::Unity::Transform contentsT(state.contentsParent);
                IL2CPP::Module::Unity::GameObject tmpl(state.quickStatsTemplate);

                for (int i = 0; i < needed; ++i) {
                    auto clone = tmpl.Instantiate();
                    if (!clone.raw() || !clone.IsValid()) continue;
                    IL2CPP::Module::Unity::GameObject cloneGo(clone.raw());
                    float yPos = -60.f - (i * 30.f);
                    SetupTagClone(cloneGo, contentsT, yPos);

                    if (!textTags[i].iconName.empty()) {
                        auto iconIt = s_iconMap.find(textTags[i].iconName);
                        if (iconIt != s_iconMap.end()) {
                            auto cloneT = cloneGo.GetTransform();
                            auto iconT = cloneT.Find("Trust Icon");
                            if (iconT.valid()) {
                                auto iconGO = iconT.GetGameObject();
                                if (iconGO.valid()) {
                                    std::string key = "icon_" + textTags[i].iconName;
                                    void* sprite = SpriteLoader::Get().GetCached(key);
                                    if (!sprite)
                                        sprite = SpriteLoader::Get().LoadFromResource(iconIt->second, key);
                                    if (sprite) {
                                        auto imgComp = iconGO.GetComponentByName("UnityEngine.UI.Image");
                                        if (imgComp.valid()) {
                                            IL2CPP::Module::Unity::Image img(imgComp.raw());
                                            img.SetSprite(sprite);
                                            img.SetColor(IL2CPP::Color(1.f, 1.f, 1.f, 1.f));
                                        }
                                        iconGO.SetActive(true);
                                    }
                                }
                            }
                        }
                    }

                    state.tagObjects.push_back(clone.raw());
                }
                state.lastTagCount = needed;
            }

            bool anyLBL = false;
            for (auto& tt : textTags) {
                uint16_t f = tt.animFlags;
                if (f == Anim_None && tt.animation != AnimationType::None)
                    f = AnimTypeToFlag(tt.animation);
                if (f & Anim_LetterByLetter) { anyLBL = true; break; }
            }
            if (anyLBL) {
                state.lblTimer += dt;
                if (state.lblTimer >= 0.45f) {
                    state.lblTimer = 0.f;
                    if (state.lblForward) {
                        state.lblIndex++;
                    } else {
                        state.lblIndex--;
                    }
                }
            }

            for (int i = 0; i < static_cast<int>(state.tagObjects.size()) && i < static_cast<int>(textTags.size()); ++i) {
                if (!SafeIsValid(state.tagObjects[i])) continue;
                IL2CPP::Module::Unity::GameObject tagGo(state.tagObjects[i]);

                if (!tagGo.GetActiveSelf())
                    tagGo.SetActive(true);

                auto tagT = tagGo.GetTransform();
                if (!tagT.valid()) continue;
                auto trustT = tagT.Find("Trust Text");
                if (!trustT.valid()) continue;
                auto trustGO = trustT.GetGameObject();
                if (!trustGO.valid()) continue;

                auto tmpComponent = trustGO.GetComponentByName("TMPro.TextMeshProUGUI");
                if (!tmpComponent.valid())
                    tmpComponent = trustGO.GetComponentByName("TextMeshProUGUI");
                if (!tmpComponent.valid()) continue;

                IL2CPP::Module::Unity::TMP_Text tmp(tmpComponent.raw());

                uint16_t f = textTags[i].animFlags;
                if (f == Anim_None && textTags[i].animation != AnimationType::None)
                    f = AnimTypeToFlag(textTags[i].animation);

                if (f & Anim_LetterByLetter) {
                    int textLen = static_cast<int>(textTags[i].text.size());
                    if (state.lblIndex > textLen) {
                        state.lblIndex = textLen;
                        state.lblForward = false;
                    }
                    if (state.lblIndex < 0) {
                        state.lblIndex = 0;
                        state.lblForward = true;
                    }
                    std::string sub = textTags[i].text.substr(0, state.lblIndex);
                    std::string colored = "<color=#" + ColorToRichText(textTags[i].color) + ">" + sub + "</color>";
                    tmp.SetText(colored);
                } else {
                    std::string text = BuildAnimatedText(textTags[i], state.animTime, 0);
                    tmp.SetText(text);
                }
            }
        }
    }

    void NameplateTagModule::UpdateIcons() {
        for (auto& state : m_states) {
            if (!state.initialized || !state.trustIconObject) continue;

            auto tags = TagManager::Get().GetParsedTagsForUser(state.userId);

            std::string iconName;
            for (auto& t : tags) {
                if (!t.iconName.empty()) {
                    iconName = t.iconName;
                    break;
                }
            }

            bool isDevIcon = false;
            if (iconName.empty() && !state.userId.empty()) {
                auto usersSnap = HeartbeatManager::Get().GetActiveUsers();
                for (auto& u : *usersSnap) {
                    if (u.isDev && u.userId == state.userId) {
                        iconName = "terminal";
                        isDevIcon = true;
                        break;
                    }
                }
            }

            if (!SafeIsValid(state.trustIconObject)) { state.trustIconObject = nullptr; continue; }
            IL2CPP::Module::Unity::GameObject iconGo(state.trustIconObject);

            if (iconName.empty()) {
                if (iconGo.GetActiveSelf())
                    iconGo.SetActive(false);
                state.appliedIcon.clear();
                continue;
            }

            if (!state.userId.empty() && state.quickStatsTemplate) {
                bool isDev = false;
                auto usersSnap = HeartbeatManager::Get().GetActiveUsers();
                for (auto& u : *usersSnap) {
                    if (u.isDev && u.userId == state.userId) { isDev = true; break; }
                }
                if (isDev && SafeIsValid(state.quickStatsTemplate)) {
                    IL2CPP::Module::Unity::GameObject qsGo(state.quickStatsTemplate);
                    {
                        auto qsT = qsGo.GetTransform();
                        auto ttT = qsT.Find("Trust Text");
                        if (ttT.valid()) {
                            auto ttGO = ttT.GetGameObject();
                            if (ttGO.valid()) {
                                auto tmpComp = ttGO.GetComponentByName("TMPro.TextMeshProUGUI");
                                if (!tmpComp.valid())
                                    tmpComp = ttGO.GetComponentByName("TextMeshProUGUI");
                                if (tmpComp.valid()) {
                                    IL2CPP::Module::Unity::TMP_Text tmp(tmpComp.raw());
                                    tmp.SetText(GradientText("Developer", 0.f, 0.75f, 1.f, 0.78f, 0.24f, 1.f));
                                }
                            }
                        }
                    }
                }
            }

            if (iconName == state.appliedIcon) continue;

            auto it = s_iconMap.find(iconName);
            if (it == s_iconMap.end()) {
                if (iconGo.GetActiveSelf())
                    iconGo.SetActive(false);
                state.appliedIcon.clear();
                continue;
            }

            auto& sprites = SpriteLoader::Get();
            std::string cacheKey = "icon_" + iconName;
            void* sprite = sprites.GetCached(cacheKey);
            if (!sprite)
                sprite = sprites.LoadFromResource(it->second, cacheKey);
            if (!sprite) continue;

            auto imgComponent = iconGo.GetComponentByName("UnityEngine.UI.Image");
            if (!imgComponent.valid()) continue;

            IL2CPP::Module::Unity::Image img(imgComponent.raw());
            img.SetSprite(sprite);

            if (isDevIcon)
                img.SetColor(IL2CPP::Color(0.39f, 0.50f, 1.f, 1.f));
            else
                img.SetColor(IL2CPP::Color(1.f, 1.f, 1.f, 1.f));

            if (!iconGo.GetActiveSelf())
                iconGo.SetActive(true);

            state.appliedIcon = iconName;
        }
    }

    void NameplateTagModule::UpdateInfoBars() {
        auto& cache = ModuleManager::Get().GetPlayerCache();
        auto playersSnap = cache.GetPlayers();

        for (auto& state : m_states) {
            if (!state.initialized || !state.infoBarObject) continue;

            if (!SafeIsValid(state.infoBarObject)) { state.infoBarObject = nullptr; continue; }
            IL2CPP::Module::Unity::GameObject infoGo(state.infoBarObject);

            auto infoT = infoGo.GetTransform();
            if (!infoT.valid()) continue;
            auto trustT = infoT.Find("Trust Text");
            if (!trustT.valid()) continue;
            auto trustGO = trustT.GetGameObject();
            if (!trustGO.valid()) continue;

            auto tmpComponent = trustGO.GetComponentByName("TMPro.TextMeshProUGUI");
            if (!tmpComponent.valid())
                tmpComponent = trustGO.GetComponentByName("TextMeshProUGUI");
            if (!tmpComponent.valid()) continue;

            IL2CPP::Module::Unity::TMP_Text tmp(tmpComponent.raw());

            const PlayerEntry* entry = nullptr;
            for (auto& p : *playersSnap) {
                if (p.playerId == state.playerId) {
                    entry = &p;
                    break;
                }
            }

            if (!entry) continue;

            std::string rankText = ReadNameplateRankText(state.quickStatsTemplate);
            IL2CPP::Color rankCol = ReadNameplateRankColor(state.quickStatsTemplate);
            std::string rc = ColorToHex(rankCol);

            std::string info;

            bool isDev = false;
            if (!state.userId.empty()) {
                auto usersSnap = HeartbeatManager::Get().GetActiveUsers();
                for (auto& u : *usersSnap) {
                    if (u.isDev && u.userId == state.userId) {
                        isDev = true;
                        break;
                    }
                }
            }

            if (isDev) {
                info += GradientText("Developer", 0.f, 0.75f, 1.f, 0.78f, 0.24f, 1.f) + " ";
            } else {
                if (rankText.empty()) rankText = "Unknown";
                info += "<color=#" + rc + ">" + rankText + "</color> ";
            }

            if (entry->isQuest)
                info += "<color=#" + rc + ">[Q]</color> ";
            else if (entry->isVR)
                info += "<color=#" + rc + ">[VR]</color> ";
            else
                info += "<color=#" + rc + ">[PC]</color> ";

            if (entry->isMaster)
                info += "<color=#FFD700>[Host]</color> ";

            tmp.SetText(info);
        }
    }

    static void ColorGraphicOnGO(IL2CPP::Module::Unity::GameObject& go, IL2CPP::Color& color, IL2CPP::Module::Method& setColorMethod) {
        auto compClass = IL2CPP::Module::Class::find("UnityEngine.Component");
        if (!compClass) return;
        auto allComps = go.GetComponents(compClass);
        for (auto& comp : allComps) {
            if (!comp || !comp.raw()) continue;
            try {
                std::string cn = comp.get_class_name();
                if (cn.find("MaskableGraphic") != std::string::npos ||
                    cn.find("Image") != std::string::npos) {
                    void* params[] = { &color };
                    setColorMethod.invoke(comp.raw(), params);
                } else if (cn == "UnityEngine.CanvasRenderer") {
                    static auto crSetColor = IL2CPP::Module::MethodHandler::resolve("UnityEngine.CanvasRenderer", "SetColor", 1);
                    static auto crSetAlpha = IL2CPP::Module::MethodHandler::resolve("UnityEngine.CanvasRenderer", "SetAlpha", 1);
                    if (crSetColor) {
                        void* params[] = { &color };
                        crSetColor.invoke(comp.raw(), params);
                    }
                    if (crSetAlpha) {
                        void* params[] = { &color.a };
                        crSetAlpha.invoke(comp.raw(), params);
                    }
                }
            } catch (...) { continue; }
        }
    }

    void NameplateTagModule::UpdateNameTextColors() {
        for (auto& state : m_states) {
            if (!state.initialized || !state.contentsParent || !state.quickStatsTemplate) continue;
            if (!SafeIsValid(state.contentsParent)) { state.contentsParent = nullptr; continue; }

            IL2CPP::Color rankColor = ReadNameplateRankColor(state.quickStatsTemplate);

            IL2CPP::Module::Unity::Transform contentsT(state.contentsParent);
            auto nameT = contentsT.Find("Main/Text Container/Name");
            if (!nameT.valid()) continue;
            auto nameGO = nameT.GetGameObject();
            if (!nameGO.valid()) continue;

            auto tmpComp = nameGO.GetComponentByName("TMPro.TextMeshProUGUI");
            if (!tmpComp.valid())
                tmpComp = nameGO.GetComponentByName("TextMeshProUGUI");
            if (!tmpComp.valid()) continue;

            IL2CPP::Module::Unity::TMP_Text nameTmp(tmpComp.raw());
            nameTmp.SetColor(rankColor);
        }
    }

    void NameplateTagModule::UpdateSpeakingGlows() {
        static auto setColor = IL2CPP::Module::MethodHandler::resolve("UnityEngine.UI.Graphic", "set_color", 1);
        if (!setColor) return;

        for (auto& state : m_states) {
            if (!state.initialized || !state.contentsParent || !state.quickStatsTemplate) continue;
            if (!SafeIsValid(state.contentsParent)) { state.contentsParent = nullptr; continue; }

            IL2CPP::Color rankColor = ReadNameplateRankColor(state.quickStatsTemplate);

            IL2CPP::Module::Unity::Transform contentsT(state.contentsParent);

            auto mainGlowT = contentsT.Find("Main/Glow");
            if (mainGlowT.valid()) {
                auto glowGO = mainGlowT.GetGameObject();
                if (glowGO.IsValid())
                    ColorGraphicOnGO(glowGO, rankColor, setColor);
            }

            auto iconGlowT = contentsT.Find("Icon/Glow");
            if (iconGlowT.valid()) {
                auto glowGO = iconGlowT.GetGameObject();
                if (glowGO.IsValid())
                    ColorGraphicOnGO(glowGO, rankColor, setColor);
            }
        }
    }

    static void ColorChatBubbleGraphic(IL2CPP::Module::Unity::Transform& bubbleT, IL2CPP::Color& color) {
        auto chatT = bubbleT.Find("Canvas/Chat");
        if (!chatT.valid()) return;

        auto chatGO = chatT.GetGameObject();
        if (!chatGO.IsValid()) return;

        static auto setColor = IL2CPP::Module::MethodHandler::resolve("UnityEngine.UI.Graphic", "set_color", 1);
        if (!setColor) return;

        ColorGraphicOnGO(chatGO, color, setColor);
    }

    void NameplateTagModule::UpdateChatBubbleColors() {
        for (auto& state : m_states) {
            if (!state.initialized || !state.contentsParent || !state.quickStatsTemplate) continue;
            if (!SafeIsValid(state.contentsParent)) { state.contentsParent = nullptr; continue; }

            IL2CPP::Color color = ReadNameplateRankColor(state.quickStatsTemplate);

            IL2CPP::Module::Unity::Transform contentsT(state.contentsParent);
            auto nameplateT = contentsT.GetParent();
            if (!nameplateT.valid()) continue;
            auto containerT = nameplateT.GetParent();
            if (!containerT.valid()) continue;

            auto chatBubbleT = containerT.Find("ChatBubble");
            if (chatBubbleT.valid())
                ColorChatBubbleGraphic(chatBubbleT, color);

            auto chatMirrorT = containerT.Find("ChatBubbleMirror");
            if (chatMirrorT.valid())
                ColorChatBubbleGraphic(chatMirrorT, color);
        }
    }

    std::string NameplateTagModule::BuildAnimatedRichText(const std::string& text, uint16_t flags, float time) {
        bool hasGlitch = (flags & Anim_Glitch) != 0;
        if (!hasGlitch)
            return text;

        int visCount = 0;
        for (size_t p = 0; p < text.size(); ) {
            if (text[p] == '<') {
                auto e = text.find('>', p);
                p = (e != std::string::npos) ? e + 1 : p + 1;
            } else {
                visCount++;
                p++;
            }
        }
        if (visCount == 0) return text;

        static const char gc[] = "!@#$%^&*()_+-=[]{}|;':\",./<>?~`";
        int gf = static_cast<int>(time * 15.f);
        float gn1 = 0.5f + 0.5f * std::sin(time * 0.5f * 3.14159f);
        float gn2 = 0.5f + 0.5f * std::sin(time * 0.7f * 3.14159f + 100.f);
        float gn3 = 0.5f + 0.5f * std::sin(time * 0.3f * 3.14159f + 200.f);
        bool shouldCorrupt = gn2 > 0.6f;
        bool shouldShift = gn3 > 0.4f;
        int gci = gf % visCount;

        std::string result;
        result.reserve(text.size() * 2);
        int vi = 0;
        bool pendingVoffsetClose = false;

        for (size_t p = 0; p < text.size(); ) {
            if (text[p] == '<') {
                auto end = text.find('>', p);
                if (end == std::string::npos) { result += text[p]; p++; continue; }

                std::string_view tagStr(&text[p], end - p + 1);

                if (tagStr.size() >= 15 && tagStr.substr(0, 8) == "<color=#") {
                    std::string hex(tagStr.substr(8, tagStr.size() - 9));

                    if (gn1 > 0.5f) {
                        float fa = 0.2f + std::fmod(gn1 + vi * 0.25f, 1.f) * 0.8f;
                        char ab[4];
                        snprintf(ab, sizeof(ab), "%02X", std::clamp(static_cast<int>(fa * 255.f), 0, 255));
                        hex += ab;
                    }

                    if (shouldShift) {
                        float yoff = std::cos(vi * 0.3f + time * 1.5f) * std::sin(time * 1.5f) * 6.75f * 0.15f;
                        char vb[32];
                        snprintf(vb, sizeof(vb), "<voffset=%.1fpx>", yoff);
                        result += vb;
                        pendingVoffsetClose = true;
                    }

                    result += "<color=#" + hex + ">";
                } else if (tagStr == "</color>") {
                    result += "</color>";
                    if (pendingVoffsetClose) {
                        result += "</voffset>";
                        pendingVoffsetClose = false;
                    }
                } else {
                    result += std::string(tagStr);
                }
                p = end + 1;
            } else {
                char ch = text[p];

                float cr = std::fmod(gn1 + vi * 0.1f, 1.f);
                if (shouldCorrupt && vi == gci)
                    ch = gc[gf % (sizeof(gc) - 1)];
                else if (gn1 > 0.3f && cr < 0.25f)
                    ch = gc[static_cast<int>(cr * (sizeof(gc) - 1)) % (sizeof(gc) - 1)];

                bool charVoffset = false;
                if (shouldShift) {
                    float yoff = std::cos(vi * 0.3f + time * 1.5f) * std::sin(time * 1.5f) * 6.75f * 0.15f;
                    char vb[32];
                    snprintf(vb, sizeof(vb), "<voffset=%.1fpx>", yoff);
                    result += vb;
                    charVoffset = true;
                }

                result += ch;

                if (charVoffset)
                    result += "</voffset>";

                vi++;
                p++;
            }
        }

        return result;
    }

    std::string NameplateTagModule::BuildAnimatedText(const ParsedTag& tag, float time, int charOffset) {
        uint16_t flags = tag.animFlags;
        if (flags == Anim_None && tag.animation != AnimationType::None)
            flags = AnimTypeToFlag(tag.animation);

        if (tag.isRichText) {
            if (flags == Anim_None) return tag.text;
            return BuildAnimatedRichText(tag.text, flags, time);
        }

        if (flags == Anim_None)
            return "<color=#" + ColorToRichText(tag.color) + ">" + tag.text + "</color>";

        std::string text = tag.text;
        int len = static_cast<int>(text.size());
        if (len == 0) return "";

        if (flags & Anim_Blink) {
            float alpha = std::fabs(std::sin(time * 1.5f * 3.14159f));
            int a = std::clamp(static_cast<int>(alpha * 255.f), 0, 255);
            char buf[4];
            snprintf(buf, sizeof(buf), "%02X", a);
            return "<color=#" + ColorToRichText(tag.color) + std::string(buf) + ">" + text + "</color>";
        }

        if (flags & Anim_Scroll) {
            std::string padded = text + " ";
            int total = static_cast<int>(padded.size());
            int windowSize = std::min(total, std::max(14, std::min(26, static_cast<int>(total * 0.7f))));
            int start = static_cast<int>(time * 8.f) % total;
            std::string visible;
            for (int i = 0; i < windowSize; ++i)
                visible += padded[(start + i) % total];
            text = visible;
            len = static_cast<int>(text.size());
        }

        bool hasRainbow = (flags & Anim_Rainbow) != 0;
        bool hasSmoothRainbow = (flags & Anim_SmoothRainbow) != 0;
        bool hasCylinder = (flags & Anim_Cylinder) != 0;
        bool hasPulse = (flags & Anim_Pulse) != 0;
        bool hasJump = (flags & Anim_Jump) != 0;
        bool hasShake = (flags & Anim_Shake) != 0;
        bool hasGhostTrail = (flags & Anim_GhostTrail) != 0;
        bool hasGlitch = (flags & Anim_Glitch) != 0;

        bool perChar = hasRainbow || hasSmoothRainbow || hasCylinder || hasPulse
                    || hasJump || hasShake || hasGhostTrail || hasGlitch;

        if (perChar) {
            std::string result;
            result.reserve(text.size() * 40);
            int mid = len / 2;

            static const char glitchChars[] = "!@#$%^&*()_+-=[]{}|;':\",./<>?~`";
            int glitchFrame = static_cast<int>(time * 15.f);
            float glitchNoise1 = 0.5f + 0.5f * std::sin(time * 0.5f * 3.14159f);
            float glitchNoise2 = 0.5f + 0.5f * std::sin(time * 0.7f * 3.14159f + 100.f);
            float glitchNoise3 = 0.5f + 0.5f * std::sin(time * 0.3f * 3.14159f + 200.f);
            bool shouldCorrupt = glitchNoise2 > 0.6f;
            bool shouldShift = glitchNoise3 > 0.4f;
            int glitchCharIdx = glitchFrame % std::max(1, len);

            for (int i = 0; i < len; ++i) {
                char ch = text[i];

                if (hasGlitch) {
                    float charRand = std::fmod(glitchNoise1 + i * 0.1f, 1.f);
                    if (shouldCorrupt && i == glitchCharIdx)
                        ch = glitchChars[glitchFrame % (sizeof(glitchChars) - 1)];
                    else if (glitchNoise1 > 0.3f && charRand < 0.25f)
                        ch = glitchChars[static_cast<int>(charRand * (sizeof(glitchChars) - 1)) % (sizeof(glitchChars) - 1)];
                }

                Color4 c = tag.color;

                if (hasSmoothRainbow) {
                    float hue = std::fmod(time * 0.3125f + static_cast<float>(i) / std::max(1, len), 1.f);
                    float cv = 1.f;
                    float x = cv * (1.f - std::fabs(std::fmod(hue * 6.f, 2.f) - 1.f));
                    int h = static_cast<int>(hue * 6.f);
                    switch (h % 6) {
                        case 0: c.r = cv; c.g = x;  c.b = 0;  break;
                        case 1: c.r = x;  c.g = cv; c.b = 0;  break;
                        case 2: c.r = 0;  c.g = cv; c.b = x;  break;
                        case 3: c.r = 0;  c.g = x;  c.b = cv; break;
                        case 4: c.r = x;  c.g = 0;  c.b = cv; break;
                        default: c.r = cv; c.g = 0;  c.b = x;  break;
                    }
                } else if (hasRainbow) {
                    static const float rainbow[][3] = {
                        {1,0,0},{1,.5f,0},{1,1,0},{0,1,0},{0,0,1},{.29f,0,.51f},{.56f,0,1}
                    };
                    int idx = (static_cast<int>(time * 2.5f * 7.f) + i) % 7;
                    c.r = rainbow[idx][0]; c.g = rainbow[idx][1]; c.b = rainbow[idx][2];
                }

                if (hasCylinder) {
                    float wave = (std::sin(time * 3.f + static_cast<float>(i + charOffset) * 0.5f) + 1.f) * 0.5f;
                    float brightness = 0.3f + wave * 0.7f;
                    c.r *= brightness; c.g *= brightness; c.b *= brightness;
                }

                if (hasGlitch) {
                    float charRand = std::fmod(glitchNoise1 + i * 0.1f, 1.f);
                    float charRand2 = std::fmod(glitchNoise2 + i * 0.15f, 1.f);
                    float charRand3 = std::fmod(glitchNoise3 + i * 0.2f, 1.f);
                    if (shouldCorrupt && i == glitchCharIdx) {
                        c.r = 0.5f + charRand * 0.5f;
                        c.g = charRand2 * 0.5f;
                        c.b = 0.5f + charRand3 * 0.5f;
                    } else if (glitchNoise1 > 0.3f && charRand < 0.4f) {
                        c.r = 0.8f + charRand * 0.2f;
                        c.g = charRand2 * 0.2f;
                        c.b = 0.8f + charRand3 * 0.2f;
                    }
                    if (glitchNoise1 > 0.5f) {
                        float flickerAlpha = 0.2f + std::fmod(glitchNoise1 + i * 0.25f, 1.f) * 0.8f;
                        c.r *= flickerAlpha; c.g *= flickerAlpha; c.b *= flickerAlpha;
                    }
                }

                float ghostAlpha = 1.f;
                if (hasGhostTrail) {
                    float pulse = std::clamp(std::sin(time * 5.f - i * 0.3f) * 0.5f + 0.5f, 0.f, 1.f);
                    ghostAlpha = pulse;
                }

                std::string colorHex = ColorToRichText(c);
                if (hasGhostTrail) {
                    int a = std::clamp(static_cast<int>(ghostAlpha * 255.f), 0, 255);
                    char abuf[4];
                    snprintf(abuf, sizeof(abuf), "%02X", a);
                    colorHex += abuf;
                }

                if (hasJump) {
                    float offsetDist = std::fabs(static_cast<float>(i) - mid);
                    float voff = std::sin(time * 4.f - offsetDist * 0.3f) * 6.f;
                    char vbuf[32];
                    snprintf(vbuf, sizeof(vbuf), "<voffset=%.1fpx>", voff);
                    result += vbuf;
                }

                if (hasShake) {
                    float rot = std::sin(time * 30.f * 0.1f + i * 0.2f) * 20.f;
                    char rbuf[32];
                    snprintf(rbuf, sizeof(rbuf), "<rotate=%.1f>", rot);
                    result += rbuf;
                }

                if (hasPulse) {
                    float pulseScale = 1.f + std::sin(time * 4.f - i * 0.3f) * 0.2f;
                    char sbuf[32];
                    snprintf(sbuf, sizeof(sbuf), "<size=%.0f%%>", pulseScale * 100.f);
                    result += sbuf;
                }

                if (hasGlitch && shouldShift) {
                    float yoff = std::cos(i * 0.3f + time * 1.5f) * std::sin(time * 1.5f) * 6.75f * 0.15f;
                    char vbuf[32];
                    snprintf(vbuf, sizeof(vbuf), "<voffset=%.1fpx>", yoff);
                    result += vbuf;
                }

                result += "<color=#" + colorHex + ">";
                result += ch;
                result += "</color>";

                if (hasGlitch && shouldShift)
                    result += "</voffset>";
                if (hasPulse)
                    result += "</size>";
                if (hasShake)
                    result += "</rotate>";
                if (hasJump)
                    result += "</voffset>";
            }
            return result;
        }

        return "<color=#" + ColorToRichText(tag.color) + ">" + text + "</color>";
    }

    std::string NameplateTagModule::ColorToRichText(const Color4& c) {
        char buf[16];
        int r = std::clamp(static_cast<int>(c.r * 255.f), 0, 255);
        int g = std::clamp(static_cast<int>(c.g * 255.f), 0, 255);
        int b = std::clamp(static_cast<int>(c.b * 255.f), 0, 255);
        snprintf(buf, sizeof(buf), "%02X%02X%02X", r, g, b);
        return buf;
    }

    std::string NameplateTagModule::ApplyRainbow(const std::string& text, float time) {
        static const char* rainbow[] = {
            "FF0000", "FF7F00", "FFFF00", "00FF00", "0000FF", "4B0082", "8F00FF"
        };

        std::string result;
        for (size_t i = 0; i < text.size(); ++i) {
            int idx = (static_cast<int>(time * 5.f) + static_cast<int>(i)) % 7;
            result += "<color=#";
            result += rainbow[idx];
            result += ">";
            result += text[i];
            result += "</color>";
        }
        return result;
    }

    std::string NameplateTagModule::ApplySmoothRainbow(const std::string& text, float time) {
        std::string result;
        for (size_t i = 0; i < text.size(); ++i) {
            float hue = std::fmod(time * 0.5f + static_cast<float>(i) * 0.1f, 1.f);
            float s = 1.f, v = 1.f;
            float c = v * s;
            float x = c * (1.f - std::fabs(std::fmod(hue * 6.f, 2.f) - 1.f));
            float m = v - c;
            float r, g, b;
            int h = static_cast<int>(hue * 6.f);
            switch (h % 6) {
                case 0: r = c; g = x; b = 0; break;
                case 1: r = x; g = c; b = 0; break;
                case 2: r = 0; g = c; b = x; break;
                case 3: r = 0; g = x; b = c; break;
                case 4: r = x; g = 0; b = c; break;
                default: r = c; g = 0; b = x; break;
            }
            char buf[16];
            snprintf(buf, sizeof(buf), "%02X%02X%02X",
                static_cast<int>((r + m) * 255.f),
                static_cast<int>((g + m) * 255.f),
                static_cast<int>((b + m) * 255.f));
            result += "<color=#";
            result += buf;
            result += ">";
            result += text[i];
            result += "</color>";
        }
        return result;
    }

    std::string NameplateTagModule::ApplyGlitch(const std::string& text, float time) {
        static const char glitchChars[] = "!@#$%^&*<>?/|\\~";
        std::string result = text;
        int period = 7;
        int frame = static_cast<int>(time * 15.f);

        for (size_t i = 0; i < result.size(); ++i) {
            if ((static_cast<int>(i) + frame) % period == 0) {
                result[i] = glitchChars[(frame + i) % (sizeof(glitchChars) - 1)];
            }
        }
        return "<color=#00FF00>" + result + "</color>";
    }

    void NameplateTagModule::CleanupState(NameplateState& state) {
        for (auto* obj : state.tagObjects) {
            if (obj && SafeIsValid(obj)) {
                try {
                    IL2CPP::Module::Unity::Object o(obj);
                    o.Destroy();
                } catch (...) {}
            }
        }
        state.tagObjects.clear();
        state.lastTagCount = 0;
        if (state.infoBarObject && SafeIsValid(state.infoBarObject)) {
            try {
                IL2CPP::Module::Unity::Object obj(state.infoBarObject);
                obj.Destroy();
            } catch (...) {}
        }
        state.infoBarObject = nullptr;
        state.contentsParent = nullptr;
        state.quickStatsTemplate = nullptr;
        state.trustIconObject = nullptr;
        state.bgImage = nullptr;
        state.appliedIcon.clear();
    }

    void NameplateTagModule::CleanupAll() {
        for (auto& state : m_states)
            CleanupState(state);
        m_states.clear();
    }

} // namespace UNIx
