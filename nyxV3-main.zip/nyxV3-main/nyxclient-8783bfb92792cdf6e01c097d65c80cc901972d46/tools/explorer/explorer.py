import socket
import struct
import json
import tkinter as tk
from tkinter import ttk, messagebox
import threading
import re

BRIDGE_HOST = "127.0.0.1"
BRIDGE_PORT = 29150

# ── bridge comms ──

class Bridge:
    def __init__(self):
        self._sock = None
        self._next_id = 1
        self._lock = threading.Lock()

    def connect(self):
        with self._lock:
            if self._sock is not None:
                return
            self._sock = socket.create_connection((BRIDGE_HOST, BRIDGE_PORT), timeout=5)
            self._sock.settimeout(15)

    def disconnect(self):
        with self._lock:
            if self._sock:
                try:
                    self._sock.close()
                except Exception:
                    pass
                self._sock = None

    def send(self, method, **params):
        with self._lock:
            if self._sock is None:
                try:
                    self._sock = socket.create_connection((BRIDGE_HOST, BRIDGE_PORT), timeout=5)
                    self._sock.settimeout(15)
                except Exception as e:
                    self._sock = None
                    return {"error": f"Connection failed: {e}"}

            msg = {"id": self._next_id, "method": method, **params}
            self._next_id += 1

            try:
                data = json.dumps(msg).encode("utf-8")
                self._sock.sendall(struct.pack("<I", len(data)))
                self._sock.sendall(data)

                length_buf = self._recv_all(4)
                if length_buf is None:
                    raise ConnectionError("read failed")
                resp_len = struct.unpack("<I", length_buf)[0]

                resp_buf = self._recv_all(resp_len)
                if resp_buf is None:
                    raise ConnectionError("read failed")

                return json.loads(resp_buf.decode("utf-8"))
            except Exception as e:
                try:
                    self._sock.close()
                except Exception:
                    pass
                self._sock = None
                return {"error": str(e)}

    def _recv_all(self, n):
        buf = b""
        while len(buf) < n:
            chunk = self._sock.recv(n - len(buf))
            if not chunk:
                return None
            buf += chunk
        return buf


# ── colors ──

BG = "#1e1e2e"
BG_DARKER = "#181825"
BG_LIGHTER = "#313244"
BG_SURFACE = "#252536"
FG = "#cdd6f4"
FG_DIM = "#6c7086"
FG_BRIGHT = "#ffffff"
ACCENT = "#b4befe"
ACCENT2 = "#89b4fa"
GREEN = "#a6e3a1"
RED = "#f38ba8"
YELLOW = "#f9e2af"
ORANGE = "#fab387"
PINK = "#f5c2e7"
TEAL = "#94e2d5"
BORDER = "#45475a"


class ExplorerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("VoidUnix Explorer")
        self.root.geometry("1280x800")
        self.root.configure(bg=BG)
        self.root.minsize(900, 600)

        self.bridge = Bridge()
        self.connected = False
        self._path_map = {}
        self._module_vars = {}

        self._setup_styles()
        self._build_ui()
        self._try_connect()

    def _setup_styles(self):
        style = ttk.Style()
        style.theme_use("clam")

        style.configure(".", background=BG, foreground=FG, fieldbackground=BG_DARKER,
                         borderwidth=0, font=("Segoe UI", 10))

        style.configure("Treeview", background=BG_DARKER, foreground=FG,
                         fieldbackground=BG_DARKER, rowheight=24,
                         font=("Cascadia Code", 10))
        style.configure("Treeview.Heading", background=BG_LIGHTER, foreground=ACCENT,
                         font=("Segoe UI Semibold", 10))
        style.map("Treeview",
                   background=[("selected", BG_LIGHTER)],
                   foreground=[("selected", ACCENT)])

        style.configure("TNotebook", background=BG, borderwidth=0)
        style.configure("TNotebook.Tab", background=BG_LIGHTER, foreground=FG_DIM,
                         padding=[12, 6], font=("Segoe UI Semibold", 10))
        style.map("TNotebook.Tab",
                   background=[("selected", BG_SURFACE)],
                   foreground=[("selected", ACCENT)])

        style.configure("TFrame", background=BG)
        style.configure("Surface.TFrame", background=BG_SURFACE)
        style.configure("TLabel", background=BG, foreground=FG)
        style.configure("Header.TLabel", font=("Segoe UI Semibold", 11), foreground=ACCENT)
        style.configure("Title.TLabel", font=("Segoe UI Bold", 13), foreground=FG_BRIGHT)
        style.configure("Dim.TLabel", foreground=FG_DIM)
        style.configure("Green.TLabel", foreground=GREEN)
        style.configure("Red.TLabel", foreground=RED)

        style.configure("Accent.TButton", background=ACCENT, foreground=BG_DARKER,
                         font=("Segoe UI Semibold", 10), padding=[10, 4])
        style.map("Accent.TButton", background=[("active", ACCENT2)])

        style.configure("TButton", background=BG_LIGHTER, foreground=FG,
                         font=("Segoe UI", 10), padding=[8, 4])
        style.map("TButton", background=[("active", BORDER)])

        style.configure("Small.TButton", font=("Segoe UI", 9), padding=[6, 2])

        style.configure("TEntry", fieldbackground=BG_DARKER, foreground=FG,
                         insertcolor=FG, font=("Cascadia Code", 10))

        style.configure("Horizontal.TProgressbar", background=ACCENT, troughcolor=BG_DARKER)

    def _build_ui(self):
        # top bar
        top = tk.Frame(self.root, bg=BG_DARKER, height=44)
        top.pack(fill=tk.X, side=tk.TOP)
        top.pack_propagate(False)

        tk.Label(top, text=" VoidUnix Explorer", font=("Segoe UI Bold", 14),
                 bg=BG_DARKER, fg=ACCENT).pack(side=tk.LEFT, padx=8)

        self.status_dot = tk.Label(top, text="\u25cf", font=("Segoe UI", 12),
                                    bg=BG_DARKER, fg=RED)
        self.status_dot.pack(side=tk.LEFT, padx=4)
        self.status_label = tk.Label(top, text="Disconnected", font=("Segoe UI", 10),
                                      bg=BG_DARKER, fg=FG_DIM)
        self.status_label.pack(side=tk.LEFT)

        ttk.Button(top, text="Reconnect", style="Small.TButton",
                   command=self._try_connect).pack(side=tk.RIGHT, padx=8, pady=8)

        # search bar
        search_frame = tk.Frame(top, bg=BG_DARKER)
        search_frame.pack(side=tk.RIGHT, padx=4, pady=8)
        tk.Label(search_frame, text="Search:", bg=BG_DARKER, fg=FG_DIM,
                 font=("Segoe UI", 10)).pack(side=tk.LEFT, padx=4)
        self.search_var = tk.StringVar()
        search_entry = tk.Entry(search_frame, textvariable=self.search_var,
                                bg=BG_DARKER, fg=FG, insertbackground=FG,
                                font=("Cascadia Code", 10), width=20,
                                relief=tk.FLAT, highlightthickness=1,
                                highlightcolor=ACCENT, highlightbackground=BORDER)
        search_entry.pack(side=tk.LEFT, padx=2)
        search_entry.bind("<Return>", lambda e: self._do_search())
        ttk.Button(search_frame, text="Go", style="Small.TButton",
                   command=self._do_search).pack(side=tk.LEFT, padx=2)

        # main paned window
        main_pw = tk.PanedWindow(self.root, orient=tk.HORIZONTAL, bg=BORDER,
                                  sashwidth=3, sashrelief=tk.FLAT)
        main_pw.pack(fill=tk.BOTH, expand=True, padx=1, pady=1)

        # left: scene tree
        left = tk.Frame(main_pw, bg=BG_SURFACE)
        main_pw.add(left, width=380, minsize=250)

        tree_header = tk.Frame(left, bg=BG_SURFACE)
        tree_header.pack(fill=tk.X, padx=8, pady=(8, 4))
        tk.Label(tree_header, text="Scene Hierarchy", font=("Segoe UI Semibold", 11),
                 bg=BG_SURFACE, fg=ACCENT).pack(side=tk.LEFT)
        ttk.Button(tree_header, text="Refresh", style="Small.TButton",
                   command=self._load_root_objects).pack(side=tk.RIGHT)

        tree_container = tk.Frame(left, bg=BG_DARKER)
        tree_container.pack(fill=tk.BOTH, expand=True, padx=8, pady=(0, 8))

        self.tree = ttk.Treeview(tree_container, show="tree", selectmode="browse")
        tree_scroll = ttk.Scrollbar(tree_container, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscrollcommand=tree_scroll.set)
        tree_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.tree.pack(fill=tk.BOTH, expand=True)
        self.tree.bind("<<TreeviewOpen>>", self._on_tree_expand)
        self.tree.bind("<<TreeviewSelect>>", self._on_tree_select)

        # right: tabbed inspector
        right = tk.Frame(main_pw, bg=BG)
        main_pw.add(right, minsize=400)

        self.notebook = ttk.Notebook(right)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=4, pady=4)

        # tab: Inspector
        self.inspector_frame = tk.Frame(self.notebook, bg=BG)
        self.notebook.add(self.inspector_frame, text="  Inspector  ")
        self._build_inspector(self.inspector_frame)

        # tab: Modules
        self.modules_frame = tk.Frame(self.notebook, bg=BG)
        self.notebook.add(self.modules_frame, text="  Modules  ")
        self._build_modules_tab(self.modules_frame)

        # tab: Players
        self.players_frame = tk.Frame(self.notebook, bg=BG)
        self.notebook.add(self.players_frame, text="  Players  ")
        self._build_players_tab(self.players_frame)

        # tab: Udon
        self.udon_frame = tk.Frame(self.notebook, bg=BG)
        self.notebook.add(self.udon_frame, text="  Udon  ")
        self._build_udon_tab(self.udon_frame)

        # tab: World
        self.world_frame = tk.Frame(self.notebook, bg=BG)
        self.notebook.add(self.world_frame, text="  World  ")
        self._build_world_tab(self.world_frame)

        # tab: Tools
        self.tools_frame = tk.Frame(self.notebook, bg=BG)
        self.notebook.add(self.tools_frame, text="  Tools  ")
        self._build_tools_tab(self.tools_frame)

        # tab: Console
        self.console_frame = tk.Frame(self.notebook, bg=BG)
        self.notebook.add(self.console_frame, text="  Console  ")
        self._build_console_tab(self.console_frame)

    # ── inspector tab ──

    def _build_inspector(self, parent):
        self.inspector_text = tk.Text(parent, bg=BG_DARKER, fg=FG,
                                       font=("Cascadia Code", 10), relief=tk.FLAT,
                                       wrap=tk.WORD, state=tk.DISABLED,
                                       insertbackground=FG, selectbackground=BG_LIGHTER,
                                       padx=12, pady=8)
        scroll = ttk.Scrollbar(parent, orient=tk.VERTICAL, command=self.inspector_text.yview)
        self.inspector_text.configure(yscrollcommand=scroll.set)
        scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.inspector_text.pack(fill=tk.BOTH, expand=True)

        self.inspector_text.tag_configure("header", foreground=ACCENT,
                                           font=("Segoe UI Bold", 13))
        self.inspector_text.tag_configure("section", foreground=ACCENT2,
                                           font=("Segoe UI Semibold", 11))
        self.inspector_text.tag_configure("key", foreground=TEAL,
                                           font=("Cascadia Code", 10))
        self.inspector_text.tag_configure("value", foreground=FG)
        self.inspector_text.tag_configure("dim", foreground=FG_DIM)
        self.inspector_text.tag_configure("green", foreground=GREEN)
        self.inspector_text.tag_configure("red", foreground=RED)
        self.inspector_text.tag_configure("yellow", foreground=YELLOW)
        self.inspector_text.tag_configure("orange", foreground=ORANGE)
        self.inspector_text.tag_configure("pink", foreground=PINK)
        self.inspector_text.tag_configure("component", foreground=ORANGE,
                                           font=("Cascadia Code SemiBold", 10))

        # action bar at bottom
        action_bar = tk.Frame(parent, bg=BG_LIGHTER, height=36)
        action_bar.pack(fill=tk.X, side=tk.BOTTOM)
        action_bar.pack_propagate(False)

        ttk.Button(action_bar, text="Toggle Active", style="Small.TButton",
                   command=self._toggle_selected_active).pack(side=tk.LEFT, padx=4, pady=4)
        ttk.Button(action_bar, text="Copy Path", style="Small.TButton",
                   command=self._copy_selected_path).pack(side=tk.LEFT, padx=4, pady=4)

        tk.Label(action_bar, text="Send Udon Event:", bg=BG_LIGHTER, fg=FG_DIM,
                 font=("Segoe UI", 9)).pack(side=tk.LEFT, padx=(12, 4))
        self.udon_event_var = tk.StringVar()
        udon_entry = tk.Entry(action_bar, textvariable=self.udon_event_var,
                              bg=BG_DARKER, fg=FG, insertbackground=FG,
                              font=("Cascadia Code", 9), width=18,
                              relief=tk.FLAT, highlightthickness=1,
                              highlightcolor=ACCENT, highlightbackground=BORDER)
        udon_entry.pack(side=tk.LEFT, padx=2, pady=4)
        udon_entry.bind("<Return>", lambda e: self._send_udon_from_inspector())
        ttk.Button(action_bar, text="Send", style="Small.TButton",
                   command=self._send_udon_from_inspector).pack(side=tk.LEFT, padx=2, pady=4)

    # ── modules tab ──

    def _build_modules_tab(self, parent):
        header = tk.Frame(parent, bg=BG)
        header.pack(fill=tk.X, padx=8, pady=8)
        tk.Label(header, text="Module Manager", font=("Segoe UI Bold", 13),
                 bg=BG, fg=ACCENT).pack(side=tk.LEFT)
        ttk.Button(header, text="Refresh", style="Small.TButton",
                   command=self._load_modules).pack(side=tk.RIGHT)

        container = tk.Frame(parent, bg=BG_DARKER)
        container.pack(fill=tk.BOTH, expand=True, padx=8, pady=(0, 8))

        canvas = tk.Canvas(container, bg=BG_DARKER, highlightthickness=0)
        scrollbar = ttk.Scrollbar(container, orient=tk.VERTICAL, command=canvas.yview)
        self.modules_inner = tk.Frame(canvas, bg=BG_DARKER)

        self.modules_inner.bind("<Configure>",
                                 lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self.modules_inner, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        canvas.pack(fill=tk.BOTH, expand=True)

        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        canvas.bind_all("<MouseWheel>", _on_mousewheel, add="+")

    # ── players tab ──

    def _build_players_tab(self, parent):
        header = tk.Frame(parent, bg=BG)
        header.pack(fill=tk.X, padx=8, pady=8)
        tk.Label(header, text="Players in Room", font=("Segoe UI Bold", 13),
                 bg=BG, fg=ACCENT).pack(side=tk.LEFT)
        ttk.Button(header, text="Refresh", style="Small.TButton",
                   command=self._load_players).pack(side=tk.RIGHT)

        # action bar
        action_bar = tk.Frame(parent, bg=BG_LIGHTER)
        action_bar.pack(fill=tk.X, side=tk.BOTTOM, padx=8, pady=(0, 4))

        tk.Label(action_bar, text="Target:", bg=BG_LIGHTER, fg=FG_DIM,
                 font=("Segoe UI", 9)).pack(side=tk.LEFT, padx=4, pady=4)
        self._player_target_var = tk.StringVar()
        tk.Entry(action_bar, textvariable=self._player_target_var, bg=BG_DARKER, fg=FG,
                 insertbackground=FG, font=("Cascadia Code", 9), width=16, relief=tk.FLAT,
                 highlightthickness=1, highlightcolor=ACCENT, highlightbackground=BORDER
                 ).pack(side=tk.LEFT, padx=2, pady=4)

        ttk.Button(action_bar, text="TP To", style="Small.TButton",
                   command=self._player_tp_to).pack(side=tk.LEFT, padx=2, pady=4)
        ttk.Button(action_bar, text="Bones", style="Small.TButton",
                   command=self._player_get_bones).pack(side=tk.LEFT, padx=2, pady=4)
        ttk.Button(action_bar, text="Mute", style="Small.TButton",
                   command=lambda: self._player_voice("set_voice_gain", 0)).pack(side=tk.LEFT, padx=2, pady=4)
        ttk.Button(action_bar, text="Unmute", style="Small.TButton",
                   command=lambda: self._player_voice("set_voice_gain", 1.0)).pack(side=tk.LEFT, padx=2, pady=4)

        self._player_status = tk.Label(action_bar, text="", bg=BG_LIGHTER, fg=FG_DIM,
                                        font=("Segoe UI", 9))
        self._player_status.pack(side=tk.RIGHT, padx=8, pady=4)

        self.players_text = tk.Text(parent, bg=BG_DARKER, fg=FG,
                                     font=("Cascadia Code", 10), relief=tk.FLAT,
                                     wrap=tk.WORD, state=tk.DISABLED,
                                     padx=12, pady=8)
        scroll = ttk.Scrollbar(parent, orient=tk.VERTICAL, command=self.players_text.yview)
        self.players_text.configure(yscrollcommand=scroll.set)
        scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.players_text.pack(fill=tk.BOTH, expand=True, padx=8, pady=(0, 4))

        self.players_text.tag_configure("header", foreground=ACCENT,
                                         font=("Segoe UI Bold", 12))
        self.players_text.tag_configure("name", foreground=FG_BRIGHT,
                                         font=("Cascadia Code SemiBold", 11))
        self.players_text.tag_configure("key", foreground=TEAL)
        self.players_text.tag_configure("dim", foreground=FG_DIM)
        self.players_text.tag_configure("visitor", foreground="#CCCCCC")
        self.players_text.tag_configure("basic", foreground="#2BCF5C")
        self.players_text.tag_configure("known", foreground="#FF7A42")
        self.players_text.tag_configure("trusted", foreground="#C73DFF")
        self.players_text.tag_configure("veteran", foreground="#FFFF00")
        self.players_text.tag_configure("admin", foreground="#FF0000")

    # ── udon tab ──

    def _build_udon_tab(self, parent):
        udon_nb = ttk.Notebook(parent)
        udon_nb.pack(fill=tk.BOTH, expand=True, padx=4, pady=4)

        behaviours_frame = tk.Frame(udon_nb, bg=BG)
        udon_nb.add(behaviours_frame, text="  Behaviours  ")
        self._build_udon_behaviours(behaviours_frame)

        monitor_frame = tk.Frame(udon_nb, bg=BG)
        udon_nb.add(monitor_frame, text="  Event Monitor  ")
        self._build_udon_monitor(monitor_frame)

    def _build_udon_behaviours(self, parent):
        header = tk.Frame(parent, bg=BG)
        header.pack(fill=tk.X, padx=8, pady=8)
        tk.Label(header, text="Udon Behaviours", font=("Segoe UI Bold", 13),
                 bg=BG, fg=ACCENT).pack(side=tk.LEFT)
        ttk.Button(header, text="Refresh", style="Small.TButton",
                   command=self._load_udon).pack(side=tk.RIGHT)

        pw = tk.PanedWindow(parent, orient=tk.VERTICAL, bg=BORDER, sashwidth=3)
        pw.pack(fill=tk.BOTH, expand=True, padx=8, pady=(0, 8))

        list_frame = tk.Frame(pw, bg=BG_DARKER)
        pw.add(list_frame, height=300, minsize=150)

        self.udon_tree = ttk.Treeview(list_frame, columns=("path",), show="headings",
                                        selectmode="browse")
        self.udon_tree.heading("path", text="UdonBehaviour Path")
        self.udon_tree.column("path", width=500)
        udon_scroll = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.udon_tree.yview)
        self.udon_tree.configure(yscrollcommand=udon_scroll.set)
        udon_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.udon_tree.pack(fill=tk.BOTH, expand=True)

        bottom = tk.Frame(pw, bg=BG_SURFACE)
        pw.add(bottom, height=200, minsize=100)

        event_bar = tk.Frame(bottom, bg=BG_SURFACE)
        event_bar.pack(fill=tk.X, padx=8, pady=8)
        tk.Label(event_bar, text="Event Name:", bg=BG_SURFACE, fg=FG_DIM,
                 font=("Segoe UI", 10)).pack(side=tk.LEFT, padx=4)
        self.udon_send_var = tk.StringVar()
        event_entry = tk.Entry(event_bar, textvariable=self.udon_send_var,
                               bg=BG_DARKER, fg=FG, insertbackground=FG,
                               font=("Cascadia Code", 10), width=25,
                               relief=tk.FLAT, highlightthickness=1,
                               highlightcolor=ACCENT, highlightbackground=BORDER)
        event_entry.pack(side=tk.LEFT, padx=4)
        event_entry.bind("<Return>", lambda e: self._send_udon_from_tab())
        ttk.Button(event_bar, text="Send Event", style="Accent.TButton",
                   command=self._send_udon_from_tab).pack(side=tk.LEFT, padx=4)

        quick_frame = tk.Frame(bottom, bg=BG_SURFACE)
        quick_frame.pack(fill=tk.X, padx=8)
        tk.Label(quick_frame, text="Quick:", bg=BG_SURFACE, fg=FG_DIM,
                 font=("Segoe UI", 9)).pack(side=tk.LEFT, padx=4)
        for evt in ["_interact", "OnPlayerTriggerEnter", "OnPlayerTriggerExit",
                     "Start", "OnEnable", "OnDisable"]:
            ttk.Button(quick_frame, text=evt, style="Small.TButton",
                       command=lambda e=evt: self._quick_udon(e)).pack(side=tk.LEFT, padx=2)

        self.udon_log = tk.Text(bottom, bg=BG_DARKER, fg=FG,
                                 font=("Cascadia Code", 9), relief=tk.FLAT,
                                 height=5, state=tk.DISABLED, padx=8, pady=4)
        self.udon_log.pack(fill=tk.BOTH, expand=True, padx=8, pady=(4, 8))
        self.udon_log.tag_configure("ok", foreground=GREEN)
        self.udon_log.tag_configure("err", foreground=RED)
        self.udon_log.tag_configure("dim", foreground=FG_DIM)

    def _build_udon_monitor(self, parent):
        self._udon_monitor_active = False
        self._udon_monitor_last_ts = 0
        self._udon_monitor_job = None
        self._udon_monitor_filter = ""
        self._udon_monitor_paused = False

        header = tk.Frame(parent, bg=BG)
        header.pack(fill=tk.X, padx=8, pady=8)
        tk.Label(header, text="Live Event Monitor", font=("Segoe UI Bold", 13),
                 bg=BG, fg=ACCENT).pack(side=tk.LEFT)

        self._monitor_status_var = tk.StringVar(value="Stopped")
        tk.Label(header, textvariable=self._monitor_status_var,
                 font=("Segoe UI", 10), bg=BG, fg=FG_DIM).pack(side=tk.LEFT, padx=12)

        ttk.Button(header, text="Clear", style="Small.TButton",
                   command=self._monitor_clear).pack(side=tk.RIGHT, padx=4)
        self._monitor_pause_btn = ttk.Button(header, text="Pause", style="Small.TButton",
                   command=self._monitor_toggle_pause)
        self._monitor_pause_btn.pack(side=tk.RIGHT, padx=4)
        self._monitor_btn = ttk.Button(header, text="Start Monitor", style="Accent.TButton",
                   command=self._monitor_toggle)
        self._monitor_btn.pack(side=tk.RIGHT, padx=4)

        filter_bar = tk.Frame(parent, bg=BG)
        filter_bar.pack(fill=tk.X, padx=8, pady=(0, 4))
        tk.Label(filter_bar, text="Filter:", bg=BG, fg=FG_DIM,
                 font=("Segoe UI", 10)).pack(side=tk.LEFT, padx=4)
        self._monitor_filter_var = tk.StringVar()
        self._monitor_filter_var.trace_add("write", lambda *_: self._monitor_update_filter())
        filter_entry = tk.Entry(filter_bar, textvariable=self._monitor_filter_var,
                               bg=BG_DARKER, fg=FG, insertbackground=FG,
                               font=("Cascadia Code", 10), width=30,
                               relief=tk.FLAT, highlightthickness=1,
                               highlightcolor=ACCENT, highlightbackground=BORDER)
        filter_entry.pack(side=tk.LEFT, padx=4, fill=tk.X, expand=True)

        self._monitor_text = tk.Text(parent, bg=BG_DARKER, fg=FG,
                                      font=("Cascadia Code", 9), relief=tk.FLAT,
                                      state=tk.DISABLED, padx=8, pady=4, wrap=tk.NONE)
        monitor_scroll_y = ttk.Scrollbar(parent, orient=tk.VERTICAL, command=self._monitor_text.yview)
        monitor_scroll_x = ttk.Scrollbar(parent, orient=tk.HORIZONTAL, command=self._monitor_text.xview)
        self._monitor_text.configure(yscrollcommand=monitor_scroll_y.set, xscrollcommand=monitor_scroll_x.set)
        monitor_scroll_y.pack(side=tk.RIGHT, fill=tk.Y, padx=(0, 8), pady=(0, 8))
        monitor_scroll_x.pack(side=tk.BOTTOM, fill=tk.X, padx=8, pady=(0, 8))
        self._monitor_text.pack(fill=tk.BOTH, expand=True, padx=(8, 0), pady=(0, 0))
        self._monitor_text.tag_configure("ts", foreground=FG_DIM)
        self._monitor_text.tag_configure("go", foreground=ACCENT)
        self._monitor_text.tag_configure("ev", foreground=GREEN)
        self._monitor_text.tag_configure("dim", foreground=FG_DIM)

    # ── world tab ──

    def _build_world_tab(self, parent):
        header = tk.Frame(parent, bg=BG)
        header.pack(fill=tk.X, padx=8, pady=8)
        tk.Label(header, text="World & Network Info", font=("Segoe UI Bold", 13),
                 bg=BG, fg=ACCENT).pack(side=tk.LEFT)
        ttk.Button(header, text="Refresh", style="Small.TButton",
                   command=self._load_world_info).pack(side=tk.RIGHT)

        self.world_text = tk.Text(parent, bg=BG_DARKER, fg=FG,
                                   font=("Cascadia Code", 10), relief=tk.FLAT,
                                   wrap=tk.WORD, state=tk.DISABLED,
                                   padx=12, pady=8)
        scroll = ttk.Scrollbar(parent, orient=tk.VERTICAL, command=self.world_text.yview)
        self.world_text.configure(yscrollcommand=scroll.set)
        scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.world_text.pack(fill=tk.BOTH, expand=True, padx=8, pady=(0, 8))

        self.world_text.tag_configure("section", foreground=ACCENT2,
                                       font=("Segoe UI Semibold", 11))
        self.world_text.tag_configure("key", foreground=TEAL)
        self.world_text.tag_configure("value", foreground=FG)
        self.world_text.tag_configure("dim", foreground=FG_DIM)

    # ── tools tab ──

    def _build_tools_tab(self, parent):
        canvas = tk.Canvas(parent, bg=BG, highlightthickness=0)
        scrollbar = ttk.Scrollbar(parent, orient=tk.VERTICAL, command=canvas.yview)
        inner = tk.Frame(canvas, bg=BG)
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        canvas.pack(fill=tk.BOTH, expand=True)
        canvas.bind_all("<MouseWheel>", lambda e: canvas.yview_scroll(int(-1 * (e.delta / 120)), "units"), add="+")

        # teleport
        sec = self._tools_section(inner, "Teleport")
        row = tk.Frame(sec, bg=BG_SURFACE)
        row.pack(fill=tk.X, padx=8, pady=2)
        self._tp_vars = {}
        for axis in ("X", "Y", "Z"):
            tk.Label(row, text=f"{axis}:", bg=BG_SURFACE, fg=FG_DIM, font=("Segoe UI", 9)).pack(side=tk.LEFT, padx=2)
            var = tk.StringVar(value="0")
            self._tp_vars[axis.lower()] = var
            tk.Entry(row, textvariable=var, bg=BG_DARKER, fg=FG, insertbackground=FG,
                     font=("Cascadia Code", 9), width=8, relief=tk.FLAT,
                     highlightthickness=1, highlightcolor=ACCENT, highlightbackground=BORDER
                     ).pack(side=tk.LEFT, padx=2)
        ttk.Button(row, text="Teleport", style="Accent.TButton",
                   command=self._do_teleport).pack(side=tk.LEFT, padx=8)
        ttk.Button(row, text="Get Pos", style="Small.TButton",
                   command=self._get_current_pos).pack(side=tk.LEFT, padx=2)

        # teleport to player
        row2 = tk.Frame(sec, bg=BG_SURFACE)
        row2.pack(fill=tk.X, padx=8, pady=2)
        tk.Label(row2, text="Player:", bg=BG_SURFACE, fg=FG_DIM, font=("Segoe UI", 9)).pack(side=tk.LEFT, padx=2)
        self._tp_player_var = tk.StringVar()
        tk.Entry(row2, textvariable=self._tp_player_var, bg=BG_DARKER, fg=FG, insertbackground=FG,
                 font=("Cascadia Code", 9), width=20, relief=tk.FLAT,
                 highlightthickness=1, highlightcolor=ACCENT, highlightbackground=BORDER
                 ).pack(side=tk.LEFT, padx=2)
        ttk.Button(row2, text="Teleport To", style="Accent.TButton",
                   command=self._do_teleport_to_player).pack(side=tk.LEFT, padx=8)

        # movement
        sec = self._tools_section(inner, "Movement")
        self._move_vars = {}
        move_row = tk.Frame(sec, bg=BG_SURFACE)
        move_row.pack(fill=tk.X, padx=8, pady=2)
        for label in ("walk", "run", "strafe"):
            tk.Label(move_row, text=f"{label.title()}:", bg=BG_SURFACE, fg=FG_DIM,
                     font=("Segoe UI", 9)).pack(side=tk.LEFT, padx=2)
            var = tk.StringVar(value="")
            self._move_vars[label] = var
            tk.Entry(move_row, textvariable=var, bg=BG_DARKER, fg=FG, insertbackground=FG,
                     font=("Cascadia Code", 9), width=6, relief=tk.FLAT,
                     highlightthickness=1, highlightcolor=ACCENT, highlightbackground=BORDER
                     ).pack(side=tk.LEFT, padx=2)

        move_row2 = tk.Frame(sec, bg=BG_SURFACE)
        move_row2.pack(fill=tk.X, padx=8, pady=2)
        for label in ("jump", "gravity"):
            tk.Label(move_row2, text=f"{label.title()}:", bg=BG_SURFACE, fg=FG_DIM,
                     font=("Segoe UI", 9)).pack(side=tk.LEFT, padx=2)
            var = tk.StringVar(value="")
            self._move_vars[label] = var
            tk.Entry(move_row2, textvariable=var, bg=BG_DARKER, fg=FG, insertbackground=FG,
                     font=("Cascadia Code", 9), width=6, relief=tk.FLAT,
                     highlightthickness=1, highlightcolor=ACCENT, highlightbackground=BORDER
                     ).pack(side=tk.LEFT, padx=2)
        ttk.Button(move_row2, text="Apply", style="Accent.TButton",
                   command=self._apply_movement).pack(side=tk.LEFT, padx=8)

        # time scale
        sec = self._tools_section(inner, "Time Scale")
        ts_row = tk.Frame(sec, bg=BG_SURFACE)
        ts_row.pack(fill=tk.X, padx=8, pady=2)
        self._timescale_var = tk.StringVar(value="1.0")
        tk.Entry(ts_row, textvariable=self._timescale_var, bg=BG_DARKER, fg=FG, insertbackground=FG,
                 font=("Cascadia Code", 9), width=6, relief=tk.FLAT,
                 highlightthickness=1, highlightcolor=ACCENT, highlightbackground=BORDER
                 ).pack(side=tk.LEFT, padx=4)
        for val in ("0.1", "0.5", "1.0", "2.0", "5.0"):
            ttk.Button(ts_row, text=val, style="Small.TButton",
                       command=lambda v=val: self._set_timescale(v)).pack(side=tk.LEFT, padx=2)

        # go to room
        sec = self._tools_section(inner, "Go To Room")
        room_row = tk.Frame(sec, bg=BG_SURFACE)
        room_row.pack(fill=tk.X, padx=8, pady=2)
        self._room_var = tk.StringVar()
        tk.Entry(room_row, textvariable=self._room_var, bg=BG_DARKER, fg=FG, insertbackground=FG,
                 font=("Cascadia Code", 9), width=40, relief=tk.FLAT,
                 highlightthickness=1, highlightcolor=ACCENT, highlightbackground=BORDER
                 ).pack(side=tk.LEFT, padx=4)
        ttk.Button(room_row, text="Join", style="Accent.TButton",
                   command=self._do_go_to_room).pack(side=tk.LEFT, padx=4)

        # transform
        sec = self._tools_section(inner, "Set Transform")
        tf_row = tk.Frame(sec, bg=BG_SURFACE)
        tf_row.pack(fill=tk.X, padx=8, pady=2)
        tk.Label(tf_row, text="Path:", bg=BG_SURFACE, fg=FG_DIM, font=("Segoe UI", 9)).pack(side=tk.LEFT, padx=2)
        self._tf_path_var = tk.StringVar()
        tk.Entry(tf_row, textvariable=self._tf_path_var, bg=BG_DARKER, fg=FG, insertbackground=FG,
                 font=("Cascadia Code", 9), width=30, relief=tk.FLAT,
                 highlightthickness=1, highlightcolor=ACCENT, highlightbackground=BORDER
                 ).pack(side=tk.LEFT, padx=2)

        tf_row2 = tk.Frame(sec, bg=BG_SURFACE)
        tf_row2.pack(fill=tk.X, padx=8, pady=2)
        self._tf_pos_vars = {}
        tk.Label(tf_row2, text="Pos:", bg=BG_SURFACE, fg=FG_DIM, font=("Segoe UI", 9)).pack(side=tk.LEFT, padx=2)
        for axis in ("x", "y", "z"):
            var = tk.StringVar(value="0")
            self._tf_pos_vars[axis] = var
            tk.Entry(tf_row2, textvariable=var, bg=BG_DARKER, fg=FG, insertbackground=FG,
                     font=("Cascadia Code", 9), width=7, relief=tk.FLAT,
                     highlightthickness=1, highlightcolor=ACCENT, highlightbackground=BORDER
                     ).pack(side=tk.LEFT, padx=1)
        ttk.Button(tf_row2, text="Set Pos", style="Small.TButton",
                   command=lambda: self._set_transform("position")).pack(side=tk.LEFT, padx=4)

        tf_row3 = tk.Frame(sec, bg=BG_SURFACE)
        tf_row3.pack(fill=tk.X, padx=8, pady=2)
        self._tf_rot_vars = {}
        tk.Label(tf_row3, text="Rot:", bg=BG_SURFACE, fg=FG_DIM, font=("Segoe UI", 9)).pack(side=tk.LEFT, padx=2)
        for axis in ("x", "y", "z"):
            var = tk.StringVar(value="0")
            self._tf_rot_vars[axis] = var
            tk.Entry(tf_row3, textvariable=var, bg=BG_DARKER, fg=FG, insertbackground=FG,
                     font=("Cascadia Code", 9), width=7, relief=tk.FLAT,
                     highlightthickness=1, highlightcolor=ACCENT, highlightbackground=BORDER
                     ).pack(side=tk.LEFT, padx=1)
        ttk.Button(tf_row3, text="Set Rot", style="Small.TButton",
                   command=lambda: self._set_transform("rotation")).pack(side=tk.LEFT, padx=4)

        tf_row4 = tk.Frame(sec, bg=BG_SURFACE)
        tf_row4.pack(fill=tk.X, padx=8, pady=2)
        self._tf_scale_vars = {}
        tk.Label(tf_row4, text="Scl:", bg=BG_SURFACE, fg=FG_DIM, font=("Segoe UI", 9)).pack(side=tk.LEFT, padx=2)
        for axis in ("x", "y", "z"):
            var = tk.StringVar(value="1")
            self._tf_scale_vars[axis] = var
            tk.Entry(tf_row4, textvariable=var, bg=BG_DARKER, fg=FG, insertbackground=FG,
                     font=("Cascadia Code", 9), width=7, relief=tk.FLAT,
                     highlightthickness=1, highlightcolor=ACCENT, highlightbackground=BORDER
                     ).pack(side=tk.LEFT, padx=1)
        ttk.Button(tf_row4, text="Set Scale", style="Small.TButton",
                   command=lambda: self._set_transform("scale")).pack(side=tk.LEFT, padx=4)

        # find by tag
        sec = self._tools_section(inner, "Find By Tag")
        tag_row = tk.Frame(sec, bg=BG_SURFACE)
        tag_row.pack(fill=tk.X, padx=8, pady=2)
        self._tag_var = tk.StringVar()
        tk.Entry(tag_row, textvariable=self._tag_var, bg=BG_DARKER, fg=FG, insertbackground=FG,
                 font=("Cascadia Code", 9), width=20, relief=tk.FLAT,
                 highlightthickness=1, highlightcolor=ACCENT, highlightbackground=BORDER
                 ).pack(side=tk.LEFT, padx=4)
        ttk.Button(tag_row, text="Find", style="Accent.TButton",
                   command=self._do_find_by_tag).pack(side=tk.LEFT, padx=4)
        for t in ("Player", "Untagged", "MainCamera"):
            ttk.Button(tag_row, text=t, style="Small.TButton",
                       command=lambda v=t: self._quick_find_tag(v)).pack(side=tk.LEFT, padx=2)

        # quick actions
        sec = self._tools_section(inner, "Quick Actions")
        qa_row = tk.Frame(sec, bg=BG_SURFACE)
        qa_row.pack(fill=tk.X, padx=8, pady=2)
        ttk.Button(qa_row, text="Respawn", style="Accent.TButton",
                   command=lambda: self._player_action("respawn")).pack(side=tk.LEFT, padx=4)
        ttk.Button(qa_row, text="Immobilize", style="Small.TButton",
                   command=lambda: self._player_action("immobilize", value=True)).pack(side=tk.LEFT, padx=2)
        ttk.Button(qa_row, text="Unfreeze", style="Small.TButton",
                   command=lambda: self._player_action("immobilize", value=False)).pack(side=tk.LEFT, padx=2)

        # tools status
        self._tools_status = tk.Label(inner, text="", bg=BG, fg=FG_DIM, font=("Segoe UI", 9),
                                       anchor=tk.W)
        self._tools_status.pack(fill=tk.X, padx=12, pady=4)

    def _tools_section(self, parent, title):
        frame = tk.Frame(parent, bg=BG_SURFACE, highlightthickness=1, highlightbackground=BORDER)
        frame.pack(fill=tk.X, padx=8, pady=4)
        tk.Label(frame, text=title, bg=BG_SURFACE, fg=ACCENT,
                 font=("Segoe UI Semibold", 10)).pack(anchor=tk.W, padx=8, pady=(6, 2))
        return frame

    def _tools_set_status(self, text, color=FG_DIM):
        self._tools_status.config(text=text, fg=color)

    def _do_teleport(self):
        try:
            x = float(self._tp_vars["x"].get())
            y = float(self._tp_vars["y"].get())
            z = float(self._tp_vars["z"].get())
        except ValueError:
            self._tools_set_status("Invalid coordinates", RED)
            return
        def on_result(resp):
            result = resp.get("result", resp)
            if isinstance(result, dict) and result.get("ok"):
                self._tools_set_status(f"Teleported to ({x:.1f}, {y:.1f}, {z:.1f})", GREEN)
            else:
                self._tools_set_status(f"Teleport failed: {result}", RED)
        self._async("teleport", on_result, x=x, y=y, z=z)

    def _get_current_pos(self):
        def on_result(resp):
            result = resp.get("result", resp)
            if isinstance(result, dict) and "position" in result:
                pos = result["position"]
                self._tp_vars["x"].set(f"{pos.get('x', 0):.2f}")
                self._tp_vars["y"].set(f"{pos.get('y', 0):.2f}")
                self._tp_vars["z"].set(f"{pos.get('z', 0):.2f}")
                self._tools_set_status("Position loaded", GREEN)
            elif isinstance(result, dict):
                pos = result
                if "x" in pos:
                    self._tp_vars["x"].set(f"{pos.get('x', 0):.2f}")
                    self._tp_vars["y"].set(f"{pos.get('y', 0):.2f}")
                    self._tp_vars["z"].set(f"{pos.get('z', 0):.2f}")
                    self._tools_set_status("Position loaded", GREEN)
        self._async("get_player_info", on_result, player_id=-1)

    def _do_teleport_to_player(self):
        name = self._tp_player_var.get().strip()
        if not name:
            self._tools_set_status("Enter a player name", RED)
            return
        def on_result(resp):
            result = resp.get("result", resp)
            if isinstance(result, dict) and result.get("ok"):
                self._tools_set_status(f"Teleported to {name}", GREEN)
            else:
                self._tools_set_status(f"Failed: {result}", RED)
        self._async("teleport_to_player", on_result, name=name)

    def _apply_movement(self):
        params = {}
        for key, var in self._move_vars.items():
            val = var.get().strip()
            if val:
                try:
                    params[key] = float(val)
                except ValueError:
                    self._tools_set_status(f"Invalid {key} value", RED)
                    return
        if not params:
            self._tools_set_status("Enter at least one value", RED)
            return
        def on_result(resp):
            result = resp.get("result", resp)
            if isinstance(result, dict) and result.get("ok"):
                self._tools_set_status("Movement applied", GREEN)
            else:
                self._tools_set_status(f"Failed: {result}", RED)
        self._async("set_movement", on_result, **params)

    def _set_timescale(self, val):
        self._timescale_var.set(val)
        try:
            scale = float(val)
        except ValueError:
            return
        def on_result(resp):
            result = resp.get("result", resp)
            if isinstance(result, dict) and result.get("ok"):
                self._tools_set_status(f"Time scale: {scale}", GREEN)
            else:
                self._tools_set_status(f"Failed: {result}", RED)
        self._async("set_time_scale", on_result, scale=scale)

    def _do_go_to_room(self):
        room_id = self._room_var.get().strip()
        if not room_id:
            self._tools_set_status("Enter a room ID", RED)
            return
        def on_result(resp):
            result = resp.get("result", resp)
            if isinstance(result, dict) and result.get("ok"):
                self._tools_set_status(f"Joining {room_id}", GREEN)
            else:
                self._tools_set_status(f"Failed: {result}", RED)
        self._async("go_to_room", on_result, room_id=room_id)

    def _set_transform(self, mode):
        path = self._tf_path_var.get().strip()
        if not path:
            sel = self.tree.selection()
            if sel:
                path = self._path_map.get(sel[0], "")
        if not path:
            self._tools_set_status("Enter or select a path", RED)
            return
        params = {"path": path}
        try:
            if mode == "position":
                params["position"] = {a: float(self._tf_pos_vars[a].get()) for a in ("x", "y", "z")}
            elif mode == "rotation":
                params["rotation"] = {a: float(self._tf_rot_vars[a].get()) for a in ("x", "y", "z")}
            elif mode == "scale":
                params["scale"] = {a: float(self._tf_scale_vars[a].get()) for a in ("x", "y", "z")}
        except ValueError:
            self._tools_set_status("Invalid values", RED)
            return
        def on_result(resp):
            result = resp.get("result", resp)
            if isinstance(result, dict) and result.get("ok"):
                self._tools_set_status(f"Transform {mode} set", GREEN)
            else:
                self._tools_set_status(f"Failed: {result}", RED)
        self._async("set_transform", on_result, **params)

    def _do_find_by_tag(self):
        tag = self._tag_var.get().strip()
        if not tag:
            return
        def on_result(resp):
            result = resp.get("result", resp)
            if isinstance(result, list):
                for item in self.tree.get_children():
                    self.tree.delete(item)
                self._path_map.clear()
                header = self.tree.insert("", tk.END, text=f"Tag: \"{tag}\" ({len(result)} results)")
                for obj in result:
                    self._add_tree_node(header, obj)
                self.tree.item(header, open=True)
                self._tools_set_status(f"Found {len(result)} objects with tag '{tag}'", GREEN)
            else:
                self._tools_set_status(f"Find failed: {result}", RED)
        self._async("find_by_tag", on_result, tag=tag)

    def _quick_find_tag(self, tag):
        self._tag_var.set(tag)
        self._do_find_by_tag()

    def _player_action(self, action, **extra):
        params = {"action": action, **extra}
        def on_result(resp):
            result = resp.get("result", resp)
            if isinstance(result, dict) and result.get("ok"):
                self._tools_set_status(f"Action '{action}' done", GREEN)
            else:
                self._tools_set_status(f"Failed: {result}", RED)
        self._async("player_action", on_result, **params)

    # ── console tab ──

    def _build_console_tab(self, parent):
        header = tk.Frame(parent, bg=BG)
        header.pack(fill=tk.X, padx=8, pady=8)
        tk.Label(header, text="Debug Log", font=("Segoe UI Bold", 13),
                 bg=BG, fg=ACCENT).pack(side=tk.LEFT)
        ttk.Button(header, text="Refresh", style="Small.TButton",
                   command=self._load_log).pack(side=tk.RIGHT)
        ttk.Button(header, text="Clear", style="Small.TButton",
                   command=self._clear_log_display).pack(side=tk.RIGHT, padx=4)

        self.log_text = tk.Text(parent, bg=BG_DARKER, fg=FG,
                                 font=("Cascadia Code", 9), relief=tk.FLAT,
                                 wrap=tk.WORD, state=tk.DISABLED,
                                 padx=8, pady=4)
        scroll = ttk.Scrollbar(parent, orient=tk.VERTICAL, command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=scroll.set)
        scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.pack(fill=tk.BOTH, expand=True, padx=8, pady=(0, 4))

        self.log_text.tag_configure("info", foreground=ACCENT2)
        self.log_text.tag_configure("warn", foreground=YELLOW)
        self.log_text.tag_configure("error", foreground=RED)
        self.log_text.tag_configure("dim", foreground=FG_DIM)

        send_bar = tk.Frame(parent, bg=BG_LIGHTER, height=36)
        send_bar.pack(fill=tk.X, side=tk.BOTTOM)
        send_bar.pack_propagate(False)
        tk.Label(send_bar, text="Send:", bg=BG_LIGHTER, fg=FG_DIM,
                 font=("Segoe UI", 9)).pack(side=tk.LEFT, padx=4)
        self.log_send_var = tk.StringVar()
        entry = tk.Entry(send_bar, textvariable=self.log_send_var,
                         bg=BG_DARKER, fg=FG, insertbackground=FG,
                         font=("Cascadia Code", 9), relief=tk.FLAT,
                         highlightthickness=1, highlightcolor=ACCENT,
                         highlightbackground=BORDER)
        entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=4, pady=4)
        entry.bind("<Return>", lambda e: self._send_log_msg())
        ttk.Button(send_bar, text="Send", style="Small.TButton",
                   command=self._send_log_msg).pack(side=tk.RIGHT, padx=4, pady=4)

    # ── connection ──

    def _try_connect(self):
        def do():
            try:
                self.bridge.connect()
                resp = self.bridge.send("ping")
                if resp.get("result", {}).get("status") == "ok" or resp.get("status") == "ok":
                    self.connected = True
                    self.root.after(0, self._on_connected)
                else:
                    self.root.after(0, lambda: self._set_status(False, "Ping failed"))
            except Exception as e:
                msg = str(e)
                self.root.after(0, lambda msg=msg: self._set_status(False, msg))
        threading.Thread(target=do, daemon=True).start()

    def _on_connected(self):
        self._set_status(True, "Connected")
        self._load_root_objects()
        self._load_modules()

    def _set_status(self, ok, text):
        self.status_dot.config(fg=GREEN if ok else RED)
        self.status_label.config(text=text)
        self.connected = ok

    # ── async bridge helper ──

    def _async(self, method, callback, **params):
        def do():
            resp = self.bridge.send(method, **params)
            self.root.after(0, lambda: callback(resp))
        threading.Thread(target=do, daemon=True).start()

    # ── scene tree ──

    def _load_root_objects(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        self._path_map.clear()

        def on_result(resp):
            result = resp.get("result", resp)
            if isinstance(result, list):
                for obj in result:
                    self._add_tree_node("", obj)
        self._async("list_gameobjects", on_result, path="/", limit=200)

    def _add_tree_node(self, parent_iid, obj):
        name = obj.get("name", "?")
        path = obj.get("path", name)
        active = obj.get("active", True)
        child_count = obj.get("childCount", 0)

        prefix = "\u25cf " if active else "\u25cb "
        display = prefix + name
        if child_count > 0:
            display += f"  ({child_count})"

        iid = self.tree.insert(parent_iid, tk.END, text=display)
        self._path_map[iid] = path

        if child_count > 0:
            self.tree.insert(iid, tk.END, text="Loading...")

    def _on_tree_expand(self, event):
        iid = self.tree.focus()
        children = self.tree.get_children(iid)
        if len(children) == 1 and self.tree.item(children[0], "text") == "Loading...":
            self.tree.delete(children[0])
            path = self._path_map.get(iid, "")
            def on_result(resp):
                result = resp.get("result", resp)
                if isinstance(result, list):
                    for obj in result:
                        self._add_tree_node(iid, obj)
                elif isinstance(result, dict) and "error" in result:
                    self.tree.insert(iid, tk.END, text=f"  (error: {result['error']})")
            self._async("list_gameobjects", on_result, path=path, limit=200)

    def _on_tree_select(self, event):
        sel = self.tree.selection()
        if not sel:
            return
        iid = sel[0]
        path = self._path_map.get(iid, "")
        if path:
            self._inspect_object(path)

    def _inspect_object(self, path):
        self.notebook.select(0)
        self._inspector_set("Loading...")
        self._current_inspect_path = path

        def on_result(resp):
            result = resp.get("result", resp)
            if isinstance(result, dict) and "error" not in result:
                self._display_inspect(path, result)
            else:
                err = result.get("error", "Unknown error") if isinstance(result, dict) else str(result)
                self._inspector_set(f"Error: {err}")

        self._async("inspect_gameobject", on_result, path=path)

    def _display_inspect(self, path, data):
        t = self.inspector_text
        t.config(state=tk.NORMAL)
        t.delete("1.0", tk.END)

        name = data.get("name", "?")
        active = data.get("active", False)
        layer = data.get("layer", 0)
        pos = data.get("position", {})
        rot = data.get("rotation", {})
        scale = data.get("scale", {})
        components = data.get("components", [])

        t.insert(tk.END, f"{name}\n", "header")
        t.insert(tk.END, f"{path}\n", "dim")
        t.insert(tk.END, "\n")

        t.insert(tk.END, "Active   ", "key")
        t.insert(tk.END, f"{'Yes' if active else 'No'}\n", "green" if active else "red")

        t.insert(tk.END, "Layer    ", "key")
        t.insert(tk.END, f"{layer}\n", "value")
        t.insert(tk.END, "\n")

        t.insert(tk.END, "Transform\n", "section")
        t.insert(tk.END, "  Position  ", "key")
        t.insert(tk.END, f"({pos.get('x', 0):.3f}, {pos.get('y', 0):.3f}, {pos.get('z', 0):.3f})\n", "value")
        t.insert(tk.END, "  Rotation  ", "key")
        t.insert(tk.END, f"({rot.get('x', 0):.3f}, {rot.get('y', 0):.3f}, {rot.get('z', 0):.3f}, {rot.get('w', 0):.3f})\n", "value")
        t.insert(tk.END, "  Scale     ", "key")
        t.insert(tk.END, f"({scale.get('x', 0):.3f}, {scale.get('y', 0):.3f}, {scale.get('z', 0):.3f})\n", "value")
        t.insert(tk.END, "\n")

        if components:
            t.insert(tk.END, f"Components ({len(components)})\n", "section")
            for comp in components:
                cname = comp.get("className", "?")
                ns = comp.get("namespace", "")
                idx = comp.get("index", "")
                display_name = f"{ns}.{cname}" if ns else cname
                if len(display_name) > 60:
                    display_name = display_name[:57] + "..."
                t.insert(tk.END, f"  [{idx}] ", "dim")
                t.insert(tk.END, f"{display_name}\n", "component")

        t.config(state=tk.DISABLED)

    def _inspector_set(self, text):
        t = self.inspector_text
        t.config(state=tk.NORMAL)
        t.delete("1.0", tk.END)
        t.insert("1.0", text, "dim")
        t.config(state=tk.DISABLED)

    def _toggle_selected_active(self):
        sel = self.tree.selection()
        if not sel:
            return
        path = self._path_map.get(sel[0], "")
        if not path:
            return
        current_text = self.tree.item(sel[0], "text")
        is_active = current_text.startswith("\u25cf")
        self._async("set_gameobject_active", lambda r: self._inspect_object(path),
                     path=path, active=not is_active)

    def _copy_selected_path(self):
        sel = self.tree.selection()
        if not sel:
            return
        path = self._path_map.get(sel[0], "")
        self.root.clipboard_clear()
        self.root.clipboard_append(path)

    def _send_udon_from_inspector(self):
        path = getattr(self, "_current_inspect_path", "")
        event = self.udon_event_var.get().strip()
        if not path or not event:
            return
        def on_result(resp):
            result = resp.get("result", resp)
            ok = result.get("ok", False) if isinstance(result, dict) else False
            status = "sent" if ok else f"error: {result}"
            self._udon_log_append(f"[Inspector] {path} -> {event}: {status}")
        self._async("send_udon_event", on_result, path=path, event=event)

    # ── search ──

    def _do_search(self):
        pattern = self.search_var.get().strip()
        if not pattern:
            return
        def on_result(resp):
            result = resp.get("result", resp)
            if isinstance(result, list):
                for item in self.tree.get_children():
                    self.tree.delete(item)
                self._path_map.clear()
                header_iid = self.tree.insert("", tk.END, text=f"Search: \"{pattern}\" ({len(result)} results)")
                for obj in result:
                    self._add_tree_node(header_iid, obj)
                self.tree.item(header_iid, open=True)
        self._async("search_scene", on_result, pattern=pattern, limit=100)

    # ── modules ──

    def _load_modules(self):
        for w in self.modules_inner.winfo_children():
            w.destroy()
        self._module_vars.clear()

        def on_result(resp):
            result = resp.get("result", resp)
            if not isinstance(result, list):
                return

            categories = {}
            for mod in result:
                cat = mod.get("category", "Other")
                categories.setdefault(cat, []).append(mod)

            for cat_name, modules in sorted(categories.items()):
                cat_frame = tk.Frame(self.modules_inner, bg=BG_DARKER)
                cat_frame.pack(fill=tk.X, padx=4, pady=(8, 2))

                tk.Label(cat_frame, text=cat_name.upper(), bg=BG_DARKER, fg=ACCENT,
                         font=("Segoe UI Semibold", 10)).pack(anchor=tk.W, padx=8, pady=(4, 2))

                sep = tk.Frame(cat_frame, bg=BORDER, height=1)
                sep.pack(fill=tk.X, padx=8)

                for mod in modules:
                    self._add_module_row(cat_frame, mod)

        self._async("list_modules", on_result)

    def _add_module_row(self, parent, mod):
        name = mod.get("name", "?")
        desc = mod.get("description", "")
        enabled = mod.get("enabled", False)
        keybind = mod.get("keybind", 0)

        row = tk.Frame(parent, bg=BG_SURFACE, highlightthickness=1,
                        highlightbackground=BORDER)
        row.pack(fill=tk.X, padx=8, pady=2)

        left = tk.Frame(row, bg=BG_SURFACE)
        left.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=8, pady=6)

        name_label = tk.Label(left, text=name, bg=BG_SURFACE, fg=FG_BRIGHT,
                               font=("Segoe UI Semibold", 10))
        name_label.pack(anchor=tk.W)

        if desc:
            tk.Label(left, text=desc, bg=BG_SURFACE, fg=FG_DIM,
                     font=("Segoe UI", 9)).pack(anchor=tk.W)

        right = tk.Frame(row, bg=BG_SURFACE)
        right.pack(side=tk.RIGHT, padx=8, pady=6)

        if keybind > 0:
            key_name = self._vk_name(keybind)
            tk.Label(right, text=key_name, bg=BG_LIGHTER, fg=FG_DIM,
                     font=("Cascadia Code", 8), padx=4, pady=1).pack(side=tk.LEFT, padx=4)

        var = tk.BooleanVar(value=enabled)
        self._module_vars[name] = var

        toggle_btn = tk.Button(row, text="ON" if enabled else "OFF",
                                bg=GREEN if enabled else BG_LIGHTER,
                                fg=BG_DARKER if enabled else FG_DIM,
                                font=("Segoe UI Bold", 9), width=4, relief=tk.FLAT,
                                cursor="hand2")

        def do_toggle(btn=toggle_btn, n=name, v=var):
            new_state = not v.get()
            v.set(new_state)
            btn.config(text="ON" if new_state else "OFF",
                       bg=GREEN if new_state else BG_LIGHTER,
                       fg=BG_DARKER if new_state else FG_DIM)
            self._async("toggle_module", lambda r: None,
                         name=n, enabled="true" if new_state else "false")

        toggle_btn.config(command=do_toggle)
        toggle_btn.pack(side=tk.RIGHT, padx=4)

    def _vk_name(self, vk):
        names = {
            112: "F1", 113: "F2", 114: "F3", 115: "F4", 116: "F5",
            117: "F6", 118: "F7", 119: "F8", 120: "F9", 121: "F10",
            122: "F11", 123: "F12", 70: "F",
        }
        return names.get(vk, f"0x{vk:02X}")

    # ── players ──

    def _load_players(self):
        def on_result(resp):
            result = resp.get("result", resp)
            t = self.players_text
            t.config(state=tk.NORMAL)
            t.delete("1.0", tk.END)

            if not isinstance(result, list):
                t.insert(tk.END, "No player data", "dim")
                t.config(state=tk.DISABLED)
                return

            for p in result:
                name = p.get("displayName", "?")
                pid = p.get("playerId", "?")
                rank = p.get("rank", "visitor").lower()
                platform = p.get("platform", "?")
                is_master = p.get("isMaster", False)
                is_local = p.get("isLocal", False)
                user_id = p.get("userId", "")

                rank_tag = rank if rank in ("visitor", "basic", "known", "trusted", "veteran", "admin") else "visitor"
                t.insert(tk.END, f"{name}", rank_tag)
                badges = []
                if is_local:
                    badges.append("LOCAL")
                if is_master:
                    badges.append("MASTER")
                if badges:
                    t.insert(tk.END, f"  [{', '.join(badges)}]", "dim")
                t.insert(tk.END, "\n")

                t.insert(tk.END, f"  ID: ", "key")
                t.insert(tk.END, f"{pid}  ", "dim")
                t.insert(tk.END, f"Rank: ", "key")
                t.insert(tk.END, f"{rank}  ", rank_tag)
                t.insert(tk.END, f"Platform: ", "key")
                t.insert(tk.END, f"{platform}\n", "dim")

                if user_id:
                    t.insert(tk.END, f"  UserID: ", "key")
                    t.insert(tk.END, f"{user_id}\n", "dim")

                t.insert(tk.END, "\n")

            t.config(state=tk.DISABLED)

        self._async("list_players", on_result)

    def _player_tp_to(self):
        name = self._player_target_var.get().strip()
        if not name:
            self._player_status.config(text="Enter a player name", fg=RED)
            return
        def on_result(resp):
            result = resp.get("result", resp)
            if isinstance(result, dict) and result.get("ok"):
                self._player_status.config(text=f"Teleported to {name}", fg=GREEN)
            else:
                self._player_status.config(text=f"Failed", fg=RED)
        self._async("teleport_to_player", on_result, name=name)

    def _player_get_bones(self):
        name = self._player_target_var.get().strip()
        if not name:
            self._player_status.config(text="Enter a player name", fg=RED)
            return
        def on_found(resp):
            result = resp.get("result", resp)
            if isinstance(result, dict) and "playerId" in result:
                pid = result["playerId"]
                def on_bones(resp2):
                    bones = resp2.get("result", resp2)
                    t = self.players_text
                    t.config(state=tk.NORMAL)
                    t.delete("1.0", tk.END)
                    t.insert(tk.END, f"Bones for {name}\n\n", "header")
                    if isinstance(bones, dict) and "bones" in bones:
                        for bone in bones["bones"]:
                            bname = bone.get("name", "?")
                            pos = bone.get("position", {})
                            t.insert(tk.END, f"  {bname:20s} ", "key")
                            t.insert(tk.END, f"({pos.get('x',0):.2f}, {pos.get('y',0):.2f}, {pos.get('z',0):.2f})\n", "dim")
                    t.config(state=tk.DISABLED)
                    self._player_status.config(text=f"Bones loaded for {name}", fg=GREEN)
                self._async("get_all_bones", on_bones, player_id=pid)
            else:
                self._player_status.config(text=f"Player not found", fg=RED)
        self._async("get_player_by_name", on_found, name=name)

    def _player_voice(self, action, value):
        name = self._player_target_var.get().strip()
        if not name:
            self._player_status.config(text="Enter a player name", fg=RED)
            return
        def on_found(resp):
            result = resp.get("result", resp)
            if isinstance(result, dict) and "playerId" in result:
                pid = result["playerId"]
                def on_done(resp2):
                    r = resp2.get("result", resp2)
                    if isinstance(r, dict) and r.get("ok"):
                        self._player_status.config(text=f"{action} applied to {name}", fg=GREEN)
                    else:
                        self._player_status.config(text="Failed", fg=RED)
                self._async("player_action", on_done, player_id=pid, action=action, value=value)
            else:
                self._player_status.config(text="Player not found", fg=RED)
        self._async("get_player_by_name", on_found, name=name)

    # ── udon ──

    def _load_udon(self):
        for item in self.udon_tree.get_children():
            self.udon_tree.delete(item)

        def on_result(resp):
            result = resp.get("result", resp)
            if isinstance(result, list):
                for ub in result:
                    path = ub.get("path", ub.get("name", "?"))
                    name = ub.get("name", "?")
                    self.udon_tree.insert("", tk.END, values=(f"{path}",))

        self._async("list_udon_behaviours", on_result, limit=200)

    def _send_udon_from_tab(self):
        sel = self.udon_tree.selection()
        if not sel:
            self._udon_log_append("Select an UdonBehaviour first", tag="err")
            return
        path = self.udon_tree.item(sel[0], "values")[0]
        event = self.udon_send_var.get().strip()
        if not event:
            return

        def on_result(resp):
            result = resp.get("result", resp)
            ok = result.get("ok", False) if isinstance(result, dict) else False
            if ok:
                self._udon_log_append(f"Sent '{event}' -> {path}", tag="ok")
            else:
                err = result.get("error", str(result)) if isinstance(result, dict) else str(result)
                self._udon_log_append(f"Failed '{event}' -> {path}: {err}", tag="err")

        self._async("send_udon_event", on_result, path=path, event=event)

    def _quick_udon(self, event_name):
        self.udon_send_var.set(event_name)
        self._send_udon_from_tab()

    def _udon_log_append(self, text, tag="dim"):
        t = self.udon_log
        t.config(state=tk.NORMAL)
        t.insert(tk.END, text + "\n", tag)
        t.see(tk.END)
        t.config(state=tk.DISABLED)

    # ── udon monitor ──

    def _monitor_toggle(self):
        if self._udon_monitor_active:
            self._monitor_stop()
        else:
            self._monitor_start()

    def _monitor_start(self):
        def on_result(resp):
            result = resp.get("result", resp)
            ok = result.get("ok", False) if isinstance(result, dict) else False
            if ok:
                self._udon_monitor_active = True
                self._udon_monitor_last_ts = 0
                self._monitor_btn.configure(text="Stop Monitor")
                self._monitor_status_var.set("Recording...")
                self._monitor_poll()
            else:
                err = result.get("error", str(result)) if isinstance(result, dict) else str(result)
                self._monitor_status_var.set(f"Failed: {err}")

        self._async("start_udon_monitor", on_result)

    def _monitor_stop(self):
        self._udon_monitor_active = False
        if self._udon_monitor_job:
            self.root.after_cancel(self._udon_monitor_job)
            self._udon_monitor_job = None
        self._monitor_btn.configure(text="Start Monitor")
        self._monitor_status_var.set("Stopped")
        self._async("stop_udon_monitor", lambda r: None)

    def _monitor_poll(self):
        if not self._udon_monitor_active:
            return

        def on_result(resp):
            if not self._udon_monitor_active:
                return
            result = resp.get("result", resp)
            events = result.get("events", []) if isinstance(result, dict) else []
            if events and not self._udon_monitor_paused:
                t = self._monitor_text
                t.config(state=tk.NORMAL)
                filt = self._udon_monitor_filter.lower()
                for ev in events:
                    go = ev.get("gameObject", "?")
                    name = ev.get("event", "?")
                    ts = ev.get("timestamp", 0)
                    if filt and filt not in go.lower() and filt not in name.lower():
                        continue
                    secs = ts / 1000.0
                    mins = int(secs // 60) % 60
                    s = secs % 60
                    t.insert(tk.END, f"[{mins:02d}:{s:05.2f}] ", "ts")
                    t.insert(tk.END, f"{go}", "go")
                    t.insert(tk.END, " -> ", "dim")
                    t.insert(tk.END, f"{name}\n", "ev")
                t.see(tk.END)
                t.config(state=tk.DISABLED)
            if events:
                last = events[-1].get("timestamp", self._udon_monitor_last_ts)
                self._udon_monitor_last_ts = last
            self._udon_monitor_job = self.root.after(250, self._monitor_poll)

        self._async("get_udon_events", on_result, since=self._udon_monitor_last_ts)

    def _monitor_toggle_pause(self):
        self._udon_monitor_paused = not self._udon_monitor_paused
        if self._udon_monitor_paused:
            self._monitor_pause_btn.configure(text="Resume")
            self._monitor_status_var.set("Paused")
        else:
            self._monitor_pause_btn.configure(text="Pause")
            self._monitor_status_var.set("Recording...")

    def _monitor_clear(self):
        self._monitor_text.config(state=tk.NORMAL)
        self._monitor_text.delete("1.0", tk.END)
        self._monitor_text.config(state=tk.DISABLED)

    def _monitor_update_filter(self):
        self._udon_monitor_filter = self._monitor_filter_var.get().strip()

    # ── world ──

    def _load_world_info(self):
        def on_world(resp):
            world = resp.get("result", resp)
            def on_network(resp2):
                network = resp2.get("result", resp2)
                def on_time(resp3):
                    time_info = resp3.get("result", resp3)
                    def on_screen(resp4):
                        screen = resp4.get("result", resp4)
                        self._display_world(world, network, time_info, screen)
                    self._async("get_screen_info", on_screen)
                self._async("get_time_info", on_time)
            self._async("get_network_info", on_network)
        self._async("get_world_info", on_world)

    def _display_world(self, world, network, time_info, screen):
        t = self.world_text
        t.config(state=tk.NORMAL)
        t.delete("1.0", tk.END)

        t.insert(tk.END, "World\n", "section")
        if isinstance(world, dict):
            for k, v in world.items():
                t.insert(tk.END, f"  {k:20s} ", "key")
                t.insert(tk.END, f"{v}\n", "value")
        t.insert(tk.END, "\n")

        t.insert(tk.END, "Network\n", "section")
        if isinstance(network, dict):
            for k, v in network.items():
                t.insert(tk.END, f"  {k:20s} ", "key")
                t.insert(tk.END, f"{v}\n", "value")
        t.insert(tk.END, "\n")

        t.insert(tk.END, "Time\n", "section")
        if isinstance(time_info, dict):
            for k, v in time_info.items():
                t.insert(tk.END, f"  {k:20s} ", "key")
                t.insert(tk.END, f"{v}\n", "value")
        t.insert(tk.END, "\n")

        t.insert(tk.END, "Screen\n", "section")
        if isinstance(screen, dict):
            for k, v in screen.items():
                t.insert(tk.END, f"  {k:20s} ", "key")
                t.insert(tk.END, f"{v}\n", "value")

        t.config(state=tk.DISABLED)

    # ── console ──

    def _load_log(self):
        def on_result(resp):
            result = resp.get("result", resp)
            t = self.log_text
            t.config(state=tk.NORMAL)
            t.delete("1.0", tk.END)

            if isinstance(result, dict) and "lines" in result:
                lines = result["lines"]
            elif isinstance(result, list):
                lines = result
            elif isinstance(result, str):
                lines = result.split("\n")
            else:
                lines = [str(result)]

            for line in lines:
                if not isinstance(line, str):
                    line = str(line)
                tag = "dim"
                ll = line.lower()
                if "error" in ll or "exception" in ll:
                    tag = "error"
                elif "warn" in ll:
                    tag = "warn"
                elif "[info]" in ll or "[mcp]" in ll:
                    tag = "info"
                t.insert(tk.END, line + "\n", tag)

            t.see(tk.END)
            t.config(state=tk.DISABLED)

        self._async("read_log", on_result, lines=100)

    def _clear_log_display(self):
        self.log_text.config(state=tk.NORMAL)
        self.log_text.delete("1.0", tk.END)
        self.log_text.config(state=tk.DISABLED)

    def _send_log_msg(self):
        msg = self.log_send_var.get().strip()
        if not msg:
            return
        self.log_send_var.set("")
        self._async("send_log", lambda r: self._load_log(), message=msg)


def main():
    root = tk.Tk()
    root.tk_setPalette(background=BG, foreground=FG)

    try:
        root.iconbitmap(default="")
    except Exception:
        pass

    app = ExplorerApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
