#pragma once

#include <Core/BaseModule.hpp>
#include <deque>
#include <string>
#include <mutex>

namespace UNIx {

    enum class ToastType { Join, Leave, FriendJoin, FriendLeave, FriendOnline, FriendOffline, Info };

    class ToastModule : public BaseModule {
    public:
        ToastModule();

        void OnPlayerJoinComplete(IL2CPP::VRChat::Player player) override;
        void OnPlayerLeave(IL2CPP::VRChat::Player player) override;
        void OnUpdate() override;
        void OnSceneLoad(int scene, int loadMode) override;
        void OnSceneUnload(int scene, int loadMode) override;
        void OnSetupQuickMenu(uint32_t moduleId, uint32_t categoryPageId) override;

        void AddToast(const std::string& message, ToastType type);

        static ToastModule* s_instance;

    private:
        void FindCarousel();
        void ShowNativeNotification(const std::string& message, ToastType type);

        struct PendingToast {
            std::string message;
            ToastType type;
        };

        std::mutex m_pendingMutex;
        std::deque<PendingToast> m_queue;

        void* m_carouselComponent = nullptr;
        float m_showTimer = 0.f;
        bool m_showing = false;

        bool m_initialized = false;
        float m_initDelay = 5.f;
        float m_joinGrace = 0.f;

        static constexpr float kDisplayTime = 10.f;
        static constexpr float kJoinGracePeriod = 8.f;

        bool m_showJoins = true;
        bool m_showLeaves = true;
        bool m_showFriends = true;
        bool m_showFriendOnline = true;

        static void __cdecl QmShowJoinsCb(uint32_t, bool val);
        static void __cdecl QmShowLeavesCb(uint32_t, bool val);
        static void __cdecl QmShowFriendsCb(uint32_t, bool val);
        static void __cdecl QmShowFriendOnlineCb(uint32_t, bool val);
    };

} // namespace UNIx
