#include <Modules/Movement/RaycastTP/RaycastTPModule.hpp>
#include <Core/FileLog/FileLog.hpp>

#include <IL2CPP.Module/include/Unity/Camera.hpp>
#include <IL2CPP.Module/include/Unity/Transform.hpp>
#include <IL2CPP.Module/include/Unity/Physics.hpp>
#include <Bootstrap.Module/include/VRChat/VRCPlayerApi.hpp>

using namespace IL2CPP::Module::Unity;

namespace UNIx {

    RaycastTPModule::RaycastTPModule()
        : BaseModule("Raycast TP", "Ctrl+Del teleport to where you aim", 0, "Movement") {
        m_enabled = true;
        m_showInQuickMenu = false;
    }

    void RaycastTPModule::OnUpdate() {
        bool ctrl = (GetAsyncKeyState(VK_CONTROL) & 0x8000) != 0;
        bool delPressed = (GetAsyncKeyState(VK_DELETE) & 0x0001) != 0;
        if (!ctrl || !delPressed) return;

        auto cam = Camera::GetMain();
        if (!cam.valid()) return;

        auto camT = cam.GetTransform();
        if (!camT.valid()) return;

        IL2CPP::Vector3 origin = camT.GetPosition();
        IL2CPP::Vector3 direction = camT.GetForward();

        IL2CPP::RaycastHit hit;
        if (!Physics::Raycast(origin, direction, hit, m_maxDistance)) return;

        auto api = GetLocalPlayerApi();
        if (!api.valid()) return;

        IL2CPP::Vector3 hitPoint = hit.point;
        hitPoint.y += 0.1f;

        api.TeleportTo(hitPoint, api.GetRotation(), IL2CPP::VRChat::SpawnOrientation::Default, true);
        FLOG("[RaycastTP] Teleported to ({:.1f}, {:.1f}, {:.1f})", hitPoint.x, hitPoint.y, hitPoint.z);
    }

} // namespace UNIx
