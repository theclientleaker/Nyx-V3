#pragma once

#include <Core/BaseModule.hpp>
#include <Core/NameplateConfigManager/NameplateConfigManager.hpp>

#include <vector>
#include <string>

namespace UNIx {

    struct CustomNameplateState {
        int playerId = 0;
        std::string userId;
        void* bgImage = nullptr;
        void* borderImage = nullptr;
        void* borderObject = nullptr;
        void* originalBgSprite = nullptr;
        float origBgColor[4] = {1,1,1,1};
        bool initialized = false;
        float pendingTimer = 0.f;
        int retryCount = 0;
        uint64_t appliedConfigHash = 0;
    };

    class CustomNameplateModule : public BaseModule {
    public:
        CustomNameplateModule();

        void OnPlayerJoinComplete(IL2CPP::VRChat::Player player) override;
        void OnPlayerLeave(IL2CPP::VRChat::Player player) override;
        void OnSceneLoad(int scene, int loadMode) override;
        void OnUpdate() override;
        void OnEnable() override;
        void OnDisable() override;
        void OnRender() override;

    private:
        bool LoadTextures();
        void InitializeNameplate(CustomNameplateState& state);
        void ApplyConfig(CustomNameplateState& state, const NameplateConfig& cfg);
        void RestoreOriginal(CustomNameplateState& state);
        void CleanupState(CustomNameplateState& state);
        void CleanupAll();
        static uint64_t HashConfig(const NameplateConfig& cfg);

        std::vector<CustomNameplateState> m_states;

        void* m_bgSprite = nullptr;
        void* m_borderSprite = nullptr;
        bool m_texturesLoaded = false;
        bool m_texturesFailed = false;
        float m_globalTime = 0.f;
    };

} // namespace UNIx
