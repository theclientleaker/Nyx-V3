#pragma once
#include <Core/BaseModule.hpp>

namespace UNIx {

    class WingPlayerListModule : public BaseModule {
    public:
        WingPlayerListModule();

        void OnUpdate() override;
        void OnEnable() override;
        void OnDisable() override;
        void OnSceneLoad(int scene, int loadMode) override;
        void OnSetupQuickMenu(uint32_t moduleId, uint32_t categoryPageId) override;

        static WingPlayerListModule* s_instance;
        static void __cdecl QmFontSizeCb(uint32_t id, float val);
        static void __cdecl QmPanelWidthCb(uint32_t id, float val);
        static void __cdecl QmPanelHeightCb(uint32_t id, float val);
        static void __cdecl QmShowPlatformCb(uint32_t id, bool val);
        static void __cdecl QmShowHostCb(uint32_t id, bool val);

        void* GetPanelObject() const { return m_panelObject; }

    private:
        void InitializePanel();
        void UpdatePlayerText();
        void Cleanup();
        void SetPanelVisible(bool visible);

        bool  m_initialized = false;
        bool  m_initFailed = false;
        float m_initDelay = 5.0f;
        float m_updateTimer = 0.f;
        int   m_initRetries = 0;
        void* m_panelObject = nullptr;
        void* m_tmpComponent = nullptr;
        void* m_bgImageComp = nullptr;
        void* m_titleTmpComp = nullptr;

        float m_fontSize = 33.f;
        float m_panelWidth = 700.f;
        float m_panelHeight = 280.f;
        float m_glowTimer = 0.f;
        bool  m_showPlatform = true;
        bool  m_showHost = true;
    };

}
