#pragma once
#include <Core/BaseModule.hpp>
#include <ThirdParty/imgui/imgui.h>
#include <Bootstrap.Module/include/VRChat/APIUser.hpp>
#include <vector>
#include <mutex>

namespace UNIx {

    class BoneESPModule : public BaseModule {
    public:
        BoneESPModule() : BaseModule("Bone ESP", "Player skeleton ESP overlay", 0, "Visual") {}

        void OnOverlay() override;
        void OnUpdate() override;

    private:
        static ImU32 RankToESPColor(IL2CPP::VRChat::PlayerRank rank);

        static constexpr int kBoneCount = 21;
        static constexpr int kConnectionCount = 20;
        static const int kBoneIds[kBoneCount];
        static const int kConnections[kConnectionCount][2];

        struct BoneESPEntry {
            ImVec2 bones[kBoneCount];
            bool   visible[kBoneCount];
            ImU32  color;
        };

        std::mutex m_dataMutex;
        std::vector<BoneESPEntry> m_entries;
    };

} // namespace UNIx
