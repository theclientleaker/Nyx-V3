// VRC+ Spoof is now an auto-patch in ModuleManager::DispatchUpdate().
// This file is kept for vcxproj compatibility.
