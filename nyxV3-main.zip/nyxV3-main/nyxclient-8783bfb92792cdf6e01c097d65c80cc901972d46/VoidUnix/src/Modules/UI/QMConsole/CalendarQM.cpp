#include <Modules/UI/CalendarQM/CalendarQMModule.hpp>
#include <Core/FileLog/FileLog.hpp>
#include <Core/DashboardConsole/DashboardConsole.hpp>
#include <Core/SpriteLoader/SpriteLoader.hpp>
#include "resource.h"

#include <IL2CPP.Module/include/il2cpp_module.hpp>
#include <IL2CPP.Module/include/Unity/GameObject.hpp>
#include <IL2CPP.Module/include/Unity/Transform.hpp>
#include <IL2CPP.Module/include/Unity/RectTransform.hpp>
#include <IL2CPP.Module/include/Unity/TMP_Text.hpp>
#include <IL2CPP.Module/include/Unity/Object.hpp>
#include <IL2CPP.Module/include/Unity/Component.hpp>
#include <IL2CPP.Module/include/Reflection.hpp>
#include <IL2CPP.Module/include/MethodHandler.hpp>

namespace UNIx {

    using namespace IL2CPP::Module;
    using namespace IL2CPP::Module::Unity;

    // ---------------------------------------------------------------------------
    CalendarQMModule::ConsoleTab CalendarQMModule::CategorizeEntry(const std::string& text) {
        if (text.find("[NYX]: ") == 0) {
            if (text.find(" joined") != std::string::npos ||
                text.find(" left") != std::string::npos ||
                text.find("Joined as ") != std::string::npos)
                return ConsoleTab::PlayerEvents;
        }
        if (text.find("[Fish]") == 0 ||
            text.find("[Udon]") == 0 ||
            text.find("Udon") != std::string::npos ||
            text.find("udon") != std::string::npos)
            return ConsoleTab::Udon;
        return ConsoleTab::Functions;
    }

    // ---------------------------------------------------------------------------
    void CalendarQMModule::StripCalendarPage() {
        if (m_stripped) return;

        auto calendarGO = GameObject::Find("Menu_MM_Calendar(Clone)");
        if (!calendarGO.IsValid()) return;

        auto calendarT = calendarGO.GetTransform();
        if (!calendarT.valid()) return;

        for (int i = calendarT.GetChildCount() - 1; i >= 0; --i) {
            auto childT = calendarT.GetChild(i);
            if (childT.valid()) {
                auto childGO = childT.GetGameObject();
                if (childGO.valid()) childGO.Destroy();
            }
        }

        m_stripped = true;
        FLOG("[CalendarQM] Menu_MM_Calendar(Clone) stripped");
    }

    // ---------------------------------------------------------------------------
    static void* FindTMPTemplate() {
        auto qmCanvas = GameObject::Find("Canvas_QuickMenu(Clone)");
        if (!qmCanvas.IsValid()) return nullptr;

        auto canvasT = qmCanvas.GetTransform();
        auto qmParentT = canvasT.Find("CanvasGroup/Container/Window/QMParent");
        if (!qmParentT.valid()) return nullptr;

        auto launchpadT = qmParentT.Find("Body/Menu_QM_Launchpad");
        if (!launchpadT.valid()) launchpadT = qmParentT;

        auto launchpadGO = launchpadT.GetGameObject();
        if (!launchpadGO.valid()) return nullptr;

        auto tmpClass = Class::find("TMPro.TextMeshProUGUI");
        if (!tmpClass) return nullptr;

        auto templateComp = launchpadGO.GetComponentInChildren(tmpClass, true);
        if (!templateComp.valid()) return nullptr;

        static auto getGameObject = MethodHandler::resolve("UnityEngine.Component", "get_gameObject", 0);
        return MethodHandler::invoke<void*>(getGameObject, templateComp.raw());
    }

    // ---------------------------------------------------------------------------
    static GameObject CloneAndStrip(void* templateGORaw, const std::string& name) {
        GameObject templateGO(templateGORaw);
        auto clone = templateGO.Instantiate();
        if (!clone.raw() || !clone.IsValid()) return GameObject{};

        GameObject go(clone.raw());
        go.SetName(name);
        go.SetActive(true);

        auto t = go.GetTransform();
        for (int i = t.GetChildCount() - 1; i >= 0; --i) {
            auto childT = t.GetChild(i);
            if (childT.valid()) {
                auto childGO = childT.GetGameObject();
                if (childGO.valid()) childGO.Destroy();
            }
        }
        return go;
    }

    // ---------------------------------------------------------------------------
    void CalendarQMModule::CreateTabs() {
        if (m_tabsCreated) {
            if (m_tabBtnObjects[0]) {
                GameObject go(m_tabBtnObjects[0]);
                if (go.IsValid()) return;
            }
            for (int i = 0; i < 3; i++) {
                m_tabBtnObjects[i] = nullptr;
                m_tabTmpRaws[i] = nullptr;
            }
            m_tabsCreated = false;
        }

        auto calendarGO = GameObject::Find("Menu_MM_Calendar(Clone)");
        if (!calendarGO.IsValid()) return;
        auto calendarT = calendarGO.GetTransform();
        if (!calendarT.valid()) return;

        void* templateGORaw = FindTMPTemplate();
        if (!templateGORaw) return;

        static auto setRaycastTarget = MethodHandler::resolve("UnityEngine.UI.Graphic", "set_raycastTarget", 1);

        const char* tabNames[3] = { "Player Activity", "UDON", "Functions" };

        for (int i = 0; i < 3; i++) {
            auto tabGO = CloneAndStrip(templateGORaw, std::string("nyx_Tab_") + std::to_string(i));
            if (!tabGO.raw()) continue;

            auto tabT = tabGO.GetTransform();
            tabT.SetParent(calendarT, false);

            float xMin = i / 3.f;
            float xMax = (i + 1) / 3.f;
            RectTransform rt(tabT.raw());
            rt.SetAnchorMin({ xMin, 1.f });
            rt.SetAnchorMax({ xMax, 1.f });
            rt.SetPivot({ 0.5f, 1.f });
            rt.SetAnchoredPosition({ 0.f, 0.f });
            rt.SetSizeDelta({ 0.f, 55.f });

            auto tmpComp = tabGO.GetComponentByName("TMPro.TextMeshProUGUI");
            if (!tmpComp.valid()) continue;

            m_tabTmpRaws[i] = tmpComp.raw();
            m_tabBtnObjects[i] = tabGO.raw();

            TMP_Text tmp(tmpComp.raw());
            tmp.SetRichText(true);
            tmp.SetFontSize(26.f);
            tmp.SetAlignment(514);  // MiddleCenter
            tmp.SetEnableWordWrapping(false);
            tmp.SetColor({ 1.f, 1.f, 1.f, 1.f });
            tmp.SetText(std::string(tabNames[i]));

            if (setRaycastTarget) {
                bool val = false;
                void* rtP[] = { &val };
                MethodHandler::invoke(setRaycastTarget, tmpComp.raw(), rtP);
            }
        }

        m_tabsCreated = true;
        FLOG("[CalendarQM] Tab labels created");
    }

    // ---------------------------------------------------------------------------
    void CalendarQMModule::CreateConsoleTexts() {
        if (m_textsCreated) {
            if (m_textObjects[0]) {
                GameObject go(m_textObjects[0]);
                if (go.IsValid()) return;
            }
            for (int i = 0; i < 3; i++) {
                m_textObjects[i] = nullptr;
                m_tmpRaws[i] = nullptr;
            }
            m_textsCreated = false;
        }

        auto calendarGO = GameObject::Find("Menu_MM_Calendar(Clone)");
        if (!calendarGO.IsValid()) return;
        auto calendarT = calendarGO.GetTransform();
        if (!calendarT.valid()) return;

        void* templateGORaw = FindTMPTemplate();
        if (!templateGORaw) return;

        static auto setRaycastTarget = MethodHandler::resolve("UnityEngine.UI.Graphic", "set_raycastTarget", 1);

        for (int i = 0; i < 3; i++) {
            auto textGO = CloneAndStrip(templateGORaw, std::string("nyx_Console_") + std::to_string(i));
            if (!textGO.raw()) continue;

            auto cloneT = textGO.GetTransform();
            cloneT.SetParent(calendarT, false);

            // Each column takes 1/3 width, below the tab labels
            float xMin = i / 3.f;
            float xMax = (i + 1) / 3.f;
            RectTransform rt(cloneT.raw());
            rt.SetAnchorMin({ xMin, 0.f });
            rt.SetAnchorMax({ xMax, 1.f });
            rt.SetPivot({ 0.f, 1.f });
            rt.SetAnchoredPosition({ 10.f, -60.f });   // below tabs
            rt.SetSizeDelta({ -20.f, -70.f });

            auto tmpComp = textGO.GetComponentByName("TMPro.TextMeshProUGUI");
            if (!tmpComp.valid()) { textGO.Destroy(); continue; }

            TMP_Text tmp(tmpComp.raw());
            tmp.SetRichText(true);
            tmp.SetFontSize(16.f);
            tmp.SetEnableWordWrapping(true);
            tmp.SetAlignment(257);  // TopLeft
            tmp.SetColor({ 1.f, 1.f, 1.f, 1.f });

            if (setRaycastTarget) {
                bool val = false;
                void* rtP[] = { &val };
                MethodHandler::invoke(setRaycastTarget, tmpComp.raw(), rtP);
            }

            m_textObjects[i] = textGO.raw();
            m_tmpRaws[i] = tmpComp.raw();
        }

        m_textsCreated = true;
        FLOG("[CalendarQM] Console columns created");
    }

    // ---------------------------------------------------------------------------
    std::string CalendarQMModule::BuildRichText(ConsoleTab filter) {
        auto& console = DashboardConsole::Get();
        auto& lines = console.GetLines();

        std::string result;

        for (auto& entry : lines) {
            if (CategorizeEntry(entry.text) != filter)
                continue;

            result += "<color=#888888>[" + entry.timestamp + "]</color> ";

            const char* hex = "D9D9E6";
            switch (entry.color) {
            case DashboardConsole::LogColor::System:   hex = "8C28E1"; break;
            case DashboardConsole::LogColor::Enabled:  hex = "2BCF5C"; break;
            case DashboardConsole::LogColor::Disabled: hex = "F87070"; break;
            default: break;
            }

            result += "<color=#";
            result += hex;
            result += ">";
            result += entry.text;
            result += "</color>\n";
        }
        return result;
    }

    // ---------------------------------------------------------------------------
    void CalendarQMModule::UpdateConsoleTexts() {
        auto& console = DashboardConsole::Get();
        size_t currentCount = console.GetLineCount();

        if (currentCount == m_lastLineCount) return;
        m_lastLineCount = currentCount;

        for (int i = 0; i < 3; i++) {
            if (!m_tmpRaws[i]) continue;
            Object chk(m_tmpRaws[i]);
            if (!chk.IsValid()) { m_tmpRaws[i] = nullptr; continue; }
            TMP_Text tmp(m_tmpRaws[i]);
            tmp.SetText(BuildRichText(static_cast<ConsoleTab>(i)));
        }
    }

    // ---------------------------------------------------------------------------
    // Just set_sprite on the existing ImageEx. Simplest possible — no clone, no destroy.
    static bool SwapIconSprite(Transform rootT, const char* pathToBtn, void* termSprite) {
        auto btnT = rootT.Find(pathToBtn);
        if (!btnT.valid()) return false;

        auto iconT = btnT.Find("Icon");
        if (!iconT.valid()) return false;

        auto iconGO = iconT.GetGameObject();
        if (!iconGO.valid() || !iconGO.IsValid()) return false;

        // Get the ImageEx (or Image) on Icon
        auto imageExClass = Class::find("VRC.UI.ImageEx");
        auto imageClass = Class::find("UnityEngine.UI.Image");

        Component imageComp;
        if (imageExClass) imageComp = iconGO.GetComponent(imageExClass);
        if (!imageComp.valid() && imageClass) imageComp = iconGO.GetComponent(imageClass);
        if (!imageComp.valid()) return false;

        static auto setSprite = MethodHandler::resolve("UnityEngine.UI.Image", "set_sprite", 1);
        static auto setType = MethodHandler::resolve("UnityEngine.UI.Image", "set_type", 1);
        if (!setSprite) return false;

        void* sprP[] = { termSprite };
        MethodHandler::invoke(setSprite, imageComp.raw(), sprP);

        if (setType) {
            int simple = 0;
            void* typeP[] = { &simple };
            MethodHandler::invoke(setType, imageComp.raw(), typeP);
        }

        return true;
    }

    // ---------------------------------------------------------------------------
    void CalendarQMModule::SwapCalendarIcons() {
        if (m_qmIconSwapped && m_mmIconSwapped) return;

        auto& sprites = SpriteLoader::Get();
        void* termSprite = sprites.LoadFromResource(IDR_ICON_TERMINAL, "console_btn_terminal");
        if (!termSprite) return;

        // QM LaunchPad calendar icon
        if (!m_qmIconSwapped) {
            auto qmCanvas = GameObject::Find("Canvas_QuickMenu(Clone)");
            if (qmCanvas.IsValid()) {
                auto qmT = qmCanvas.GetTransform();
                if (SwapIconSprite(qmT,
                    "CanvasGroup/Container/Window/QMParent/Body/Menu_QM_Launchpad/Header_H1/RightItemContainer/Button_QM_Calendar",
                    termSprite)) {
                    m_qmIconSwapped = true;
                    FLOG("[CalendarQM] Swapped QM calendar icon");
                }
            }
        }

        // Main Menu calendar icon
        if (!m_mmIconSwapped) {
            auto mmCanvas = GameObject::Find("Canvas_MainMenu(Clone)");
            if (mmCanvas.IsValid()) {
                auto mmT = mmCanvas.GetTransform();
                if (SwapIconSprite(mmT,
                    "Container/MMParent/Panel_MM_Header/Content/HeaderRight/Button_Calendar",
                    termSprite)) {
                    m_mmIconSwapped = true;
                    FLOG("[CalendarQM] Swapped MM calendar icon");
                }
            }
        }
    }

    // ---------------------------------------------------------------------------
    void CalendarQMModule::OnUpdate() {
        StripCalendarPage();

        if (m_stripped) {
            SwapCalendarIcons();
            CreateTabs();
            CreateConsoleTexts();
            UpdateConsoleTexts();
        }
    }

    // ---------------------------------------------------------------------------
    void CalendarQMModule::OnSceneLoad(int, int loadMode) {
        if (loadMode == 0) {
            m_stripped = false;
            m_tabsCreated = false;
            m_textsCreated = false;
            m_qmIconSwapped = false;
            m_mmIconSwapped = false;
            m_lastLineCount = 0;
            for (int i = 0; i < 3; i++) {
                m_tabBtnObjects[i] = nullptr;
                m_tabTmpRaws[i] = nullptr;
                m_textObjects[i] = nullptr;
                m_tmpRaws[i] = nullptr;
            }
        }
    }

} // namespace UNIx