#pragma once

#include <Core/BaseModule.hpp>
#include <IL2CPP.Module/include/Reflection.hpp>
#include <IL2CPP.Module/include/ManagedObject.hpp>

#include <vector>
#include <string>
#include <mutex>
#include <atomic>
#include <memory>

namespace UNIx {

    class UnityExplorerModule : public BaseModule {
    public:
        UnityExplorerModule();

        void OnUpdate() override;
        void OnOverlay() override;
        void OnRender() override;
        bool OnEvent(uint32_t msg, uintptr_t wParam, intptr_t lParam) override;
        void OnSceneLoad(int scene, int loadMode) override;
        void OnSceneUnload(int scene, int loadMode) override;
        void OnEnable() override;
        void OnDisable() override;

    private:
        // ===== Data Structures =====

        struct SceneNode {
            void* gameObject = nullptr;
            void* transform  = nullptr;
            std::string name;
            bool  activeSelf       = true;
            bool  activeInHierarchy = true;
            int   childCount       = 0;
            std::vector<SceneNode> children;
        };

        struct ComponentEntry {
            void*       raw         = nullptr;
            std::string typeName;
            bool        enabled     = true;
            bool        isBehaviour = false;
        };

        struct FieldEntry {
            std::string name;
            std::string typeName;
            std::string value;
            int    offset     = 0;
            bool   isStatic   = false;
            bool   isReadonly = false;
        };

        struct PropertyEntry {
            std::string name;
            std::string typeName;
            std::string value;
            bool hasGetter = false;
            bool hasSetter = false;
        };

        struct MethodEntry {
            std::string name;
            std::string returnType;
            std::string paramSig;
            int  paramCount = 0;
            bool isStatic   = false;
        };

        struct SearchResult {
            void*       gameObject = nullptr;
            std::string name;
            std::string path;
        };

        struct SceneLightEntry {
            void*       lightPtr    = nullptr;
            void*       goPtr       = nullptr;
            std::string name;
            int         type        = 0;   // 0=Spot, 1=Directional, 2=Point, 3=Area
            float       intensity   = 1.0f;
            float       range       = 10.0f;
            float       spotAngle   = 30.0f;
            float       color[3]    = {};
            bool        enabled     = true;
        };

        // ===== Navbar & Panel Rendering =====
        void RenderNavbar();
        void RenderScenePanel();
        void RenderInspectorPanel();
        void RenderSearchPanel();
        void RenderFreeCamPanel();
        void RenderLightsPanel();
        void RenderMiscPanel();

        // ===== Scene Browser =====
        void RefreshSceneTree();
        void BuildNode(SceneNode& out, void* transformPtr, int depth);
        void RenderSceneNode(SceneNode& node);

        // ===== Inspector =====
        enum class InspectorMode { None, GameObject, Component };

        void RefreshGameObjectData(void* goPtr);
        void RefreshComponentReflection(void* compPtr);
        void RenderGameObjectView();
        void RenderComponentView();
        std::string ReadFieldValue(void* obj, const IL2CPP::Module::Field& field);
        std::string ReadPropertyValue(void* obj, const IL2CPP::Module::Property& prop);

        // ===== Search =====
        void ExecuteSearch();
        void SearchSceneTree(const SceneNode& node, const std::string& queryLower,
                             std::vector<SearchResult>& results, int maxResults);
        void SearchSceneTreeImpl(const SceneNode& node, const std::string& queryLower,
                                 const std::string& parentPath,
                                 std::vector<SearchResult>& results, int maxResults);

        // ===== Bookmarks =====
        struct Bookmark {
            void*       gameObject = nullptr;
            std::string name;
            std::string path;
        };

        // ===== FreeCam =====
        void UpdateFreeCam();

        // ===== Mouse Inspect =====
        void DoMouseInspect();
        void DoMouseInspectWorld();
        void DoMouseInspectUI();
        void RenderMouseResultsPanel();

        // ===== TimeScale =====
        void ApplyTimeScale();

        // ===== Lights =====
        void RefreshSceneLights();

        // ===== Misc =====
        void ToggleHUD();
        void TeleportToSelected();
        void RenderBookmarksPanel();

        // ===== History =====
        struct HistoryEntry {
            InspectorMode mode = InspectorMode::None;
            void* target = nullptr;
        };
        void PushHistory(InspectorMode mode, void* target);
        void NavigateBack();
        void NavigateForward();

        // ===== Shared State (protected by m_mutex) =====
        std::mutex m_mutex;

        // Scene tree — shared_ptr so render thread can hold a ref while Unity thread swaps
        std::shared_ptr<std::vector<SceneNode>> m_sceneRoots = std::make_shared<std::vector<SceneNode>>();
        int m_nodeCount = 0;

        // Inspector — selected GO
        InspectorMode m_inspectorMode = InspectorMode::None;
        void*       m_selectedGO   = nullptr;
        std::string m_goName;
        bool        m_goActive     = true;
        unsigned int m_goLayer     = 0;
        std::string m_goTag;
        std::string m_goPath;
        std::string m_goScene;
        int         m_goInstanceId = 0;
        void*       m_goParentTransform = nullptr;
        float       m_position[3]  = {};
        float       m_rotation[3]  = {};
        float       m_scale[3]     = {};
        std::vector<ComponentEntry> m_components;

        // Inspector — children list
        struct ChildEntry {
            void*       gameObject = nullptr;
            std::string name;
            bool        active = true;
        };
        std::vector<ChildEntry> m_children;

        // Inspector — selected component
        void*       m_selectedComponent = nullptr;
        std::string m_selectedComponentType;
        std::vector<FieldEntry>    m_fields;
        std::vector<PropertyEntry> m_properties;
        std::vector<MethodEntry>   m_methods;

        // Search
        char m_searchBuf[256] = {};
        int  m_searchMode = 0; // 0=Name, 1=Type
        std::vector<SearchResult> m_searchResults;

        // ===== Request Flags =====
        std::atomic<bool> m_needsSceneRefresh{true};
        void*  m_pendingSelectGO        = nullptr;
        void*  m_pendingSelectComponent = nullptr;
        bool   m_needsSearch            = false;
        std::string m_pendingSearchQuery;
        int    m_pendingSearchMode      = 0;

        // Inspector edit requests (render -> unity thread)
        bool   m_pendingSetActive       = false;
        bool   m_pendingActiveValue     = true;
        bool   m_pendingDestroyGO       = false;
        bool   m_pendingDestroyComp     = false;
        void*  m_pendingDestroyTarget   = nullptr;
        bool   m_pendingTransformEdit   = false;
        float  m_pendingPos[3]          = {};
        float  m_pendingRot[3]          = {};
        float  m_pendingScl[3]          = {};
        bool   m_pendingCompToggle      = false;
        void*  m_pendingCompToggleTarget = nullptr;
        bool   m_pendingCompToggleValue = true;
        bool   m_pendingViewParent      = false;

        // ===== Panel Visibility =====
        bool m_showScenePanel    = true;
        bool m_showInspectorPanel = false;
        bool m_showSearchPanel   = false;
        bool m_showFreeCamPanel  = false;
        bool m_showLightsPanel   = false;
        bool m_showMiscPanel     = false;

        // ===== TimeScale =====
        float m_timeScale     = 1.0f;
        bool  m_gamePaused    = false;
        float m_prevTimeScale = 1.0f;

        // ===== FreeCam State =====
        bool   m_freeCamActive      = false;
        float  m_freeCamSpeed       = 5.0f;
        float  m_freeCamSensitivity = 2.0f;
        float  m_camPos[3]          = {};
        float  m_camEuler[3]        = {};   // pitch, yaw, roll
        bool   m_freeCamKeys[6]     = {};   // W, A, S, D, Q, E
        float  m_lastMouseX = 0, m_lastMouseY = 0;
        bool   m_freeCamMouseHeld   = false;
        float  m_freeCamFOV         = 60.0f;
        float  m_origFOV            = 60.0f;
        float  m_nearClip           = 0.01f;
        float  m_farClip            = 1000.0f;
        bool   m_fovKeys[2]        = {};  // increase, decrease
        bool   m_shiftHeld         = false;
        bool   m_ctrlHeld          = false;

        // ===== Mouse Inspector =====
        bool  m_mouseInspectActive     = false;
        bool  m_mouseInspectPending    = false;
        float m_mouseInspectX = 0, m_mouseInspectY = 0;
        int   m_mouseInspectMode       = 0;  // 0=World, 1=UI

        // Mouse inspect results panel
        struct MouseHitResult {
            void*       goPtr = nullptr;
            std::string name;
            std::string path;
        };
        std::vector<MouseHitResult> m_mouseHitResults;
        bool m_showMouseResults = false;

        // ===== Lights =====
        std::vector<SceneLightEntry> m_sceneLights;
        bool m_needsLightRefresh = true;

        // ===== Bookmarks =====
        std::vector<Bookmark> m_bookmarks;
        bool m_showBookmarksPanel = false;

        // ===== Teleport =====
        bool m_pendingTeleport = false;

        // ===== Hierarchy Dump =====
        bool m_pendingDumpHierarchy = false;
        bool m_showDumpPopup        = false;
        bool m_dumpComponents       = true;
        bool m_dumpEnabledState     = true;
        bool m_dumpInactiveObjects  = true;
        bool m_dumpFullPaths        = true;
        int  m_dumpMaxDepth         = 50;
        void DumpHierarchyToFile();
        void RenderDumpPopup();

        // ===== Go-to-path =====
        char m_goToPathBuf[512] = {};

        // ===== Auto-navigate to _Application root =====
        bool  m_autoNavigatedToApp = false;
        float m_appSearchTimer     = 0.f;
        int   m_appSearchRetries   = 0;

        // ===== Auto-refresh =====
        bool  m_autoRefreshInspector = false;
        float m_autoRefreshTimer     = 0.f;

        // ===== Misc =====
        bool m_hudHidden   = false;
        bool m_forceLOD    = false;

        // ===== UI State (render thread only) =====
        int  m_inspectorFilter   = 0; // 0=All,1=Fields,2=Props,3=Methods
        bool m_showInactive      = true;
        bool m_showStaticMembers = false;
        bool m_switchToInspector = false;

        // ===== Theme =====
        int  m_themeIndex = 0; // 0=Obsidian,1=Nord,2=Monokai,3=Solarized,4=Cyberpunk,5=Dracula,6=Gruvbox,7=TokyoNight,8=Catppuccin,9=Synthwave,10=RosePine,11=Abyss

        // ===== History =====
        std::vector<HistoryEntry> m_history;
        int m_historyIdx = -1;

        static constexpr int   kMaxDepth     = 20;
        static constexpr int   kMaxNodes     = 10000;
        static constexpr float kNavbarHeight = 35.0f;
    };

} // namespace UNIx
