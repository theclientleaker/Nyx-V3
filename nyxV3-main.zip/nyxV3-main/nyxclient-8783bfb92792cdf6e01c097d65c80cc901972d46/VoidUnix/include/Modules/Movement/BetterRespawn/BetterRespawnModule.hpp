#pragma once

#include <Core/BaseModule.hpp>
#include <string>
#include <unordered_map>

namespace UNIx {

    class BetterRespawnModule : public BaseModule {
    public:
        BetterRespawnModule();

        void OnUpdate() override;
        void OnSceneLoad(int scene, int loadMode) override;
        void OnRender() override;
        void OnEnable() override;
        void OnDisable() override;

    private:
        void SavePositions();
        void LoadPositions();
        std::string GetCurrentWorldId();

        struct SavedTransform {
            IL2CPP::Vector3 position = { 0.f, 0.f, 0.f };
            IL2CPP::Quaternion rotation = { 0.f, 0.f, 0.f, 1.f };
        };

        std::unordered_map<std::string, SavedTransform> m_saved;
        std::string m_currentWorldId;
        bool m_loaded = false;
        bool m_pendingRestore = false;
        float m_restoreDelay = 0.f;
        float m_saveTimer = 0.f;

        static constexpr float kSaveInterval = 3.f;
        static constexpr float kRestoreDelay = 8.f;
        static constexpr const char* kSavePath = "C:\\nyx\\Config\\better_respawn.txt";
    };

} // namespace UNIx
